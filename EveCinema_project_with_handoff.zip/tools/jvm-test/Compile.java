import javax.tools.*;
import java.io.File;
import java.util.*;
/** javac is not installed as a binary here, but the jdk.compiler module is: drive it through javax.tools. */
public class Compile {
    public static void main(String[] a) throws Exception {
        JavaCompiler c = ToolProvider.getSystemJavaCompiler();
        if (c == null) { System.err.println("no system compiler"); System.exit(2); }
        List<String> opts = new ArrayList<>(); List<File> files = new ArrayList<>();
        for (int i = 0; i < a.length; i++) { if (a[i].startsWith("-")) { opts.add(a[i]); if (i + 1 < a.length && !a[i+1].endsWith(".java")) opts.add(a[++i]); } else files.add(new File(a[i])); }
        StandardJavaFileManager fm = c.getStandardFileManager(null, null, java.nio.charset.StandardCharsets.UTF_8);
        boolean ok = c.getTask(null, fm, null, opts, null, fm.getJavaFileObjectsFromFiles(files)).call();
        System.exit(ok ? 0 : 1);
    }
}
