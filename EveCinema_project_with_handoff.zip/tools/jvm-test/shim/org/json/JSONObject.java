package org.json;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
/** TEST-ONLY shim: minimal stand-in for org.json.JSONObject (semantics follow org.json's opt* family). */
public class JSONObject {
    public static final Object NULL = new Object() { @Override public String toString() { return "null"; } };
    final Map<String, Object> map = new LinkedHashMap<>();
    public JSONObject() {}
    public JSONObject(String src) throws JSONException {
        Object o = new Parser(src).parseValue();
        if (!(o instanceof JSONObject)) throw new JSONException("not an object");
        map.putAll(((JSONObject) o).map);
    }
    public boolean has(String k) { return map.containsKey(k); }
    public Object opt(String k) { return map.get(k); }
    public JSONObject put(String k, Object v) throws JSONException { if (v == null) map.remove(k); else map.put(k, v); return this; }
    public JSONObject put(String k, int v) throws JSONException { map.put(k, v); return this; }
    public JSONObject put(String k, long v) throws JSONException { map.put(k, v); return this; }
    public JSONObject put(String k, boolean v) throws JSONException { map.put(k, v); return this; }
    public Iterator<String> keys() { return map.keySet().iterator(); }
    public int length() { return map.size(); }
    public JSONObject optJSONObject(String k) { Object o = map.get(k); return o instanceof JSONObject ? (JSONObject) o : null; }
    public JSONArray optJSONArray(String k) { Object o = map.get(k); return o instanceof JSONArray ? (JSONArray) o : null; }
    public String optString(String k) { return optString(k, ""); }
    public String optString(String k, String d) {
        Object o = map.get(k);
        if (o == null || o == NULL) return d;
        return o.toString();
    }
    public boolean optBoolean(String k) { return optBoolean(k, false); }
    public boolean optBoolean(String k, boolean d) {
        Object o = map.get(k);
        if (o instanceof Boolean) return (Boolean) o;
        if (o instanceof String) { String s = (String) o; if (s.equalsIgnoreCase("true")) return true; if (s.equalsIgnoreCase("false")) return false; }
        return d;
    }
    public int optInt(String k) { return optInt(k, 0); }
    public int optInt(String k, int d) {
        Object o = map.get(k);
        if (o instanceof Number) return ((Number) o).intValue();
        if (o instanceof String) { try { return (int) Double.parseDouble(((String) o).trim()); } catch (Exception e) { return d; } }
        return d;
    }
    public long optLong(String k) { return optLong(k, 0L); }
    public long optLong(String k, long d) {
        Object o = map.get(k);
        if (o instanceof Number) return ((Number) o).longValue();
        if (o instanceof String) { try { return Long.parseLong(((String) o).trim()); } catch (Exception e) { try { return (long) Double.parseDouble(((String) o).trim()); } catch (Exception e2) { return d; } } }
        return d;
    }
    static String render(Object v) {
        if (v == null || v == NULL) return "null";
        if (v instanceof String) return "\"" + ((String) v).replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
        return v.toString();
    }
    @Override public String toString() {
        StringBuilder sb = new StringBuilder("{"); boolean first = true;
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (!first) sb.append(','); first = false;
            sb.append(render(e.getKey())).append(':').append(render(e.getValue()));
        }
        return sb.append('}').toString();
    }
}
