package org.json;
/** TEST-ONLY shim: minimal stand-in for org.json (no real org.json jar in this sandbox). */
public class JSONException extends Exception {
    public JSONException(String m) { super(m); }
}
