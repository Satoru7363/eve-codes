package org.json;
import java.util.ArrayList;
import java.util.List;
/** TEST-ONLY shim: minimal stand-in for org.json.JSONArray. */
public class JSONArray {
    final List<Object> list = new ArrayList<>();
    public JSONArray() {}
    public JSONArray(String src) throws JSONException {
        Object o = new Parser(src).parseValue();
        if (!(o instanceof JSONArray)) throw new JSONException("not an array");
        list.addAll(((JSONArray) o).list);
    }
    public int length() { return list.size(); }
    public JSONArray put(Object o) { list.add(o); return this; }
    public JSONArray put(int v) { list.add(v); return this; }
    public Object opt(int i) { return i >= 0 && i < list.size() ? list.get(i) : null; }
    public JSONObject optJSONObject(int i) { Object o = opt(i); return o instanceof JSONObject ? (JSONObject) o : null; }
    public JSONArray optJSONArray(int i) { Object o = opt(i); return o instanceof JSONArray ? (JSONArray) o : null; }
    public int optInt(int i) { return optInt(i, 0); }
    public int optInt(int i, int d) { Object o = opt(i); if (o instanceof Number) return ((Number) o).intValue(); if (o instanceof String) { try { return (int) Double.parseDouble(((String) o).trim()); } catch (Exception e) { return d; } } return d; }
    public String optString(int i) { Object o = opt(i); return o == null || o == JSONObject.NULL ? "" : o.toString(); }
    @Override public String toString() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) { if (i > 0) sb.append(','); sb.append(JSONObject.render(list.get(i))); }
        return sb.append(']').toString();
    }
}
