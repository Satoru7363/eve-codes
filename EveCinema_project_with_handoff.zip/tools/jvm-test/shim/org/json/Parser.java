package org.json;
/** TEST-ONLY shim: tiny strict JSON parser. */
final class Parser {
    private final String s; private int i;
    Parser(String s) { this.s = s; }
    Object parseValue() throws JSONException {
        ws(); if (i >= s.length()) throw new JSONException("eof");
        char c = s.charAt(i);
        if (c == '{') return obj();
        if (c == '[') return arr();
        if (c == '"') return str();
        if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
        if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
        if (s.startsWith("null", i)) { i += 4; return JSONObject.NULL; }
        return num();
    }
    private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
    private JSONObject obj() throws JSONException {
        JSONObject o = new JSONObject(); i++; ws();
        if (s.charAt(i) == '}') { i++; return o; }
        while (true) {
            ws(); String k = str(); ws();
            if (s.charAt(i++) != ':') throw new JSONException("colon at " + i);
            o.map.put(k, parseValue()); ws();
            char c = s.charAt(i++);
            if (c == '}') return o;
            if (c != ',') throw new JSONException("comma at " + i);
        }
    }
    private JSONArray arr() throws JSONException {
        JSONArray a = new JSONArray(); i++; ws();
        if (s.charAt(i) == ']') { i++; return a; }
        while (true) {
            a.list.add(parseValue()); ws();
            char c = s.charAt(i++);
            if (c == ']') return a;
            if (c != ',') throw new JSONException("comma at " + i);
        }
    }
    private String str() throws JSONException {
        if (s.charAt(i) != '"') throw new JSONException("string at " + i);
        i++; StringBuilder sb = new StringBuilder();
        while (true) {
            char c = s.charAt(i++);
            if (c == '"') return sb.toString();
            if (c == '\\') {
                char e = s.charAt(i++);
                switch (e) {
                    case 'n': sb.append('\n'); break; case 't': sb.append('\t'); break; case 'r': sb.append('\r'); break;
                    case 'b': sb.append('\b'); break; case 'f': sb.append('\f'); break;
                    case 'u': sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break;
                    default: sb.append(e);
                }
            } else sb.append(c);
        }
    }
    private Object num() throws JSONException {
        int st = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        String t = s.substring(st, i);
        if (t.isEmpty()) throw new JSONException("bad token at " + st);
        try {
            if (t.contains(".") || t.contains("e") || t.contains("E")) return Double.valueOf(t);
            long l = Long.parseLong(t);
            return (l >= Integer.MIN_VALUE && l <= Integer.MAX_VALUE) ? (Object) Integer.valueOf((int) l) : (Object) Long.valueOf(l);
        } catch (NumberFormatException e) { throw new JSONException("bad number " + t); }
    }
}
