#!/usr/bin/env bash
# Runs the project's pure-Java unit tests + Python wiring tests WITHOUT Gradle/Android.
#
#   bash tools/jvm-test/run_jvm_tests.sh            # everything
#   bash tools/jvm-test/run_jvm_tests.sh MovieBoxDubClassificationTest   # one Java test class
#
# Needs only a JDK/JRE >= 11 that contains the jdk.compiler module (a JRE with no `javac` binary is
# fine: Compile.java drives the compiler through javax.tools). org.json is NOT in a plain JDK, so a
# TEST-ONLY shim (tools/jvm-test/shim) is compiled unless you point ORG_JSON_JAR at a real org.json jar.
# Only classes reachable from the tests are compiled (-sourcepath), so Android-only classes are never
# touched: new logic that must be tested here has to stay free of android.* imports.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
MAIN="$ROOT/main"
BUILD="${BUILD_DIR:-$ROOT/build/jvm-test}"
mkdir -p "$BUILD/classes" "$BUILD/shim" "$BUILD/reports"

jc() { if command -v javac >/dev/null 2>&1; then javac "$@"; else java "$HERE/Compile.java" "$@"; fi; }

if [ -n "${ORG_JSON_JAR:-}" ]; then JSON_CP="$ORG_JSON_JAR"; JSON_NOTE="real org.json jar ($ORG_JSON_JAR)"
else
  jc -encoding UTF-8 -d "$BUILD/shim" "$HERE"/shim/org/json/*.java || { echo "shim compile failed"; exit 2; }
  JSON_CP="$BUILD/shim"; JSON_NOTE="TEST-ONLY org.json shim (not Android's org.json)"
fi
echo "org.json: $JSON_NOTE"

if [ $# -gt 0 ]; then TESTS=("$@"); else
  TESTS=(); while IFS= read -r f; do TESTS+=("$(basename "$f" .java)"); done < <(find "$MAIN/tests/java" -name '*Test.java' -o -name '*Suite.java' | sort)
fi

FAIL=0; TOTAL=0
for t in "${TESTS[@]}"; do
  src="$(find "$MAIN/tests/java" -name "$t.java" | head -1)"
  [ -z "$src" ] && { echo "!! test not found: $t"; FAIL=1; continue; }
  pkg="$(grep -m1 '^package ' "$src" | sed 's/package \(.*\);/\1/')"
  out="$BUILD/classes/$t"; rm -rf "$out"; mkdir -p "$out"
  if ! jc -encoding UTF-8 -cp "$JSON_CP" -sourcepath "$MAIN/java" -d "$out" "$src" 2> "$BUILD/$t.compile.log"; then
    echo "== $t: COMPILE FAILED (see $BUILD/$t.compile.log)"; head -5 "$BUILD/$t.compile.log"; FAIL=1; continue; fi
  args=()
  [ "$t" = "SubtitleScenarioSuite" ] && args=("$MAIN/tests/fixtures/subtitle_scenarios.tsv" "$BUILD/reports/subtitle-scenarios.tsv")
  echo "== $t"; TOTAL=$((TOTAL+1))
  outlog="$BUILD/$t.run.log"
  if (cd "$MAIN" && java -cp "$out:$JSON_CP" "$pkg.$t" "${args[@]}") > "$outlog" 2>&1; then tail -3 "$outlog"
  else tail -8 "$outlog"; echo "!! $t FAILED (non-zero exit)"; FAIL=1; fi
done

# Python wiring tests resolve paths as <...>/app/src/main (java/, res/, AndroidManifest.xml): build that layout in a temp copy.
if [ $# -eq 0 ] && command -v python3 >/dev/null 2>&1; then
  PY="$BUILD/pylayout/app/src"; rm -rf "$BUILD/pylayout"; mkdir -p "$PY"
  cp -r "$MAIN" "$PY/main"
  echo "== python wiring tests"
  if (cd "$BUILD/pylayout" && python3 -m unittest discover -s app/src/main/tests -p 'test_*.py') > "$BUILD/python.log" 2>&1; then tail -4 "$BUILD/python.log"
  else tail -12 "$BUILD/python.log"; echo "!! python wiring tests FAILED"; FAIL=1; fi
fi
echo; [ $FAIL -eq 0 ] && echo "ALL GREEN ($TOTAL java test classes)" || echo "FAILURES PRESENT"
exit $FAIL
