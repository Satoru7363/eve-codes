# tools/jvm-test — run the unit tests without Android Studio / Gradle

`bash tools/jvm-test/run_jvm_tests.sh` compiles only what the tests reach (`-sourcepath main/java`) and runs
every `*Test.java` / `*Suite.java` under `main/tests/java`, plus the Python wiring tests.

* `shim/org/json/*` is a **TEST-ONLY** minimal re-implementation of org.json (the sandbox JDK has none).
  It is NOT shipped in the app. If a different parse behaviour is ever suspected, run with a real jar:
  `ORG_JSON_JAR=/path/to/org.json.jar bash tools/jvm-test/run_jvm_tests.sh`.
* `Compile.java` drives `javax.tools` so a JRE without the `javac` launcher still works.
* Code that must be unit-testable here must not import `android.*` (use small interfaces, see
  `MovieBoxModels`, `MovieBoxParser`, `SubtitleParser`). Android-bound code (Activities, MovieBoxBridge)
  cannot be compiled here — logic that matters should be extracted into pure classes.
