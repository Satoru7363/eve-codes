import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BRIDGE = (ROOT / "java/com/eve/cinema/moviebox/MovieBoxBridge.java").read_text(encoding="utf-8")
MODELS = (ROOT / "java/com/eve/cinema/moviebox/MovieBoxModels.java").read_text(encoding="utf-8")
PARSER = (ROOT / "java/com/eve/cinema/moviebox/MovieBoxParser.java").read_text(encoding="utf-8")
PLAYER = (ROOT / "java/com/eve/cinema/PlayerActivity.java").read_text(encoding="utf-8")


class MovieBoxSubtitleHotfixWiringTest(unittest.TestCase):
    def test_related_releases_available_before_caption_fetch(self):
        start = BRIDGE.index("private Playback buildPlaybackFromStreams(")
        end = BRIDGE.index("public synchronized List<SubtitleOption> captionsFor", start)
        block = BRIDGE[start:end]
        self.assertLess(block.index("playback.dubs = dubs"), block.index("fetchCaptions(playback, st)"))
        self.assertLess(block.index("playback.canonicalSubjectId = canonicalSubjectId"),
                        block.index("fetchCaptions(playback, st)"))
        self.assertIn("base.canonicalSubjectId())", BRIDGE)
        self.assertIn("dubs);", BRIDGE[BRIDGE.index("public Playback resolveMovie("):BRIDGE.index("public Playback resolveEpisode(")])

    def test_arabic_search_continues_after_nonempty_non_arabic_response(self):
        start = BRIDGE.index("private CaptionsFetchResult fetchCaptions(")
        end = BRIDGE.index("private CaptionsFetchResult finishCaptions", start)
        block = BRIDGE[start:end]
        self.assertIn("validateArabicCandidates(all, validation, result)", block)
        self.assertIn("subtitleSiblingCandidates(playback,", block)
        self.assertIn("if (!result.hasArabic)", block)
        self.assertNotIn("if (all.isEmpty())", block)

    def test_sibling_captions_are_never_fetched_for_the_active_release(self):
        self.assertIn('"ARABIC_CROSS_RELEASE_CAPTIONS_SKIPPED"', BRIDGE)
        self.assertIn("same title/runtime cannot prove cut or audio timing across releases", BRIDGE)
        start = BRIDGE.index("private CaptionsFetchResult fetchCaptions(")
        end = BRIDGE.index("private CaptionsFetchResult finishCaptions", start)
        fetch = BRIDGE[start:end]
        self.assertNotIn("captionsAt(sibling.subjectId", fetch)
        self.assertNotIn("stream.url =", fetch)
        self.assertNotIn("playback.subjectId =", fetch)

    def test_movie_resolution_ranks_the_plain_release_before_a_provider_first_dub(self):
        start = BRIDGE.index("public Playback resolveMovie(")
        end = BRIDGE.index("public Playback resolveEpisode(", start)
        movie = BRIDGE[start:end]
        self.assertIn("findReleaseCandidates(title, originalTitle, year, 0, false)", movie)
        self.assertIn("isSafeDefaultMovieRelease(candidate.tag)", movie)
        self.assertIn("refusing automatic language-labelled playback", movie)
        self.assertNotIn("findSubject(title, originalTitle, year, false)", movie)
        self.assertIn("addRelatedReleaseSearchCandidates(playback, candidates)", movie)
        self.assertIn("tag.isArabicDubHint()", BRIDGE)
        verify = BRIDGE[BRIDGE.index("public boolean verifyDubRelease("):BRIDGE.index("private JSONObject detailsOrThrow(")]
        self.assertIn("sameIdentity(base.title, base.isSeries", verify)
        self.assertIn("releasePreference(a.tag)", (ROOT / "java/com/eve/cinema/moviebox/MovieBoxTitleMatcher.java").read_text(encoding="utf-8"))

    def test_only_arabic_subtitle_hints_are_reported_as_skipped_siblings(self):
        self.assertIn("isArabicSubtitleHint(\n                                d.lanCode, d.language, d.label)", BRIDGE)
        self.assertIn("ARABIC_SUBTITLE", (ROOT / "java/com/eve/cinema/moviebox/MovieBoxReleaseClassifier.java").read_text(encoding="utf-8"))

    def test_three_modes_have_independent_release_and_caption_paths(self):
        self.assertIn("candidate.tag.isArabicSubtitleHint()", BRIDGE)
        self.assertIn("continue; // A translated video is selectable", BRIDGE)
        self.assertIn("resolveArabicSubtitleRelease", BRIDGE)
        self.assertIn("verifyArabicSubtitleRelease", BRIDGE)
        self.assertIn("ARABIC_IN_VIDEO_SUBTITLE", PLAYER)
        self.assertIn("PlaybackMode.ARABIC_SUBTITLE", PLAYER)
        self.assertIn("player_mode_ar_video_subtitle", PLAYER)
        self.assertIn("player_mode_ar_sub", PLAYER)

    def test_arabic_subtitle_release_does_not_satisfy_original_search_gate(self):
        block = BRIDGE.split("private static boolean hasOriginalRelease(", 1)[1].split(
            "private List<MovieBoxTitleMatcher.ReleaseCandidate> findReleaseCandidates(", 1)[0]
        self.assertIn("!c.tag.isArabicSubtitleHint()", block)
        self.assertIn("ARABIC_AMBIGUOUS", block)

    def test_series_subtitle_release_requires_episode_numbers_from_provider(self):
        verify = BRIDGE.split("public boolean verifyArabicSubtitleRelease(", 1)[1].split(
            "private static boolean hasExactNumberedEpisodeStream(", 1)[0]
        helper = BRIDGE.split("private static boolean hasExactNumberedEpisodeStream(", 1)[1].split(
            "private JSONObject detailsOrThrow(", 1)[0]
        self.assertIn("hasExactNumberedEpisodeStream(playInfoStreams, s, e)", verify)
        self.assertIn("hasExactNumberedEpisodeStream(resourceStreams, s, e)", verify)
        fallback = BRIDGE.split("if (firstError == null && subtitleFallback != null)", 1)[1].split(
            "throw firstError != null", 1)[0]
        self.assertIn("hasExactNumberedEpisodeStream(onlyVideoSubtitle.streams, season, episode)", fallback)
        self.assertIn("stream.numberingFromResponse", helper)
        self.assertIn("stream.season == season && stream.episode == episode", helper)

    def test_already_resolved_subtitle_fallback_survives_next_episode(self):
        block = PLAYER.split("if (inVideoSubtitleActive) {", 1)[1].split(
            "} else if (dubActive)", 1)[0]
        self.assertIn("if (!nextPlayback.inVideoSubtitleRelease)", block)
        self.assertIn("resolveArabicSubtitleRelease(nextPlayback, release)", block)

    def test_all_resource_pages_and_exact_rows_are_bounded(self):
        self.assertIn("MAX_RESOURCE_PAGES = 5", BRIDGE)
        self.assertIn("resourceHasMore(payload)", BRIDGE)
        self.assertIn("resourceMatchesEpisode(item, season, episode)", BRIDGE)
        self.assertNotIn("resolveResourceId(", BRIDGE)

    def test_failed_request_or_parse_does_not_mark_captions_resolved(self):
        self.assertIn("stream.captionsResolved = result.resolved()", BRIDGE)
        self.assertNotIn("stream.captionsResolved = true", BRIDGE)
        self.assertIn("mayMarkResolved(\n                    exhausted, requestFailure, validationFailure)", BRIDGE)
        self.assertIn("if (!playback.dubsResolved)", BRIDGE)
        self.assertIn("dubsResolved", MODELS)
        self.assertIn("ARABIC_SUBTITLE_REQUEST_FAILED", BRIDGE)
        self.assertIn("ARABIC_CAPTION_DOWNLOAD_OR_PARSE_FAILED", BRIDGE)
        self.assertIn("CAPTION_DOWNLOAD_OR_PARSE_FAILED", BRIDGE)

    def test_unvalidated_caption_is_never_advertised_and_runtime_survives_json(self):
        self.assertNotIn("UNVALIDATED_KEPT", BRIDGE)
        self.assertIn("durationSeconds", MODELS)
        self.assertIn("durationSeconds = optLongLoose(stream, \"duration\", 0)", PARSER)
        self.assertIn("durationSeconds = optLongLoose(item, \"duration\", 0)", PARSER)

    def test_player_load_failure_and_success_are_distinct_existing_events(self):
        self.assertIn('"subtitle_loaded", "success"', PLAYER)
        self.assertIn('"subtitle_load", "failed"', PLAYER)


if __name__ == "__main__":
    unittest.main()
