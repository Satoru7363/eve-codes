package com.eve.cinema.moviebox;

import java.util.Arrays;
import java.util.List;

import org.json.JSONObject;

import com.eve.cinema.moviebox.MovieBoxModels.DubOption;
import com.eve.cinema.moviebox.MovieBoxModels.Playback;
import com.eve.cinema.moviebox.MovieBoxModels.SubjectItem;
import com.eve.cinema.moviebox.MovieBoxReleaseClassifier.Kind;

/**
 * Checks parseDubs / Playback.arabicDub() / JSON round trip / release ranking.
 *
 * Needs org.json on the classpath (Android's is not available on a plain JVM). Run from the
 * project's main/ directory with a JVM org.json jar (path below is a placeholder):
 *   javac -encoding UTF-8 -cp /path/to/org.json.jar -d /tmp/eve-dub-tests \
 *     java/com/eve/cinema/playback/LanguageMatcher.java \
 *     java/com/eve/cinema/playback/MediaIdentity.java \
 *     java/com/eve/cinema/moviebox/MovieBoxTitleCleaner.java \
 *     java/com/eve/cinema/moviebox/MovieBoxReleaseClassifier.java \
 *     java/com/eve/cinema/moviebox/MovieBoxReleaseTag.java \
 *     java/com/eve/cinema/moviebox/MovieBoxModels.java \
 *     java/com/eve/cinema/moviebox/MovieBoxBase64.java \
 *     java/com/eve/cinema/moviebox/MovieBoxParser.java \
 *     java/com/eve/cinema/moviebox/MovieBoxTitleMatcher.java \
 *     tests/java/com/eve/cinema/moviebox/MovieBoxDubClassificationTest.java \
 *   && java -cp /tmp/eve-dub-tests:/path/to/org.json.jar com.eve.cinema.moviebox.MovieBoxDubClassificationTest
 *
 * Fixtures use sanitized MovieBox field combinations observed in user-provided traces;
 * identifiers are synthetic and no URL, cookie, token or account data is retained.
 */
public final class MovieBoxDubClassificationTest {

    private static int checks = 0;
    private static int failures = 0;

    private MovieBoxDubClassificationTest() {}

    public static void main(String[] args) throws Exception {
        parseDubsPreservesRawFields();
        subtitleVariantIsNotAnArabicDub();
        explicitDubIsReturned();
        providerTypeDisambiguatesConservatively();
        ambiguousAndConflictingEntriesAreNotDubs();
        activeSubjectIsSkipped();
        jsonRoundTripKeepsRawFields();
        rankingDemotesOnlyExplicitDubs();

        System.out.println(checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
    }

    // ── helpers ─────────────────────────────────────────────

    private static void eq(String name, Object expected, Object actual) {
        checks++;
        boolean ok = expected == null ? actual == null : expected.equals(actual);
        if (!ok) {
            failures++;
            System.out.println("FAIL " + name + ": expected <" + expected + "> but was <" + actual + ">");
        }
    }

    private static List<DubOption> dubs(String dubsArrayJson) throws Exception {
        return MovieBoxParser.parseDubs(new JSONObject("{\"dubs\":" + dubsArrayJson + "}"));
    }

    private static Playback playbackActive(String activeSubjectId, String dubsArrayJson) throws Exception {
        Playback p = new Playback();
        p.subjectId = activeSubjectId;
        p.dubs = dubs(dubsArrayJson);
        return p;
    }

    private static final String ARABIC_SUB_ENTRY =
            "{\"subjectId\":\"id-sub\",\"lanName\":\"Arabic\",\"lanCode\":\"ar\",\"type\":1,"
                    + "\"title\":\"Sample [ترجمة عربية]\"}";
    private static final String ARABIC_DUB_ENTRY =
            "{\"subjectId\":\"id-dub\",\"lanName\":\"Arabic\",\"lanCode\":\"ar\",\"type\":0,"
                    + "\"title\":\"Sample [مدبلج للعربية]\"}";
    private static final String ORIGINAL_ENTRY =
            "{\"subjectId\":\"id-orig\",\"lanName\":\"English\",\"lanCode\":\"en\",\"type\":0,"
                    + "\"title\":\"Sample\"}";

    // ── parseDubs preserves lanCode and the raw type ────────

    private static void parseDubsPreservesRawFields() throws Exception {
        List<DubOption> list = dubs("[" + ARABIC_SUB_ENTRY + "," + ARABIC_DUB_ENTRY + "]");
        eq("two entries parsed", 2, list.size());
        eq("lanCode kept (sub)", "ar", list.get(0).lanCode);
        eq("raw type kept as text (sub)", "1", list.get(0).rawType);
        eq("raw type kept as text (dub)", "0", list.get(1).rawType);
        eq("existing language field unchanged", "Arabic", list.get(0).language);
        eq("existing label field unchanged", "Sample [ترجمة عربية]", list.get(0).label);

        List<DubOption> odd = dubs("[{\"subjectId\":\"a\",\"type\":\"1\",\"lanCode\":\"AR\"},"
                + "{\"subjectId\":\"b\",\"type\":7},"
                + "{\"subjectId\":\"c\",\"type\":null,\"lanCode\":null},"
                + "{\"subjectId\":\"d\"},"
                + "{\"subjectId\":\"e\",\"type\":2.5}]");
        eq("string type preserved verbatim", "1", odd.get(0).rawType);
        eq("lanCode not normalised or lower-cased", "AR", odd.get(0).lanCode);
        eq("unknown type value preserved", "7", odd.get(1).rawType);
        eq("JSON null type -> null", null, odd.get(2).rawType);
        eq("JSON null lanCode -> null", null, odd.get(2).lanCode);
        eq("absent type -> null", null, odd.get(3).rawType);
        eq("absent lanCode -> null", null, odd.get(3).lanCode);
        eq("fractional type preserved", "2.5", odd.get(4).rawType);
    }

    // ── Arabic subtitle version is not an Arabic dub ────────

    private static void subtitleVariantIsNotAnArabicDub() throws Exception {
        Playback p = playbackActive("id-orig", "[" + ORIGINAL_ENTRY + "," + ARABIC_SUB_ENTRY + "]");
        eq("only a subtitle variant -> no Arabic dub", null, p.arabicDub());
        eq("subtitle variant classified as subtitle", Kind.ARABIC_SUBTITLE,
                p.dubs.get(1).classification().kind);
        eq("subtitle video release is independently selectable", "id-sub",
                p.arabicSubtitleRelease() == null ? null : p.arabicSubtitleRelease().subjectId);
        eq("original entry classified OTHER", Kind.OTHER, p.dubs.get(0).classification().kind);
    }

    private static void explicitDubIsReturned() throws Exception {
        Playback p = playbackActive("id-orig",
                "[" + ORIGINAL_ENTRY + "," + ARABIC_SUB_ENTRY + "," + ARABIC_DUB_ENTRY + "]");
        DubOption dub = p.arabicDub();
        eq("explicit dub is found", "id-dub", dub == null ? null : dub.subjectId);
        eq("explicit dub classified ARABIC_DUB", Kind.ARABIC_DUB, p.dubs.get(2).classification().kind);
    }

    // ── Observed provider type is corroborating evidence, not a standalone dub claim ──

    private static void providerTypeDisambiguatesConservatively() throws Exception {
        String subWithDubsType = ARABIC_SUB_ENTRY.replace("\"type\":1", "\"type\":0");
        String dubWithSubsType = ARABIC_DUB_ENTRY.replace("\"type\":0", "\"type\":1");
        Playback swapped = playbackActive("id-orig",
                "[" + ORIGINAL_ENTRY + "," + subWithDubsType + "]");
        eq("type 0 conflicting with subtitle label is not a dub", null, swapped.arabicDub());
        eq("type 0/subtitle conflict stays ambiguous", Kind.ARABIC_AMBIGUOUS,
                swapped.dubs.get(1).classification().kind);
        Playback swapped2 = playbackActive("id-orig",
                "[" + ORIGINAL_ENTRY + "," + dubWithSubsType + "]");
        eq("type 1 conflicting with dub label is not a dub", null, swapped2.arabicDub());
        eq("type 1/dub conflict stays ambiguous", Kind.ARABIC_AMBIGUOUS,
                swapped2.dubs.get(1).classification().kind);
        eq("raw type still preserved after swap", "1", swapped2.dubs.get(1).rawType);
        String bareArabicTypeOne = "{\"subjectId\":\"x\",\"lanName\":\"Arabic\","
                + "\"lanCode\":\"ar\",\"type\":1}";
        eq("observed type 1 disambiguates a bare Arabic release as video subtitle",
                Kind.ARABIC_SUBTITLE, dubs("[" + bareArabicTypeOne + "]").get(0).classification().kind);
        String bareArabicTypeZero = "{\"subjectId\":\"x\",\"lanName\":\"Arabic\","
                + "\"lanCode\":\"ar\",\"type\":0}";
        eq("type 0 alone does not claim a dub", Kind.ARABIC_AMBIGUOUS,
                dubs("[" + bareArabicTypeZero + "]").get(0).classification().kind);
        String weird = ARABIC_DUB_ENTRY.replace("\"type\":0", "\"type\":99");
        eq("unknown type value does not block an explicit dub", "id-dub",
                playbackActive("id-orig", "[" + weird + "]").arabicDub().subjectId);
    }

    // ── Ambiguous / conflicting metadata ────────────────────

    private static void ambiguousAndConflictingEntriesAreNotDubs() throws Exception {
        String bareArabic = "{\"subjectId\":\"x1\",\"lanName\":\"Arabic\",\"lanCode\":\"ar\",\"type\":0}";
        eq("bare 'Arabic' entry (no marker) is not a dub", null,
                playbackActive("id-orig", "[" + bareArabic + "]").arabicDub());
        eq("bare entry is classified ambiguous", Kind.ARABIC_AMBIGUOUS,
                dubs("[" + bareArabic + "]").get(0).classification().kind);

        String codeOnly = "{\"subjectId\":\"x2\",\"lanCode\":\"ar\",\"type\":0}";
        eq("lanCode-only entry is not a dub", null,
                playbackActive("id-orig", "[" + codeOnly + "]").arabicDub());

        String conflicting = "{\"subjectId\":\"x3\",\"lanName\":\"English\",\"lanCode\":\"en\","
                + "\"type\":0,\"title\":\"Sample [مدبلج للعربية]\"}";
        eq("dub marker but non-Arabic language metadata is not a dub", null,
                playbackActive("id-orig", "[" + conflicting + "]").arabicDub());

        String both = "{\"subjectId\":\"x4\",\"lanName\":\"Arabic\",\"lanCode\":\"ar\","
                + "\"title\":\"Sample [مدبلج] [ترجمة عربية]\"}";
        eq("dub + subtitle markers together is not a dub", null,
                playbackActive("id-orig", "[" + both + "]").arabicDub());

        eq("empty dubs", null, playbackActive("id-orig", "[]").arabicDub());
        eq("entry without subjectId is skipped", 0,
                dubs("[{\"lanName\":\"Arabic\",\"title\":\"x [مدبلج للعربية]\"}]").size());
    }

    private static void activeSubjectIsSkipped() throws Exception {
        Playback p = playbackActive("id-dub", "[" + ARABIC_DUB_ENTRY + "," + ARABIC_SUB_ENTRY + "]");
        eq("the active release is never offered as 'another' dub", null, p.arabicDub());
    }

    // ── Playback JSON keeps the raw fields ──────────────────

    private static void jsonRoundTripKeepsRawFields() throws Exception {
        Playback p = playbackActive("id-orig", "[" + ARABIC_SUB_ENTRY + "," + ARABIC_DUB_ENTRY + "]");
        p.dubsResolved = true;
        p.inVideoSubtitleRelease = true;
        com.eve.cinema.moviebox.MovieBoxModels.StreamSource runtimeStream =
                new com.eve.cinema.moviebox.MovieBoxModels.StreamSource();
        runtimeStream.url = "https://cdn.test/sample.mp4";
        runtimeStream.durationSeconds = 8700;
        p.streams.add(runtimeStream);
        Playback back = Playback.fromJson(new JSONObject(p.toJson().toString()));
        eq("round trip: entries", 2, back.dubs.size());
        eq("round trip: dubs metadata resolved", true, back.dubsResolved);
        eq("round trip: provider runtime retained", 8700L, back.streams.get(0).durationSeconds);
        eq("round trip: lanCode", "ar", back.dubs.get(0).lanCode);
        eq("round trip: raw type", "1", back.dubs.get(0).rawType);
        eq("round trip: classification stable", Kind.ARABIC_SUBTITLE, back.dubs.get(0).classification().kind);
        eq("round trip: active video is the in-video subtitle release", true,
                back.inVideoSubtitleRelease);
        eq("round trip: dub still found", "id-dub",
                back.arabicDub() == null ? null : back.arabicDub().subjectId);

        // A payload written before this change has neither field.
        JSONObject legacy = new JSONObject("{\"subjectId\":\"s\",\"title\":\"t\",\"isSeries\":false,"
                + "\"dubs\":[{\"subjectId\":\"d\",\"language\":\"Arabic\",\"label\":\"Arabic\"}]}");
        Playback old = Playback.fromJson(legacy);
        eq("legacy payload: dubs metadata requires retry", false, old.dubsResolved);
        eq("legacy payload: lanCode absent", null, old.dubs.get(0).lanCode);
        eq("legacy payload: rawType absent", null, old.dubs.get(0).rawType);
        eq("legacy payload: bare Arabic is not a dub", null, old.arabicDub());
    }

    // ── Ranking: only explicit dubs are demoted ─────────────

    private static SubjectItem series(String id, String title, String year) {
        SubjectItem s = new SubjectItem();
        s.subjectId = id;
        s.title = title;
        s.isSeries = true;
        s.year = year;
        return s;
    }

    private static void rankingDemotesOnlyExplicitDubs() {
        List<SubjectItem> dubFirst = Arrays.asList(
                series("1", "Sample [مدبلج للعربية] S1-S2", "2022"),
                series("2", "Sample S1-S2", "2022"));
        List<MovieBoxTitleMatcher.ReleaseCandidate> ranked1 =
                MovieBoxTitleMatcher.rankReleases(dubFirst, "Sample", null, 2022, true, 1);
        eq("dub-labelled and original both pass identity", 2, ranked1.size());
        eq("explicit Arabic dub ranks after the original", "2", ranked1.get(0).item.subjectId);
        eq("the dub candidate keeps dubLabelled", true, ranked1.get(1).tag.dubLabelled);

        List<SubjectItem> subFirst = Arrays.asList(
                series("1", "Sample [ترجمة عربية] S1-S2", "2022"),
                series("2", "Sample S1-S2", "2022"));
        List<MovieBoxTitleMatcher.ReleaseCandidate> ranked2 =
                MovieBoxTitleMatcher.rankReleases(subFirst, "Sample", null, 2022, true, 1);
        eq("Arabic-subtitle release is not demoted as a dub", "1", ranked2.get(0).item.subjectId);
        eq("Arabic-subtitle release keeps subtitle hint", true, ranked2.get(0).tag.isArabicSubtitleHint());
        eq("Arabic-subtitle release is not dubLabelled", false, ranked2.get(0).tag.dubLabelled);

        List<SubjectItem> bare = Arrays.asList(
                series("1", "Sample [Arabic] S1-S2", "2022"),
                series("2", "Sample S1-S2", "2022"));
        List<MovieBoxTitleMatcher.ReleaseCandidate> ranked3 =
                MovieBoxTitleMatcher.rankReleases(bare, "Sample", null, 2022, true, 1);
        eq("ambiguous [Arabic] is not demoted as a dub", "1", ranked3.get(0).item.subjectId);
    }
}
