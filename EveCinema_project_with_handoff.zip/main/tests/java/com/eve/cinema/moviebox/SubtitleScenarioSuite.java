package com.eve.cinema.moviebox;

import com.eve.cinema.playback.SubtitleParser;
import com.eve.cinema.playback.SubtitleTimeline;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Deterministic JVM scenario runner. Cases are checked in under
 * app/src/main/tests/fixtures/subtitle_scenarios.tsv. It exercises production
 * Java policy/parser/timeline functions with synthetic inputs; it is not a live
 * MovieBox test and does not replace Android Media3/player or real-media sync tests.
 */
public final class SubtitleScenarioSuite {
    private SubtitleScenarioSuite() {}

    public static void main(String[] args) throws Exception {
        Path inventory = args.length > 0 ? Paths.get(args[0]) : Paths.get(
                "app/src/main/tests/fixtures/subtitle_scenarios.tsv");
        Path report = args.length > 1 ? Paths.get(args[1]) : Paths.get(
                "app/build/reports/subtitle-scenarios-results.tsv");
        Files.createDirectories(report.getParent());
        int executed = 0, passed = 0, failed = 0;
        List<String> failures = new ArrayList<>();
        try (BufferedWriter out = Files.newBufferedWriter(report, StandardCharsets.UTF_8)) {
            out.write("ID\tCATEGORY\tEXPECTED\tACTUAL\tRESULT\tEVIDENCE\tDESCRIPTION\n");
            for (String line : Files.readAllLines(inventory, StandardCharsets.UTF_8)) {
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] fields = line.split("\\t", -1);
                if (fields.length != 7) throw new AssertionError("Malformed inventory row: " + fields.length);
                String id = fields[0], category = fields[1], op = fields[2];
                String expected = fields[4], actual;
                try {
                    actual = evaluate(op, fields[3]);
                } catch (Throwable t) {
                    actual = "EXCEPTION:" + t.getClass().getSimpleName();
                }
                boolean ok = expected.equals(actual);
                executed++;
                if (ok) passed++; else {
                    failed++;
                    failures.add(id + " expected=" + expected + " actual=" + actual);
                }
                out.write(tsv(id) + "\t" + tsv(category) + "\t" + tsv(expected) + "\t"
                        + tsv(actual) + "\t" + (ok ? "PASS" : "FAIL") + "\t"
                        + tsv(fields[5]) + "\t" + tsv(fields[6]) + "\n");
            }
        }
        System.out.println("Subtitle scenarios: " + passed + " passed / " + executed
                + " executed / " + failed + " failed / 0 skipped");
        System.out.println("Inventory: " + inventory.toAbsolutePath());
        System.out.println("Per-case results: " + report.toAbsolutePath());
        for (String failure : failures) System.out.println("FAIL " + failure);
        if (executed != 406) throw new AssertionError("Expected exactly 406 distinct scenarios, got " + executed);
        if (failed != 0) throw new AssertionError("Scenario failures: " + failed);
    }

    private static String evaluate(String operation, String rawInput) {
        String[] a = rawInput.split("\\|", -1);
        switch (operation) {
            case "CLASSIFY":
                return MovieBoxReleaseClassifier.classify(nullable(a[0]), a[1], a[2]).kind.name();
            case "RELEASE_TYPE":
                return MovieBoxReleaseClassifier.classifyProviderRelease(
                        nullable(a[0]), nullable(a[1]), a[2], a[3]).kind.name();
            case "TITLE": {
                MovieBoxReleaseTag tag = MovieBoxReleaseTag.parse(a[0]);
                return tag.markerKind.name() + "|" + tag.isArabicDubHint() + "|" + tag.isArabicSubtitleHint();
            }
            case "CAPTION":
                return String.valueOf(MovieBoxSubtitleReleaseResolver.isArabicCaption(nullable(a[0]), nullable(a[1])));
            case "IDENTITY":
                return String.valueOf(MovieBoxSubtitleReleaseResolver.sameIdentity(
                        a[0], bool(a[1]), a[2], bool(a[3])));
            case "RUNTIME":
                return String.valueOf(MovieBoxSubtitleReleaseResolver.runtimeCompatible(
                        Long.parseLong(a[0]), Long.parseLong(a[1])));
            case "RESOURCE":
                return String.valueOf(MovieBoxSubtitleReleaseResolver.compatibleResource(
                        a[0], bool(a[1]), a[2], Integer.parseInt(a[3]), Integer.parseInt(a[4]),
                        integer(a[5]), integer(a[6]), Long.parseLong(a[7]), Long.parseLong(a[8]), bool(a[9])));
            case "RESOLVED":
                return String.valueOf(MovieBoxSubtitleReleaseResolver.mayMarkResolved(
                        bool(a[0]), bool(a[1]), bool(a[2])));
            case "BELONGS":
                return String.valueOf(MovieBoxCaptionResourcePolicy.belongsTo(
                        nullable(a[0]), nullable(a[1]), nullable(a[2]), nullable(a[3]),
                        nullable(a[4]), bool(a[5]), bool(a[6]), bool(a[7])));
            case "PAGES":
                return join(MovieBoxSubtitleResourcePlanner.pageOrder(Integer.parseInt(a[0])));
            case "PARSE": {
                String format = a[0];
                String start = a[1], end = a[2];
                String text = unescape(a[3]);
                String content = "VTT".equals(format)
                        ? "WEBVTT\n\n" + start + " --> " + end + "\n" + text + "\n"
                        : "1\n" + start + " --> " + end + "\n" + text + "\n";
                return describeCues(SubtitleParser.parse(content));
            }
            case "PARSE_RAW":
                return describeCues(SubtitleParser.parse(unescape(rawInput)));
            case "TIMELINE": {
                long pos = Long.parseLong(a[0]);
                List<SubtitleParser.Cue> cues = new ArrayList<>();
                if (!a[1].isEmpty()) {
                    for (String item : a[1].split(";")) {
                        String[] c = item.split(":", 3);
                        cues.add(new SubtitleParser.Cue(Long.parseLong(c[0]), Long.parseLong(c[1]), c[2]));
                    }
                }
                SubtitleParser.Cue cue = new SubtitleTimeline(cues).cueAt(pos);
                return cue == null ? "NONE" : cue.text;
            }
            case "COMBO": {
                boolean caption = MovieBoxSubtitleReleaseResolver.isArabicCaption(nullable(a[0]), nullable(a[1]));
                boolean resource = MovieBoxSubtitleReleaseResolver.compatibleResource(
                        a[2], bool(a[3]), a[4], Integer.parseInt(a[5]), Integer.parseInt(a[6]),
                        integer(a[7]), integer(a[8]), Long.parseLong(a[9]), Long.parseLong(a[10]), bool(a[11]));
                return caption + "|" + resource;
            }
            default:
                throw new IllegalArgumentException("Unknown operation: " + operation);
        }
    }

    private static String describeCues(List<SubtitleParser.Cue> cues) {
        if (cues.isEmpty()) return "0";
        SubtitleParser.Cue first = cues.get(0);
        return cues.size() + "|" + first.startMs + "|" + first.endMs + "|" + escapeText(first.text);
    }

    private static String escapeText(String s) {
        return s.replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r");
    }

    private static String unescape(String s) {
        String bomToken = new String(new char[]{'\\', 'u', 'F', 'E', 'F', 'F'});
        return s.replace(bomToken, String.valueOf((char) 0xFEFF))
                .replace("\\r", "\r").replace("\\n", "\n").replace("\\t", "\t")
                .replace("\\\\", "\\");
    }

    private static String join(int[] values) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) out.append(',');
            out.append(values[i]);
        }
        return out.toString();
    }

    private static String tsv(String s) {
        return s.replace("\t", " ").replace("\r", " ").replace("\n", "\\n");
    }

    private static boolean bool(String s) { return "1".equals(s) || Boolean.parseBoolean(s); }
    private static String nullable(String s) { return s.isEmpty() ? null : s; }
    private static Integer integer(String s) { return "-".equals(s) || s.isEmpty() ? null : Integer.valueOf(s); }
}
