package com.eve.cinema.moviebox;

import com.eve.cinema.moviebox.MovieBoxReleaseClassifier.Kind;

/**
 * Pure-Java checks for release classification (no org.json needed).
 *
 * Run from the project's main/ directory:
 *   javac -d /tmp/eve-cls-tests \
 *     java/com/eve/cinema/playback/LanguageMatcher.java \
 *     java/com/eve/cinema/moviebox/MovieBoxTitleCleaner.java \
 *     java/com/eve/cinema/moviebox/MovieBoxReleaseClassifier.java \
 *     java/com/eve/cinema/moviebox/MovieBoxReleaseTag.java \
 *     tests/java/com/eve/cinema/moviebox/MovieBoxReleaseClassifierTest.java \
 *   && java -cp /tmp/eve-cls-tests com.eve.cinema.moviebox.MovieBoxReleaseClassifierTest
 *
 * All labels below are synthetic label-only examples. Provider type corroboration is
 * tested separately against sanitized fields from the user's traces.
 */
public final class MovieBoxReleaseClassifierTest {

    private static int checks = 0;
    private static int failures = 0;

    private MovieBoxReleaseClassifierTest() {}

    public static void main(String[] args) {
        arabicSubtitleLabels();
        arabicDubLabels();
        originalAndOtherLanguageLabels();
        ambiguousAndConflictingMetadata();
        audioLanguageIsNotSubtitleLanguage();
        releaseTagTitles();
        releaseTagKeepsExistingEnglishBehaviour();

        System.out.println(checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
    }

    // ── helpers ─────────────────────────────────────────────

    private static void eq(String name, Object expected, Object actual) {
        checks++;
        boolean ok = expected == null ? actual == null : expected.equals(actual);
        if (!ok) {
            failures++;
            System.out.println("FAIL " + name + ": expected <" + expected + "> but was <" + actual + ">");
        }
    }

    private static void kind(String name, Kind expected, String lanCode, String... texts) {
        eq(name, expected, MovieBoxReleaseClassifier.classify(lanCode, texts).kind);
    }

    // ── Arabic-subtitle releases ────────────────────────────

    private static void arabicSubtitleLabels() {
        kind("sub: Arabic-script title marker", Kind.ARABIC_SUBTITLE, null, "From [ترجمة عربية] S1-S4");
        kind("sub: مترجم", Kind.ARABIC_SUBTITLE, null, "فيلم [مترجم للعربية]");
        kind("sub: english label 'Arabic sub'", Kind.ARABIC_SUBTITLE, null, "Arabic sub");
        kind("sub: 'Arabic Subtitles'", Kind.ARABIC_SUBTITLE, null, "Arabic Subtitles");
        kind("sub: marker + lanCode ar", Kind.ARABIC_SUBTITLE, "ar", "Sub");
        kind("sub: label + lanCode ar", Kind.ARABIC_SUBTITLE, "ar", "Arabic sub", "Arabic");
    }

    // ── Arabic dubs ─────────────────────────────────────────

    private static void arabicDubLabels() {
        kind("dub: Arabic-script title marker", Kind.ARABIC_DUB, null, "Tangled [مدبلج للعربية]");
        kind("dub: دبلجة عربية", Kind.ARABIC_DUB, null, "دبلجة عربية");
        kind("dub: 'Arabic dub'", Kind.ARABIC_DUB, null, "Arabic dub");
        kind("dub: 'Arabic Dubbed'", Kind.ARABIC_DUB, null, "Arabic Dubbed");
        kind("dub: 'Arabic audio'", Kind.ARABIC_DUB, null, "Arabic audio");
        kind("dub: marker + lanCode ar", Kind.ARABIC_DUB, "ar", "Dub");
        kind("dub: diacritics are ignored", Kind.ARABIC_DUB, null, "مُدَبْلَج للعربية");
    }

    // ── Original / other-language releases ──────────────────

    private static void originalAndOtherLanguageLabels() {
        kind("other: Original Audio", Kind.OTHER, null, "Original Audio");
        kind("other: Original Audio + non-Arabic lanCode", Kind.OTHER, "ja", "Original Audio");
        kind("other: English dub", Kind.OTHER, "en", "English dub");
        kind("other: English sub", Kind.OTHER, null, "English sub");
        kind("other: Hindi dub", Kind.OTHER, null, "Hindi dub");
        kind("other: plain title, non-Arabic lanCode", Kind.OTHER, "en", "Tangled");
        kind("unknown: nothing usable", Kind.UNKNOWN, null, "Tangled");
        kind("unknown: null inputs", Kind.UNKNOWN, null, (String) null);
        kind("unknown: undetermined lanCode", Kind.UNKNOWN, "und", "");
        // Short tokens must not count as languages ("it", "no", "he" are ordinary words).
        kind("unknown: 'Run it back' is not Italian", Kind.UNKNOWN, null, "Run it back");
    }

    // ── Ambiguous or conflicting metadata ───────────────────

    private static void ambiguousAndConflictingMetadata() {
        kind("ambig: bare 'Arabic'", Kind.ARABIC_AMBIGUOUS, null, "Arabic");
        kind("ambig: bare العربية", Kind.ARABIC_AMBIGUOUS, null, "العربية");
        kind("ambig: lanCode ar only", Kind.ARABIC_AMBIGUOUS, "ar", "", null);
        kind("ambig: lanCode ar + plain title", Kind.ARABIC_AMBIGUOUS, "ar", "Tangled");
        kind("ambig: dub + sub markers together", Kind.ARABIC_AMBIGUOUS, null, "Arabic dub / Arabic sub");
        kind("ambig: Arabic marker but lanCode en", Kind.ARABIC_AMBIGUOUS, "en", "Arabic dub");
        kind("ambig: Arabic sub marker but lanCode en", Kind.ARABIC_AMBIGUOUS, "en", "ترجمة عربية");
        kind("ambig: Arabic + English mentioned", Kind.ARABIC_AMBIGUOUS, null, "English Arabic dub");
        kind("ambig: Original Audio with lanCode ar is not a dub", Kind.ARABIC_AMBIGUOUS, "ar", "Original Audio");
        kind("ambig: Arabic title text without a marker", Kind.ARABIC_AMBIGUOUS, null, "ملوك العرب");
        // `type` is not an input: the classifier cannot be steered by it either way.
        kind("ambig result does not depend on rawType (not an input)",
                Kind.ARABIC_AMBIGUOUS, "ar", "Arabic");
    }

    // ── Audio language vs subtitle language ─────────────────

    private static void audioLanguageIsNotSubtitleLanguage() {
        // The same lanCode "ar" must not decide audio vs subtitle on its own.
        Kind withSubMarker = MovieBoxReleaseClassifier.classify("ar", "Arabic sub").kind;
        Kind withDubMarker = MovieBoxReleaseClassifier.classify("ar", "Arabic dub").kind;
        Kind noMarker = MovieBoxReleaseClassifier.classify("ar", "Arabic").kind;
        eq("same lanCode, sub marker -> subtitle", Kind.ARABIC_SUBTITLE, withSubMarker);
        eq("same lanCode, dub marker -> dub", Kind.ARABIC_DUB, withDubMarker);
        eq("same lanCode, no marker -> ambiguous, not dub", Kind.ARABIC_AMBIGUOUS, noMarker);
        // An Arabic subtitle release over English audio is not an Arabic dub.
        kind("English audio + Arabic subtitles is not a dub", Kind.ARABIC_AMBIGUOUS, null,
                "English audio, Arabic subtitles");
        eq("subtitle result never reports dub",
                false, MovieBoxReleaseClassifier.classify(null, "ترجمة عربية").kind == Kind.ARABIC_DUB);
        eq("reason is populated", true,
                MovieBoxReleaseClassifier.classify("ar", "Arabic").reason.length() > 0);
    }

    // ── MovieBoxReleaseTag (title markers) ──────────────────

    private static void releaseTagTitles() {
        MovieBoxReleaseTag sub = MovieBoxReleaseTag.parse("From [ترجمة عربية] S1-S4");
        eq("tag sub: markerKind", Kind.ARABIC_SUBTITLE, sub.markerKind);
        eq("tag sub: subtitle hint", true, sub.isArabicSubtitleHint());
        eq("tag sub: not a dub hint", false, sub.isArabicDubHint());
        eq("tag sub: dubLabelled false (original audio)", false, sub.dubLabelled);
        eq("tag sub: base title", "From", sub.baseTitle);
        eq("tag sub: season range kept", 1, sub.seasonFrom);
        eq("tag sub: season range kept (to)", 4, sub.seasonTo);

        MovieBoxReleaseTag dub = MovieBoxReleaseTag.parse("Tangled [مدبلج للعربية]");
        eq("tag dub: markerKind", Kind.ARABIC_DUB, dub.markerKind);
        eq("tag dub: dub hint", true, dub.isArabicDubHint());
        eq("tag dub: dubLabelled", true, dub.dubLabelled);
        eq("tag dub: base title", "Tangled", dub.baseTitle);

        MovieBoxReleaseTag original = MovieBoxReleaseTag.parse("Tangled");
        eq("tag original: markerKind", Kind.UNKNOWN, original.markerKind);
        eq("tag original: no hints", false, original.isArabicSubtitleHint() || original.isArabicDubHint());
        eq("tag original: not dub", false, original.dubLabelled);

        // Ambiguous markers must not be labelled a dub.
        MovieBoxReleaseTag bareArabic = MovieBoxReleaseTag.parse("Show [Arabic]");
        eq("tag bare [Arabic]: ambiguous", Kind.ARABIC_AMBIGUOUS, bareArabic.markerKind);
        eq("tag bare [Arabic]: not dubLabelled", false, bareArabic.dubLabelled);
        MovieBoxReleaseTag bareDash = MovieBoxReleaseTag.parse("Show - Arabic");
        eq("tag dash Arabic: not dubLabelled", false, bareDash.dubLabelled);

        MovieBoxReleaseTag mixed = MovieBoxReleaseTag.parse("Show [Arabic Dub] [ترجمة عربية]");
        eq("tag conflicting markers: ambiguous", Kind.ARABIC_AMBIGUOUS, mixed.markerKind);
        eq("tag conflicting markers: not dubLabelled", false, mixed.dubLabelled);

        eq("tag english Arabic sub", Kind.ARABIC_SUBTITLE,
                MovieBoxReleaseTag.parse("Show [Arabic Sub] S1").markerKind);
        eq("tag english Arabic dub", Kind.ARABIC_DUB,
                MovieBoxReleaseTag.parse("Show [Arabic Dub] S1").markerKind);
        eq("tag title word 'Dubai' is not a marker", Kind.UNKNOWN,
                MovieBoxReleaseTag.parse("Dubai Bling").markerKind);
        eq("tag null title", Kind.UNKNOWN, MovieBoxReleaseTag.parse(null).markerKind);
    }

    /** Behaviour that existed before this change must not move. */
    private static void releaseTagKeepsExistingEnglishBehaviour() {
        MovieBoxReleaseTag english = MovieBoxReleaseTag.parse(
                "Re:ZERO -Starting Life in Another World- [English] S1-S3");
        eq("regress english: languageTag", "english", english.languageTag);
        eq("regress english: dubLabelled", true, english.dubLabelled);
        eq("regress english: markerKind not Arabic", Kind.OTHER, english.markerKind);
        eq("regress english: claims S1", 1, english.seasonFrom);
        eq("regress english: claims S3", 3, english.seasonTo);
        eq("regress english: covers S2", true, english.coversSeason(2));
        eq("regress english: does not cover S4", false, english.coversSeason(4));

        MovieBoxReleaseTag hindi = MovieBoxReleaseTag.parse("Show - Hindi Dub");
        eq("regress hindi dash: dubLabelled", true, hindi.dubLabelled);

        MovieBoxReleaseTag japanese = MovieBoxReleaseTag.parse("Show [Japanese]");
        eq("regress original anime audio is not a dub", false, japanese.dubLabelled);

        MovieBoxReleaseTag plain = MovieBoxReleaseTag.parse("Jujutsu Kaisen S1-S3");
        eq("regress plain: no language", null, plain.languageTag);
        eq("regress plain: not dub", false, plain.dubLabelled);
    }
}
