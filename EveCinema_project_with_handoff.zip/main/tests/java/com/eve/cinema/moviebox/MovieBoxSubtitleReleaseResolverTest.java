package com.eve.cinema.moviebox;

import com.eve.cinema.moviebox.MovieBoxReleaseClassifier.Kind;

/** Pure-Java regression tests; fixtures are synthetic and contain no provider credentials. */
public final class MovieBoxSubtitleReleaseResolverTest {
    private static int checks;
    private static int failures;

    private MovieBoxSubtitleReleaseResolverTest() {}

    public static void main(String[] args) {
        subtitleHintIsNotAudioDub();
        identityAndPlayableResourceAreRequired();
        trailerAndMismatchedCutAreRejected();
        exactEpisodeAndRuntimeAreRequired();
        onlyArabicCaptionMetadataResolvesArabic();
        failuresRemainRetryable();
        observedRegressionFixtureRejectsCrossReleaseCaption();
        System.out.println(checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
    }

    private static void eq(String name, Object expected, Object actual) {
        checks++;
        if (expected == null ? actual != null : !expected.equals(actual)) {
            failures++;
            System.out.println("FAIL " + name);
        }
    }

    private static void subtitleHintIsNotAudioDub() {
        eq("Arabic sub metadata is subtitle hint", true,
                MovieBoxSubtitleReleaseResolver.isArabicSubtitleHint("ar", "Arabic sub",
                        "Spider-Man: Brand New Day [ترجمة عربية]"));
        eq("Arabic sub is not ARABIC_DUB", Kind.ARABIC_SUBTITLE,
                MovieBoxReleaseClassifier.classify("ar", "Arabic sub").kind);
        eq("Arabic dub has different classification", false,
                MovieBoxSubtitleReleaseResolver.isArabicSubtitleHint("ar", "Arabic dub", ""));
        // Raw type is deliberately absent from the resolver API and cannot change classification.
    }

    private static void identityAndPlayableResourceAreRequired() {
        eq("same release identity after subtitle marker removal", true,
                MovieBoxSubtitleReleaseResolver.sameIdentity(
                        "Spider-Man: Brand New Day", false,
                        "Spider-Man: Brand New Day [ترجمة عربية]", false));
        eq("unrelated title rejected", false,
                MovieBoxSubtitleReleaseResolver.sameIdentity(
                        "Spider-Man: Brand New Day", false, "Marvel's Spider-Man 2", false));
        eq("media type mismatch rejected", false,
                MovieBoxSubtitleReleaseResolver.sameIdentity("Tangled", false, "Tangled", true));
        eq("non-playable resource rejected", false,
                MovieBoxSubtitleReleaseResolver.compatibleResource("Tangled", false, "Tangled",
                        0, 0, 0, 0, 6015, 6015, false));
    }

    private static void trailerAndMismatchedCutAreRejected() {
        eq("Trailer post/resource evidence rejected", false,
                MovieBoxSubtitleReleaseResolver.compatibleResource(
                        "Spider-Man: Brand New Day", false,
                        "Trailer-Spider-Man: Brand New Day", 0, 0,
                        0, 0, 8700, 180, true));
        eq("different full-length cut rejected", false,
                MovieBoxSubtitleReleaseResolver.compatibleResource(
                        "Spider-Man: Brand New Day", false,
                        "Spider-Man: Brand New Day", 0, 0,
                        0, 0, 8700, 8100, true));
        eq("matching title and exact runtime accepted as a necessary filter", true,
                MovieBoxSubtitleReleaseResolver.compatibleResource(
                        "Tangled", false, "Tangled [ترجمة عربية]", 0, 0,
                        0, 0, 6015, 6015, true));
        eq("observed 22-second Spider-Man runtime delta rejected without a documented tolerance", false,
                MovieBoxSubtitleReleaseResolver.compatibleResource(
                        "Spider-Man: Brand New Day", false,
                        "Spider-Man: Brand New Day[ترجمة عربية]_360P", 0, 0,
                        0, 0, 8700, 8678, true));
        eq("unknown runtime is not proof", false,
                MovieBoxSubtitleReleaseResolver.runtimeCompatible(8700, 0));
    }

    private static void exactEpisodeAndRuntimeAreRequired() {
        eq("same episode and compatible runtime accepted", true,
                MovieBoxSubtitleReleaseResolver.compatibleResource(
                        "Example Show", true, "Example Show - Episode 2", 1, 2,
                        1, 2, 2400, 2400, true));
        eq("wrong episode rejected", false,
                MovieBoxSubtitleReleaseResolver.compatibleResource(
                        "Example Show", true, "Example Show - Episode 3", 1, 2,
                        1, 3, 2400, 2410, true));
        eq("missing episode mapping rejected", false,
                MovieBoxSubtitleReleaseResolver.compatibleResource(
                        "Example Show", true, "Example Show - Episode 2", 1, 2,
                        null, null, 2400, 2410, true));
    }

    private static void onlyArabicCaptionMetadataResolvesArabic() {
        eq("English-only captions do not resolve Arabic", false,
                MovieBoxSubtitleReleaseResolver.isArabicCaption("en", "English"));
        eq("Arabic code identifies Arabic caption", true,
                MovieBoxSubtitleReleaseResolver.isArabicCaption("ar", "Unknown"));
        eq("Arabic name identifies caption when code is absent", true,
                MovieBoxSubtitleReleaseResolver.isArabicCaption(null, "Arabic"));
        eq("English code contradicting Arabic name is not treated as Arabic", false,
                MovieBoxSubtitleReleaseResolver.isArabicCaption("en", "Arabic"));
        eq("Arabic code contradicting Japanese name is not treated as Arabic", false,
                MovieBoxSubtitleReleaseResolver.isArabicCaption("ar", "Japanese"));
        eq("mixed-language label is ambiguous, not verified Arabic", false,
                MovieBoxSubtitleReleaseResolver.isArabicCaption(null, "Arabic English"));
    }

    private static void failuresRemainRetryable() {
        eq("exhausted successful search may be marked resolved", true,
                MovieBoxSubtitleReleaseResolver.mayMarkResolved(true, false, false));
        eq("request failure is retryable", false,
                MovieBoxSubtitleReleaseResolver.mayMarkResolved(true, true, false));
        eq("download/parse failure is retryable", false,
                MovieBoxSubtitleReleaseResolver.mayMarkResolved(true, false, true));
        eq("unexhausted candidates are not resolved", false,
                MovieBoxSubtitleReleaseResolver.mayMarkResolved(false, false, false));
    }

    /** Sanitized regression shape from MovieBox: matching title/runtime did not prove release identity. */
    private static void observedRegressionFixtureRejectsCrossReleaseCaption() {
        String activeTitle = "Frozen";
        long activeRuntime = 6133;
        eq("canonical Frozen Arabic caption language metadata is Arabic", true,
                MovieBoxSubtitleReleaseResolver.isArabicCaption("ar", "Arabic"));
        eq("same title/runtime passes only the resource eligibility filter", true,
                MovieBoxSubtitleReleaseResolver.compatibleResource(activeTitle, false,
                        "Frozen", 0, 0, 0, 0, activeRuntime, activeRuntime, true));
        eq("Frozen canonical caption cannot cross into active Arabic-dub release", false,
                MovieBoxCaptionResourcePolicy.belongsTo("frozen-dub", "frozen-dub",
                        "dub-stream", "frozen-original", "original-resource", true,
                        true, true));
        eq("same-subject alternate row still requires its metadata verification", true,
                MovieBoxCaptionResourcePolicy.belongsTo("frozen-dub", "frozen-dub",
                        "dub-stream", "frozen-dub", "alternate-resource", true,
                        false, true));
        eq("Spider-Man Arabic sibling cannot be advertised as the active original caption", false,
                MovieBoxCaptionResourcePolicy.belongsTo("spiderman-original",
                        "spiderman-original", "active-stream", "spiderman-ar-sub",
                        "translated-resource", true, true, true));
    }
}
