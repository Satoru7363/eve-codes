package com.eve.cinema.moviebox;

import org.json.JSONArray;
import org.json.JSONObject;

/** Synthetic JSON tests for exact resource-row selection and bounded pagination metadata. */
public final class MovieBoxSubtitleResourceParserTest {
    private static int checks;
    private static int failures;

    private MovieBoxSubtitleResourceParserTest() {}

    public static void main(String[] args) throws Exception {
        JSONObject payload = new JSONObject(
                "{\"data\":{\"list\":["
                + "{\"resourceId\":\"row-a\",\"se\":0,\"ep\":0,\"title\":\"Tangled\",\"duration\":6015,\"resourceLink\":\"https://cdn.test/movie.mp4?quality=1080\"},"
                + "{\"resourceId\":\"row-b\",\"se\":1,\"ep\":2,\"title\":\"Example Show\",\"duration\":2400,\"resourceLink\":\"https://cdn.test/episode.mp4\"},"
                + "{\"resourceId\":\"row-c\",\"title\":\"Tangled\",\"duration\":6015,\"resourceLink\":\"https://cdn.test/watch?id=3\"}"
                + "],\"pager\":{\"hasMore\":true,\"nextPage\":\"2\"}}}");
        JSONArray rows = MovieBoxParser.resourceItems(payload);
        eq("all rows exposed", 3, rows.length());
        eq("movie row exact 0/0 accepted", true,
                MovieBoxParser.resourceMatchesEpisode(rows.optJSONObject(0), 0, 0));
        eq("movie-specific row with episode numbering rejected", false,
                MovieBoxParser.resourceMatchesEpisode(rows.optJSONObject(1), 0, 0));
        eq("movie row without numbering accepted for subject-scoped endpoint", true,
                MovieBoxParser.resourceMatchesEpisode(rows.optJSONObject(2), 0, 0));
        eq("series exact requested episode accepted", true,
                MovieBoxParser.resourceMatchesEpisode(rows.optJSONObject(1), 1, 2));
        eq("series mismatched episode rejected", false,
                MovieBoxParser.resourceMatchesEpisode(rows.optJSONObject(1), 1, 3));
        eq("direct media row recognized", true,
                MovieBoxParser.isDirectPlayableResourceItem(rows.optJSONObject(0)));
        eq("resolver page rejected", false,
                MovieBoxParser.isDirectPlayableResourceItem(rows.optJSONObject(2)));
        JSONObject verifiedArabicRow = new JSONObject(
                "{\"title\":\"Spider-Man: Brand New Day[ترجمة عربية]_360P\","
                + "\"duration\":8678,\"se\":0,\"ep\":0,"
                + "\"resourceLink\":\"https://cdn.test/other/b164fbfb4347792950bdfbfb563d39d9.mp4\"}");
        eq("legacy notice heuristic does not bless an unverified row", false,
                MovieBoxParser.isDirectPlayableResourceItem(verifiedArabicRow));
        eq("direct media URL can be checked after metadata verification", true,
                MovieBoxParser.isDirectMediaResourceItem(verifiedArabicRow));
        eq("explicit notice file remains rejected", false,
                MovieBoxParser.isDirectMediaResourceItem(new JSONObject(
                        "{\"resourceLink\":\"https://cdn.test/other/notice.mp4\"}")));
        eq("pager continues", true, MovieBoxParser.resourceHasMore(payload));
        eq("no continuation without true flag", false,
                MovieBoxParser.resourceHasMore(new JSONObject("{\"data\":{\"pager\":{\"hasMore\":false}}}")));
        System.out.println(checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
    }

    private static void eq(String name, Object expected, Object actual) {
        checks++;
        if (expected == null ? actual != null : !expected.equals(actual)) {
            failures++;
            System.out.println("FAIL " + name);
        }
    }
}
