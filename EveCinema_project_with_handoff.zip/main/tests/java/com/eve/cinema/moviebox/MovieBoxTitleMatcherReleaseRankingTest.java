package com.eve.cinema.moviebox;

import java.util.Arrays;
import java.util.List;

import com.eve.cinema.moviebox.MovieBoxModels.SubjectItem;

/** Regression for provider order: a dub may precede the original in search results. */
public final class MovieBoxTitleMatcherReleaseRankingTest {
    private static int checks;
    private static int failures;

    private MovieBoxTitleMatcherReleaseRankingTest() {}

    public static void main(String[] args) {
        SubjectItem dubbed = item("dub", "Tangled [مدبلج للعربية]", "2010");
        SubjectItem subtitle = item("sub", "Tangled [ترجمة عربية]", "2010");
        SubjectItem original = item("original", "Tangled", "2010");

        List<MovieBoxTitleMatcher.ReleaseCandidate> ranked = MovieBoxTitleMatcher.rankReleases(
                Arrays.asList(dubbed, subtitle, original), "Tangled", "Tangled", 2010, false, 0);
        eq("all same-work candidates retained", 3, ranked.size());
        eq("plain/original release outranks provider-first dub", "original",
                ranked.get(0).item.subjectId);
        eq("Arabic subtitle release stays distinct from dub", "sub",
                ranked.get(1).item.subjectId);
        eq("explicit Arabic dub is never promoted above original", "dub",
                ranked.get(2).item.subjectId);

        System.out.println(checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
    }

    private static SubjectItem item(String id, String title, String year) {
        SubjectItem item = new SubjectItem();
        item.subjectId = id;
        item.title = title;
        item.year = year;
        item.isSeries = false;
        return item;
    }

    private static void eq(String name, Object expected, Object actual) {
        checks++;
        if (expected == null ? actual != null : !expected.equals(actual)) {
            failures++;
            System.out.println("FAIL " + name);
        }
    }
}
