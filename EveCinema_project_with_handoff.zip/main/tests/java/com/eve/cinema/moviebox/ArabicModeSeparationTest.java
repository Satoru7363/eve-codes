package com.eve.cinema.moviebox;

import com.eve.cinema.playback.ModeResolver;
import com.eve.cinema.playback.PlaybackMode;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Pure-JVM regression tests for three Arabic playback paths. */
public final class ArabicModeSeparationTest {
    private ArabicModeSeparationTest() {}

    public static void main(String[] args) {
        allThreeOptionsAreDistinctAndPrioritized();
        videoSubtitleDoesNotLoadAnExternalOverlayOrForceAudio();
        externalSubtitleIsControllableOverlayOnly();
        unavailableRequestFallsBackWithoutReclassifyingTheSource();
        automaticPriorityUsesVerifiedArabicBeforeEnglish();
        System.out.println("Arabic mode separation: 5 tests passed");
    }

    private static void allThreeOptionsAreDistinctAndPrioritized() {
        ModeResolver.Availability a = ModeResolver.evaluate(
                Arrays.asList("ar", "en"), Arrays.asList("ar", "en"), true, true);
        List<PlaybackMode> options = ModeResolver.chooserOptions(a);
        eq(Arrays.asList(PlaybackMode.ARABIC_DUB,
                        PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE,
                        PlaybackMode.ARABIC_SUBTITLE), options);
        eq(PlaybackMode.ARABIC_DUB, ModeResolver.effectiveMode(PlaybackMode.ARABIC_DUB, a));
        eq(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE,
                ModeResolver.effectiveMode(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE, a));
        eq(PlaybackMode.ARABIC_SUBTITLE,
                ModeResolver.effectiveMode(PlaybackMode.ARABIC_SUBTITLE, a));
    }

    private static void videoSubtitleDoesNotLoadAnExternalOverlayOrForceAudio() {
        ModeResolver.Availability a = ModeResolver.evaluate(
                Collections.<String>emptyList(), Collections.<String>emptyList(), false, true);
        eq(Collections.singletonList(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE),
                ModeResolver.chooserOptions(a));
        eq(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE,
                ModeResolver.effectiveMode(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE, a));
        eq(-1, ModeResolver.subtitleIndexFor(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE,
                Arrays.asList("ar")));
        eq(null, ModeResolver.audioLanguageFor(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE, a));
    }

    private static void externalSubtitleIsControllableOverlayOnly() {
        ModeResolver.Availability a = ModeResolver.evaluate(
                Arrays.asList("ar"), Collections.<String>emptyList(), false, false);
        eq(Collections.singletonList(PlaybackMode.ARABIC_SUBTITLE), ModeResolver.chooserOptions(a));
        eq(0, ModeResolver.subtitleIndexFor(PlaybackMode.ARABIC_SUBTITLE, Arrays.asList("ar")));
        eq(-1, ModeResolver.subtitleIndexFor(PlaybackMode.ARABIC_DUB, Arrays.asList("ar")));
        eq(-1, ModeResolver.subtitleIndexFor(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE,
                Arrays.asList("ar")));
    }

    private static void unavailableRequestFallsBackWithoutReclassifyingTheSource() {
        ModeResolver.Availability externalOnly = ModeResolver.evaluate(
                Arrays.asList("ar"), Collections.<String>emptyList(), false, false);
        eq(PlaybackMode.ARABIC_SUBTITLE,
                ModeResolver.effectiveMode(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE, externalOnly));
        ModeResolver.Availability videoOnly = ModeResolver.evaluate(
                Collections.<String>emptyList(), Collections.<String>emptyList(), false, true);
        eq(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE,
                ModeResolver.effectiveMode(PlaybackMode.ARABIC_SUBTITLE, videoOnly));
    }

    private static void automaticPriorityUsesVerifiedArabicBeforeEnglish() {
        ModeResolver.Availability a = ModeResolver.evaluate(
                Arrays.asList("en"), Arrays.asList("en"), true, true);
        eq(PlaybackMode.ARABIC_DUB, ModeResolver.automaticMode(a));
        ModeResolver.Availability b = ModeResolver.evaluate(
                Arrays.asList("en"), Arrays.asList("en"), false, true);
        eq(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE, ModeResolver.automaticMode(b));
    }

    private static void eq(Object expected, Object actual) {
        if (expected == null ? actual != null : !expected.equals(actual))
            throw new AssertionError("expected=" + expected + " actual=" + actual);
    }
}
