package com.eve.cinema;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

/** Run with: javac -d /tmp/eve-redaction-tests java/com/eve/cinema/DiagnosticRedactor.java tests/java/com/eve/cinema/DiagnosticRedactorTest.java && java -cp /tmp/eve-redaction-tests com.eve.cinema.DiagnosticRedactorTest */
public final class DiagnosticRedactorTest {
    private static final String BEARER = "CANARY_BEARER_7f2c";
    private static final String COOKIE = "CANARY_COOKIE_91ab";
    private static final String API_KEY = "CANARY_APIKEY_6d3e";
    private static final String ACCESS_TOKEN = "CANARY_ACCESS_TOKEN_3a11";
    private static final String SIGNED_SIG = "CANARY_SIGNED_SIG_82ce";
    private static final String REFRESH = "CANARY_REFRESH_44d0";
    private static final String JWT = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJjYW5hcnkifQ.signatureCanaryValue123";

    private DiagnosticRedactorTest() {}

    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("eve-redaction-test-");
        Path payloads = Files.createDirectories(root.resolve("payloads"));

        Map<String, Object> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + BEARER);
        headers.put("Cookie", "sid=" + COOKIE);
        headers.put("X-Api-Key", API_KEY);
        String headerMetadata = DiagnosticRedactor.headerSummary(headers);

        String event = "{\"url\":\"https://cdn.test/play?quality=1080&access_token=" + ACCESS_TOKEN
                + "&X-Amz-Signature=" + SIGNED_SIG + "\",\"headers\":\"Authorization: Bearer "
                + BEARER + "\\nCookie: sid=" + COOKIE + "; theme=dark\",\"headerSummary\":\""
                + headerMetadata + "\",\"jwt\":\"" + JWT
                + "\",\"secretsRedacted\":false,\"secretCount\":42}";
        String body = "{\"auth\":{\"accessToken\":\"" + ACCESS_TOKEN + "\",\"refresh_token\":\""
                + REFRESH + "\",\"api_key\":\"" + API_KEY
                + "\",\"keep\":\"ordinary-value\"},\"url\":\"https://cdn.test/v?sig="
                + SIGNED_SIG + "&quality=720\"}";
        String xml = "<root><session_token>" + ACCESS_TOKEN + "</session_token><message>ordinary</message></root>";

        // Exercise the same sanitizer immediately before writing event and payload files.
        Files.write(root.resolve("events.jsonl"),
                (DiagnosticRedactor.redactText(event) + "\n").getBytes(StandardCharsets.UTF_8));
        Files.write(payloads.resolve("response.txt"),
                DiagnosticRedactor.redactText(body).getBytes(StandardCharsets.UTF_8));
        Files.write(payloads.resolve("request.txt"),
                DiagnosticRedactor.redactText(xml).getBytes(StandardCharsets.UTF_8));
        String rawHeaders = "Cookie: sid=" + COOKIE + "; refresh_token=" + REFRESH
                + "\nAuthorization: Bearer " + BEARER + "\n";
        Files.write(payloads.resolve("raw-headers.txt"),
                DiagnosticRedactor.redactText(rawHeaders).getBytes(StandardCharsets.UTF_8));
        Files.write(payloads.resolve("header-summary.txt"),
                headerMetadata.getBytes(StandardCharsets.UTF_8));

        String[] canaries = {BEARER, COOKIE, API_KEY, ACCESS_TOKEN, SIGNED_SIG, REFRESH, JWT};
        try {
        try (Stream<Path> paths = Files.walk(root)) {
            for (Path path : (Iterable<Path>) paths.filter(Files::isRegularFile)::iterator) {
                String saved = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
                for (int i = 0; i < canaries.length; i++) {
                    if (saved.contains(canaries[i]))
                        throw new AssertionError("synthetic canary index " + i + " persisted in " + path.getFileName());
                }
            }
        }
        String safeEvent = new String(Files.readAllBytes(root.resolve("events.jsonl")), StandardCharsets.UTF_8);
        String safePayload = new String(Files.readAllBytes(payloads.resolve("response.txt")), StandardCharsets.UTF_8);
        if (!safeEvent.contains("quality=1080") || !safePayload.contains("ordinary-value"))
            throw new AssertionError("redaction removed non-sensitive diagnostic fields");
        if (!safeEvent.contains("\"secretsRedacted\":false")
                || !safeEvent.contains("\"secretCount\":\"[REDACTED]\""))
            throw new AssertionError("redaction corrupted JSON scalar syntax");
        if (!headerMetadata.contains("values omitted") || headerMetadata.contains("Authorization: Bearer"))
            throw new AssertionError("header summary retained values");

        System.out.println("PASS: synthetic secrets absent from all saved event/payload test files; safe diagnostic fields retained");
        } finally {
            deleteTree(root);
        }
    }

    private static void deleteTree(Path path) throws IOException {
        if (Files.isDirectory(path)) {
            try (Stream<Path> children = Files.list(path)) {
                for (Path child : (Iterable<Path>) children::iterator) deleteTree(child);
            }
        }
        Files.deleteIfExists(path);
    }
}
