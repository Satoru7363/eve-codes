from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
RECORDER = (ROOT / "java/com/eve/cinema/DiagnosticsRecorder.java").read_text()
APP = (ROOT / "java/com/eve/cinema/Applications.java").read_text()


def method_body(source: str, signature: str) -> str:
    start = source.index(signature)
    open_brace = source.index("{", start)
    depth = 0
    in_string = False
    escaped = False
    for i in range(open_brace, len(source)):
        c = source[i]
        if in_string:
            if escaped:
                escaped = False
            elif c == "\\":
                escaped = True
            elif c == '"':
                in_string = False
            continue
        if c == '"':
            in_string = True
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return source[open_brace + 1:i]
    raise AssertionError(f"method body not closed: {signature}")


class RecorderWiringTests(unittest.TestCase):
    def test_recording_enabled_with_redaction_guards(self):
        self.assertIn("private static final boolean RECORDING_ENABLED = true;", RECORDER)
        initialize = method_body(RECORDER, "void initialize(Context context)")
        self.assertLess(initialize.index("if (!RECORDING_ENABLED) return;"), initialize.index("testStorage(preferred)"))
        for signature in (
            "void event(String source",
            "void headers(String source",
            "void network(String source",
            "void appendEvent(String source",
            "void flushForCrash()",
            "void finish(String reason)",
        ):
            self.assertIn("if (!RECORDING_ENABLED) return;", method_body(RECORDER, signature))

    def test_raw_headers_are_never_stringified(self):
        headers = method_body(RECORDER, "void headers(String source")
        self.assertIn("DiagnosticRedactor.headerSummary(headers)", headers)
        self.assertNotIn("String.valueOf(headers)", headers)

    def test_both_payloads_are_redacted_before_enqueue_and_write(self):
        append = method_body(RECORDER, "void appendEvent(String source")
        self.assertIn("DiagnosticRedactor.redactText(requestBody)", append)
        self.assertIn("DiagnosticRedactor.redactText(responseBody)", append)
        self.assertIn("DiagnosticRedactor.redactText(data.toString())", append)
        payload = method_body(RECORDER, "JSONObject writePayload(String name")
        self.assertIn("DiagnosticRedactor.redactText(text)", payload)

    def test_trace_line_is_redacted_before_logcat(self):
        self.assertIn("if (!DiagnosticsRecorder.isRecordingEnabled()) return;", APP)
        self.assertIn("String safeLine = DiagnosticRedactor.redactText(line);", APP)
        self.assertIn("android.util.Log.d(tag, safeLine);", APP)
        self.assertLess(
            APP.index("if (!DiagnosticsRecorder.isRecordingEnabled()) return;"),
            APP.index("android.util.Log.d(tag, safeLine);")
        )

    def test_summary_strings_are_redacted_before_serialization(self):
        summary = method_body(RECORDER, "void writeSummary(String state)")
        for expression in (
            "storagePath",
            "sessionDir.getAbsolutePath()",
            "storageFallbackReason",
            "storageFailure",
        ):
            self.assertIn(f'DiagnosticRedactor.redactText({expression}', summary)


if __name__ == "__main__":
    unittest.main(verbosity=2)
