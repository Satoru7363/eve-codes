#!/usr/bin/env python3
"""Static integration guards for Android-only paths unavailable to the plain JVM suite."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[4]
SRC = ROOT / "app/src/main"
BRIDGE = (SRC / "java/com/eve/cinema/moviebox/MovieBoxBridge.java").read_text(encoding="utf-8")
MODELS = (SRC / "java/com/eve/cinema/moviebox/MovieBoxModels.java").read_text(encoding="utf-8")
PLAYER = (SRC / "java/com/eve/cinema/PlayerActivity.java").read_text(encoding="utf-8")
PARSER = (SRC / "java/com/eve/cinema/playback/SubtitleParser.java").read_text(encoding="utf-8")
STRINGS = (SRC / "res/values/strings.xml").read_text(encoding="utf-8")
MANAGER = (SRC / "java/com/eve/cinema/SubtitleManager.java").read_text(encoding="utf-8")
EVIDENCE = (SRC / "java/com/eve/cinema/PlaybackSubtitleEvidence.java").read_text(encoding="utf-8")

class SubtitleSafetyWiring(unittest.TestCase):
    def test_active_alternate_resource_requires_metadata_match(self):
        self.assertIn("compatibleResource(playback.title", BRIDGE)
        self.assertIn('"ACTIVE_RESOURCE_REJECTED"', BRIDGE)
        self.assertIn("resourceIdentityVerified", BRIDGE)
        self.assertIn("p.isDocumentedSibling(o.subjectId), o.resourceIdentityVerified", MODELS)

    def test_model_delegates_to_exact_ownership_policy(self):
        self.assertIn("MovieBoxCaptionResourcePolicy.belongsTo", MODELS)

    def test_cross_release_caption_candidates_are_skipped_before_fetch(self):
        self.assertIn('"ARABIC_CROSS_RELEASE_CAPTIONS_SKIPPED"', BRIDGE)
        self.assertIn("same title/runtime cannot prove cut or audio timing across releases", BRIDGE)
        self.assertNotIn("captionsAt(sibling.subjectId", BRIDGE)

    def test_stale_async_load_cannot_replace_current_track(self):
        self.assertIn("generation.incrementAndGet()", MANAGER)
        self.assertIn("if (generation.get() != gen) return", MANAGER)
        self.assertIn("new SubtitleTimeline(Collections.emptyList())", MANAGER)

    def test_position_discontinuity_ticks_even_when_paused(self):
        body = PLAYER.split("public void onPositionDiscontinuity", 1)[1].split("public void onTimelineChanged", 1)[0]
        self.assertIn("subtitleManager.tick", body)
        self.assertIn("newPosition.positionMs", body)

    def test_seekbar_scrub_ticks_at_target_position(self):
        body = PLAYER.split("public void onProgressChanged", 1)[1].split("public void onStartTrackingTouch", 1)[0]
        self.assertIn("exoPlayer.seekTo(pos)", body)
        self.assertIn("subtitleManager.tick(pos)", body)

    def test_parsed_external_subtitle_is_explicitly_unverified_and_adjustable(self):
        self.assertIn('"subtitle_sync", "unverified"', PLAYER)
        self.assertIn("setOnLongClickListener", PLAYER)
        self.assertIn("showSubtitleSyncDialog()", PLAYER)
        self.assertIn("player_subtitle_sync_unverified", PLAYER)

    def test_absence_copy_is_about_external_evidence_not_burned_in_text(self):
        self.assertIn("قد يحتوي الفيديو على نص عربي بالصورة", STRINGS)
        self.assertIn("ترجمة عربية خارجية", STRINGS)
        self.assertIn("نسخة ترجمة عربية داخل الفيديو", STRINGS)
        self.assertIn("لم يُتحقق من التزامن", STRINGS)

    def test_player_does_not_claim_burned_in_text_detection(self):
        self.assertIn("setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)", PLAYER)
        self.assertNotIn("burned_in_detected", PLAYER)

    def test_cue_evidence_uses_the_production_parser_cue_type(self):
        self.assertIn("SubtitleParser.Cue", EVIDENCE)
        self.assertNotIn("SubtitleManager.Cue", EVIDENCE)

    def test_play_info_resource_fallback_uses_the_shared_page_plan(self):
        self.assertIn("MovieBoxSubtitleResourcePlanner.pageOrder(episode)", BRIDGE)
        self.assertNotIn("resourcePages(episode)", BRIDGE)

    def test_parser_timestamp_regex_is_anchored_and_range_checked(self):
        self.assertIn("private static final Pattern TIME", PARSER)
        self.assertIn("Math.multiplyExact", PARSER)
        self.assertIn("end <= start", PARSER)

if __name__ == "__main__":
    unittest.main(verbosity=2)
