# Recorded MovieBox responses (scrubbed) — replay fixtures

Source: the three diagnostic sessions in `docs/AGENT_HANDOFF.md` §3. Secrets (`signCookie`, `sign=`, `t=`,
`Signature`, `Policy`) were replaced by `<REDACTED>`. Names: `<Session>_<endpoint>_<subjectId>[_r<resourceId>].json`
(`search_v2_search*.json` = search/v2 responses; several searches per session, de-duplicated by content).

| Session | Meaning |
|---|---|
| `A_` | 2026-10-11 ~09:58 — Spider-Man: Brand New Day + Tangled (the original C1-hotfix evidence) |
| `B_` | 2026-10-12 ~06:24 — CinemaBox outage session: Spider-Man, Swapped, Frozen (+ their dub / "Arabic sub" releases) |
| `C_` | 2026-10-12 ~11:29 — after CinemaBox recovery: Swapped / Frozen / Spider-Man, Swapped Arabic dub playback |

Subjects: Spider-Man `6026412232966389904` (Arabic-sub release `8206595508174050336`) · Tangled `5361417278070342968`
(Arabic dub `…` see A_get) · Swapped `5600808304957183512` (Arabic dub `7205258608995882512`) ·
Frozen `3361412976908583976` (Arabic dub `5896110727550697776`, Arabic sub `1621679319460236088`).

`captions_timing/spiderman_8700s_<lang>.timing.tsv`: cue start/end (ms) only, **text stripped**, from the five
external captions MovieBox returned for Spider-Man (en, es, fr, id, pt). Used to calibrate the cross-language
timing "sync gate" (see handoff §6.4). No Arabic caption file has ever been captured yet.

NOTE: In sessions B and C every play-info stream and every /resource row carries the SAME placeholder
`macdn.aoneroom.com/other/2026/10/10/80da5272…mp4` with `duration: 23`. That is a notice/trailer placeholder, not
the film; the real media comes only from `signCookie` → DASH (`sacdn.hakunaymatata.com/dash/<subjectId>_…/index.mpd`).
