package com.eve.cinema;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.dash.DashMediaSource;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import com.eve.cinema.extractor.CinemaBoxExtractor;
import com.eve.cinema.moviebox.MovieBoxModels;
import com.eve.cinema.moviebox.MovieBoxTitleCleaner;

import androidx.media3.common.Format;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import com.eve.cinema.moviebox.MovieBoxBridge;
import com.eve.cinema.playback.LanguageMatcher;
import com.eve.cinema.playback.ModeResolver;
import com.eve.cinema.playback.NextEpisodeWindow;
import com.eve.cinema.playback.PlaybackMode;
import com.eve.cinema.playback.QualityPlanner;
import com.eve.cinema.playback.EpisodeNavigator;
import com.eve.cinema.playback.SourceSwitchValidator;
import com.eve.cinema.playback.SubtitleFetcher;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ═══════════════════════════════════════════════════════════
 *  PlayerActivity — إيف سينما — مشغل سينمائي احترافي
 *  Powered by ExoPlayer (AndroidX Media3)
 *
 *  Features:
 *  ✅ ExoPlayer with HLS / MP4 / Adaptive streams
 *  ✅ True immersive fullscreen (sticky)
 *  ✅ Premium gesture controller (swipe/tap/pinch)
 *  ✅ Volume & Brightness swipe control
 *  ✅ Double-tap seek with animation
 *  ✅ Pinch-to-zoom
 *  ✅ 5 resize modes (Fit/Zoom/Fill/FixedW/FixedH)
 *  ✅ Professional subtitle engine (SRT + VTT)
 *  ✅ Quality bottom sheet
 *  ✅ Playback speed selector
 *  ✅ Skip intro scheduling
 *  ✅ Next episode auto-advance
 *  ✅ Controls lock / unlock
 *  ✅ Auto reconnect on network error
 *  ✅ Proper lifecycle management (no leaks)
 * ═══════════════════════════════════════════════════════════
 */
@OptIn(markerClass = UnstableApi.class)
public class PlayerActivity extends Activity {

    // ───────────────────────────────────────────────────────
    //  Constants
    // ───────────────────────────────────────────────────────
    private static final int  CONTROLS_AUTO_HIDE_MS  = 4_000;
    private static final long SEEK_STEP_MS           = 10_000L;
    private static final int  PROGRESS_UPDATE_MS     = 500;
    private static final int  VB_INDICATOR_HIDE_MS   = 1_600;
    private static final int  MAX_RETRY_ATTEMPTS     = 3;
    private static final int  SEEK_INDICATOR_DURATION= 600;

    // ── Watch Progress ────────────────────────────────────
    /** اسم ملف التفضيلات المشترك لحفظ مواضع المشاهدة */
    private static final String PREFS_WATCH          = "eve_watch_progress";
    /** لا تستعد إذا كان الموضع أقل من 10 ثوانٍ (ربما بدأ للتو) */
    private static final long   RESUME_MIN_MS        = 10_000L;
    /** اعتبره مكتملاً عند 92% — امسح السجل */
    private static final float  COMPLETE_RATIO       = 0.92f;
    /** احفظ الموضع كل 30 ثانية أثناء التشغيل */
    private static final long   AUTO_SAVE_INTERVAL   = 30_000L;

    // ───────────────────────────────────────────────────────
    //  Intent data
    // ───────────────────────────────────────────────────────
    private int    episodeId      = -1;
    private String tmdbId         = "";
    private String mediaType      = "movie";
    private String title          = "";
    private int    currentSeason  = 1;
    private int    currentEpisode = 1;

    // ───────────────────────────────────────────────────────
    //  ExoPlayer
    // ───────────────────────────────────────────────────────
    private ExoPlayer            exoPlayer;
    private DefaultTrackSelector trackSelector;
    private PlayerView           playerView;

    // ───────────────────────────────────────────────────────
    //  Views — Layout containers
    // ───────────────────────────────────────────────────────
    private View          gestureOverlay;
    private View          controlsOverlay;
    private View          topBar;
    private View          bottomBar;
    private View          centerControls;

    // ── Top bar ──────────────────────────────────────────
    private ImageButton   btnBack;
    private TextView      tvTitle;
    private TextView      tvSeasonEp;
    private ImageButton   btnLock;

    // ── Center ───────────────────────────────────────────
    private ImageButton   btnPlayPause;
    private View          btnRewind;
    private View          btnForward;

    // ── Bottom bar ───────────────────────────────────────
    private SeekBar       seekBar;
    private TextView      tvCurrentTime;
    private TextView      tvTotalTime;
    private TextView      btnSpeed;
    private TextView      btnSubtitle;
    private TextView      btnQuality;
    private ImageButton   btnResize;
    private TextView      btnSubSizeDown;
    private TextView      btnSubSizeUp;

    // Subtitle text size
    private float         subtitleTextSizeSp = 18f;
    private static final float SUB_SIZE_MIN  = 12f;
    private static final float SUB_SIZE_MAX  = 30f;
    private static final float SUB_SIZE_STEP = 2f;

    // Buffering state (hide center controls during loading)
    private boolean       isBuffering        = false;

    // ── Overlays ─────────────────────────────────────────
    private View          loadingOverlay;
    private TextView      tvBufferingPct;
    private View          errorOverlay;
    private TextView      tvError;
    private View          btnRetry;

    // ── VB Indicator ─────────────────────────────────────
    private View          vbIndicator;
    private ImageView     ivVbIcon;
    private ProgressBar   vbBar;

    // ── Seek Indicators ──────────────────────────────────
    private View          seekIndicatorLeft;
    private View          seekIndicatorRight;

    // ── Lock ─────────────────────────────────────────────
    private View          lockOverlay;
    private ImageButton   btnUnlock;

    // ── Floating buttons ─────────────────────────────────
    private TextView      btnSkipIntro;
    private View          nextEpisodeCard;
    // Next-episode button state. The card is shown only while a valid next episode
    // exists AND the controls are visible AND <= 60 s remain (NextEpisodeWindow).
    private boolean       nextEpisodeAvailable     = false; // cached per episode
    private boolean       nextEpisodeTargetVisible = false; // last state we animated to

    // ── Subtitle ─────────────────────────────────────────
    private CinemaSubtitleView subtitleView;

    // ───────────────────────────────────────────────────────
    //  State
    // ───────────────────────────────────────────────────────
    private CinemaBoxExtractor.MediaResult currentMedia;
    // ── MovieBox provider mode (fallback path) ──────────────
    private MovieBoxModels.Playback movieboxPlayback;
    private int     movieboxStreamIndex = 0;
    private EpisodeNavigator.Provider currentProvider = EpisodeNavigator.Provider.CINEMABOX;

    // ── Viewing mode / real qualities ──
    private static final long MODE_DISCOVERY_TIMEOUT_MS = 8_000L;
    private PlaybackMode requestedMode;          // chosen pre-playback, kept across episodes
    private PlaybackMode effectiveMode;          // what is actually applied now
    private boolean awaitingModeDecision = false;
    private boolean playbackBlocked = false; // P7 fail-safe: anime without a MovieBox payload
    private int     discoveryGeneration  = 0;
    private int     extractionGeneration = 0;
    private int     captionGeneration = 0;
    private boolean playAfterDecision    = true;
    private boolean dubConflict          = false;
    private String  pendingAudioLanguage;
    private boolean verifyAudioOnTracksChanged;
    private boolean audioRetryApplied;
    private boolean adaptiveMenuUsed     = false;
    private final List<SubChoice> currentSubChoices = new ArrayList<>();
    private int     selectedVideoHeight  = 0;    // 0 = Auto (adaptive)
    private String  srcSearchTitle = "";
    private String  srcOriginalTitle = null;
    private int     srcYear = 0;
    private String  tmdbSeasonCountsJson = null;
    private int     tmdbSeason = 1, tmdbEpisode = 1;
    private int     navGeneration = 0;   // guards async next-episode navigation
    private int     pendingVideoRestoreHeight;

    /** One subtitle candidate with the provider headers needed to download it. */
    private static final class SubChoice {
        final String language;
        final String url;
        final Map<String, String> headers;
        SubChoice(String language, String url, Map<String, String> headers) {
            this.language = language; this.url = url; this.headers = headers;
        }
    }

    private String  currentStreamUrl  = "";
    private String  currentQuality    = "";
    private boolean controlsVisible   = true;
    private boolean isLocked          = false;
    private boolean subtitlesEnabled  = false;
    private boolean hasSubtitles      = false;
    private boolean isUserSeeking     = false;
    private boolean resumeApplied     = false; // true once saved position is applied per load
    private int     retryCount        = 0;
    private long    pendingSeekMs     = 0L;
    private float   playbackSpeed     = 1.0f;

    // Resize mode cycling — auto-selected on first video frame, then user can cycle
    private int     resizeModeIndex   = 0;
    private final int[] RESIZE_MODES  = {
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    };
    private final String[] RESIZE_LABELS = {"احتواء", "ملء", "ارتفاع ثابت"};

    // Pinch zoom
    private float scaleFactor = 1f;

    // ───────────────────────────────────────────────────────
    //  Audio / Brightness
    // ───────────────────────────────────────────────────────
    private AudioManager audioManager;
    private int          maxVolume;
    private float        currentBrightness = -1f;

    // ───────────────────────────────────────────────────────
    //  Threading
    // ───────────────────────────────────────────────────────
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler         handler  = new Handler(Looper.getMainLooper());

    // ───────────────────────────────────────────────────────
    //  Managers
    // ───────────────────────────────────────────────────────
    private SubtitleManager subtitleManager;

    // ───────────────────────────────────────────────────────
    //  Gesture detectors
    // ───────────────────────────────────────────────────────
    private GestureDetector      gestureDetector;
    private ScaleGestureDetector scaleDetector;

    // Swipe tracking
    private boolean swipeIsVertical    = false;
    private boolean swipeIsBrightness  = false;
    private boolean swipeInitialized   = false;

    // ───────────────────────────────────────────────────────
    //  Runnables
    // ───────────────────────────────────────────────────────
    private final Runnable hideControlsRunnable = this::hideControls;
    private final Runnable progressRunnable     = this::updateProgress;
    private final Runnable hideVbRunnable       = this::dismissVbIndicator;
    private final Runnable autoSaveRunnable     = this::autoSaveCycle;
    // تأخير إنزال الترجمة حتى تنتهي أنيميشن اختفاء أزرار التحكم (220ms)
    private final Runnable subtitleHideRunnable = () -> setSubtitleBottomMargin(24);

    // ════════════════════════════════════════════════════════
    //  Lifecycle
    // ════════════════════════════════════════════════════════

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
        setContentView(R.layout.activity_player);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        maxVolume    = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        parseIntent();
        bindViews();
        setupExoPlayer();
        setupGestures();
        setupClickListeners();
        enterImmersiveMode();
        startExtraction();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(autoSaveRunnable);
        persistWatchPosition(); // immediate save on any pause (screen off, back, switch app)
        if (exoPlayer != null) exoPlayer.pause();
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onStop() {
        super.onStop();
        persistWatchPosition(); // belt-and-suspenders: also save on stop
    }

    @Override
    protected void onResume() {
        super.onResume();
        enterImmersiveMode();
        if (exoPlayer != null && !exoPlayer.isPlaying() && !awaitingModeDecision
                && exoPlayer.getPlaybackState() == Player.STATE_READY) {
            exoPlayer.play();
            handler.post(progressRunnable);
            scheduleHideControls();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        executor.shutdown();
        if (subtitleManager != null) subtitleManager.release();
        releasePlayer();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (isLocked) {
            animatePulse(btnUnlock);
            return;
        }
        super.onBackPressed();
    }

    // ════════════════════════════════════════════════════════
    //  Window
    // ════════════════════════════════════════════════════════

    private void setupWindow() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        // Force landscape
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN            |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION       |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY      |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE         |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN     |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
    }

    // ════════════════════════════════════════════════════════
    //  Intent Parsing
    // ════════════════════════════════════════════════════════

    private void parseIntent() {
        Intent intent = getIntent();
        Uri    data   = intent.getData();

        // MovieBox fallback handoff: a fully-resolved playback payload.
        String mbPayload = intent.getStringExtra("moviebox_payload");
        if (mbPayload != null && !mbPayload.isEmpty()) {
            try {
                movieboxPlayback =
                    MovieBoxModels.Playback.fromJson(new org.json.JSONObject(mbPayload));
            } catch (Exception ignored) {}
            if (movieboxPlayback != null && movieboxPlayback.streams.isEmpty())
                movieboxPlayback = null;
        }
        currentProvider = movieboxPlayback != null
                ? EpisodeNavigator.Provider.MOVIEBOX : EpisodeNavigator.Provider.CINEMABOX;

        if (data != null && "eve-cinema".equals(data.getScheme())) {
            String epId = data.getQueryParameter("episode_id");
            if (epId == null) epId = data.getQueryParameter("cbid");
            if (epId != null) {
                try { episodeId = Integer.parseInt(epId); } catch (Exception ignored) {}
            }
            tmdbId    = nvl(data.getQueryParameter("tid"));
            mediaType = nvl(data.getQueryParameter("type"), "movie");
            title     = nvl(data.getQueryParameter("title"));
            String s  = data.getQueryParameter("season");
            String e  = data.getQueryParameter("episode");
            if (s != null) try { currentSeason  = Integer.parseInt(s); } catch (Exception ignored) {}
            if (e != null) try { currentEpisode = Integer.parseInt(e); } catch (Exception ignored) {}
        } else {
            episodeId      = intent.getIntExtra("episode_id", -1);
            if (episodeId == -1) episodeId = intent.getIntExtra("cinema_box_id", -1);
            tmdbId         = nvl(intent.getStringExtra("tmdb_id"));
            mediaType      = nvl(intent.getStringExtra("media_type"), "movie");
            title          = nvl(intent.getStringExtra("title"));
            currentSeason  = intent.getIntExtra("season", 1);
            currentEpisode = intent.getIntExtra("episode", 1);
        }

        srcSearchTitle       = nvl(intent.getStringExtra("search_title"), title);
        srcOriginalTitle     = intent.getStringExtra("original_title");
        srcYear              = intent.getIntExtra("year", 0);
        tmdbSeasonCountsJson = intent.getStringExtra("tmdb_season_counts");
        // The viewing mode is chosen BEFORE the player opens (portrait detail /
        // episodes screen) and arrives here as a final decision. The player
        // never asks again; it only degrades to English/original when the
        // chosen mode turns out to be unavailable on the actual tracks.
        requestedMode = PlaybackMode.fromName(intent.getStringExtra("requested_mode"));
        tmdbSeason           = currentSeason;
        tmdbEpisode          = currentEpisode;
        if (movieboxPlayback != null) {
            if (movieboxPlayback.tmdbSeason > 0) tmdbSeason = currentSeason = movieboxPlayback.tmdbSeason;
            if (movieboxPlayback.tmdbEpisode > 0) tmdbEpisode = currentEpisode = movieboxPlayback.tmdbEpisode;
            if ((tmdbSeasonCountsJson == null || tmdbSeasonCountsJson.isEmpty())
                    && !movieboxPlayback.tmdbSeasonCounts.isEmpty()) {
                org.json.JSONObject counts = new org.json.JSONObject();
                try {
                    for (Map.Entry<Integer, Integer> e : movieboxPlayback.tmdbSeasonCounts.entrySet())
                        counts.put(String.valueOf(e.getKey()), e.getValue());
                    tmdbSeasonCountsJson = counts.toString();
                } catch (Exception ignored) {}
            }
        }

        // MovieBox mode: derive a stable synthetic id so watch-progress
        // persistence keeps working (CinemaBox episode ids don't exist here).
        // Keyed on the CANONICAL subject so a dub release shares the base
        // work's saved position instead of starting a parallel history.
        if (movieboxPlayback != null && episodeId == -1) {
            episodeId = movieBoxEpisodeId(movieboxPlayback.canonicalSubjectId(),
                    tmdbSeason, tmdbEpisode);
        }

        // P7 fail-safe: anime is MovieBox-only. A CinemaBox episode id for an
        // anime means a caller bypassed the routing policy — refuse to play
        // rather than risk an unmapped/wrong episode.
        if ("anime".equals(mediaType) && movieboxPlayback == null) {
            playbackBlocked = true; // onCreate continues; startExtraction refuses
            Toast.makeText(this, R.string.player_anime_moviebox_only, Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        if (episodeId == -1 && movieboxPlayback == null) {
            Toast.makeText(this, "خطأ: لم يُحدَّد المحتوى", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    // ════════════════════════════════════════════════════════
    //  Bind Views
    // ════════════════════════════════════════════════════════

    private void bindViews() {
        playerView        = findViewById(R.id.player_view);
        gestureOverlay    = findViewById(R.id.gesture_overlay);
        controlsOverlay   = findViewById(R.id.controls_overlay);
        topBar            = findViewById(R.id.top_bar);
        bottomBar         = findViewById(R.id.bottom_bar);
        centerControls    = findViewById(R.id.center_controls);

        // Top
        btnBack           = findViewById(R.id.btn_back);
        tvTitle           = findViewById(R.id.tv_title);
        tvSeasonEp        = findViewById(R.id.tv_season_ep);
        btnLock           = findViewById(R.id.btn_lock);

        // Center
        btnPlayPause      = findViewById(R.id.btn_play_pause);
        btnRewind         = findViewById(R.id.btn_rewind);
        btnForward        = findViewById(R.id.btn_forward);

        // Bottom
        seekBar           = findViewById(R.id.seekbar);
        tvCurrentTime     = findViewById(R.id.tv_current_time);
        tvTotalTime       = findViewById(R.id.tv_total_time);
        btnSpeed          = findViewById(R.id.btn_speed);
        btnSubtitle       = findViewById(R.id.btn_subtitle);
        btnQuality        = findViewById(R.id.btn_quality);
        btnResize         = findViewById(R.id.btn_resize);
        btnSubSizeDown    = findViewById(R.id.btn_sub_size_down);
        btnSubSizeUp      = findViewById(R.id.btn_sub_size_up);

        // Overlays
        loadingOverlay    = findViewById(R.id.loading_overlay);
        tvBufferingPct    = findViewById(R.id.tv_buffering_pct);
        errorOverlay      = findViewById(R.id.error_overlay);
        tvError           = findViewById(R.id.tv_error);
        btnRetry          = findViewById(R.id.btn_retry);

        // VB Indicator
        vbIndicator       = findViewById(R.id.vb_indicator);
        ivVbIcon          = findViewById(R.id.iv_vb_icon);
        vbBar             = findViewById(R.id.vb_bar);

        // Seek
        seekIndicatorLeft  = findViewById(R.id.seek_indicator_left);
        seekIndicatorRight = findViewById(R.id.seek_indicator_right);

        // Lock
        lockOverlay       = findViewById(R.id.lock_overlay);
        btnUnlock         = findViewById(R.id.btn_unlock);

        // Floating
        btnSkipIntro      = findViewById(R.id.btn_skip_intro);
        nextEpisodeCard   = findViewById(R.id.next_episode_card);

        // Subtitle
        subtitleView      = findViewById(R.id.subtitle_view);
        subtitleManager   = new SubtitleManager(subtitleView);

        // الحجم الابتدائي للترجمة من Settings → Playback (يظل قابلًا للضبط داخل المشغّل)
        subtitleTextSizeSp = SettingsStore.getSubtitleSizeSp(this);
        subtitleView.setTextSizeSp(subtitleTextSizeSp);


        // ── Initial state ──
        tvTitle.setText(title);
        if (!"movie".equals(mediaType)) {
            tvSeasonEp.setVisibility(View.VISIBLE);
            tvSeasonEp.setText(getString(R.string.player_season_episode,
                    currentSeason, currentEpisode));
        }

        updateSubtitleBtn(false, false);
        setQualityBadge("");
    }

    // ════════════════════════════════════════════════════════
    //  ExoPlayer Setup
    // ════════════════════════════════════════════════════════

    private void setupExoPlayer() {
        DiagnosticsRecorder.newTrace("playback");
        DiagnosticsRecorder.event("Media3", "player_setup", "started", DiagnosticsRecorder.details("title", title, "streamUrl", currentStreamUrl, "source", "unknown", "season", currentSeason, "episode", currentEpisode));
        trackSelector = new DefaultTrackSelector(this);
        trackSelector.setParameters(
            trackSelector.buildUponParameters()
                // ✅ تعطيل ترجمة ExoPlayer المدمجة — نستخدم CinemaSubtitleView بدلاً منها
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
        );

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
            .setUserAgent("CinemaBox/5.0 (Android; Media3)")
            .setDefaultRequestProperties(new java.util.HashMap<String, String>() {{
                put("Referer", "https://cinema.albox.co/");
                put("Origin",  "https://cinema.albox.co");
            }})
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true);

        exoPlayer = new ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(http))
            .build();

        exoPlayer.setAudioAttributes(
            new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            /* handleAudioFocus= */ true
        );
        exoPlayer.setHandleAudioBecomingNoisy(true);

        // Attach to PlayerView (no built-in controller)
        // Resize mode will be auto-selected by applyBestResizeMode() on first video frame
        playerView.setPlayer(exoPlayer);
        playerView.setUseController(false);

        exoPlayer.addListener(playerListener);
    }

    // ── ExoPlayer listener ──────────────────────────────
    private final Player.Listener playerListener = new Player.Listener() {

        @Override
        public void onPlaybackStateChanged(int state) {
            DiagnosticsRecorder.event("Media3", "player_state", "changed", DiagnosticsRecorder.details("title", title, "streamUrl", currentStreamUrl, "source", "unknown", "season", currentSeason, "episode", currentEpisode));
            switch (state) {
                case Player.STATE_BUFFERING:
                    isBuffering = true;
                    loadingOverlay.setVisibility(View.VISIBLE);
                    // Hide center controls so spinner is not obscured
                    if (centerControls != null)
                        centerControls.setVisibility(View.INVISIBLE);
                    break;

                case Player.STATE_READY:
                    isBuffering = false;
                    loadingOverlay.setVisibility(View.GONE);
                    // Restore center controls if controls panel is visible
                    if (centerControls != null && controlsVisible)
                        centerControls.setVisibility(View.VISIBLE);
                    retryCount = 0;
                    if (pendingSeekMs > 0) {
                        // تبديل الجودة — انتقل للموضع المحفوظ مؤقتاً
                        exoPlayer.seekTo(pendingSeekMs);
                        pendingSeekMs = 0;
                    } else if (!resumeApplied) {
                        resumeApplied = true;
                        applyResumeIfNeeded();
                    }
                    if (!isUserSeeking) {
                        handler.post(progressRunnable);
                        scheduleHideControls();
                    }
                    long dur = exoPlayer.getDuration();
                    if (dur > 0) tvTotalTime.setText(formatTime(dur));
                    break;

                case Player.STATE_ENDED:
                    isBuffering = false;
                    handler.removeCallbacks(progressRunnable);
                    onVideoEnded();
                    break;

                case Player.STATE_IDLE:
                    isBuffering = false;
                    loadingOverlay.setVisibility(View.GONE);
                    break;
            }
            // Duration may just have become known / playback ended / went idle.
            syncNextEpisodeButton();
        }

        @Override
        public void onPositionDiscontinuity(@NonNull Player.PositionInfo oldPosition,
                                            @NonNull Player.PositionInfo newPosition,
                                            int reason) {
            // Seeks (button, gesture, seek bar, skip-intro) land here. Re-evaluate
            // both the next-episode affordance and subtitle cue at the landed position,
            // including while paused (the periodic playing loop is not running then).
            syncNextEpisodeButton();
            if (subtitlesEnabled && subtitleManager != null)
                subtitleManager.tick(Math.max(0L, newPosition.positionMs));
        }

        @Override
        public void onTimelineChanged(@NonNull androidx.media3.common.Timeline timeline,
                                      int reason) {
            // New media / duration becoming available.
            syncNextEpisodeButton();
        }

        @Override
        public void onIsPlayingChanged(boolean playing) {
            DiagnosticsRecorder.event("Media3", "is_playing", playing ? "playing" : "paused", DiagnosticsRecorder.details("source", "unknown", "season", currentSeason, "episode", currentEpisode, "mediaId", exoPlayer == null || exoPlayer.getCurrentMediaItem() == null ? "" : exoPlayer.getCurrentMediaItem().mediaId));
            updatePlayPauseIcon(playing);
            if (playing) {
                handler.post(progressRunnable);
                scheduleHideControls();
                // بدء الحفظ الدوري كل 30 ثانية
                handler.removeCallbacks(autoSaveRunnable);
                handler.postDelayed(autoSaveRunnable, AUTO_SAVE_INTERVAL);
            } else {
                handler.removeCallbacks(progressRunnable);
                handler.removeCallbacks(hideControlsRunnable);
                handler.removeCallbacks(autoSaveRunnable);
                showControls();
            }
        }

        @Override
        public void onTracksChanged(@NonNull Tracks tracks) {
            if (awaitingModeDecision && !tracks.getGroups().isEmpty()) decideMode();
            if (verifyAudioOnTracksChanged && !tracks.getGroups().isEmpty())
                verifyAudioSelection();
            if (pendingVideoRestoreHeight > 0 && currentIsAdaptive()) {
                QualityPlanner.VideoTrack restore = QualityPlanner.match(
                        QualityPlanner.options(realVideoTracks()), pendingVideoRestoreHeight);
                pendingVideoRestoreHeight = 0;
                if (restore != null) applyVideoTrack(restore);
            }
            refreshQualityBadge();
        }

        @Override
        public void onVideoSizeChanged(@NonNull androidx.media3.common.VideoSize videoSize) {
            if (videoSize.width == 0 || videoSize.height == 0) return;
            applyBestResizeMode(videoSize.width, videoSize.height);
            refreshQualityBadge();
        }

        @Override
        public void onRenderedFirstFrame() {
            refreshQualityBadge();
        }

        @Override
        public void onPlayerError(@NonNull PlaybackException error) {
            DiagnosticsRecorder.event("Media3", "player_error", "failed", DiagnosticsRecorder.details("errorCodeName", error.getErrorCodeName(), "message", error.getMessage(), "stackTrace", android.util.Log.getStackTraceString(error), "title", title, "source", "unknown", "season", currentSeason, "episode", currentEpisode));
            isBuffering = false;
            awaitingModeDecision = false;
            loadingOverlay.setVisibility(View.GONE);
            // Restore center controls (error overlay will cover screen anyway)
            if (centerControls != null && controlsVisible)
                centerControls.setVisibility(View.VISIBLE);
            boolean isNetwork =
                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS;

            if (isNetwork && retryCount < MAX_RETRY_ATTEMPTS) {
                retryCount++;
                long delay = 2000L * retryCount;
                tvError.setText("جاري إعادة الاتصال... (" + retryCount + "/" + MAX_RETRY_ATTEMPTS + ")");
                errorOverlay.setVisibility(View.VISIBLE);
                handler.postDelayed(() -> {
                    if (exoPlayer != null) {
                        errorOverlay.setVisibility(View.GONE);
                        exoPlayer.prepare();
                    }
                }, delay);
            } else {
                showError("تعذّر تشغيل الفيديو\n" + getErrorMessage(error));
            }
        }

        private String getErrorMessage(PlaybackException e) {
            switch (e.errorCode) {
                case PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED:
                    return "تحقق من اتصالك بالإنترنت";
                case PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND:
                    return "الرابط غير متوفر";
                case PlaybackException.ERROR_CODE_DECODER_INIT_FAILED:
                    return "خطأ في مشفر الفيديو";
                default:
                    return "رمز الخطأ: " + e.errorCode;
            }
        }
    };

    // ════════════════════════════════════════════════════════
    //  Gesture Setup
    // ════════════════════════════════════════════════════════

    private void setupGestures() {

        gestureDetector = new GestureDetector(this,
            new GestureDetector.SimpleOnGestureListener() {

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (isLocked) { animatePulse(btnUnlock); return true; }
                toggleControls();
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (isLocked || exoPlayer == null) return false;
                boolean right = e.getX() > gestureOverlay.getWidth() / 2f;
                if (right) {
                    animateSeekIndicator(true);
                    seekRelative(SEEK_STEP_MS);
                } else {
                    animateSeekIndicator(false);
                    seekRelative(-SEEK_STEP_MS);
                }
                resetHideTimer();
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2,
                                    float distX, float distY) {
                if (isLocked || exoPlayer == null || e1 == null) return false;

                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();

                // Only vertical swipe — determine side on first move
                if (!swipeInitialized) {
                    if (Math.abs(dy) < 18f) return false; // ignore tiny moves
                    swipeInitialized  = true;
                    swipeIsVertical   = true;
                    swipeIsBrightness = e1.getX() < gestureOverlay.getWidth() / 2f;
                }

                if (swipeIsVertical) {
                    float height = gestureOverlay.getHeight();
                    float delta  = -dy / height; // upward = positive
                    if (swipeIsBrightness) adjustBrightness(delta * 0.5f);
                    else                  adjustVolume(delta * 0.5f);
                }
                return true;
            }
        });

        gestureDetector.setIsLongpressEnabled(false);

        scaleDetector = new ScaleGestureDetector(this,
            new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                if (isLocked) return false;
                scaleFactor *= d.getScaleFactor();
                scaleFactor  = Math.max(0.8f, Math.min(scaleFactor, 2.8f));
                playerView.setScaleX(scaleFactor);
                playerView.setScaleY(scaleFactor);
                return true;
            }
        });

        gestureOverlay.setOnTouchListener((v, event) -> {
            int action = event.getActionMasked();

            // Dispatch to detectors
            scaleDetector.onTouchEvent(event);
            if (!scaleDetector.isInProgress()) {
                gestureDetector.onTouchEvent(event);
            }

            // Reset swipe state on finger lift
            if (action == MotionEvent.ACTION_UP
                    || action == MotionEvent.ACTION_CANCEL
                    || action == MotionEvent.ACTION_POINTER_UP) {
                swipeInitialized  = false;
                swipeIsVertical   = false;
                dismissVbIndicator();
            }
            return true;
        });
    }

    // ════════════════════════════════════════════════════════
    //  Click Listeners
    // ════════════════════════════════════════════════════════

    private void setupClickListeners() {
        btnBack.setOnClickListener(v -> onBackPressed());
        btnPlayPause.setOnClickListener(v -> togglePlayPause());

        btnRewind.setOnClickListener(v -> {
            animateSeekIndicator(false);
            seekRelative(-SEEK_STEP_MS);
        });
        btnForward.setOnClickListener(v -> {
            animateSeekIndicator(true);
            seekRelative(SEEK_STEP_MS);
        });

        // Seekbar
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser && exoPlayer != null) {
                    long dur = exoPlayer.getDuration();
                    if (dur > 0) {
                        long pos = (long)(dur * (progress / 1000.0));
                        exoPlayer.seekTo(pos);
                        if (subtitlesEnabled && subtitleManager != null) subtitleManager.tick(pos);
                        tvCurrentTime.setText(formatTime(pos));
                    }
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {
                isUserSeeking = true;
                handler.removeCallbacks(hideControlsRunnable);
            }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                isUserSeeking = false;
                scheduleHideControls();
            }
        });

        // Subtitle toggle
        btnSubtitle.setOnClickListener(v -> {
            if (!hasSubtitles) return;
            subtitlesEnabled = !subtitlesEnabled;
            subtitleManager.setEnabled(subtitlesEnabled);
            updateSubtitleBtn(true, subtitlesEnabled);
            // Show/hide size buttons based on subtitle state
            int sizeVis = subtitlesEnabled ? View.VISIBLE : View.GONE;
            btnSubSizeDown.setVisibility(sizeVis);
            btnSubSizeUp.setVisibility(sizeVis);
            resetHideTimer();
        });

        // Long-press CC opens manual calibration; loading/parsing is not sync proof.
        btnSubtitle.setOnLongClickListener(v -> {
            if (!hasSubtitles || !subtitlesEnabled) return true;
            showSubtitleSyncDialog();
            return true;
        });

        // Subtitle size down
        btnSubSizeDown.setOnClickListener(v -> {
            subtitleTextSizeSp = Math.max(SUB_SIZE_MIN, subtitleTextSizeSp - SUB_SIZE_STEP);
            subtitleView.setTextSizeSp(subtitleTextSizeSp);
            resetHideTimer();
        });

        // Subtitle size up
        btnSubSizeUp.setOnClickListener(v -> {
            subtitleTextSizeSp = Math.min(SUB_SIZE_MAX, subtitleTextSizeSp + SUB_SIZE_STEP);
            subtitleView.setTextSizeSp(subtitleTextSizeSp);
            resetHideTimer();
        });

        // Quality
        btnQuality.setOnClickListener(v -> { showQualitySheet(); resetHideTimer(); });

        // Resize mode cycle
        btnResize.setOnClickListener(v -> { cycleResize(); resetHideTimer(); });

        // Lock
        btnLock.setOnClickListener(v -> setLocked(true));
        btnUnlock.setOnClickListener(v -> setLocked(false));

        // Speed
        btnSpeed.setOnClickListener(v -> showSpeedSheet());

        // Retry
        btnRetry.setOnClickListener(v -> {
            errorOverlay.setVisibility(View.GONE);
            retryCount = 0;
            startExtraction();
        });

        // Skip intro — seek to end of intro, clear window, and explicitly hide button
        btnSkipIntro.setOnClickListener(v -> {
            Object tag = btnSkipIntro.getTag();
            if (tag instanceof Long && exoPlayer != null) {
                exoPlayer.seekTo((Long) tag);
            }
            introEndMs = -1L; // mark window closed so syncIntroButton won't reopen it
            fadeOut(btnSkipIntro); // hide explicitly — syncIntroButton returns early when introEndMs<0
        });

        // Next episode — reads next_episode_id put by EpisodesActivity.launchPlayer()
        nextEpisodeCard.setOnClickListener(v -> {
            if (!nextEpisodeAvailable) return; // no valid next episode (e.g. mid fade-out)
            if (currentProvider == EpisodeNavigator.Provider.MOVIEBOX) {
                goNextEpisode(-1);
                return;
            }
            int nextId = getIntent().getIntExtra("next_episode_id", -1);
            if (nextId != -1) goNextEpisode(nextId);
        });
    }

    // ════════════════════════════════════════════════════════
    //  Extraction & Playback
    // ════════════════════════════════════════════════════════

    private void startExtraction() {
        if (playbackBlocked) return; // anime policy violation — do not play anything
        if (movieboxPlayback != null) {
            startMovieBoxPlayback();
            return;
        }
        showLoading(true);
        errorOverlay.setVisibility(View.GONE);
        resumeApplied = false; // allow restore for this new episode
        final int targetId = episodeId;
        final int gen = ++extractionGeneration;

        executor.execute(() -> {
            try {
                CinemaBoxExtractor ex = CinemaBoxBridge.ensureLoggedIn();
                final CinemaBoxExtractor.MediaResult media = ex.getStream(targetId);

                if (media == null || media.videos == null || media.videos.isEmpty()) {
                    throw new Exception("لا توجد روابط بث متاحة");
                }

                handler.post(() -> {
                    if (isFinishing() || gen != extractionGeneration || targetId != episodeId
                            || movieboxPlayback != null) return;
                    showLoading(false);
                    beginCinemaBoxPlayback(media, -1L, true);
                });

            } catch (Exception e) {
                final String msg = e.getMessage() != null ? e.getMessage() : "خطأ غير متوقع";
                handler.post(() -> {
                    if (isFinishing() || gen != extractionGeneration || targetId != episodeId) return;
                    showLoading(false);
                    showError(msg);
                });
            }
        });
    }

    private void playStream(String url) {
        if (exoPlayer == null) return;
        DiagnosticsRecorder.event("Media3", "media_item_set", "started", DiagnosticsRecorder.details("title", title, "url", url, "quality", currentQuality, "season", currentSeason, "episode", currentEpisode));
        exoPlayer.setMediaItem(MediaItem.fromUri(url));
        exoPlayer.prepare();
        exoPlayer.setPlayWhenReady(true);
    }

    // ════════════════════════════════════════════════════════
    //  MovieBox playback path
    // ════════════════════════════════════════════════════════

    /**
     * The MovieBox payload is fully resolved upstream (Detail/Episodes), so
     * this only has to pick the initial stream, wire subtitles, and play.
     */
    private void startMovieBoxPlayback() {
        startMovieBoxPlayback(-1L, true);
    }

    /** @param resumeMs -1 = saved watch progress; otherwise exact position (switch/dub/rollback). */
    private void startMovieBoxPlayback(long resumeMs, boolean playWhenReady) {
        startMovieBoxPlayback(resumeMs, playWhenReady, -1);
    }

    private void startMovieBoxPlayback(long resumeMs, boolean playWhenReady, int preferredStreamIndex) {
        currentProvider = EpisodeNavigator.Provider.MOVIEBOX;
        if (preferredStreamIndex < 0) pendingVideoRestoreHeight = 0;
        showLoading(true);
        errorOverlay.setVisibility(View.GONE);
        resumeApplied = resumeMs >= 0;
        List<MovieBoxModels.StreamSource> streams = movieboxPlayback.streams;
        if (streams.isEmpty()) {
            showLoading(false);
            showError("لا توجد روابط بث متاحة من MovieBox");
            return;
        }
        // Prefer an adaptive manifest (real renditions come from Media3 tracks).
        int idx = preferredStreamIndex >= 0 && preferredStreamIndex < streams.size()
                ? preferredStreamIndex : 0;
        if (preferredStreamIndex < 0) {
            for (int i = 0; i < streams.size(); i++) {
                if (streams.get(i).isAdaptive()) { idx = i; break; }
            }
        }
        movieboxStreamIndex = idx;
        MovieBoxModels.StreamSource stream = streams.get(idx);
        currentStreamUrl = stream.url;
        selectedVideoHeight = 0;
        clearVideoOverride();
        currentQuality = stream.isAdaptive()
                ? getString(R.string.player_quality_auto)
                : stream.qualityLabel() + (stream.codec != null && !stream.codec.isEmpty()
                        ? " " + stream.codec : "");
        resetSubtitleState();
        setMovieBoxSubChoices(stream);
        if (movieboxPlayback.title != null && !movieboxPlayback.title.isEmpty())
            tvTitle.setText(movieboxPlayback.title);
        if (!"movie".equals(mediaType)) {
            tvSeasonEp.setVisibility(View.VISIBLE);
            tvSeasonEp.setText(getString(R.string.player_season_episode,
                    tmdbSeason, tmdbEpisode));
        }
        setQualityBadge(currentQuality);
        showLoading(false);
        playMovieBoxStream(stream, Math.max(0L, resumeMs), false);
        // Evaluate only AFTER the new media is set, so the previous episode's
        // (near-the-end) position/duration can never flash the button for this one.
        updateMovieBoxNextEpisodeVisibility();
        beginModeDiscovery(playWhenReady);
    }

    private void setMovieBoxSubChoices(MovieBoxModels.StreamSource stream) {
        currentSubChoices.clear();
        if (movieboxPlayback == null) return;
        final MovieBoxModels.Playback playback = movieboxPlayback;
        for (MovieBoxModels.SubtitleOption o : playback.subtitlesFor(stream)) {
            if (o == null || o.url == null || o.url.isEmpty()) continue;
            if (!MovieBoxModels.Playback.belongsTo(o, stream, playback)) continue;
            Map<String, String> h = new HashMap<>(o.headers);
            if (h.isEmpty() && stream != null) {
                String ua = stream.headers.get("User-Agent");
                String ref = stream.headers.get("Referer");
                if (ua != null) h.put("User-Agent", ua);
                if (ref != null) h.put("Referer", ref);
            }
            currentSubChoices.add(new SubChoice(o.languageEvidence(), o.url, h));
        }
        if (stream == null || stream.captionsResolved || stream.streamId == null
                || stream.streamId.isEmpty()) return;
        final int gen = ++captionGeneration;
        executor.execute(() -> {
            try {
                MovieBoxBridge.get(PlayerActivity.this).captionsFor(playback, stream);
            } catch (Exception ignored) {}
            handler.post(() -> {
                if (isFinishing() || gen != captionGeneration || playback != movieboxPlayback
                        || currentProvider != EpisodeNavigator.Provider.MOVIEBOX
                        || movieboxStreamIndex >= playback.streams.size()
                        || playback.streams.get(movieboxStreamIndex) != stream) return;
                setMovieBoxSubChoices(stream);
                if (awaitingModeDecision) {
                    if (exoPlayer != null && !exoPlayer.getCurrentTracks().getGroups().isEmpty())
                        decideMode();
                } else if (effectiveMode != null) {
                    if (requestedMode != null) {
                        applySubtitleForMode();
                    } else {
                        ModeResolver.Availability availability =
                                ModeResolver.evaluate(subtitleLanguages(), audioLanguages(),
                                        playback.arabicDub() != null
                                                && !LanguageMatcher.isArabic(playback.audioLanguage),
                                        playback.inVideoSubtitleRelease);
                        PlaybackMode resolved = ModeResolver.effectiveMode(effectiveMode, availability);
                        if (resolved != effectiveMode) applyMode(resolved, availability);
                        else applySubtitleForMode();
                    }
                }
            });
        });
    }

    private Map<Integer, Integer> episodeCounts() {
        Map<Integer, Integer> counts = parseSeasonCounts(tmdbSeasonCountsJson);
        if (movieboxPlayback != null) {
            for (Map.Entry<Integer, Integer> entry : movieboxPlayback.tmdbSeasonCounts.entrySet())
                if (!counts.containsKey(entry.getKey())) counts.put(entry.getKey(), entry.getValue());
        }
        return counts;
    }

    private int movieBoxEpisodeId(String subjectId, int season, int episode) {
        String id = subjectId == null ? "" : subjectId;
        return id.hashCode() + 31 * season + 131 * episode;
    }

    private void updateMovieBoxNextEpisodeVisibility() {
        refreshNextEpisodeAvailability();
    }

    // ── Next-episode button ──────────────────────────────────
    // Visibility is DERIVED, never timer-driven: it is re-evaluated from the real
    // player state whenever position (progress tick), seeks, duration, the episode
    // or the controls change — see NextEpisodeWindow for the rule.

    /** Recomputes (once per episode) whether a valid next episode exists, then re-syncs. */
    private void refreshNextEpisodeAvailability() {
        nextEpisodeAvailable = computeValidNextEpisode();
        syncNextEpisodeButton();
    }

    private boolean computeValidNextEpisode() {
        if ("movie".equals(mediaType)) return false;
        if (currentProvider == EpisodeNavigator.Provider.MOVIEBOX) {
            return movieboxPlayback != null
                    && EpisodeNavigator.next(tmdbSeason, tmdbEpisode, episodeCounts()) != null;
        }
        // CinemaBox: EpisodesActivity resolves next_episode_id. After advancing once
        // the extra is stale (it equals the episode now playing) and is not a next.
        int nextId = getIntent().getIntExtra("next_episode_id", -1);
        return nextId > 0 && nextId != episodeId;
    }

    /** Shows/hides the button from the live player state (idempotent, no flicker). */
    private void syncNextEpisodeButton() {
        if (nextEpisodeCard == null) return;
        boolean show = false;
        if (nextEpisodeAvailable && exoPlayer != null && !isLocked
                && exoPlayer.getPlaybackState() != Player.STATE_IDLE) {
            show = NextEpisodeWindow.shouldShow(true, controlsVisible,
                    exoPlayer.getDuration(), exoPlayer.getCurrentPosition());
        }
        setNextEpisodeCardVisible(show);
    }

    /** Fades the card only when the target state actually changes. */
    private void setNextEpisodeCardVisible(boolean show) {
        if (nextEpisodeCard == null || show == nextEpisodeTargetVisible) return;
        nextEpisodeTargetVisible = show;
        nextEpisodeCard.animate().cancel();
        if (show) {
            if (nextEpisodeCard.getVisibility() != View.VISIBLE) nextEpisodeCard.setAlpha(0f);
            nextEpisodeCard.setVisibility(View.VISIBLE);
            nextEpisodeCard.animate().alpha(1f).setDuration(220).start();
        } else {
            nextEpisodeCard.animate().alpha(0f).setDuration(220)
                    .withEndAction(() -> {
                        if (!nextEpisodeTargetVisible) nextEpisodeCard.setVisibility(View.GONE);
                    }).start();
        }
    }

    /** Episode change / teardown: hide at once and forget the previous episode's state. */
    private void hideNextEpisodeCardNow() {
        nextEpisodeAvailable = false;
        nextEpisodeTargetVisible = false;
        if (nextEpisodeCard == null) return;
        nextEpisodeCard.animate().cancel();
        nextEpisodeCard.setAlpha(0f);
        nextEpisodeCard.setVisibility(View.GONE);
    }

    /** CinemaBox playback for an already-extracted media result (main thread). */
    private void beginCinemaBoxPlayback(CinemaBoxExtractor.MediaResult media,
                                        long resumeMs, boolean playWhenReady) {
        beginCinemaBoxPlayback(media, resumeMs, playWhenReady, null);
    }

    private void beginCinemaBoxPlayback(CinemaBoxExtractor.MediaResult media,
                                        long resumeMs, boolean playWhenReady, String preferredUrl) {
        currentProvider = EpisodeNavigator.Provider.CINEMABOX;
        movieboxPlayback = null;
        currentMedia = media;
        errorOverlay.setVisibility(View.GONE);
        hideNextEpisodeCardNow();
        refreshNextEpisodeAvailability();
        CinemaBoxExtractor.VideoStream best = null;
        if (preferredUrl != null && media.videos != null) {
            for (CinemaBoxExtractor.VideoStream video : media.videos) {
                if (preferredUrl.equals(video.url)) { best = video; break; }
            }
        }
        if (best == null) {
            String prefQ = SettingsStore.getDefaultQuality(this);
            best = SettingsStore.QUALITY_AUTO.equals(prefQ)
                    ? media.getBestQuality() : media.getQuality(prefQ);
        }
        if (best == null) {
            showError("لا توجد روابط بث متاحة");
            return;
        }
        currentStreamUrl = best.url;
        currentQuality   = best.quality;
        selectedVideoHeight = 0;
        adaptiveMenuUsed = false;
        clearVideoOverride();
        resetSubtitleState();
        currentSubChoices.clear();
        if (media.subtitles != null) {
            for (CinemaBoxExtractor.SubtitleTrack t : media.subtitles) {
                if (t == null) continue;
                String u = (t.vttUrl != null && !t.vttUrl.isEmpty()) ? t.vttUrl : t.srtUrl;
                if (u != null && !u.isEmpty())
                    currentSubChoices.add(new SubChoice(t.language, u, SubtitleFetcher.cinemaBoxHeaders()));
            }
        }
        if (media.showTitle != null && !media.showTitle.isEmpty()) tvTitle.setText(media.showTitle);
        if (!"movie".equals(mediaType)) {
            tvSeasonEp.setVisibility(View.VISIBLE);
            tvSeasonEp.setText(getString(R.string.player_season_episode,
                    media.seasonNumber, media.episodeNumber));
        }
        setQualityBadge(currentQuality);
        if (media.introEnd > 0) scheduleSkipIntro(media.introStart, media.introEnd);
        resumeApplied = resumeMs >= 0;
        if (resumeMs >= 0) pendingSeekMs = resumeMs;
        if (exoPlayer == null) return;
        DiagnosticsRecorder.event("Media3", "media_item_set", "started", DiagnosticsRecorder.details("title", title, "url", currentStreamUrl, "quality", currentQuality, "provider", "MovieBox", "season", currentSeason, "episode", currentEpisode));
        exoPlayer.setMediaItem(MediaItem.fromUri(currentStreamUrl));
        exoPlayer.prepare();
        exoPlayer.setPlayWhenReady(false);
        beginModeDiscovery(playWhenReady);
    }

    private int parseQualityHeight(String quality) {
        if (quality == null) return -1;
        String q = quality.trim();
        int end = 0;
        while (end < q.length() && Character.isDigit(q.charAt(end))) end++;
        if (end == 0) return -1;
        try { return Integer.parseInt(q.substring(0, end)); }
        catch (NumberFormatException e) { return -1; }
    }

    /** Plays a MovieBox stream with its required headers/cookies injected. */
    private void playMovieBoxStream(MovieBoxModels.StreamSource stream, long resumeMs) {
        playMovieBoxStream(stream, resumeMs, true);
    }

    private void playMovieBoxStream(MovieBoxModels.StreamSource stream, long resumeMs,
                                    boolean playWhenReady) {
        if (exoPlayer == null || stream == null || stream.url == null) return;

        Map<String, String> props = new HashMap<>(stream.headers);
        String ua = props.remove("User-Agent");
        if (ua == null || ua.isEmpty()) ua = "EveCinema/4.0 (Android; Media3)";

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setDefaultRequestProperties(props)
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true);

        MediaItem item = MediaItem.fromUri(stream.url);
        MediaSource source = stream.isDash()
            ? new DashMediaSource.Factory(http).createMediaSource(item)
            : new DefaultMediaSourceFactory(http).createMediaSource(item); // HLS or progressive

        pendingSeekMs = resumeMs;
        exoPlayer.setMediaSource(source);
        exoPlayer.prepare();
        exoPlayer.setPlayWhenReady(playWhenReady);
    }

    // ════════════════════════════════════════════════════════
    //  Viewing mode: dub / in-video subtitle release / external subtitle
    // ════════════════════════════════════════════════════════

    private void beginModeDiscovery(boolean playWhenReady) {
        playAfterDecision = playWhenReady;
        awaitingModeDecision = true;
        dubConflict = false;
        final int gen = ++discoveryGeneration;
        handler.postDelayed(() -> {
            if (gen == discoveryGeneration && awaitingModeDecision) decideMode();
        }, MODE_DISCOVERY_TIMEOUT_MS);
    }

    private List<String> subtitleLanguages() {
        List<String> out = new ArrayList<>();
        for (SubChoice c : currentSubChoices) out.add(c.language);
        return out;
    }

    /** Audio languages verified from the manifest (Media3 formats) plus documented dub releases. */
    private List<String> audioLanguages() {
        List<String> manifest = new ArrayList<>();
        if (exoPlayer != null) {
            for (Tracks.Group g : exoPlayer.getCurrentTracks().getGroups()) {
                if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
                for (int i = 0; i < g.length; i++) {
                    Format f = g.getTrackFormat(i);
                    if (f.language != null) manifest.add(f.language);
                    if (f.label != null) manifest.add(f.label);
                }
            }
        }
        List<String> out = new ArrayList<>(manifest);
        String release = movieboxPlayback != null ? movieboxPlayback.audioLanguage : null;
        if (release != null) {
            boolean manifestArabic = ModeResolver.indexOfArabic(manifest) >= 0;
            boolean manifestOther = false;
            for (String l : manifest) {
                String n = LanguageMatcher.normalize(l);
                if (n != null && !LanguageMatcher.AR.equals(n)) manifestOther = true;
            }
            // A release label never overrides a manifest that explicitly says otherwise.
            if (LanguageMatcher.isArabic(release) && !manifestArabic && manifestOther) dubConflict = true;
            else out.add(release);
        }
        return out;
    }

    private void decideMode() {
        if (!awaitingModeDecision) return;
        awaitingModeDecision = false;
        boolean release = movieboxPlayback != null && movieboxPlayback.arabicDub() != null
                && !LanguageMatcher.isArabic(movieboxPlayback.audioLanguage);
        boolean videoSubtitle = movieboxPlayback != null
                && movieboxPlayback.inVideoSubtitleRelease;
        final ModeResolver.Availability a =
                ModeResolver.evaluate(subtitleLanguages(), audioLanguages(), release, videoSubtitle);
        if (requestedMode != null) {
            // Chosen pre-playback on the portrait screen; only degrade when the
            // real tracks contradict the choice.
            applyMode(ModeResolver.effectiveMode(requestedMode, a), a);
            return;
        }
        // No explicit choice: use the resolver's verified priority order.
        PlaybackMode auto = ModeResolver.automaticMode(a);
        applyMode(auto != null ? auto : PlaybackMode.ORIGINAL, a);
    }

    private String modeLabel(PlaybackMode m) {
        if (m == PlaybackMode.ARABIC_DUB) return getString(R.string.player_mode_ar_dub);
        if (m == PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE)
            return getString(R.string.player_mode_ar_video_subtitle);
        if (m == PlaybackMode.ARABIC_SUBTITLE) return getString(R.string.player_mode_ar_sub);
        return "English";
    }

    private void applyMode(PlaybackMode mode, ModeResolver.Availability a) {
        if (mode == PlaybackMode.ARABIC_DUB && !a.arabicDubFromManifest && a.arabicDubFromRelease) {
            // Dub RELEASES are resolved before PlayerActivity opens (the
            // pre-playback chooser hands over an already-dubbed playback).
            // Reaching this branch means the payload is still the base
            // release while only a sibling dub claims Arabic — never switch
            // releases mid-playback; degrade to the best verified mode.
            a.arabicDubFromRelease = false;
            a.arabicDub = a.arabicDubFromManifest;
            mode = ModeResolver.effectiveMode(PlaybackMode.ARABIC_SUBTITLE, a);
        }
        effectiveMode = mode;
        if (requestedMode != null && mode != requestedMode
                && (mode == PlaybackMode.ARABIC_SUBTITLE
                    || mode == PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE
                    || mode == PlaybackMode.ARABIC_DUB)) {
            Toast.makeText(this, getString(R.string.player_mode_changed, modeLabel(mode)),
                    Toast.LENGTH_LONG).show();
        }
        selectAudio(ModeResolver.audioLanguageFor(mode, a));

        applySubtitleForMode();
        if (mode == PlaybackMode.ENGLISH_FALLBACK)
            Toast.makeText(this, R.string.player_english_fallback, Toast.LENGTH_LONG).show();
        else if (mode == PlaybackMode.ORIGINAL)
            Toast.makeText(this, R.string.player_no_ar_no_en, Toast.LENGTH_LONG).show();
        applyDefaultQualityIfAdaptive();
        if (exoPlayer != null) exoPlayer.setPlayWhenReady(playAfterDecision);
    }

    /** Selects an audio track by language without touching video/text selection. */
    private void selectAudio(String code) {
        pendingAudioLanguage = code;
        verifyAudioOnTracksChanged = code != null;
        audioRetryApplied = false;
        applyAudioOverride(code);
    }

    private void applyAudioOverride(String code) {
        if (trackSelector == null) return;
        DefaultTrackSelector.Parameters.Builder pb = trackSelector.buildUponParameters()
                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                .setPreferredAudioLanguage(code);
        if (code != null && exoPlayer != null) {
            for (Tracks.Group g : exoPlayer.getCurrentTracks().getGroups()) {
                if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
                for (int i = 0; i < g.length; i++) {
                    Format f = g.getTrackFormat(i);
                    if (code.equals(LanguageMatcher.normalize(f.language))
                            || code.equals(LanguageMatcher.normalize(f.label))) {
                        pb.setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), i));
                        trackSelector.setParameters(pb.build());
                        return;
                    }
                }
            }
        }
        trackSelector.setParameters(pb.build());
    }

    private void verifyAudioSelection() {
        String wanted = pendingAudioLanguage;
        if (wanted == null || exoPlayer == null) {
            verifyAudioOnTracksChanged = false;
            return;
        }
        boolean selectedMatches = false;
        boolean matchingTrackExists = false;
        for (Tracks.Group group : exoPlayer.getCurrentTracks().getGroups()) {
            if (group.getType() != C.TRACK_TYPE_AUDIO) continue;
            for (int i = 0; i < group.length; i++) {
                Format format = group.getTrackFormat(i);
                boolean matches = ModeResolver.audioMatches(wanted, format.language)
                        || ModeResolver.audioMatches(wanted, format.label);
                if (matches) matchingTrackExists = true;
                if (group.isTrackSelected(i) && matches) selectedMatches = true;
            }
        }
        if (selectedMatches) {
            verifyAudioOnTracksChanged = false;
        } else if (!audioRetryApplied && matchingTrackExists) {
            audioRetryApplied = true;
            applyAudioOverride(wanted);
        } else {
            verifyAudioOnTracksChanged = false;
            if (LanguageMatcher.EN.equals(wanted))
                Toast.makeText(this, R.string.player_english_audio_failed, Toast.LENGTH_LONG).show();
        }
    }

    private void applySubtitleForMode() {
        int idx = ModeResolver.subtitleIndexFor(effectiveMode, subtitleLanguages());
        if (idx < 0) { resetSubtitleState(); return; }
        loadSubtitle(currentSubChoices.get(idx));
    }

    private void resetSubtitleState() {
        subtitleManager.clear();
        hasSubtitles = false;
        subtitlesEnabled = false;
        subtitleManager.setEnabled(false);
        updateSubtitleBtn(false, false);
        btnSubSizeDown.setVisibility(View.GONE);
        btnSubSizeUp.setVisibility(View.GONE);
    }

    /** A parsed external file has no independent timing reference until checked against media. */
    private void showSubtitleSyncDialog() {
        final long[] deltas = {500L, -500L, 5_000L, -5_000L, 0L};
        String current = String.format(java.util.Locale.US, "%+d ms", subtitleManager.getOffsetMs());
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(getString(R.string.player_subtitle_sync_title, current))
                .setItems(R.array.player_subtitle_sync_choices, (dialog, which) -> {
                    long offset = which == deltas.length - 1
                            ? 0L : addSubtitleOffset(subtitleManager.getOffsetMs(), deltas[which]);
                    subtitleManager.setOffsetMs(offset);
                    if (exoPlayer != null) subtitleManager.tick(exoPlayer.getCurrentPosition());
                    String label = String.format(java.util.Locale.US, "%+d ms", offset);
                    Toast.makeText(PlayerActivity.this,
                            getString(R.string.player_subtitle_sync_applied, label), Toast.LENGTH_SHORT).show();
                    resetHideTimer();
                })
                .show();
    }

    private static long addSubtitleOffset(long current, long delta) {
        try { return Math.addExact(current, delta); }
        catch (ArithmeticException overflow) { return delta > 0 ? Long.MAX_VALUE : Long.MIN_VALUE; }
    }

    /** The CC button becomes active only after valid cues were parsed. */
    private void loadSubtitle(SubChoice c) {
        resetSubtitleState();
        subtitleManager.load(c.url, c.headers, new SubtitleManager.Listener() {
            @Override public void onLoaded(int cueCount) {
                DiagnosticsRecorder.event("subtitle", "subtitle_loaded", "success", DiagnosticsRecorder.details("cueCount", cueCount, "url", c.url, "language", c.language, "season", currentSeason, "episode", currentEpisode));
                if (isFinishing()) return;
                hasSubtitles = true;
                subtitlesEnabled = true;
                subtitleManager.setEnabled(true);
                btnSubSizeDown.setVisibility(View.VISIBLE);
                btnSubSizeUp.setVisibility(View.VISIBLE);
                updateSubtitleBtn(true, true);
                DiagnosticsRecorder.event("subtitle", "subtitle_sync", "unverified",
                        DiagnosticsRecorder.details("reason", "download_and_parse_do_not_verify_timing",
                                "season", currentSeason, "episode", currentEpisode));
                Toast.makeText(PlayerActivity.this, R.string.player_subtitle_sync_unverified,
                        Toast.LENGTH_LONG).show();
                if (exoPlayer != null) subtitleManager.tick(exoPlayer.getCurrentPosition());
            }
            @Override public void onFailed(String reason) {
                DiagnosticsRecorder.event("subtitle", "subtitle_load", "failed", DiagnosticsRecorder.details("reason", reason, "url", c.url, "language", c.language, "season", currentSeason, "episode", currentEpisode));
                if (isFinishing()) return;
                updateSubtitleBtn(false, false);
                Toast.makeText(PlayerActivity.this,
                        getString(R.string.player_sub_failed, reason), Toast.LENGTH_LONG).show();
            }
        });
    }

    // ════════════════════════════════════════════════════════
    //  Real renditions (Media3 tracks) — no fabricated resolutions
    // ════════════════════════════════════════════════════════

    private List<QualityPlanner.VideoTrack> realVideoTracks() {
        List<QualityPlanner.VideoTrack> out = new ArrayList<>();
        if (exoPlayer == null) return out;
        List<Tracks.Group> groups = exoPlayer.getCurrentTracks().getGroups();
        for (int gi = 0; gi < groups.size(); gi++) {
            Tracks.Group g = groups.get(gi);
            if (g.getType() != C.TRACK_TYPE_VIDEO) continue;
            for (int i = 0; i < g.length; i++) {
                Format f = g.getTrackFormat(i);
                out.add(new QualityPlanner.VideoTrack(gi, i,
                        f.height == Format.NO_VALUE ? 0 : f.height,
                        f.bitrate, g.isTrackSupported(i)));
            }
        }
        return out;
    }

    /** null = Auto (adaptive). Audio and subtitle selections are untouched. */
    private void applyVideoTrack(QualityPlanner.VideoTrack t) {
        if (trackSelector == null || exoPlayer == null) return;
        if (t == null) {
            clearVideoOverride();
            selectedVideoHeight = 0;
        } else {
            List<Tracks.Group> groups = exoPlayer.getCurrentTracks().getGroups();
            if (t.groupIndex >= groups.size()) return;
            Tracks.Group g = groups.get(t.groupIndex);
            trackSelector.setParameters(trackSelector.buildUponParameters()
                    .clearVideoSizeConstraints()
                    .setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), t.trackIndex))
                    .build());
            selectedVideoHeight = t.height;
        }
        refreshQualityBadge();
    }

    private void clearVideoOverride() {
        if (trackSelector == null) return;
        trackSelector.setParameters(trackSelector.buildUponParameters()
                .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                .clearVideoSizeConstraints()
                .build());
    }

    private boolean currentIsAdaptive() {
        if (movieboxPlayback != null && movieboxStreamIndex < movieboxPlayback.streams.size())
            return movieboxPlayback.streams.get(movieboxStreamIndex).isAdaptive();
        String u = currentStreamUrl == null ? "" : currentStreamUrl.split("\\?")[0];
        return u.endsWith(".m3u8") || u.endsWith(".mpd");
    }

    private void refreshQualityBadge() {
        if (!currentIsAdaptive()) return;
        Format actual = exoPlayer != null ? exoPlayer.getVideoFormat() : null;
        int actualHeight = actual == null || actual.height == Format.NO_VALUE ? 0 : actual.height;
        currentQuality = QualityPlanner.badgeLabel(true, selectedVideoHeight == 0,
                selectedVideoHeight, actualHeight, getString(R.string.player_quality_auto),
                getString(R.string.player_quality_unknown));
        setQualityBadge(currentQuality);
    }

    private void applyDefaultQualityIfAdaptive() {
        if (movieboxPlayback == null || !currentIsAdaptive()) return;
        String prefQ = SettingsStore.getDefaultQuality(this);
        if (SettingsStore.QUALITY_AUTO.equals(prefQ)) { applyVideoTrack(null); return; }
        applyVideoTrack(QualityPlanner.match(
                QualityPlanner.options(realVideoTracks()), parseQualityHeight(prefQ)));
    }

    private void showAdaptiveQualitySheet() {
        final List<QualityPlanner.VideoTrack> opts = QualityPlanner.options(realVideoTracks());
        if (opts.size() <= 1) {
            String l = opts.isEmpty() ? getString(R.string.player_quality_unknown)
                                      : QualityPlanner.label(opts.get(0).height);
            Toast.makeText(this, getString(R.string.player_quality_single, l), Toast.LENGTH_SHORT).show();
            return;
        }
        Format playing = exoPlayer != null ? exoPlayer.getVideoFormat() : null;
        int playingH = playing != null && playing.height != Format.NO_VALUE ? playing.height : 0;
        List<GlassChoiceSheet.Row> rows = new ArrayList<>();
        rows.add(new GlassChoiceSheet.Row(
                selectedVideoHeight == 0 && playingH > 0
                        ? getString(R.string.player_quality_auto_now, playingH + "p")
                        : getString(R.string.player_quality_auto),
                null, true, selectedVideoHeight == 0));
        for (QualityPlanner.VideoTrack t : opts) {
            rows.add(new GlassChoiceSheet.Row(QualityPlanner.label(t.height),
                    t.bitrate > 0 ? (t.bitrate / 1000) + " kbps" : null,
                    true, selectedVideoHeight == t.height));
        }
        new GlassChoiceSheet(this, getString(R.string.player_quality_title), rows, idx -> {
            applyVideoTrack(idx == 0 ? null : opts.get(idx - 1));
            resetHideTimer();
        }).show();
    }

    private static Map<Integer, Integer> parseSeasonCounts(String json) {
        Map<Integer, Integer> out = new HashMap<>();
        if (json == null || json.isEmpty()) return out;
        try {
            org.json.JSONObject o = new org.json.JSONObject(json);
            for (java.util.Iterator<String> it = o.keys(); it.hasNext();) {
                String k = it.next();
                out.put(Integer.parseInt(k), o.optInt(k, 0));
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void switchQuality(String url, String quality, long resumeMs) {
        if (exoPlayer == null) return;
        currentStreamUrl = url;
        currentQuality   = quality;
        pendingSeekMs    = resumeMs;
        setQualityBadge(quality);
        DiagnosticsRecorder.event("Media3", "media_item_set", "started", DiagnosticsRecorder.details("title", title, "url", url, "quality", currentQuality, "season", currentSeason, "episode", currentEpisode));
        exoPlayer.setMediaItem(MediaItem.fromUri(url));
        exoPlayer.prepare();
        exoPlayer.setPlayWhenReady(true);
    }

    private void releasePlayer() {
        if (exoPlayer != null) {
            exoPlayer.removeListener(playerListener);
            exoPlayer.release();
            exoPlayer = null;
        }
    }

    // ════════════════════════════════════════════════════════
    //  Controls Visibility
    // ════════════════════════════════════════════════════════

    private void toggleControls() {
        if (controlsVisible) hideControls(); else showControls();
    }

    private void showControls() {
        controlsVisible = true;
        handler.removeCallbacks(subtitleHideRunnable);
        setSubtitleBottomMargin(104);
        // Show the whole overlay layer — this includes the gradient scrim on controlsOverlay
        animateFade(controlsOverlay, true);
        animateFade(topBar,          true);
        animateFade(bottomBar,       true);
        if (!isBuffering) animateFade(centerControls, true);
        scheduleHideControls();
        syncNextEpisodeButton(); // controls are back: show the button again if <= 60 s remain
    }

    private void hideControls() {
        if (exoPlayer == null || !exoPlayer.isPlaying()) return;
        controlsVisible = false;
        syncNextEpisodeButton(); // the button follows the controls: hide it with them
        // Hide the overlay layer — gradient scrim on controlsOverlay disappears too
        animateFade(controlsOverlay,  false);
        animateFade(topBar,           false);
        animateFade(bottomBar,        false);
        animateFade(centerControls,   false);
        handler.removeCallbacks(subtitleHideRunnable);
        handler.postDelayed(subtitleHideRunnable, 220);
    }

    private void scheduleHideControls() {
        handler.removeCallbacks(hideControlsRunnable);
        handler.postDelayed(hideControlsRunnable, CONTROLS_AUTO_HIDE_MS);
    }

    private void resetHideTimer() {
        if (controlsVisible) scheduleHideControls();
    }

    private void animateFade(View v, boolean show) {
        if (v == null) return;
        v.animate().cancel();
        v.animate()
            .alpha(show ? 1f : 0f)
            .setDuration(220)
            .setInterpolator(new DecelerateInterpolator())
            .withStartAction(() -> { if (show) v.setVisibility(View.VISIBLE); })
            .withEndAction(() -> { if (!show) v.setVisibility(View.INVISIBLE); })
            .start();
    }

    // ════════════════════════════════════════════════════════
    //  Playback Control
    // ════════════════════════════════════════════════════════

    private void togglePlayPause() {
        if (exoPlayer == null) return;
        if (exoPlayer.isPlaying()) exoPlayer.pause();
        else exoPlayer.play();
        resetHideTimer();
    }

    private void updatePlayPauseIcon(boolean playing) {
        if (btnPlayPause == null) return;
        btnPlayPause.setImageResource(
            playing ? R.drawable.ic_pause_circle : R.drawable.ic_play_circle
        );
    }

    private void seekRelative(long deltaMs) {
        if (exoPlayer == null) return;
        long newPos = exoPlayer.getCurrentPosition() + deltaMs;
        newPos = Math.max(0L, Math.min(newPos, exoPlayer.getDuration()));
        exoPlayer.seekTo(newPos);
        updateProgressImmediate();
    }

    private void onVideoEnded() {
        if (currentProvider == EpisodeNavigator.Provider.MOVIEBOX) {
            int[] next = EpisodeNavigator.next(tmdbSeason, tmdbEpisode, episodeCounts());
            if (next == null) {
                hideNextEpisodeCardNow();
                showControls();
                return;
            }
            nextEpisodeAvailable = true;
            showControls(); // the button follows the controls; at the end 0 s remain → it shows
            if (SettingsStore.isAutoplayNext(this)) {
                final int gen = ++navGeneration;
                handler.postDelayed(() -> {
                    if (gen == navGeneration
                            && currentProvider == EpisodeNavigator.Provider.MOVIEBOX)
                        goNextEpisode(-1);
                }, 5000);
            } else {
                showControls();
            }
            return;
        }
        int nextId = getIntent().getIntExtra("next_episode_id", -1);
        if (nextId > 0 && nextId != episodeId) {
            nextEpisodeAvailable = true;
            showControls(); // the button follows the controls; at the end 0 s remain → it shows
            // Autoplay next episode — user-controlled via Settings → Playback
            if (SettingsStore.isAutoplayNext(this)) {
                final int gen = ++navGeneration;
                handler.postDelayed(() -> {
                    if (gen == navGeneration
                            && currentProvider == EpisodeNavigator.Provider.CINEMABOX)
                        goNextEpisode(nextId);
                }, 5000);
            } else {
                showControls(); // card stays visible; the user decides
            }
        } else {
            showControls();
        }
    }

    // ════════════════════════════════════════════════════════
    //  Progress
    // ════════════════════════════════════════════════════════

    private void updateProgress() {
        if (exoPlayer == null) return;
        long pos = exoPlayer.getCurrentPosition();
        long dur = exoPlayer.getDuration();
        if (dur > 0 && !isUserSeeking) {
            seekBar.setMax(1000);
            seekBar.setProgress((int)(1000L * pos / dur));
            long buf = exoPlayer.getBufferedPosition();
            seekBar.setSecondaryProgress((int)(1000L * buf / dur));
            tvCurrentTime.setText(formatTime(pos));
            int bufPct = (int)(100L * buf / dur);
            if (tvBufferingPct != null) tvBufferingPct.setText(bufPct + "%");
        }
        if (subtitlesEnabled) subtitleManager.tick(pos);
        syncIntroButton(pos);
        syncNextEpisodeButton();
        handler.postDelayed(progressRunnable, PROGRESS_UPDATE_MS);
    }

    private void updateProgressImmediate() {
        if (exoPlayer == null) return;
        long pos = exoPlayer.getCurrentPosition();
        long dur = exoPlayer.getDuration();
        if (dur > 0) {
            seekBar.setProgress((int)(1000L * pos / dur));
            tvCurrentTime.setText(formatTime(pos));
        }
        if (subtitlesEnabled && subtitleManager != null) subtitleManager.tick(pos);
        syncNextEpisodeButton();
    }

    // ════════════════════════════════════════════════════════
    //  Skip Intro
    // ════════════════════════════════════════════════════════

    // ── Intro window boundaries (ms). Both -1 = no intro defined. ──
    private long introStartMs = -1L;
    private long introEndMs   = -1L;

    /**
     * Store the intro window. Visibility is derived purely from playback position
     * inside updateProgress() — no timers, no flags, handles seeking correctly.
     */
    private void scheduleSkipIntro(long startMs, long endMs) {
        if (startMs < 0 || endMs <= startMs) return;
        introStartMs = startMs;
        introEndMs   = endMs;
        btnSkipIntro.setVisibility(View.GONE);
        btnSkipIntro.setAlpha(0f);
    }

    /**
     * Called from updateProgress() every 500ms.
     * Show button when inside [introStart, introEnd], hide otherwise.
     * Works correctly even after seeking forward or backward.
     */
    private void syncIntroButton(long posMs) {
        if (introEndMs <= 0) return;
        boolean inWindow = posMs >= introStartMs && posMs < introEndMs;
        boolean visible  = btnSkipIntro.getVisibility() == View.VISIBLE;
        if (inWindow == visible) return; // state unchanged — skip
        if (inWindow) {
            btnSkipIntro.setTag(introEndMs);
            btnSkipIntro.animate().cancel();
            btnSkipIntro.setVisibility(View.VISIBLE);
            btnSkipIntro.animate().alpha(1f).setDuration(250).start();
        } else {
            btnSkipIntro.animate().cancel();
            btnSkipIntro.animate()
                .alpha(0f).setDuration(250)
                .withEndAction(() -> btnSkipIntro.setVisibility(View.GONE))
                .start();
        }
    }

    // ════════════════════════════════════════════════════════
    //  Quality
    // ════════════════════════════════════════════════════════

    private void showQualitySheet() {
        if (movieboxPlayback != null) {
            showMovieBoxQualitySheet();
            return;
        }
        if (currentMedia == null || currentMedia.videos == null
                || currentMedia.videos.isEmpty()) {
            Toast.makeText(this, "لا توجد جودات متاحة", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentMedia.videos.size() <= 1 && currentIsAdaptive()
                && QualityPlanner.options(realVideoTracks()).size() > 1) {
            adaptiveMenuUsed = true;
            showAdaptiveQualitySheet();
            return;
        }
        new QualityBottomSheet(
            this,
            currentMedia.videos,
            currentStreamUrl,
            (url, quality) -> {
                long pos = exoPlayer != null ? exoPlayer.getCurrentPosition() : 0;
                switchQuality(url, quality, pos);
            }
        ).show();
    }

    private void setQualityBadge(String quality) {
        if (btnQuality == null) return;
        if (quality == null || quality.isEmpty()) {
            btnQuality.setText("Q");
        } else {
            btnQuality.setText(quality);  // e.g. "1080p"
        }
    }

    /**
     * MovieBox quality UX. A DASH stream legitimately exposes its advertised
     * resolutions via the manifest — switching is a track-selector constraint,
     * not a URL swap. Multiple direct-file streams are offered as-is.
     */
    private void showMovieBoxQualitySheet() {
        if (movieboxPlayback == null || movieboxPlayback.streams.isEmpty()) {
            Toast.makeText(this, "لا توجد جودات متاحة", Toast.LENGTH_SHORT).show();
            return;
        }
        final MovieBoxModels.StreamSource current = movieboxPlayback.streams.get(movieboxStreamIndex);
        if (current.isAdaptive()) { showAdaptiveQualitySheet(); return; }

        // Direct files: one entry per distinct full (signed) URL, labelled only
        // with heights the API declared — unknown stays "جودة غير معروفة".
        final List<MovieBoxModels.StreamSource> streams = movieboxPlayback.streams;
        final List<Integer> indices = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < streams.size(); i++) {
            MovieBoxModels.StreamSource s = streams.get(i);
            if (s.isAdaptive() || !seen.add(s.url)) continue;
            indices.add(i);
        }
        if (indices.size() <= 1) {
            Toast.makeText(this, getString(R.string.player_quality_single, current.qualityLabel()),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        List<GlassChoiceSheet.Row> rows = new ArrayList<>();
        for (int i : indices) {
            MovieBoxModels.StreamSource s = streams.get(i);
            String detail = s.sizeBytes > 0
                    ? String.format(java.util.Locale.US, "%.2f GB", s.sizeBytes / 1e9) : null;
            rows.add(new GlassChoiceSheet.Row(s.qualityLabel()
                    + (s.codec != null && !s.codec.isEmpty() ? " • " + s.codec : ""),
                    detail, true, i == movieboxStreamIndex));
        }
        new GlassChoiceSheet(this, getString(R.string.player_quality_title), rows, idx -> {
            int which = indices.get(idx);
            if (which != movieboxStreamIndex) {
                movieboxStreamIndex = which;
                MovieBoxModels.StreamSource s = streams.get(which);
                currentStreamUrl = s.url;
                currentQuality = s.qualityLabel();
                setQualityBadge(currentQuality);
                long pos = exoPlayer != null ? exoPlayer.getCurrentPosition() : 0;
                boolean pwr = exoPlayer == null || exoPlayer.getPlayWhenReady();
                playMovieBoxStream(s, pos, pwr);
                setMovieBoxSubChoices(s);
                applySubtitleForMode();
            }
            resetHideTimer();
        }).show();
    }

    // ════════════════════════════════════════════════════════
    //  Resize Mode
    // ════════════════════════════════════════════════════════

    /**
     * Called once when the first video frame arrives.
     * Compares video aspect ratio with screen aspect ratio:
     * - If they match closely (< 4% diff) → FILL (no bars, no crop)
     * - If video is wider (e.g. 21:9 on 16:9 screen) → FIT (bars on top/bottom, no crop)
     * - If video is taller → FIT (bars on sides)
     * User can still override via the resize button.
     */
    private void applyBestResizeMode(int videoW, int videoH) {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float screenAr = (float) dm.widthPixels / dm.heightPixels;
        float videoAr  = (float) videoW / videoH;
        float diff     = Math.abs(videoAr - screenAr) / screenAr;

        int bestMode;
        if (diff < 0.04f) {
            // Aspect ratios nearly identical — fill with no perceptible crop
            bestMode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
            resizeModeIndex = 1; // index of FILL in RESIZE_MODES
        } else {
            // Significant difference — fit inside screen, no crop
            bestMode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
            resizeModeIndex = 0; // index of FIT in RESIZE_MODES
        }
        playerView.setResizeMode(bestMode);
    }

    private void cycleResize() {
        resizeModeIndex = (resizeModeIndex + 1) % RESIZE_MODES.length;
        playerView.setResizeMode(RESIZE_MODES[resizeModeIndex]);
        // Reset pinch zoom when resize mode changes
        scaleFactor = 1f;
        playerView.setScaleX(1f);
        playerView.setScaleY(1f);
        Toast.makeText(this, RESIZE_LABELS[resizeModeIndex], Toast.LENGTH_SHORT).show();
    }

    // ════════════════════════════════════════════════════════
    //  Speed
    // ════════════════════════════════════════════════════════

    private void showSpeedSheet() {
        final float[]  speeds = {0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f};
        final String[] labels = {"0.25×", "0.5×", "0.75×", "عادي", "1.25×", "1.5×", "1.75×", "2×"};
        int current = 3;
        for (int i = 0; i < speeds.length; i++) {
            if (Math.abs(speeds[i] - playbackSpeed) < 0.01f) { current = i; break; }
        }
        new android.app.AlertDialog.Builder(this)
            .setTitle("سرعة التشغيل")
            .setSingleChoiceItems(labels, current, (d, which) -> {
                setPlaybackSpeed(speeds[which]);
                btnSpeed.setText(labels[which]);
                d.dismiss();
                resetHideTimer();
            })
            .show();
    }

    private void setPlaybackSpeed(float speed) {
        playbackSpeed = speed;
        if (exoPlayer != null)
            exoPlayer.setPlaybackParameters(new PlaybackParameters(playbackSpeed));
        if (btnSpeed != null)
            btnSpeed.setText(playbackSpeed == 1f ? "1×" : playbackSpeed + "×");
    }

    // ════════════════════════════════════════════════════════
    //  Subtitle
    // ════════════════════════════════════════════════════════

    private void updateSubtitleBtn(boolean available, boolean enabled) {
        if (btnSubtitle == null) return;
        btnSubtitle.setEnabled(available);
        btnSubtitle.setAlpha(available ? 1f : 0.38f);
        // Highlight CC in purple when active
        btnSubtitle.setTextColor(available && enabled ? 0xFF9B6FC4 : 0xCCFFFFFF);
    }

    /** رفع الترجمة فوق شريط التحكم عند ظهوره، وإنزالها عند إخفائه */
    private void setSubtitleBottomMargin(int dp) {
        if (subtitleView == null) return;
        android.view.ViewGroup.LayoutParams lp = subtitleView.getLayoutParams();
        if (lp instanceof FrameLayout.LayoutParams) {
            ((FrameLayout.LayoutParams) lp).bottomMargin =
                (int)(dp * getResources().getDisplayMetrics().density);
            subtitleView.setLayoutParams(lp);
        }
    }

    // ════════════════════════════════════════════════════════
    //  Volume / Brightness
    // ════════════════════════════════════════════════════════

    private void adjustVolume(float delta) {
        int cur  = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        int next = Math.max(0, Math.min(maxVolume, (int)(cur + delta * maxVolume)));
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0);
        showVbIndicator(true, next / (float) maxVolume);
    }

    private void adjustBrightness(float delta) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        if (currentBrightness < 0) currentBrightness =
            lp.screenBrightness > 0 ? lp.screenBrightness : 0.5f;
        currentBrightness = Math.max(0.01f, Math.min(1f, currentBrightness + delta));
        lp.screenBrightness = currentBrightness;
        getWindow().setAttributes(lp);
        showVbIndicator(false, currentBrightness);
    }

    private void showVbIndicator(boolean isVolume, float fraction) {
        if (vbIndicator == null) return;
        vbIndicator.setVisibility(View.VISIBLE);
        int cur = (int)(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        ivVbIcon.setImageResource(
            isVolume
                ? (cur == 0 ? R.drawable.ic_volume_off : R.drawable.ic_volume_high)
                : R.drawable.ic_brightness
        );
        vbBar.setProgress((int)(fraction * 100f));
        handler.removeCallbacks(hideVbRunnable);
        handler.postDelayed(hideVbRunnable, VB_INDICATOR_HIDE_MS);
    }

    private void dismissVbIndicator() {
        if (vbIndicator != null) vbIndicator.setVisibility(View.GONE);
    }

    // ════════════════════════════════════════════════════════
    //  Seek Animations
    // ════════════════════════════════════════════════════════

    private void animateSeekIndicator(boolean forward) {
        View v = forward ? seekIndicatorRight : seekIndicatorLeft;
        if (v == null) return;
        v.setVisibility(View.VISIBLE);
        v.setAlpha(0.9f);
        v.animate().cancel();
        v.animate()
            .alpha(0f)
            .setDuration(SEEK_INDICATOR_DURATION)
            .withEndAction(() -> v.setVisibility(View.GONE))
            .start();
    }

    // ════════════════════════════════════════════════════════
    //  Orientation / Fullscreen
    // ════════════════════════════════════════════════════════

    private void setLocked(boolean locked) {
        isLocked = locked;
        syncNextEpisodeButton();
        if (locked) {
            hideControls();
            lockOverlay.setVisibility(View.VISIBLE);
            btnUnlock.setVisibility(View.VISIBLE);
            handler.removeCallbacks(hideControlsRunnable);
        } else {
            lockOverlay.setVisibility(View.GONE);
            btnUnlock.setVisibility(View.GONE);
            showControls();
        }
    }

    // ════════════════════════════════════════════════════════
    //  Next Episode
    // ════════════════════════════════════════════════════════

    private void goNextEpisode(int nextId) {
        if (currentProvider == EpisodeNavigator.Provider.MOVIEBOX) {
            goNextMovieBoxEpisode();
            return;
        }
        handler.removeCallbacksAndMessages(null);
        navGeneration++;
        discoveryGeneration++;
        captionGeneration++;
        extractionGeneration++;
        pendingVideoRestoreHeight = 0;
        currentEpisode++;
        tmdbEpisode = currentEpisode;
        tvSeasonEp.setText(getString(R.string.player_season_episode,
                currentSeason, currentEpisode));
        episodeId        = nextId;
        currentProvider = EpisodeNavigator.Provider.CINEMABOX;
        movieboxPlayback = null;
        currentMedia = null;
        awaitingModeDecision = false;
        currentSubChoices.clear();
        hasSubtitles     = false;
        subtitlesEnabled = false;
        updateSubtitleBtn(false, false);
        subtitleManager.clear();
        hideNextEpisodeCardNow();
        btnSubSizeDown.setVisibility(View.GONE);
        btnSubSizeUp.setVisibility(View.GONE);

        introStartMs     = -1L;
        introEndMs       = -1L;
        if (exoPlayer != null) exoPlayer.stop();
        startExtraction();
    }

    private void goNextMovieBoxEpisode() {
        final int[] next = EpisodeNavigator.next(tmdbSeason, tmdbEpisode, episodeCounts());
        if (next == null || movieboxPlayback == null) return;
        persistWatchPosition();
        final int gen = ++navGeneration;
        discoveryGeneration++;
        captionGeneration++;
        extractionGeneration++;
        final int nextSeason = next[0];
        final int nextEpisodeNumber = next[1];
        final Map<Integer, Integer> counts = episodeCounts();
        final String searchTitle = srcSearchTitle;
        final String originalTitle = srcOriginalTitle;
        final int year = srcYear;
        final String failedMessage = getString(R.string.player_next_episode_failed);
        // Dub and in-video subtitle modes survive episode advances by resolving
        // the same provider subject for the requested next episode.
        final boolean dubActive = effectiveMode == PlaybackMode.ARABIC_DUB
                && !movieboxPlayback.activeSubjectId()
                        .equals(movieboxPlayback.canonicalSubjectId());
        final String activeDubSubjectId = movieboxPlayback.activeSubjectId();
        final boolean inVideoSubtitleActive = effectiveMode == PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE
                && movieboxPlayback.inVideoSubtitleRelease;
        final String activeVideoSubtitleSubjectId = movieboxPlayback.activeSubjectId();

        executor.execute(() -> {
            try {
                MovieBoxModels.Playback nextPlayback = MovieBoxBridge.get(PlayerActivity.this)
                        .resolveEpisode(searchTitle, originalTitle, year,
                                nextSeason, nextEpisodeNumber, counts);
                SourceSwitchValidator.Result validation = SourceSwitchValidator.validate(
                        true, nextSeason, nextEpisodeNumber,
                        nextPlayback.tmdbSeason, nextPlayback.tmdbEpisode,
                        nextPlayback.streams != null && !nextPlayback.streams.isEmpty());
                if (validation != SourceSwitchValidator.Result.OK) {
                    throw new com.eve.cinema.moviebox.MovieBoxException(
                            com.eve.cinema.moviebox.MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED,
                            "MovieBox returned a different episode");
                }
                if (inVideoSubtitleActive) {
                    // resolveEpisode may already have returned the verified translated
                    // video as its only playable fallback. Do not require it to appear
                    // again as a sibling in that same subject's dubs list.
                    if (!nextPlayback.inVideoSubtitleRelease) {
                        MovieBoxModels.DubOption release = null;
                        for (MovieBoxModels.DubOption d : nextPlayback.dubs) {
                            if (d != null && activeVideoSubtitleSubjectId.equals(d.subjectId)
                                    && d.classification().kind
                                        == com.eve.cinema.moviebox.MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE) {
                                release = d; break;
                            }
                        }
                        if (release == null) release = nextPlayback.arabicSubtitleRelease();
                        if (release == null) {
                            throw new com.eve.cinema.moviebox.MovieBoxException(
                                    com.eve.cinema.moviebox.MovieBoxException.Kind.EPISODE_UNAVAILABLE,
                                    "No verified Arabic subtitle video release for the next episode");
                        }
                        nextPlayback = MovieBoxBridge.get(PlayerActivity.this)
                                .resolveArabicSubtitleRelease(nextPlayback, release);
                    }
                    if (nextPlayback.tmdbSeason != nextSeason
                            || nextPlayback.tmdbEpisode != nextEpisodeNumber) {
                        throw new com.eve.cinema.moviebox.MovieBoxException(
                                com.eve.cinema.moviebox.MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED,
                                "Subtitle video release mapped to a different episode");
                    }
                } else if (dubActive) {
                    // Resolve the SAME dub release for the next episode (fall
                    // back to any verified Arabic dub of the same base work).
                    MovieBoxModels.DubOption dub = null;
                    for (MovieBoxModels.DubOption d : nextPlayback.dubs) {
                        if (d != null && activeDubSubjectId.equals(d.subjectId)) { dub = d; break; }
                    }
                    if (dub == null) dub = nextPlayback.arabicDub();
                    if (dub == null) {
                        throw new com.eve.cinema.moviebox.MovieBoxException(
                                com.eve.cinema.moviebox.MovieBoxException.Kind.EPISODE_UNAVAILABLE,
                                "No Arabic dub release for the next episode");
                    }
                    nextPlayback = MovieBoxBridge.get(PlayerActivity.this)
                            .resolveDubRelease(nextPlayback, dub, LanguageMatcher.AR);
                    if (nextPlayback.tmdbSeason != nextSeason
                            || nextPlayback.tmdbEpisode != nextEpisodeNumber) {
                        throw new com.eve.cinema.moviebox.MovieBoxException(
                                com.eve.cinema.moviebox.MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED,
                                "Dub release mapped to a different episode");
                    }
                }
                final MovieBoxModels.Playback chosen = nextPlayback;
                handler.post(() -> {
                    if (isFinishing() || gen != navGeneration
                            || currentProvider != EpisodeNavigator.Provider.MOVIEBOX) return;
                    tmdbSeason = currentSeason = nextSeason;
                    tmdbEpisode = currentEpisode = nextEpisodeNumber;
                    currentProvider = EpisodeNavigator.Provider.MOVIEBOX;
                    movieboxPlayback = chosen;
                    currentMedia = null;
                    movieboxStreamIndex = 0;
                    episodeId = movieBoxEpisodeId(chosen.canonicalSubjectId(),
                            nextSeason, nextEpisodeNumber);
                    tvSeasonEp.setText(getString(R.string.player_season_episode,
                            currentSeason, currentEpisode));
                    hideNextEpisodeCardNow();
                    startMovieBoxPlayback(-1L, true);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    if (isFinishing() || gen != navGeneration
                            || currentProvider != EpisodeNavigator.Provider.MOVIEBOX) return;
                    String message = e instanceof com.eve.cinema.moviebox.MovieBoxException
                            ? ((com.eve.cinema.moviebox.MovieBoxException) e).userMessage()
                            : (e.getMessage() == null ? failedMessage : e.getMessage());
                    Toast.makeText(PlayerActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    // ════════════════════════════════════════════════════════
    //  Error / Loading
    // ════════════════════════════════════════════════════════

    private void showLoading(boolean show) {
        if (loadingOverlay != null)
            loadingOverlay.setVisibility(show ? View.VISIBLE : View.GONE);
        // Keep center controls hidden while spinner is active; restore when done
        if (centerControls != null) {
            if (show) {
                centerControls.setVisibility(View.INVISIBLE);
            } else if (controlsVisible && !isBuffering) {
                centerControls.setVisibility(View.VISIBLE);
            }
        }
    }

    private void showError(String msg) {
        if (tvError != null) tvError.setText(msg);
        if (errorOverlay != null) errorOverlay.setVisibility(View.VISIBLE);
        showLoading(false);
    }

    // ════════════════════════════════════════════════════════
    //  Animation helpers
    // ════════════════════════════════════════════════════════

    private void fadeOut(View v) {
        if (v == null) return;
        v.animate()
            .alpha(0f)
            .setDuration(300)
            .withEndAction(() -> v.setVisibility(View.GONE))
            .start();
    }

    private void animatePulse(View v) {
        if (v == null) return;
        v.animate().scaleX(1.2f).scaleY(1.2f).setDuration(100)
            .withEndAction(() ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            ).start();
    }

    // ════════════════════════════════════════════════════════
    //  Watch Progress — Auto-save & Restore
    // ════════════════════════════════════════════════════════

    /** مفتاح فريد لكل حلقة/فيلم */
    private String watchKey() {
        // Provider-scoped: MovieBox progress never collides with CinemaBox ids.
        // Canonical subject: a dub release shares the base work's progress.
        if (currentProvider == EpisodeNavigator.Provider.MOVIEBOX && movieboxPlayback != null)
            return "pos_mb_" + movieboxPlayback.canonicalSubjectId()
                    + "_" + tmdbSeason + "_" + tmdbEpisode;
        return "pos_" + episodeId;
    }

    /** دورة الحفظ التلقائي كل AUTO_SAVE_INTERVAL — تُعيد جدولة نفسها */
    private void autoSaveCycle() {
        persistWatchPosition();
        if (exoPlayer != null && exoPlayer.isPlaying()) {
            handler.postDelayed(autoSaveRunnable, AUTO_SAVE_INTERVAL);
        }
    }

    /** احفظ الموضع الحالي فوراً في SharedPreferences */
    private void persistWatchPosition() {
        if (exoPlayer == null || episodeId == -1) return;
        long pos = exoPlayer.getCurrentPosition();
        long dur = exoPlayer.getDuration();
        if (pos < RESUME_MIN_MS) return; // لا تحفظ مشاهدة أقل من 10 ثوانٍ
        SharedPreferences.Editor ed =
            getSharedPreferences(PREFS_WATCH, MODE_PRIVATE).edit();
        if (dur > 0 && pos >= (long)(dur * COMPLETE_RATIO)) {
            ed.remove(watchKey()); // اكتملت — امسح
        } else {
            ed.putLong(watchKey(), pos);
        }
        ed.apply();
    }

    /** استرجع الموضع المحفوظ (0 إذا لم يوجد) */
    private long loadSavedPosition() {
        if (episodeId == -1) return 0;
        return getSharedPreferences(PREFS_WATCH, MODE_PRIVATE)
               .getLong(watchKey(), 0);
    }

    /**
     * يُستدعى من STATE_READY أول مرة فقط.
     * إذا وُجد موضع محفوظ: ينتقل إليه مباشرةً ويعرض بنر "استئناف من X:XX"
     * يختفي خلال 3 ثوانٍ — المستخدم لا يحتاج لفعل شيء.
     */
    private void applyResumeIfNeeded() {
        long saved = loadSavedPosition();
        if (saved <= RESUME_MIN_MS) return;
        exoPlayer.seekTo(saved);
        showResumeBanner(saved);
    }

    /** بنر خفيف يُظهر للمستخدم أنه استؤنفت المشاهدة من موضع معين */
    private void showResumeBanner(long posMs) {
        // نستخدم tvBufferingPct كـ banner مؤقت — فهو موجود ومعقول الحجم
        // بديلاً عن Toast الذي يظهر فوق كل شيء
        handler.post(() -> {
            if (tvBufferingPct == null) return;
            tvBufferingPct.setText(getString(R.string.resume_from, formatTime(posMs)));
            tvBufferingPct.setVisibility(View.VISIBLE);
            handler.postDelayed(() -> {
                if (tvBufferingPct != null) tvBufferingPct.setVisibility(View.GONE);
            }, 3_000);
        });
    }

    // ════════════════════════════════════════════════════════
    //  Helpers
    // ════════════════════════════════════════════════════════

    /**
     * يختار مسار الترجمة حسب اللغة المفضلة في Settings → Playback.
     * التطابق يكون على بادئة رمز اللغة (ar / en). auto أو غياب التطابق = أول مسار.
     */
    private String formatTime(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0)
            return String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(java.util.Locale.US, "%d:%02d", m, sec);
    }

    private String nvl(String s)             { return s != null ? s : ""; }
    private String nvl(String s, String def) { return s != null ? s : def; }
}
