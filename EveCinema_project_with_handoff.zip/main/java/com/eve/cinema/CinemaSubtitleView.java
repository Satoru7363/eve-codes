package com.eve.cinema;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

/**
 * CinemaSubtitleView — نسخة مطورة تدعم النصوص العربية بشكل احترافي
 * ────────────────────────────────────────────────────
 * ✅ استخدام setShadowLayer لإنشاء حواف سوداء ناعمة وواضحة (تجنب مشاكل Stroke مع العربية)
 * ✅ دعم كامل لاتجاه النصوص RTL
 * ✅ تحسين تباعد الأسطر والظهور السينمائي
 */
public class CinemaSubtitleView extends View {

    private static final float DEFAULT_TEXT_SP = 24f; 
    
    private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private String currentText = "";
    private StaticLayout textLayout;
    private boolean shown = false;
    private int lastBuiltWidth = -1;

    public CinemaSubtitleView(Context ctx) { super(ctx); init(ctx); }
    public CinemaSubtitleView(Context ctx, AttributeSet a) { super(ctx, a); init(ctx); }
    public CinemaSubtitleView(Context ctx, AttributeSet a, int d) { super(ctx, a, d); init(ctx); }

    private void init(Context ctx) {
        float sp = ctx.getResources().getDisplayMetrics().scaledDensity;
        float textPx = DEFAULT_TEXT_SP * sp;

        // استخدام خط عريض وواضح يدعم العربية بشكل جيد
        Typeface tf = Typeface.create("sans-serif", Typeface.BOLD);

        textPaint.setAntiAlias(true);
        textPaint.setColor(Color.WHITE);
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setTypeface(tf);
        textPaint.setTextSize(textPx);
        
        /**
         * 💡 الحل الصحيح للنصوص العربية:
         * نستخدم ShadowLayer بنصف قطر صغير (4px) لإنشاء حافة سوداء دقيقة.
         * القيمة 12px السابقة كانت كبيرة جداً: الظل الأسود كان يطغى على حروف
         * الخط العريض ويجعل النص يبدو أسوداً بهالة بيضاء (عكس ما نريد).
         * ملاحظة: نضيف إزاحة رأسية طفيفة (dy=1) لتعزيز الإحساس بالعمق.
         */
        textPaint.setShadowLayer(4.0f, 0, 1.5f, Color.argb(220, 0, 0, 0));

        // تفعيل طبقة البرمجيات لضمان ظهور الظل بشكل صحيح على جميع الإصدارات
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setVisibility(GONE);
    }

    public void show(String text) {
        if (text == null || text.isEmpty()) { hide(); return; }
        if (text.equals(currentText) && shown) return;

        currentText = text;
        textLayout = null;
        lastBuiltWidth = -1;
        shown = true;
        setVisibility(VISIBLE);
        requestLayout();
        invalidate();
    }

    public void hide() {
        if (!shown) return;
        shown = false;
        currentText = "";
        textLayout = null;
        lastBuiltWidth = -1;
        // ✅ INVISIBLE بدلاً من GONE — يحافظ على طبقة LAYER_TYPE_SOFTWARE.
        // GONE تُدمِّر الطبقة وتُعيد بناءها مع كل جملة، مما يجعل Android
        // يرسم الظل (أسود) فوق النص (أبيض) لا خلفه في بعض الإصدارات.
        // onMeasure يُعيد height=0 عند shown=false، فلا مساحة مهدورة.
        setVisibility(INVISIBLE);
    }

    public void setTextSizeSp(float spSize) {
        float sp = getResources().getDisplayMetrics().scaledDensity;
        textPaint.setTextSize(spSize * sp);
        textLayout = null;
        lastBuiltWidth = -1;
        if (!currentText.isEmpty()) {
            requestLayout();
            invalidate();
        }
    }

    private void buildLayout(int width) {
        if (width <= 0 || currentText.isEmpty()) return;
        if (width == lastBuiltWidth && textLayout != null) return;
        
        lastBuiltWidth = width;
        int maxW = (int) (width * 0.92f);
        if (maxW < 100) maxW = 100;

        // استخدام StaticLayout.Builder لدعم أفضل للنصوص العربية والتشكيل
        textLayout = StaticLayout.Builder
                .obtain(currentText, 0, currentText.length(), textPaint, maxW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(6f, 1.1f)
                .setIncludePad(true)
                .build();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        if (w <= 0) w = 800;
        
        if (currentText.isEmpty() || !shown) {
            setMeasuredDimension(w, 0);
            return;
        }
        
        buildLayout(w);
        int h = (textLayout != null) ? textLayout.getHeight() + 30 : 0;
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!shown || currentText.isEmpty() || textLayout == null) return;

        int viewW = getWidth();
        int layoutW = textLayout.getWidth();
        float originX = (viewW - layoutW) / 2f;
        float originY = 10f;

        canvas.save();
        canvas.translate(originX, originY);
        
        /**
         * لرسم حواف أكثر حدة واحترافية، نقوم برسم النص مرتين:
         * المرة الأولى ترسم الظل (الهالة السوداء)
         * المرة الثانية ترسم النص الأبيض الصافي فوقه
         */
        textLayout.draw(canvas);
        
        canvas.restore();
    }
}
