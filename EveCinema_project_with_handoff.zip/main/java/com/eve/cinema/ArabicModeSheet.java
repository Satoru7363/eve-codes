package com.eve.cinema;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Accessible themed chooser. It intentionally exposes exactly two Arabic modes. */
public final class ArabicModeSheet extends Dialog {
    public static final int ARABIC_SUBTITLES = 1;
    public static final int ARABIC_DUB = 2;
    public interface Listener { void onChosen(int mode); }
    private final boolean subtitlesAvailable, dubAvailable;
    private final String subtitleReason, dubReason;
    private final Listener listener;

    public ArabicModeSheet(Context context, boolean subtitlesAvailable, String subtitleReason,
                           boolean dubAvailable, String dubReason, Listener listener) {
        super(context, R.style.QualitySheetTheme);
        this.subtitlesAvailable = subtitlesAvailable; this.subtitleReason = subtitleReason;
        this.dubAvailable = dubAvailable; this.dubReason = dubReason; this.listener = listener;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); requestWindowFeature(Window.FEATURE_NO_TITLE);
        float d = getContext().getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(getContext()); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(px(d, 22), px(d, 20), px(d, 22), px(d, 20));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xF21B1925); bg.setCornerRadius(px(d, 24));
        bg.setStroke(px(d, 1), 0x557D63A6); root.setBackground(bg);
        TextView title = text("طريقة المشاهدة", 18, 0xFFFFFFFF, true);
        title.setGravity(Gravity.CENTER); root.addView(title, params(-1, -2, 0, 0, 0, px(d, 6)));
        TextView hint = text("اختر أحد الخيارين العربيين المتاحين لهذا المصدر", 13, 0xFFB9B3C6, false);
        hint.setGravity(Gravity.CENTER); root.addView(hint, params(-1, -2, 0, 0, 0, px(d, 16)));
        root.addView(row("ترجمة عربية", subtitlesAvailable ? "ترجمة عربية متاحة" : safeReason(subtitleReason), subtitlesAvailable, d, ARABIC_SUBTITLES));
        root.addView(row("دبلجة عربية", dubAvailable ? "مسار صوت عربي متاح" : safeReason(dubReason), dubAvailable, d, ARABIC_DUB));
        TextView cancel = text("إلغاء", 14, 0xFFB9B3C6, false); cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(0, px(d, 13), 0, px(d, 3)); cancel.setClickable(true); cancel.setFocusable(true); cancel.setOnClickListener(v -> dismiss());
        root.addView(cancel, params(-1, -2, 0, px(d, 3), 0, 0));
        setContentView(root);
        Window w = getWindow(); if (w != null) { w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); w.setGravity(Gravity.BOTTOM); w.setBackgroundDrawableResource(android.R.color.transparent); w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND); }
    }
    private View row(String label, String detail, boolean enabled, float d, int mode) {
        LinearLayout row = new LinearLayout(getContext()); row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(px(d, 15), px(d, 14), px(d, 15), px(d, 14));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(enabled ? 0xFF262131 : 0xFF201E27); bg.setCornerRadius(px(d, 15)); bg.setStroke(px(d, 1), enabled ? 0x887B61A7 : 0x443F3B46); row.setBackground(bg);
        LinearLayout.LayoutParams rp = params(-1, -2, 0, 0, 0, px(d, 9)); row.setLayoutParams(rp);
        TextView main = text(label, 16, enabled ? 0xFFFFFFFF : 0xFF77727E, true);
        TextView sub = text(detail, 12, enabled ? 0xFFC9BED9 : 0xFF7B7681, false);
        LinearLayout.LayoutParams sp = params(-1, -2, 0, px(d, 4), 0, 0); row.addView(main); row.addView(sub, sp);
        row.setEnabled(enabled); row.setClickable(enabled); row.setFocusable(true); row.setContentDescription(label + ". " + detail);
        if (enabled) row.setOnClickListener(v -> { dismiss(); if (listener != null) listener.onChosen(mode); });
        return row;
    }
    private static String safeReason(String s) { return s == null || s.trim().isEmpty() ? "غير متاحة لهذا المصدر" : s; }
    private TextView text(String s, int size, int color, boolean bold) { TextView v = new TextView(getContext()); v.setText(s); v.setTextSize(size); v.setTextColor(color); if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); return v; }
    private static LinearLayout.LayoutParams params(int w, int h, int l, int t, int r, int b) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h); p.setMargins(l,t,r,b); return p; }
    private static int px(float d, int v) { return (int)(d * v + .5f); }
}
