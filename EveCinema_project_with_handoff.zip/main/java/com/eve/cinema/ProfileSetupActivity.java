package com.eve.cinema;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * ProfileSetupActivity — شاشة إعداد الملف الشخصي
 * ─────────────────────────────────────────────────────────────────────
 * تُفتح مرة واحدة فقط بعد تسجيل الدخول بـ Google لأول مرة.
 *
 * المستخدم يختار:
 *   1. صورة من الجوال كأفاتار لحسابه
 *   2. اسم ظاهر
 *
 * تُحفظ هذه البيانات دائماً في UserSession حتى يغيّرها المستخدم
 * بنفسه من الإعدادات.
 * ─────────────────────────────────────────────────────────────────────
 */
public class ProfileSetupActivity extends Activity {

    private static final int PICK_IMAGE = 101;

    // ── ألوان ──
    private static final int C_BG        = 0xFF08080F;
    private static final int C_CARD      = 0xFF0D0D1A;
    private static final int C_PURPLE    = 0xFF9B6FC4;
    private static final int C_PURPLE_DK = 0xFF7A5099;
    private static final int C_PURPLE_BRD= 0x409B6FC4;
    private static final int C_TEXT_PRI  = 0xFFFFFFFF;
    private static final int C_TEXT_MUT  = 0xFF6B6B88;
    private static final int C_GREEN     = 0xFF34D399;
    private static final int C_BG_FIELD  = 0xFF13131F;

    // ── Views ──
    private ImageView   avatarPreview;
    private LinearLayout avatarPlaceholder;
    private FrameLayout  avatarRemove;
    private EditText    nameInput;
    private TextView    saveBtn;
    private ProgressBar progress;

    private String selectedAvatarUri = null;
    private UserSession session;

    // ══════════════════════════════════════════════════════════════════
    // onCreate
    // ══════════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        MiuiBarFix.apply(this);

        session = new UserSession(this);

        setContentView(buildUI());

        // ملء الاسم من Google تلقائياً إن وُجد
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null && user.getDisplayName() != null && !user.getDisplayName().isEmpty()) {
            nameInput.setText(user.getDisplayName());
            nameInput.setSelection(user.getDisplayName().length());
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // بناء الواجهة
    // ══════════════════════════════════════════════════════════════════
    private View buildUI() {
        // Root scroll
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(C_BG);
        sv.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(56), dp(24), dp(40));

        // ── عنوان ──
        TextView title = tv("أكمل إعداد حسابك", 22f, C_TEXT_PRI, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = lp(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, dp(8));
        title.setLayoutParams(tlp);
        root.addView(title);

        TextView sub = tv("اختر صورة واسماً يظهران في ملفك الشخصي.\nيمكنك تغييرهما لاحقاً من الإعدادات.", 13f, C_TEXT_MUT, Typeface.NORMAL);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams slp = lp(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, dp(36));
        sub.setLayoutParams(slp);
        root.addView(sub);

        // ══ منطقة الأفاتار ══
        root.addView(buildAvatarSection());

        // ══ حقل الاسم ══
        root.addView(buildLabel("الاسم المعروض"));
        nameInput = buildEditText("أدخل اسمك");
        nameInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(30)});
        LinearLayout.LayoutParams eilp = lp(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, dp(6));
        nameInput.setLayoutParams(eilp);
        root.addView(nameInput);

        TextView hint = tv("هذا الاسم يظهر في ملفك الشخصي", 11f, C_TEXT_MUT, Typeface.NORMAL);
        hint.setPadding(dp(4), 0, 0, 0);
        LinearLayout.LayoutParams hlp = lp(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, dp(32));
        hint.setLayoutParams(hlp);
        root.addView(hint);

        // ══ مؤشر التحميل ══
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams plp2 = new LinearLayout.LayoutParams(dp(32), dp(32));
        plp2.gravity = Gravity.CENTER_HORIZONTAL;
        plp2.bottomMargin = dp(12);
        progress.setLayoutParams(plp2);
        root.addView(progress);

        // ══ زر الحفظ ══
        saveBtn = new TextView(this);
        saveBtn.setText("✓  حفظ والمتابعة");
        saveBtn.setTextColor(Color.WHITE);
        saveBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f);
        saveBtn.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        saveBtn.setGravity(Gravity.CENTER);
        saveBtn.setPadding(0, dp(18), 0, dp(18));
        GradientDrawable saveBg = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, new int[]{C_PURPLE, C_PURPLE_DK});
        saveBg.setCornerRadius(dp(16));
        saveBtn.setBackground(saveBg);
        LinearLayout.LayoutParams sblp = lp(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, 0);
        saveBtn.setLayoutParams(sblp);
        saveBtn.setClickable(true);
        saveBtn.setFocusable(true);
        saveBtn.setOnClickListener(v -> saveProfile());
        root.addView(saveBtn);

        sv.addView(root);
        return sv;
    }

    /** قسم رفع الصورة */
    private View buildAvatarSection() {
        // الغلاف الخارجي
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams wlp = lp(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, dp(28));
        wrapper.setLayoutParams(wlp);

        // منطقة الصورة القابلة للنقر
        FrameLayout uploadArea = new FrameLayout(this);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(dp(110), dp(110));
        ulp.gravity = Gravity.CENTER_HORIZONTAL;
        uploadArea.setLayoutParams(ulp);
        uploadArea.setClickable(true);
        uploadArea.setFocusable(true);

        // خلفية دائرية
        GradientDrawable circleBg = new GradientDrawable();
        circleBg.setShape(GradientDrawable.OVAL);
        circleBg.setColor(C_CARD);
        circleBg.setStroke(dp(2), C_PURPLE_BRD);
        uploadArea.setBackground(circleBg);

        // نص الـ placeholder
        avatarPlaceholder = new LinearLayout(this);
        avatarPlaceholder.setOrientation(LinearLayout.VERTICAL);
        avatarPlaceholder.setGravity(Gravity.CENTER);
        avatarPlaceholder.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView camIcon = tv("📷", 26f, C_PURPLE, Typeface.NORMAL);
        camIcon.setGravity(Gravity.CENTER);
        avatarPlaceholder.addView(camIcon);

        TextView addTv = tv("اختر صورة", 11f, C_TEXT_MUT, Typeface.NORMAL);
        addTv.setGravity(Gravity.CENTER);
        avatarPlaceholder.addView(addTv);

        uploadArea.addView(avatarPlaceholder);

        // صورة المعاينة (مخفية في البداية)
        avatarPreview = new ImageView(this);
        avatarPreview.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        avatarPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarPreview.setVisibility(View.GONE);
        uploadArea.addView(avatarPreview);

        // زر إزالة الصورة (X) في الزاوية
        avatarRemove = new FrameLayout(this);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(26), dp(26));
        rlp.gravity = Gravity.END | Gravity.TOP;
        avatarRemove.setLayoutParams(rlp);
        GradientDrawable removeBg = new GradientDrawable();
        removeBg.setShape(GradientDrawable.OVAL);
        removeBg.setColor(0xFFE53935);
        avatarRemove.setBackground(removeBg);
        avatarRemove.setVisibility(View.GONE);
        TextView removeX = tv("✕", 11f, Color.WHITE, Typeface.BOLD);
        removeX.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        removeX.setGravity(Gravity.CENTER);
        avatarRemove.addView(removeX);
        uploadArea.addView(avatarRemove);

        uploadArea.setOnClickListener(v -> pickImageFromGallery());
        avatarRemove.setOnClickListener(v -> clearAvatar());

        wrapper.addView(uploadArea);

        // نص "اختياري"
        TextView optTv = tv("الصورة اختيارية", 11f, C_TEXT_MUT, Typeface.NORMAL);
        optTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams otlp = lp(LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT, dp(8), 0, 0, 0);
        optTv.setLayoutParams(otlp);
        wrapper.addView(optTv);

        return wrapper;
    }

    // ══════════════════════════════════════════════════════════════════
    // رفع الصورة من المعرض
    // ══════════════════════════════════════════════════════════════════
    private void pickImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE);
    }

    private void clearAvatar() {
        selectedAvatarUri = null;
        avatarPreview.setVisibility(View.GONE);
        avatarPreview.setImageBitmap(null);
        avatarPlaceholder.setVisibility(View.VISIBLE);
        avatarRemove.setVisibility(View.GONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    try {
                        getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {}

                    InputStream is = getContentResolver().openInputStream(uri);
                    Bitmap bmp = BitmapFactory.decodeStream(is);
                    if (bmp != null) {
                        // ── نسخ الصورة للتخزين الداخلي (تبقى بعد إعادة التشغيل) ──
                        Bitmap scaled = Bitmap.createScaledBitmap(bmp, 256, 256, true);
                        String savedPath = saveAvatarToInternalStorage(scaled);
                        selectedAvatarUri = savedPath != null ? savedPath : uri.toString();
                        Bitmap circular = MainActivity.makeCircular(
                            Bitmap.createScaledBitmap(bmp, 192, 192, true));

                        avatarPreview.setImageBitmap(circular);
                        avatarPreview.setVisibility(View.VISIBLE);
                        avatarPreview.animate().scaleX(0.8f).scaleY(0.8f).setDuration(0).start();
                        avatarPreview.animate().scaleX(1f).scaleY(1f).setDuration(250).start();
                        avatarPlaceholder.setVisibility(View.GONE);
                        avatarRemove.setVisibility(View.VISIBLE);
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "تعذر تحميل الصورة", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // حفظ الملف الشخصي
    // ══════════════════════════════════════════════════════════════════
    private void saveProfile() {
        String name = nameInput.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "أدخل اسمك الظاهر", Toast.LENGTH_SHORT).show();
            return;
        }
        if (name.length() < 2) {
            Toast.makeText(this, "الاسم قصير جداً (حرفان على الأقل)", Toast.LENGTH_SHORT).show();
            return;
        }

        setUiLoading(true);

        // ① حفظ محلياً في UserSession (دائم)
        session.saveProfile(name, 0, selectedAvatarUri != null ? selectedAvatarUri : "");

        // ② حفظ في Firestore
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            Map<String, Object> updates = new HashMap<>();
            updates.put("name",      name);
            updates.put("photoUri",  selectedAvatarUri != null ? selectedAvatarUri : "");
            updates.put("lastLogin", System.currentTimeMillis());

            FirebaseFirestore.getInstance()
                .collection("users")
                .document(user.getUid())
                .update(updates)
                .addOnCompleteListener(t -> goToMain());
        } else {
            goToMain();
        }
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    private void setUiLoading(boolean loading) {
        saveBtn.setAlpha(loading ? 0.5f : 1f);
        saveBtn.setClickable(!loading);
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
    }

    // ══════════════════════════════════════════════════════════════════
    // UI helpers
    // ══════════════════════════════════════════════════════════════════
    private View buildLabel(String text) {
        TextView lbl = tv(text, 12f, C_TEXT_MUT, Typeface.BOLD);
        lbl.setLetterSpacing(0.05f);
        lbl.setPadding(dp(4), 0, 0, dp(6));
        return lbl;
    }

    private EditText buildEditText(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setHintTextColor(C_TEXT_MUT);
        et.setTextColor(C_TEXT_PRI);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        et.setPadding(dp(16), dp(14), dp(16), dp(14));
        et.setBackground(buildFieldBg());
        et.setSingleLine(true);
        et.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return et;
    }

    private GradientDrawable buildFieldBg() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(C_BG_FIELD);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), C_PURPLE_BRD);
        return bg;
    }

    private TextView tv(String text, float sp, int color, int style) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTypeface(Typeface.create(Typeface.DEFAULT, style));
        return tv;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top, int end, int bot_unused, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = top;
        p.bottomMargin = bottom;
        return p;
    }

    /**
     * تنسخ الصورة إلى التخزين الداخلي للتطبيق حتى تبقى بعد إعادة التشغيل.
     * المسار: /data/data/com.eve.cinema/files/user_avatar.jpg
     */
    private String saveAvatarToInternalStorage(Bitmap bmp) {
        try {
            File avatarFile = new File(getFilesDir(), "user_avatar.jpg");
            FileOutputStream fos = new FileOutputStream(avatarFile);
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.flush();
            fos.close();
            return avatarFile.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onResume() { super.onResume(); MiuiBarFix.apply(this); }

    @Override
    protected void onDestroy() { super.onDestroy(); MiuiBarFix.release(this); }

    /** منع الرجوع — يجب إكمال الإعداد */
    @Override
    public void onBackPressed() { }
}
