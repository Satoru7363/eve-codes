package com.eve.cinema;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.eve.cinema.extractor.CinemaBoxExtractor;

import java.util.List;

/**
 * QualityBottomSheet
 * ────────────────────────────────────────────────────────
 * Premium animated quality selector panel.
 * Slides up from bottom with glassmorphism styling.
 */
public class QualityBottomSheet extends Dialog {

    public interface OnQualitySelected {
        void onSelected(String url, String quality);
    }

    private final List<CinemaBoxExtractor.VideoStream> streams;
    private final String                               currentUrl;
    private final OnQualitySelected                    callback;

    public QualityBottomSheet(Context ctx,
                              List<CinemaBoxExtractor.VideoStream> streams,
                              String currentUrl,
                              OnQualitySelected callback) {
        super(ctx, R.style.QualitySheetTheme);
        this.streams    = streams;
        this.currentUrl = currentUrl;
        this.callback   = callback;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(buildLayout());

        Window w = getWindow();
        if (w != null) {
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setWindowAnimations(R.style.QualitySheetAnim);
        }
    }

    private View buildLayout() {
        Context ctx = getContext();
        float density = ctx.getResources().getDisplayMetrics().density;

        // Root container
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(ctx.getDrawable(R.drawable.bg_quality_sheet));
        int padH = (int)(24 * density);
        int padV = (int)(20 * density);
        root.setPadding(padH, padV, padH, padV);

        // ── Handle bar ──
        View handle = new View(ctx);
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(
            (int)(40 * density), (int)(4 * density));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.bottomMargin = (int)(20 * density);
        handle.setLayoutParams(handleLp);
        handle.setBackground(ctx.getDrawable(R.drawable.bg_handle));
        root.addView(handle);

        // ── Title ──
        TextView title = new TextView(ctx);
        title.setText("جودة الصورة");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(16f);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium",
                          android.graphics.Typeface.BOLD));
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleLp.bottomMargin = (int)(16 * density);
        title.setLayoutParams(titleLp);
        root.addView(title);

        // ── Quality rows ──
        for (CinemaBoxExtractor.VideoStream stream : streams) {
            root.addView(buildQualityRow(ctx, stream, density));
        }

        return root;
    }

    private View buildQualityRow(Context ctx, CinemaBoxExtractor.VideoStream stream,
                                  float density) {
        boolean isCurrent = stream.url.equals(currentUrl);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        int rowPadH = (int)(12 * density);
        int rowPadV = (int)(14 * density);
        row.setPadding(rowPadH, rowPadV, rowPadH, rowPadV);
        row.setBackground(ctx.getDrawable(
            isCurrent ? R.drawable.bg_quality_row_active : R.drawable.bg_quality_row));

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.bottomMargin = (int)(8 * density);
        row.setLayoutParams(rowLp);

        // Quality label badge (clean text)
        TextView badge = new TextView(ctx);
        badge.setText(getQualityLabel(stream.quality));
        badge.setTextColor(isCurrent ? 0xFF9B6FC4 : 0xFF888888);
        badge.setTextSize(11f);
        badge.setMinWidth((int)(36 * density));
        row.addView(badge);

        // Quality label
        TextView label = new TextView(ctx);
        label.setText(stream.quality);
        label.setTextColor(isCurrent ? 0xFF9B6FC4 : 0xFFFFFFFF);
        label.setTextSize(15f);
        label.setTypeface(android.graphics.Typeface.create("sans-serif",
                          isCurrent ? android.graphics.Typeface.BOLD
                                    : android.graphics.Typeface.NORMAL));
        LinearLayout.LayoutParams lLp = new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lLp.setMarginStart((int)(12 * density));
        label.setLayoutParams(lLp);
        row.addView(label);

        // Checkmark if current
        if (isCurrent) {
            TextView check = new TextView(ctx);
            check.setText("✓");
            check.setTextColor(0xFF9B6FC4);
            check.setTextSize(18f);
            row.addView(check);
        }

        row.setOnClickListener(v -> {
            if (!isCurrent && callback != null) {
                callback.onSelected(stream.url, stream.quality);
            }
            dismiss();
        });

        // Ripple feedback
        row.setClickable(true);
        row.setFocusable(true);

        return row;
    }

    private String getQualityLabel(String quality) {
        if (quality == null) return "SD";
        String q = quality.toLowerCase();
        if (q.contains("4k") || q.contains("2160")) return "4K";
        if (q.contains("1080"))                      return "FHD";
        if (q.contains("720"))                       return "HD";
        if (q.contains("480"))                       return "SD";
        if (q.contains("360"))                       return "LD";
        if (q.contains("240"))                       return "240p";
        return "—";
    }
}
