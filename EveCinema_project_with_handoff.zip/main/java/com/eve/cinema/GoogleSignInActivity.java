package com.eve.cinema;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

/**
 * GoogleSignInActivity — شاشة Google الإجبارية
 * ─────────────────────────────────────────────────────────────────────────────
 * Firebase-first flow:
 *   Google → Firebase Auth → Firestore Save → Session Cache → MainActivity
 *
 * لا ProfileSetupActivity — الملف الشخصي يأتي من Google مباشرة.
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class GoogleSignInActivity extends Activity {

    private static final int RC_GOOGLE = 9001;

    private static final int C_BG       = 0xFF08080F;
    private static final int C_PURPLE   = 0xFF9B6FC4;
    private static final int C_PURPLE_DK= 0xFF7A5099;
    private static final int C_TEXT_MUT = 0xFF6B6B88;

    private GoogleSignInClient googleSignInClient;
    private FirebaseAuth       firebaseAuth;
    private FirebaseFirestore  firestore;
    private UserSession        session;

    private boolean      signInLaunched = false;
    private boolean      navigationDone = false;
    private ProgressBar  loadingBar;
    private LinearLayout retryLayout;
    private TextView     waitTv;

    // ═════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        MiuiBarFix.apply(this);

        session      = new UserSession(this);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore    = FirebaseFirestore.getInstance();

        GoogleSignInOptions gso = new GoogleSignInOptions
                .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .requestProfile()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);

        setContentView(buildUI());
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser current = firebaseAuth.getCurrentUser();
        if (current != null) {
            firebaseFirstFlow(current);
            return;
        }
        if (!signInLaunched) {
            signInLaunched = true;
            launchGooglePicker();
        }
    }

    private void launchGooglePicker() {
        googleSignInClient.signOut().addOnCompleteListener(task -> {
            if (!isFinishing() && !isDestroyed())
                startActivityForResult(googleSignInClient.getSignInIntent(), RC_GOOGLE);
        });
    }

    // ═════════════════════════════════════════════════════
    //  UI
    // ═════════════════════════════════════════════════════
    private View buildUI() {
        // Root with ambient halo (نفس لغة شاشة الدخول)
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(C_BG);

        View halo = new View(this);
        FrameLayout.LayoutParams haloLp = new FrameLayout.LayoutParams(dp(380), dp(380));
        haloLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        haloLp.topMargin = -dp(210);
        halo.setLayoutParams(haloLp);
        halo.setAlpha(0.4f);
        GradientDrawable haloBg = new GradientDrawable();
        haloBg.setShape(GradientDrawable.OVAL);
        haloBg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        haloBg.setColors(new int[]{ 0x669B6FC4, 0x339B6FC4, 0x009B6FC4 });
        haloBg.setGradientRadius(dp(190));
        halo.setBackground(haloBg);
        frame.addView(halo);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(32), dp(48), dp(32), dp(48));
        frame.addView(root, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // logo — بنفس كبسولة الشعار المستخدمة في الدخول/الإعدادات
        FrameLayout logoWrap = new FrameLayout(this);
        LinearLayout.LayoutParams lwp = new LinearLayout.LayoutParams(dp(72), dp(72));
        lwp.gravity = Gravity.CENTER_HORIZONTAL;
        lwp.bottomMargin = dp(14);
        logoWrap.setLayoutParams(lwp);
        GradientDrawable logoBg = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR, new int[]{C_PURPLE, C_PURPLE_DK});
        logoBg.setCornerRadius(dp(24));
        logoWrap.setBackground(logoBg);
        TextView logoTv = tv("V", 34f, Color.WHITE, Typeface.BOLD);
        logoTv.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        logoTv.setGravity(Gravity.CENTER);
        logoWrap.addView(logoTv);
        root.addView(logoWrap);

        TextView wordmark = tv("EVE CINEMA", 11f, 0xFFC4A0E8, Typeface.BOLD);
        wordmark.setLetterSpacing(0.24f);
        LinearLayout.LayoutParams wmLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        wmLp.bottomMargin = dp(34);
        wordmark.setLayoutParams(wmLp);
        root.addView(wordmark);

        waitTv = tv("جارٍ فتح اختيار الحساب...", 15f, 0xFFCCCCCC, Typeface.NORMAL);
        waitTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        wlp.bottomMargin = dp(24);
        waitTv.setLayoutParams(wlp);
        root.addView(waitTv);

        loadingBar = new ProgressBar(this);
        loadingBar.setIndeterminate(true);
        loadingBar.setIndeterminateTintList(
            android.content.res.ColorStateList.valueOf(C_PURPLE));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(40), dp(40));
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        plp.bottomMargin = dp(32);
        loadingBar.setLayoutParams(plp);
        root.addView(loadingBar);

        // retry section داخل بطاقة زجاجية (مخفية بالكامل حتى تُطلب)
        LinearLayout retryCard = new LinearLayout(this);
        retryCard.setOrientation(LinearLayout.VERTICAL);
        retryCard.setGravity(Gravity.CENTER);
        retryCard.setPadding(dp(22), dp(24), dp(22), dp(22));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setCornerRadius(dp(24));
        cardBg.setColor(0xB8121224);          // glass_panel_fill
        cardBg.setStroke(dp(1), 0x22FFFFFF);  // glass_panel_stroke
        retryCard.setBackground(cardBg);
        retryCard.setClipToOutline(true);
        retryCard.setVisibility(View.GONE);
        retryLayout = retryCard;
        root.addView(retryCard);

        TextView cancelMsg = tv("تم إلغاء تسجيل الدخول", 13f, C_TEXT_MUT, Typeface.NORMAL);
        cancelMsg.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cmlp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cmlp.bottomMargin = dp(20);
        cancelMsg.setLayoutParams(cmlp);
        retryCard.addView(cancelMsg);

        LinearLayout retryBtn = buildGoogleBtn();
        retryBtn.setOnClickListener(v -> {
            retryLayout.setVisibility(View.GONE);
            loadingBar.setVisibility(View.VISIBLE);
            if (waitTv != null) waitTv.setVisibility(View.VISIBLE);
            launchGooglePicker();
        });
        retryCard.addView(retryBtn);

        return frame;
    }

    private LinearLayout buildGoogleBtn() {
        LinearLayout btn = new LinearLayout(this);
        btn.setOrientation(LinearLayout.HORIZONTAL);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(16), 0, dp(16));
        LinearLayout.LayoutParams rblp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        btn.setLayoutParams(rblp);
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, new int[]{C_PURPLE, C_PURPLE_DK});
        bg.setCornerRadius(dp(14));
        btn.setBackground(bg);
        btn.setClickable(true);
        btn.setFocusable(true);

        FrameLayout gCircle = new FrameLayout(this);
        LinearLayout.LayoutParams gcp = new LinearLayout.LayoutParams(dp(28), dp(28));
        gcp.setMarginEnd(dp(10));
        gCircle.setLayoutParams(gcp);
        GradientDrawable gBg = new GradientDrawable();
        gBg.setShape(GradientDrawable.OVAL);
        gBg.setColor(0xFF4285F4);
        gCircle.setBackground(gBg);
        TextView gIcon = tv("G", 14f, Color.WHITE, Typeface.BOLD);
        gIcon.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        gIcon.setGravity(Gravity.CENTER);
        gCircle.addView(gIcon);
        btn.addView(gCircle);
        btn.addView(tv("اختر حساب Google", 15f, Color.WHITE, Typeface.BOLD));

        btn.setOnTouchListener((v, e) -> {
            if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) btn.setAlpha(0.75f);
            else btn.setAlpha(1f);
            return false;
        });

        return btn;
    }

    // ═════════════════════════════════════════════════════
    //  onActivityResult
    // ═════════════════════════════════════════════════════
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != RC_GOOGLE) return;

        if (resultCode != RESULT_OK || data == null) {
            showRetry();
            return;
        }

        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);

            firebaseAuth.signInWithCredential(credential).addOnCompleteListener(t -> {
                if (t.isSuccessful()) {
                    FirebaseUser user = firebaseAuth.getCurrentUser();
                    if (user != null) firebaseFirstFlow(user);
                    else showRetry();
                } else {
                    showRetry();
                }
            });

        } catch (ApiException e) {
            showRetry();
        }
    }

    // ═════════════════════════════════════════════════════
    //  FIREBASE-FIRST FLOW
    //  Google → Firestore → Session Cache → Cinematic → MainActivity
    // ═════════════════════════════════════════════════════
    private void firebaseFirstFlow(FirebaseUser user) {
        if (navigationDone) return;

        String name     = user.getDisplayName() != null ? user.getDisplayName() : "مستخدم";
        String email    = user.getEmail() != null ? user.getEmail() : "";
        String photoUrl = user.getPhotoUrl() != null
            ? user.getPhotoUrl().toString().replace("=s96-c", "=s400-c") : "";

        // local cache أولاً (instant)
        session.saveGoogleProfile(name, email, photoUrl);

        // Firestore save مع merge (لا blocking)
        Map<String, Object> data = new HashMap<>();
        data.put("uid",         user.getUid());
        data.put("name",        name);
        data.put("email",       email);
        data.put("photoUrl",    photoUrl);
        data.put("premiumCode", session.getCode());
        data.put("deviceId",    session.getDeviceId());
        data.put("lastLogin",   System.currentTimeMillis());
        data.put("createdAt",   System.currentTimeMillis());

        firestore.collection("users")
            .document(user.getUid())
            .set(data, SetOptions.merge());
        // لا ننتظر نتيجة Firestore — نتابع مباشرة

        showCinematicAndNavigate();
    }

    /** Overlay سينمائي قبل الانتقال */
    private void showCinematicAndNavigate() {
        if (navigationDone) return;
        navigationDone = true;

        View root = getWindow().getDecorView().getRootView();
        ObjectAnimator fadeOut = ObjectAnimator.ofFloat(root, "alpha", 1f, 0f);
        fadeOut.setDuration(380);
        fadeOut.setInterpolator(new DecelerateInterpolator());
        fadeOut.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (!isFinishing() && !isDestroyed()) navigateToMain();
            }
        });
        fadeOut.start();
    }

    private void navigateToMain() {
        Intent next = new Intent(this, MainActivity.class);
        next.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(next);
        overridePendingTransition(0, 0);
        finish();
    }

    private void showRetry() {
        signInLaunched = false;
        if (loadingBar != null)  loadingBar.setVisibility(View.GONE);
        if (waitTv != null)    waitTv.setVisibility(View.GONE);
        if (retryLayout != null) retryLayout.setVisibility(View.VISIBLE);
    }

    // ── helpers ──
    private TextView tv(String text, float sp, int color, int style) {
        TextView tv = new TextView(this);
        tv.setText(text); tv.setTextColor(color);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTypeface(Typeface.create(Typeface.DEFAULT, style));
        return tv;
    }
    private int dp(int d) { return Math.round(d * getResources().getDisplayMetrics().density); }

    @Override protected void onResume()  { super.onResume();  MiuiBarFix.apply(this); }
    @Override protected void onDestroy() { super.onDestroy(); MiuiBarFix.release(this); }
    @Override public void onBackPressed() { /* إجبارية */ }
}
