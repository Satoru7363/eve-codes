package com.eve.cinema;

import com.eve.cinema.extractor.CinemaBoxExtractor;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class CinemaBoxBridge {

    // ── حدود الثقة ────────────────────────────────────────────
    private static final int MIN_SCORE        = 30;  // رُفع من 28
    private static final int MIN_SCORE_STRICT = 34;  // رُفع من 32

    // ── الحد الأدنى لطول الكلمة المعتبرة في word-overlap ────
    private static final int WORD_MIN_LEN = 3;

    // ── كلمات شائعة لا تُحتسب في word-overlap ───────────────
    // ✅ إصلاح: حُذفت كلمات المحتوى الأساسية (life, world, another, starting, zero...)
    private static final java.util.Set<String> STOPWORDS;
    static {
        STOPWORDS = new java.util.HashSet<String>(java.util.Arrays.asList(
            "the","and","for","with","this","that","from","into",
            "season","part","new","ova","ona","special","movie","film"
        ));
    }

    private static class ScoredResult {
        final int id;
        final int score;
        final int year;
        ScoredResult(int id, int score) { this(id, score, 0); }
        ScoredResult(int id, int score, int year) {
            this.id = id; this.score = score; this.year = year;
        }
        static final ScoredResult NONE = new ScoredResult(-1, -1, 0);
    }

    // ══════════════════════════════════════════════════════════
    //  نموذج الإخراج
    // ══════════════════════════════════════════════════════════

    public static class ResolveResult {
        public final int    episodeId;
        public final int    showId;
        public final String quality;
        public final String streamUrl;
        public final CinemaBoxExtractor.MediaResult mediaResult;

        ResolveResult(int episodeId, int showId, String quality,
                      String streamUrl, CinemaBoxExtractor.MediaResult mr) {
            this.episodeId   = episodeId;
            this.showId      = showId;
            this.quality     = quality;
            this.streamUrl   = streamUrl;
            this.mediaResult = mr;
        }
    }

    private static CinemaBoxExtractor extractor;

    public static synchronized CinemaBoxExtractor getExtractor() {
        if (extractor == null) extractor = new CinemaBoxExtractor();
        return extractor;
    }

    /**
     * Lightweight availability probe for the pre-playback source selector:
     * true when CinemaBox has a title whose type/year gates pass. Performs a
     * search only — no stream extraction. Any failure means "not available".
     * New code should use {@link #probeAvailabilityOutcome} so a transient
     * failure is never cached as a definitive "not found".
     */
    public static boolean probeAvailability(String title, String originalTitle,
                                            int year, String type) {
        return probeAvailabilityOutcome(title, originalTitle, year, type)
                == com.eve.cinema.playback.ProbeOutcome.VERIFIED;
    }

    /** Total probe attempts: the first try plus at most two retries (WP2). */
    private static final int MAX_PROBE_ATTEMPTS = 3;

    /**
     * Classified availability probe (WP2): a completed search yields VERIFIED,
     * NOT_FOUND_DEFINITIVE or REJECTED_BY_IDENTITY; login/network/parse
     * failures are retried at most twice with backoff and then reported as
     * UNRESOLVED_TRANSIENT — never as "the title does not exist" (I6).
     */
    public static com.eve.cinema.playback.ProbeOutcome probeAvailabilityOutcome(
            String title, String originalTitle, int year, String type) {
        int attempt = 0;
        while (true) {
            attempt++;
            try {
                CinemaBoxExtractor ex = ensureLoggedIn();
                boolean[] rejectedByIdentity = new boolean[1];
                int id = searchAndPick(ex, title, originalTitle, year, type,
                        rejectedByIdentity);
                com.eve.cinema.playback.ProbeOutcome outcome =
                        id != -1 ? com.eve.cinema.playback.ProbeOutcome.VERIFIED
                        : rejectedByIdentity[0]
                                ? com.eve.cinema.playback.ProbeOutcome.REJECTED_BY_IDENTITY
                                : com.eve.cinema.playback.ProbeOutcome.NOT_FOUND_DEFINITIVE;
                com.eve.cinema.playback.ResolutionTrace.record("cb.probe",
                        outcome.name(), "id=" + id);
                return outcome;
            } catch (Exception e) {
                if (attempt >= MAX_PROBE_ATTEMPTS || !probeBackoff(attempt)) {
                    com.eve.cinema.playback.ResolutionTrace.record("cb.probe",
                            "TRANSIENT", e.getClass().getSimpleName());
                    return com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT;
                }
            }
        }
    }

    /** Interruptible backoff between probe retries; false when interrupted. */
    private static boolean probeBackoff(int attempt) {
        try {
            Thread.sleep(400L * attempt);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    // ══════════════════════════════════════════════════════════
    //  resolveMovie
    // ══════════════════════════════════════════════════════════

    public static ResolveResult resolveMovie(String title, int year) throws Exception {
        return resolveMovie(title, null, year);
    }

    public static ResolveResult resolveMovie(String title, String originalTitle,
                                              int year) throws Exception {
        CinemaBoxExtractor ex = ensureLoggedIn();

        int showId = searchAndPick(ex, title, originalTitle, year, "MOVIE");
        if (showId == -1)
            throw new Exception("لم يُعثر على \"" + title + "\" في CinemaBox");

        JSONObject dynamicShow = ex.getDynamicShow(showId);
        JSONObject postInfo    = dynamicShow.optJSONObject("post_info");
        int episodeId = (postInfo != null) ? postInfo.optInt("episode_id", -1) : -1;
        if (episodeId == -1)
            throw new Exception("لم يُعثر على episode_id للفيلم: " + title);

        CinemaBoxExtractor.MediaResult media = ex.getStream(episodeId);
        if (media == null || media.videos == null || media.videos.isEmpty())
            throw new Exception("لا توجد روابط بث متاحة");

        CinemaBoxExtractor.VideoStream best = media.getBestQuality();
        return new ResolveResult(episodeId, showId, best.quality, best.url, media);
    }

    // ══════════════════════════════════════════════════════════
    //  resolveTvEpisode
    // ══════════════════════════════════════════════════════════

    public static ResolveResult resolveTvEpisode(String title, int year,
                                                  int seasonNumber, int episodeNumber)
            throws Exception {
        return resolveTvEpisode(title, null, year, seasonNumber, episodeNumber);
    }

    public static ResolveResult resolveTvEpisode(String title, String originalTitle,
                                                  int year, int seasonNumber,
                                                  int episodeNumber) throws Exception {
        CinemaBoxExtractor ex = ensureLoggedIn();

        int showId = searchAndPick(ex, title, originalTitle, year, "SERIES");
        if (showId == -1)
            throw new Exception("لم يُعثر على \"" + title + "\" في CinemaBox");

        List<Integer> seasonIds = ex.getSeasonIds(showId);

        JSONArray sections;
        if (seasonIds.isEmpty() || (seasonNumber <= 1 && seasonIds.size() <= 1)) {
            sections = ex.getSections(showId);
        } else {
            int seasonIndex = seasonNumber - 1;
            if (seasonIndex >= seasonIds.size())
                throw new Exception("الموسم " + seasonNumber + " غير موجود (المتاح: " + seasonIds.size() + ")");
            int targetSeasonId = seasonIds.get(seasonIndex);
            sections = ex.getDynamicShowWithSeason(showId, targetSeasonId)
                          .optJSONArray("sections");
        }

        int episodeId = findEpisodeInSection(sections, episodeNumber);
        if (episodeId == -1)
            throw new Exception("لم تُوجد الحلقة S" + seasonNumber + "E" + episodeNumber);

        CinemaBoxExtractor.MediaResult media = ex.getStream(episodeId);
        if (media == null || media.videos == null || media.videos.isEmpty())
            throw new Exception("لا توجد روابط بث لهذه الحلقة");

        CinemaBoxExtractor.VideoStream best = media.getBestQuality();
        return new ResolveResult(episodeId, showId, best.quality, best.url, media);
    }

    // ══════════════════════════════════════════════════════════
    //  resolveSeasonEpisodeIds
    // ══════════════════════════════════════════════════════════

    public static int[] resolveSeasonEpisodeIds(String title, int year,
                                                 int seasonNumber, int totalEpisodes)
            throws Exception {
        return resolveSeasonEpisodeIds(title, null, year, seasonNumber, totalEpisodes);
    }

    public static int[] resolveSeasonEpisodeIds(String title, String originalTitle,
                                                 int year, int seasonNumber,
                                                 int totalEpisodes) throws Exception {
        CinemaBoxExtractor ex = ensureLoggedIn();

        int showId = searchAndPick(ex, title, originalTitle, year, "SERIES");
        if (showId == -1) return new int[0];

        List<Integer> seasonIds = ex.getSeasonIds(showId);

        JSONArray sections;
        if (seasonIds.isEmpty() || (seasonNumber <= 1 && seasonIds.size() <= 1)) {
            sections = ex.getSections(showId);
        } else {
            int seasonIndex = seasonNumber - 1;
            if (seasonIndex >= seasonIds.size()) return new int[0];
            int targetSeasonId = seasonIds.get(seasonIndex);
            sections = ex.getDynamicShowWithSeason(showId, targetSeasonId)
                          .optJSONArray("sections");
        }

        List<Integer> allEpisodeIds = extractEpisodeIdsFromSections(sections);
        int count = Math.min(totalEpisodes, allEpisodeIds.size());
        int[] ids = new int[count];
        for (int i = 0; i < count; i++) ids[i] = allEpisodeIds.get(i);
        return ids;
    }

    // ══════════════════════════════════════════════════════════
    //  resolveSeasonCount
    // ══════════════════════════════════════════════════════════

    public static int resolveSeasonCount(String title, String originalTitle,
                                          int year) throws Exception {
        CinemaBoxExtractor ex = ensureLoggedIn();
        int showId = searchAndPick(ex, title, originalTitle, year, "SERIES");
        if (showId == -1) return 0;
        List<Integer> seasonIds = ex.getSeasonIds(showId);
        return seasonIds.isEmpty() ? 1 : seasonIds.size();
    }

    // ══════════════════════════════════════════════════════════
    //  SeriesInfo
    // ══════════════════════════════════════════════════════════

    public static class SeriesInfo {
        public final int           showId;
        public final List<Integer> seasonIds;
        public SeriesInfo(int showId, List<Integer> seasonIds) {
            this.showId    = showId;
            this.seasonIds = seasonIds;
        }
        public int seasonCount() { return seasonIds.isEmpty() ? 1 : seasonIds.size(); }
    }

    public static SeriesInfo getSeriesInfo(String title, String originalTitle,
                                            int year) throws Exception {
        CinemaBoxExtractor ex = ensureLoggedIn();
        int showId = searchAndPick(ex, title, originalTitle, year, "SERIES");
        if (showId == -1) return null;
        List<Integer> seasonIds = ex.getSeasonIds(showId);
        return new SeriesInfo(showId, seasonIds);
    }

    // ══════════════════════════════════════════════════════════
    //  getSeasonEpisodeCount
    // ══════════════════════════════════════════════════════════

    public static int getSeasonEpisodeCount(int showId, int seasonIndex,
                                             List<Integer> seasonIds) throws Exception {
        CinemaBoxExtractor ex = ensureLoggedIn();
        JSONArray sections;
        if (seasonIds == null || seasonIds.isEmpty()
                || (seasonIndex == 0 && seasonIds.size() == 1)) {
            sections = ex.getSections(showId);
        } else if (seasonIndex >= seasonIds.size()) {
            return 0;
        } else {
            sections = ex.getDynamicShowWithSeason(showId, seasonIds.get(seasonIndex))
                          .optJSONArray("sections");
        }
        return countEpisodesInSections(sections);
    }

    private static int countEpisodesInSections(JSONArray sections) {
        if (sections == null) return 0;
        for (int i = 0; i < sections.length(); i++) {
            try {
                JSONObject sec     = sections.getJSONObject(i);
                String     secType = sec.optString("section_type", sec.optString("type", "")).toLowerCase();
                String     secTitleStr = sec.optString("title", "").toLowerCase();
                if (isRecommendationSection(secType, secTitleStr)) continue;
                JSONArray data = sec.optJSONArray("data");
                if (data == null || data.length() == 0) continue;
                JSONObject probe = data.optJSONObject(0);
                if (probe == null) continue;
                String cardType = probe.optString("card_type", "").toLowerCase();
                String type     = probe.optString("type", "").toLowerCase();
                if (type.equals("episode") || cardType.equals("episode"))
                    return data.length();
            } catch (Exception ignored) {}
        }
        return 0;
    }

    // ══════════════════════════════════════════════════════════
    //  searchAndPick
    // ══════════════════════════════════════════════════════════

    private static int searchAndPick(CinemaBoxExtractor ex,
                                      String title, String originalTitle,
                                      int year, String type) throws Exception {
        return searchAndPick(ex, title, originalTitle, year, type, null);
    }

    /**
     * @param rejectedByIdentity optional out-flag (length 1): set true when at
     *        least one candidate was dropped by the identity gate — lets the
     *        probe distinguish "nothing there" from "there but not this work".
     */
    private static int searchAndPick(CinemaBoxExtractor ex,
                                      String title, String originalTitle,
                                      int year, String type,
                                      boolean[] rejectedByIdentity) throws Exception {

        List<String[]> variants = new ArrayList<String[]>();

        if (title != null && !title.isEmpty())
            variants.add(new String[]{ title, title });

        String titleBase = (title != null) ? extractBase(title) : "";
        if (!titleBase.isEmpty() && !titleBase.equalsIgnoreCase(title))
            variants.add(new String[]{ titleBase, title });

        String titleStripped = (title != null)
            ? title.replaceAll("[^a-zA-Z0-9\\u0600-\\u06ff ]", " ")
                   .replaceAll("\\s+", " ").trim()
            : "";
        if (!titleStripped.isEmpty()
                && !titleStripped.equalsIgnoreCase(title)
                && !titleStripped.equalsIgnoreCase(titleBase))
            variants.add(new String[]{ titleStripped, title });

        if (originalTitle != null && !originalTitle.isEmpty()
                && !originalTitle.equalsIgnoreCase(title)
                && isLatin(originalTitle)) {
            variants.add(new String[]{ originalTitle, originalTitle });

            String origBase = extractBase(originalTitle);
            if (!origBase.isEmpty() && !origBase.equalsIgnoreCase(originalTitle))
                variants.add(new String[]{ origBase, originalTitle });
        }

        ScoredResult overallBest = ScoredResult.NONE;

        for (String[] variant : variants) {
            String searchQuery = variant[0];
            String refTitle    = variant[1];
            if (searchQuery.isEmpty()) continue;

            List<CinemaBoxExtractor.ShowResult> results = ex.search(searchQuery);
            if (results == null || results.isEmpty()) continue;

            ScoredResult best = pickBestScored(results, refTitle, year, type,
                    rejectedByIdentity);

            if (best.score > overallBest.score)
                overallBest = best;

            // توقف مبكر فقط عند تطابق قوي جداً (≥55) لضمان جرب جميع الـvariants
            if (overallBest.score >= 55) break;
        }

        // ── Fallback: بحث كلمة كلمة للأنمي ذو الأسماء القصيرة في CinemaBox ──
        // مثال: "Black Clover" مخزون كـ"Black" في CinemaBox
        // نبحث كل كلمة منفردة ونقارن النتائج بالعنوان الكامل مع السنة
        if (overallBest.score < MIN_SCORE && title != null) {
            String[] rawWords = title
                .replaceAll("[^a-zA-Z0-9\\u0600-\\u06ff ]", " ")
                .replaceAll("\\s+", " ").trim().split("\\s+");

            int tried = 0;
            for (String kw : rawWords) {
                if (kw.length() < 4) continue;
                if (STOPWORDS.contains(kw.toLowerCase())) continue;
                // تجنب إعادة البحث بنفس الكلمة إذا كانت مطابقة للـtitleBase
                if (kw.equalsIgnoreCase(titleBase)) continue;
                if (tried++ >= 3) break; // أقصى 3 كلمات

                List<CinemaBoxExtractor.ShowResult> kwResults = ex.search(kw);
                if (kwResults == null || kwResults.isEmpty()) continue;

                ScoredResult kwBest = pickBestScored(kwResults, title, year, type,
                        rejectedByIdentity);
                if (kwBest.score > overallBest.score)
                    overallBest = kwBest;

                if (overallBest.score >= MIN_SCORE) break;
            }
        }

        return overallBest.score >= MIN_SCORE ? overallBest.id : -1;
    }

    // ══════════════════════════════════════════════════════════
    //  identityGate — F5 strict year/type gate (applied before scoring)
    // ══════════════════════════════════════════════════════════

    /**
     * The identity verdict for one CinemaBox candidate BEFORE any scoring:
     * media type, then the strict per-type year rule of MediaIdentity
     * (movie: exact TMDB year, unknown candidate year rejected; series: ±1
     * only with exact normalized-title equality, missing year likewise).
     * A rejection here is final — every search/fallback round applies it.
     */
    private static com.eve.cinema.playback.MediaIdentity.RejectReason identityGate(
            CinemaBoxExtractor.ShowResult r, String qNorm, int year, String type) {
        if (type != null && !com.eve.cinema.playback.MediaIdentity
                .typeMatches(type, r.type))
            return com.eve.cinema.playback.MediaIdentity.RejectReason.TYPE_MISMATCH;
        boolean exactTitle = normalize(r.title).equals(qNorm);
        return com.eve.cinema.playback.MediaIdentity.cinemaBoxRejection(
                type, year, r.year, exactTitle);
    }

    // ══════════════════════════════════════════════════════════
    //  extractBase
    // ══════════════════════════════════════════════════════════

    private static String extractBase(String raw) {
        if (raw == null || raw.isEmpty()) return "";

        int c = raw.indexOf(": ");
        if (c > 2) return raw.substring(0, c).trim();

        int d = raw.indexOf(" - ");
        if (d > 2) return raw.substring(0, d).trim();

        // ✅ إصلاح Re:ZERO: يتعامل مع " -Subtitle" (شرطة بدون مسافة بعدها)
        int e = raw.indexOf(" -");
        if (e > 2) return raw.substring(0, e).trim();

        int t = raw.indexOf(" ~");
        if (t > 2) return raw.substring(0, t).trim();

        return raw.trim();
    }

    // ══════════════════════════════════════════════════════════
    //  pickBestScored
    // ══════════════════════════════════════════════════════════

    private static ScoredResult pickBestScored(List<CinemaBoxExtractor.ShowResult> results,
                                                String query, int year, String type) {
        return pickBestScored(results, query, year, type, null);
    }

    private static ScoredResult pickBestScored(List<CinemaBoxExtractor.ShowResult> results,
                                                String query, int year, String type,
                                                boolean[] rejectedByIdentity) {
        if (results == null || results.isEmpty()) return ScoredResult.NONE;

        String   qNorm  = normalize(query);
        String[] qWords = qNorm.split("\\s+");

        ScoredResult best = ScoredResult.NONE;
        ScoredResult second = ScoredResult.NONE;
        for (CinemaBoxExtractor.ShowResult r : results) {
            // ✅ إصلاح Re:ZERO: تجاهل نسخ المدبلج فقط، دون المساس بالمحتوى العربي
            if (r.title != null && r.title.contains("مدبلج")) continue;
            // F5: بوابة هوية صارمة قبل أي تسجيل — سنة الفيلم يجب أن تطابق TMDB
            // تماماً، والمسلسل وفق قاعدة ±1 مع تطابق الاسم الحرفي. مرفوض السنة
            // لا يعود عبر أي fallback لأن كل الجولات تمر بهذه البوابة.
            com.eve.cinema.playback.MediaIdentity.RejectReason rej =
                    identityGate(r, qNorm, year, type);
            if (rej != com.eve.cinema.playback.MediaIdentity.RejectReason.NONE) {
                if (rejectedByIdentity != null) rejectedByIdentity[0] = true;
                com.eve.cinema.playback.ResolutionTrace.record("cb.identity", "reject",
                        rej.name() + " id=" + r.id + " y=" + r.year + " wantY=" + year);
                continue;
            }
            int s = scoreResult(r, qNorm, qWords, year);
            if (s > best.score) { second = best; best = new ScoredResult(r.id, s, r.year); }
            else if (s > second.score) second = new ScoredResult(r.id, s, r.year);
        }
        if (best.score >= MIN_SCORE) {
            // ✅ P6: بوابة الغموض — مرشحان متقاربان بسنتين متعارضتين (جزآن من
            // نفس السلسلة) = لا تخمين. Resident Evil 2002 ≠ إصدار 2021.
            if (com.eve.cinema.playback.AmbiguityGate.isAmbiguous(
                    best.score, best.year, second.score, second.year, MIN_SCORE))
                return ScoredResult.NONE;
            return best;
        }

        ScoredResult bestAny = ScoredResult.NONE;
        ScoredResult secondAny = ScoredResult.NONE;
        for (CinemaBoxExtractor.ShowResult r : results) {
            // ✅ نفس الفلاتر في الـfallback: مدبلج + نوع المحتوى + بوابة السنة.
            // سابقاً كانت هذه الجولة تتجاهل فلتر النوع فتعيد مسلسلاً لطلب فيلم.
            if (r.title != null && r.title.contains("مدبلج")) continue;
            com.eve.cinema.playback.MediaIdentity.RejectReason rejAny =
                    identityGate(r, qNorm, year, type);
            if (rejAny != com.eve.cinema.playback.MediaIdentity.RejectReason.NONE) {
                if (rejectedByIdentity != null) rejectedByIdentity[0] = true;
                com.eve.cinema.playback.ResolutionTrace.record("cb.identity", "reject",
                        rejAny.name() + " id=" + r.id + " y=" + r.year + " wantY=" + year);
                continue;
            }
            int s = scoreResult(r, qNorm, qWords, year);
            if (s > bestAny.score) { secondAny = bestAny; bestAny = new ScoredResult(r.id, s, r.year); }
            else if (s > secondAny.score) secondAny = new ScoredResult(r.id, s, r.year);
        }
        if (bestAny.score >= MIN_SCORE_STRICT) {
            if (com.eve.cinema.playback.AmbiguityGate.isAmbiguous(
                    bestAny.score, bestAny.year, secondAny.score, secondAny.year,
                    MIN_SCORE_STRICT))
                return ScoredResult.NONE;
            return bestAny;
        }

        return ScoredResult.NONE;
    }

    // ══════════════════════════════════════════════════════════
    //  ✅ scoreResult — نظام تسجيل مُعاد تصميمه بالكامل
    //
    //  المستويات (من الأفضل للأضعف):
    //
    //  60: تطابق حرفي كامل
    //  58: تطابق بعد إزالة الرموز (:, -, ')
    //  55: تطابق بعد إزالة المقالات (the, a, an)
    //  50: تطابق basePart
    //  40: containment متبادل + حماية الطول (≥40%)
    //  35: basePart containment + حماية الطول
    //  32: Dice ≥ 0.75  و minCoverage ≥ 0.40  (shared ≥ 2)
    //  28: Dice ≥ 0.60  و minCoverage ≥ 0.30  (shared ≥ 2)
    //  24: Dice ≥ 0.50  و minCoverage ≥ 0.25  (shared ≥ 2)
    //  22: كلمة واحدة متطابقة (طرفان كلمة واحدة فقط)
    //   0: لا تطابق → مرفوض
    //
    //  مكافأة السنة:
    //  • إذا score ≥ 30: diff=0 → +8, diff=1 → +3
    //  • إذا score < 30:  diff=0 → +3, diff=1 → +1 (مكافأة محدودة)
    // ══════════════════════════════════════════════════════════

    private static int scoreResult(CinemaBoxExtractor.ShowResult r,
                                    String qNorm, String[] qWords, int year) {
        // بوابة قاطعة: سنة متعارضة = عمل آخر/remake — لا تطابق اسمي يتجاوزها.
        // (Resident Evil 2002 ≠ Resident Evil: Welcome to Raccoon City 2021)
        if (com.eve.cinema.playback.MediaIdentity.yearHardRejects(year, r.year))
            return 0;
        String rNorm = normalize(r.title);

        // نسخ بدون رموز للمقارنة المُحكمة
        String rNormStripped = rNorm.replaceAll("[:\\-']", " ").replaceAll("\\s+", " ").trim();
        String qNormStripped = qNorm.replaceAll("[:\\-']", " ").replaceAll("\\s+", " ").trim();

        String qBase = basePart(qNorm);
        String rBase = basePart(rNorm);

        String[] rWords = rNorm.split("\\s+");
        String[] qSig = significantWords(qWords);
        String[] rSig = significantWords(rWords);

        int score = 0;

        // ── المستوى 1: تطابق حرفي كامل ─────────────────────────
        if (rNorm.equals(qNorm)) {
            score = 60;
        }
        // ── المستوى 2: تطابق بعد إزالة الرموز ──────────────────
        else if (rNormStripped.equals(qNormStripped)) {
            score = 58;
        }
        // ── المستوى 3: بعد إزالة المقالات ──────────────────────
        else if (stripArticle(rNorm).equals(stripArticle(qNorm))) {
            score = 55;
        }
        // ── المستوى 4: basePart متطابق ───────────────────────────
        else if (!qBase.isEmpty() && !rBase.isEmpty() && rBase.equals(qBase)) {
            score = 50;
        }
        // ── المستوى 4.5: تطابق بعد حذف الحروف المنفردة ──────────
        // ✅ إصلاح Hunter x Hunter: "hunter x hunter" و "hunter × hunter"
        // كلاهما يصبح "hunter hunter" بعد حذف 'x' المنفردة → تطابق كامل
        else if (isSameAfterRemovingSingleChars(qNorm, rNorm)) {
            score = 50;
        }
        // ── المستوى 5: containment مع حماية الطول ───────────────
        else if (qNorm.contains(rNorm) && rNorm.length() >= 4) {
            // ✅ إصلاح Black Clover: رُفع الحد من 0.40 إلى 0.65
            // "black"(5) / "black clover"(11) = 0.45 < 0.65 → مرفوض
            if (rNormStripped.length() >= qNormStripped.length() * 0.65) {
                score = 40;
            } else {
                score = 15; // تطابق ضعيف جداً - لا يصل للحد
            }
        } else if (rNorm.contains(qNorm) && qNorm.length() >= 4) {
            // ✅ إصلاح Black Clover: حماية الطول مطابقة للمستوى الأول
            // "black clover"(11) / "mugyutto black clover"(21) = 0.52 < 0.65 → score=15
            if (qNormStripped.length() >= rNormStripped.length() * 0.65) {
                score = 40;
            } else {
                score = 15; // تطابق ضعيف جداً - لا يصل للحد
            }
        }
        // ── المستوى 6: basePart containment ─────────────────────
        else if (!qBase.isEmpty() && !rBase.isEmpty()
                && qBase.contains(rBase) && rBase.length() >= 4) {
            if (rBase.length() >= qBase.length() * 0.40) {
                score = 35;
            } else {
                score = 12;
            }
        } else if (!qBase.isEmpty() && !rBase.isEmpty()
                && rBase.contains(qBase) && qBase.length() >= 4) {
            score = 35;
        }
        // ── المستوى 7: Dice coefficient + minCoverage ───────────
        else if (qSig.length > 0 && rSig.length > 0) {
            int shared = countSharedWords(qSig, rSig);
            if (shared >= 1) {
                double dice = (2.0 * shared) / (qSig.length + rSig.length);
                double qCov = (double) shared / qSig.length;
                double rCov = (double) shared / rSig.length;
                double minCov = Math.min(qCov, rCov);  // ✅ لا maxCoverage!

                if (dice >= 0.75 && minCov >= 0.40 && shared >= 2) {
                    score = 32;
                } else if (dice >= 0.60 && minCov >= 0.30 && shared >= 2) {
                    score = 28;
                } else if (dice >= 0.50 && minCov >= 0.25 && shared >= 2) {
                    score = 24;
                } else if (dice >= 0.75 && shared == 1
                           && qSig.length == 1 && rSig.length == 1) {
                    // طرفان كلمة واحدة فقط متطابقة تماماً
                    score = 22;
                }
            }
        }

        if (score == 0) return 0;

        // ── مكافأة/عقوبة السنة ─────────────────────────────────
        if (year > 0 && r.year > 0) {
            int diff = Math.abs(r.year - year);
            if (score >= 30) {
                // تطابق قوي: مكافأة كاملة
                if      (diff == 0) score += 8;
                else if (diff == 1) score += 3;
                else if (diff <= 3) score -= 4;
                else if (diff <= 7) score -= 10;
                else                score -= 15;
            } else {
                // تطابق ضعيف: مكافأة محدودة + عقوبة أشد
                if      (diff == 0) score += 3;
                else if (diff == 1) score += 1;
                else if (diff <= 3) score -= 8;
                else if (diff <= 7) score -= 14;
                else                score -= 20;
            }
        }

        return score;
    }

    // ══════════════════════════════════════════════════════════
    //  basePart
    // ══════════════════════════════════════════════════════════

    private static String basePart(String norm) {
        if (norm == null || norm.isEmpty()) return "";

        int c = norm.indexOf(": ");
        if (c > 2) return norm.substring(0, c).trim();

        c = norm.indexOf(':');
        if (c > 2) return norm.substring(0, c).trim();

        int d = norm.indexOf(" - ");
        if (d > 2) return norm.substring(0, d).trim();

        // ✅ إصلاح Re:ZERO: شرطة بدون مسافة بعدها
        int e = norm.indexOf(" -");
        if (e > 2) return norm.substring(0, e).trim();

        return norm;
    }

    // ══════════════════════════════════════════════════════════
    //  normalize
    // ══════════════════════════════════════════════════════════

    private static String normalize(String s) {
        if (s == null) return "";
        return s.toLowerCase()
                .replaceAll("[^a-z0-9\\u0600-\\u06ff:\\-'\\s]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    // ══════════════════════════════════════════════════════════
    //  مساعدات word-overlap
    // ══════════════════════════════════════════════════════════

    private static String[] significantWords(String[] words) {
        List<String> result = new ArrayList<String>();
        for (String w : words) {
            if (w.length() < WORD_MIN_LEN) continue;
            if (STOPWORDS.contains(w)) continue;
            result.add(w);
        }
        return result.toArray(new String[0]);
    }

    private static int countSharedWords(String[] a, String[] b) {
        int count = 0;
        for (String wa : a) {
            if (wa.length() < WORD_MIN_LEN) continue;
            for (String wb : b) {
                if (wa.equals(wb)) { count++; break; }
            }
        }
        return count;
    }

    private static boolean isSameAfterRemovingSingleChars(String a, String b) {
        // يحذف الحروف المنفردة (مثل x, v, s) ثم يقارن
        // "hunter x hunter" → "hunter hunter" ← "hunter × hunter"
        String aN = a.replaceAll("\\b[a-z]\\b", "").replaceAll("\\s+", " ").trim();
        String bN = b.replaceAll("\\b[a-z]\\b", "").replaceAll("\\s+", " ").trim();
        // يُطبّق فقط إذا حُذفت حروف فعلاً (تجنّب تكرار المستويات السابقة)
        return !aN.isEmpty() && !bN.isEmpty() && !aN.equals(a) && aN.equals(bN);
    }

    private static boolean isLatin(String s) {
        if (s == null || s.isEmpty()) return false;
        int latin = 0, total = 0;
        for (char ch : s.toCharArray()) {
            if (Character.isLetter(ch)) {
                total++;
                if (ch < 0x0100) latin++;
            }
        }
        return total > 0 && (double) latin / total >= 0.5;
    }

    private static String stripArticle(String s) {
        if (s == null) return "";
        String low = s.toLowerCase().trim();
        if (low.startsWith("the ")) return s.substring(4);
        if (low.startsWith("a "))   return s.substring(2);
        if (low.startsWith("an "))  return s.substring(3);
        if (low.startsWith("al-") || low.startsWith("al ")) return s.substring(3);
        return s;
    }

    // ══════════════════════════════════════════════════════════
    //  findEpisodeInSection
    //  ✅ إصلاح One Piece: يستخدم الفهرس التسلسلي (1-based) بدلاً من episode_number
    //  السبب: TMDB يعد الحلقات 1..1162 لكن CinemaBox يرقّمها 1..1173 (مع فجوات)
    //  الحلقة رقم 1162 عند TMDB = الحلقة رقم 1173 (episode_number) عند CinemaBox
    //  الحل: نرتب الحلقات بـepisode_number ونأخذ العنصر رقم (episodeNumber-1) بالفهرس
    // ══════════════════════════════════════════════════════════

    private static int findEpisodeInSection(JSONArray sections, int episodeNumber) {
        if (sections == null) return -1;
        List<Integer> ids = extractEpisodeIdsFromSections(sections);
        if (ids.isEmpty()) return -1;
        int idx = episodeNumber - 1;
        if (idx >= 0 && idx < ids.size()) return ids.get(idx);
        return -1;
    }

    // ══════════════════════════════════════════════════════════
    //  extractEpisodeIdsFromSections
    // ══════════════════════════════════════════════════════════

    private static List<Integer> extractEpisodeIdsFromSections(JSONArray sections) {
        List<Integer> ids = new ArrayList<Integer>();
        if (sections == null) return ids;

        for (int i = 0; i < sections.length(); i++) {
            try {
                JSONObject sec      = sections.getJSONObject(i);
                String     secType  = sec.optString("section_type",
                                          sec.optString("type", "")).toLowerCase();
                String     secTitle = sec.optString("title", "").toLowerCase();
                if (isRecommendationSection(secType, secTitle)) continue;

                JSONArray data = sec.optJSONArray("data");
                if (data == null || data.length() == 0) continue;

                JSONObject probe    = data.optJSONObject(0);
                if (probe == null) continue;
                String     cardType = probe.optString("card_type", "").toLowerCase();
                String     type     = probe.optString("type", "").toLowerCase();
                if (!type.equals("episode") && !cardType.equals("episode")) continue;

                final List<int[]> pairs = new ArrayList<int[]>();
                boolean hasEpNumbers = false;
                for (int j = 0; j < data.length(); j++) {
                    JSONObject ep = data.optJSONObject(j);
                    if (ep == null) continue;
                    int epId  = ep.optInt("id", -1);
                    if (epId == -1) continue;
                    int epNum = ep.optInt("episode_number", -999);
                    if (epNum != -999) hasEpNumbers = true;
                    pairs.add(new int[]{ epNum, epId });
                }

                if (hasEpNumbers) {
                    java.util.Collections.sort(pairs, new java.util.Comparator<int[]>() {
                        @Override public int compare(int[] a, int[] b) {
                            return Integer.compare(a[0], b[0]);
                        }
                    });
                }

                for (int[] pair : pairs) ids.add(pair[1]);
                break;

            } catch (Exception ignored) {}
        }
        return ids;
    }

    // ══════════════════════════════════════════════════════════
    //  isRecommendationSection
    // ══════════════════════════════════════════════════════════

    private static boolean isRecommendationSection(String type, String title) {
        if (type.contains("similar")    || type.contains("related")   ||
            type.contains("recommend")  || type.contains("suggestion") ||
            type.contains("also_watch") || type.contains("more_like")  ||
            type.contains("trailer"))                                    return true;
        if (title.contains("similar")   || title.contains("related")  ||
            title.contains("recommend") || title.contains("قد يعجبك") ||
            title.contains("مشابه")     || title.contains("أيضاً")    ||
            title.contains("اقتراح")    || title.contains("more like") ||
            title.contains("trailer")   || title.contains("trailers")) return true;
        return false;
    }

    // ══════════════════════════════════════════════════════════
    //  Login helper
    // ══════════════════════════════════════════════════════════

    public static CinemaBoxExtractor ensureLoggedIn() throws Exception {
        CinemaBoxExtractor ex = getExtractor();
        if (!ex.isLoggedIn()) {
            boolean ok = ex.login(Config.CINEMABOX_EMAIL, Config.CINEMABOX_PASSWORD);
            if (!ok) throw new Exception("فشل تسجيل الدخول إلى CinemaBox");
        }
        return ex;
    }
}
