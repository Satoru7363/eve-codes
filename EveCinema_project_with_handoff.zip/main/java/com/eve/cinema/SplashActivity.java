package com.eve.cinema;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;



/**
 * SplashActivity — مقدمة إيف (الأنيميشن الأصلي محفوظ بالكامل)
 * ─────────────────────────────────────────────────────────────────────────────
 * التعديلات على الأصل:
 *  1. navDone flag — منع double navigation
 *  2. runOnUiThread في verifyCodeInBackground — الكتابة على UI thread
 *  3. mainHandler يُنشأ مرة واحدة — onDestroy يلغي كل callbacks
 *  4. النتيجة: main → تحقق Firebase أولاً (google_only إذا لزم)
 *  5. deep link محفوظ كما هو
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class SplashActivity extends Activity {

    private static final long INTRO_DURATION  = 9000L;
    public  static final String EXTRA_GOOGLE_ONLY = "google_only";

    // handler واحد — يُلغى في onDestroy
    private Handler mainHandler;

    // نتيجة التحقق
    private volatile String  verifyOutcome = null;
    private volatile boolean navDone       = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        setContentView(R.layout.activity_splash);
        mainHandler = new Handler(Looper.getMainLooper());
        requestDiagnosticStorageAccess();

        final TextView    logo    = (TextView)    findViewById(R.id.splash_logo);
        final View        line    =               findViewById(R.id.splash_line);
        final TextView    name    = (TextView)    findViewById(R.id.splash_name);
        final TextView    tagline = (TextView)    findViewById(R.id.splash_tagline);

        // letterSpacing يفكّك اتصال الحروف العربية — صفّره عندما يكون النص عربياً
        if (tagline != null) {
            String lang = getResources().getConfiguration().locale.getLanguage();
            if ("ar".equals(lang)) tagline.setLetterSpacing(0f);
        }
        final ProgressBar pBar    = (ProgressBar) findViewById(R.id.splash_progress);
        final View        halo    =               findViewById(R.id.splash_halo);

        // ══════════════════════════════════════════════════════
        //  الأنيميشن الأصلي — محفوظ بالكامل بدون أي تغيير
        // ══════════════════════════════════════════════════════

        if (halo != null) {
            halo.setAlpha(0f);
            halo.setScaleX(0.2f); halo.setScaleY(0.2f);
            halo.animate().alpha(0.55f).scaleX(2.6f).scaleY(2.6f)
                .setDuration(1200)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        halo.animate().alpha(0f).setDuration(700).start();
                    }
                }).start();
        }

        if (logo != null) {
            logo.setAlpha(0f);
            logo.setScaleX(0.25f); logo.setScaleY(0.25f);
            logo.setRotation(-15f);
            logo.animate()
                .alpha(1f).scaleX(1f).scaleY(1f).rotation(0f)
                .setStartDelay(450)
                .setDuration(950)
                .setInterpolator(new OvershootInterpolator(1.6f))
                .start();
            mainHandler.postDelayed(new Runnable() {
                @Override public void run() { pulseLogo(logo); }
            }, 1700);
        }

        if (line != null) {
            line.setAlpha(0f);
            mainHandler.postDelayed(new Runnable() {
                @Override public void run() {
                    if (isFinishing() || isDestroyed()) return;
                    line.setAlpha(1f);
                    ValueAnimator va = ValueAnimator.ofInt(0, dpToPx(120));
                    va.setDuration(700);
                    va.setInterpolator(new AccelerateDecelerateInterpolator());
                    va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override public void onAnimationUpdate(ValueAnimator a) {
                            LinearLayout.LayoutParams lp =
                                (LinearLayout.LayoutParams) line.getLayoutParams();
                            lp.width = (int) a.getAnimatedValue();
                            line.setLayoutParams(lp);
                        }
                    });
                    va.start();
                }
            }, 1450);
        }

        if (name != null) {
            name.setAlpha(0f);
            name.setTranslationY(40f);
            name.animate().alpha(1f).translationY(0f)
                .setStartDelay(2100).setDuration(750).start();
        }

        if (tagline != null) {
            tagline.setAlpha(0f);
            tagline.animate().alpha(1f)
                .setStartDelay(2900).setDuration(700).start();
        }

        if (pBar != null) {
            pBar.setAlpha(0f);
            pBar.setMax(100);
            pBar.setProgress(0);
            pBar.animate().alpha(1f).setStartDelay(3500).setDuration(400).start();
            mainHandler.postDelayed(new Runnable() {
                @Override public void run() {
                    if (isFinishing() || isDestroyed()) return;
                    ValueAnimator va = ValueAnimator.ofInt(0, 100);
                    va.setDuration(INTRO_DURATION - 3900L);
                    va.setInterpolator(new AccelerateDecelerateInterpolator());
                    va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override public void onAnimationUpdate(ValueAnimator a) {
                            pBar.setProgress((int) a.getAnimatedValue());
                        }
                    });
                    va.start();
                }
            }, 3900L);
        }

        // ══════════════════════════════════════════════════════
        //  Deep Link — محفوظ كما هو
        // ══════════════════════════════════════════════════════
        Intent incoming = getIntent();
        if (incoming != null) {
            Uri data = incoming.getData();
            if (data != null && "eve-cinema".equals(data.getScheme())) {
                final Uri finalData = data;
                mainHandler.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (isFinishing() || isDestroyed()) return;
                        Intent playerIntent = new Intent(SplashActivity.this, PlayerActivity.class);
                        playerIntent.setData(finalData);
                        startActivity(playerIntent);
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        finish();
                    }
                }, 1200);
                return;
            }
        }

        // ══════════════════════════════════════════════════════
        //  التحقق من الكود في الخلفية
        // ══════════════════════════════════════════════════════
        verifyCodeInBackground();

        // ══════════════════════════════════════════════════════
        //  الانتقال بعد انتهاء المقدمة
        // ══════════════════════════════════════════════════════
        mainHandler.postDelayed(new Runnable() {
            @Override public void run() {
                navigateNext();
            }
        }, INTRO_DURATION);
    }

    // ══════════════════════════════════════════════════════════
    //  التحقق من الكود — Firebase Realtime Database
    // ══════════════════════════════════════════════════════════
    private void verifyCodeInBackground() {
        final UserSession session = new UserSession(this);

        if (!session.isLoggedIn() || session.getCode().isEmpty()) {
            verifyOutcome = "login";
            return;
        }

        final String code     = session.getCode();
        final String deviceId = session.getDeviceId();

        new Thread(new Runnable() {
            @Override
            public void run() {
                // FirebaseLicenseClient يتعامل مع Firebase REST API مباشرة
                FirebaseLicenseClient.Result result =
                    FirebaseLicenseClient.fetchAndVerify(code, deviceId);

                final String outcome;
                switch (result.status) {
                    case VALID:
                    case UNBOUND:
                        session.updateCodeStatus(UserSession.STATUS_ACTIVE);
                        if (result.telegramId != 0) session.saveTelegramId(result.telegramId);
                        outcome = "main";
                        break;
                    case NETWORK_ERROR:
                        // فشل الشبكة — graceful fallback بناءً على الـ cache المحلي
                        outcome = session.isCodeActiveLocally() ? "main" : "login";
                        break;
                    default:
                        // كود ملغى أو محظور أو منتهي
                        session.markCodeInvalid(UserSession.STATUS_DISABLED);
                        outcome = "login";
                        break;
                }

                if (!isFinishing() && !isDestroyed()) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            verifyOutcome = outcome;
                        }
                    });
                }
            }
        }).start();
    }

    // ══════════════════════════════════════════════════════════
    //  الانتقال للشاشة التالية — مرة واحدة فقط
    // ══════════════════════════════════════════════════════════
    private synchronized void navigateNext() {
        if (navDone) return; // منع double navigation
        navDone = true;

        if (isFinishing() || isDestroyed()) return;

        // fallback إذا لم ينتهِ التحقق بعد
        if (verifyOutcome == null) {
            UserSession session = new UserSession(this);
            verifyOutcome = session.isLoggedIn() ? "main" : "login";
        }

        Intent next;
        if ("main".equals(verifyOutcome)) {
            // تحقق من Firebase — إذا لم يكن موقّعاً اطلب Google
            FirebaseUser fbUser = FirebaseAuth.getInstance().getCurrentUser();
            if (fbUser != null) {
                next = new Intent(SplashActivity.this, MainActivity.class);
            } else {
                next = new Intent(SplashActivity.this, LoginActivity.class);
                next.putExtra(EXTRA_GOOGLE_ONLY, true);
            }
        } else {
            next = new Intent(SplashActivity.this, LoginActivity.class);
        }

        startActivity(next);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    // ══════════════════════════════════════════════════════════
    //  pulseLogo الأصلي — محفوظ بالكامل
    // ══════════════════════════════════════════════════════════
    private void pulseLogo(final View logo) {
        if (logo == null || isFinishing() || isDestroyed()) return;
        logo.animate().scaleX(1.06f).scaleY(1.06f).setDuration(900)
            .withEndAction(new Runnable() {
                @Override public void run() {
                    if (isFinishing() || isDestroyed()) return;
                    logo.animate().scaleX(1f).scaleY(1f).setDuration(900)
                        .withEndAction(new Runnable() {
                            @Override public void run() { pulseLogo(logo); }
                        }).start();
                }
            }).start();
    }

    private static final int REQUEST_ALL_FILES_ACCESS = 8461;
    private static final int REQUEST_WRITE_STORAGE = 8462;

    private void requestDiagnosticStorageAccess() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            if (android.os.Environment.isExternalStorageManager()) {
                DiagnosticsRecorder.initialize(getApplicationContext());
                return;
            }
            try {
                Intent appSettings = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
                appSettings.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(appSettings, REQUEST_ALL_FILES_ACCESS);
            } catch (Exception appSettingsUnavailable) {
                try {
                    Intent allFilesSettings = new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION");
                    startActivityForResult(allFilesSettings, REQUEST_ALL_FILES_ACCESS);
                } catch (Exception settingsUnavailable) {
                    android.util.Log.e("EveDiagnostics", "Unable to open all-files access settings", settingsUnavailable);
                }
            }
            return;
        }

        if (android.os.Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_STORAGE);
            return;
        }
        DiagnosticsRecorder.initialize(getApplicationContext());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ALL_FILES_ACCESS
                && android.os.Build.VERSION.SDK_INT >= 30
                && android.os.Environment.isExternalStorageManager()) {
            DiagnosticsRecorder.initialize(getApplicationContext());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WRITE_STORAGE && grantResults.length > 0
                && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            DiagnosticsRecorder.initialize(getApplicationContext());
        }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    // ══════════════════════════════════════════════════════════
    //  Lifecycle — إلغاء الـ callbacks لمنع memory leak
    // ══════════════════════════════════════════════════════════
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mainHandler != null) {
            mainHandler.removeCallbacksAndMessages(null);
            mainHandler = null;
        }
    }
}
