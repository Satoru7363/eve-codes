package com.eve.cinema;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * SettingsActivity — v9 (rebuilt from the ground up)
 * ─────────────────────────────────────────────────────────────────────────────
 * OLD UI: removed entirely (glyph icons, hardcoded strings, fake toggles).
 *
 * NEW ARCHITECTURE:
 *   • Main page  → settings_main_page.xml (rows = item_settings_row /
 *                  item_settings_toggle, every string from resources EN/AR)
 *   • Sub pages  → built programmatically with the same design tokens
 *   • State      → SettingsStore (real, persisted) — every visible setting
 *                  is consumed by PlayerActivity / MainActivity
 *   • Real data  → version from PackageManager, device from Build,
 *                  cache size from Glide disk cache, watch history from
 *                  the player's eve_watch_progress store
 *
 * PRESERVED LOGIC: Firebase/Google sign-out, avatar loading, Telegram
 * contact, TmdbCache clearing.
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class SettingsActivity extends Activity {

    // ── Palette (matches values/colors.xml) ───────────────
    private static final int C_BG_CARD    = 0xFF12121F;
    private static final int C_PURPLE     = 0xFF9B6FC4;
    private static final int C_PURPLE_LT  = 0xFFC4A0E8;
    private static final int C_PURPLE_DK  = 0xFF7A5099;
    private static final int C_TEXT_PRI   = 0xFFFFFFFF;
    private static final int C_TEXT_SEC   = 0xFFB0B0C8;
    private static final int C_TEXT_MUT   = 0xFF6B6B88;
    private static final int C_TEXT_VALUE = 0xFF9C9CB8;
    private static final int C_RED        = 0xFFF87171;
    private static final int C_GREEN      = 0xFF4ADE80;
    private static final int C_DIVIDER    = 0x12FFFFFF;
    private static final int C_ICON_TILE  = 0x1A9B6FC4;

    // ── Pages ─────────────────────────────────────────────
    private static final int PAGE_MAIN      = 0;
    private static final int PAGE_SECURITY  = 1;
    private static final int PAGE_DEVICES   = 2;
    private static final int PAGE_QUALITY   = 3;
    private static final int PAGE_SUBTITLE  = 4;
    private static final int PAGE_HELP      = 5;
    private static final int PAGE_ABOUT     = 6;

    // ── Watch progress store (owned by PlayerActivity) ────
    private static final String PREFS_WATCH = "eve_watch_progress";

    // ── State ─────────────────────────────────────────────
    private UserSession session;
    private int         currentPage = PAGE_MAIN;
    private FrameLayout rootFrame;

    // ── Firebase ──────────────────────────────────────────
    private GoogleSignInClient googleSignInClient;
    private FirebaseAuth       firebaseAuth;

    // ── Avatar loading thread ref ─────────────────────────
    private Thread avatarThread;

    // ═══════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        MiuiBarFix.apply(this);

        session      = new UserSession(this);
        firebaseAuth = FirebaseAuth.getInstance();

        GoogleSignInOptions gso = new GoogleSignInOptions
                .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .requestProfile()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);

        setContentView(R.layout.activity_settings);
        rootFrame = (FrameLayout) findViewById(R.id.settings_root);
        showPage(PAGE_MAIN, false);
    }

    // ═══════════════════════════════════════════════════════
    //  PAGE ROUTER
    // ═══════════════════════════════════════════════════════
    private void showPage(int page, boolean animate) {
        currentPage = page;
        if (avatarThread != null && avatarThread.isAlive()) avatarThread.interrupt();
        rootFrame.removeAllViews();

        View pageView;
        switch (page) {
            case PAGE_SECURITY: pageView = buildSecurityPage();  break;
            case PAGE_DEVICES:  pageView = buildDevicesPage();   break;
            case PAGE_QUALITY:  pageView = buildQualityPage();   break;
            case PAGE_SUBTITLE: pageView = buildSubtitlePage();  break;
            case PAGE_HELP:     pageView = buildHelpPage();      break;
            case PAGE_ABOUT:    pageView = buildAboutPage();     break;
            default:            pageView = buildMainPage();      break;
        }

        rootFrame.addView(pageView);
        if (animate) {
            pageView.setTranslationX(dpToPx(24));
            pageView.setAlpha(0f);
            pageView.animate()
                .translationX(0f).alpha(1f)
                .setDuration(240)
                .setInterpolator(UiMotion.DECEL_2)
                .start();
        }
    }

    private void goBack() {
        if (currentPage == PAGE_MAIN) {
            finish();
            overridePendingTransition(R.anim.enter_from_left, R.anim.exit_to_right);
        } else {
            showPage(PAGE_MAIN, true);
        }
    }

    @Override public void onBackPressed() { goBack(); }

    // ═══════════════════════════════════════════════════════
    //  MAIN PAGE — XML inflate + binding
    // ═══════════════════════════════════════════════════════
    private View buildMainPage() {
        View page = getLayoutInflater().inflate(R.layout.settings_main_page, null);

        View backBtn = page.findViewById(R.id.settings_back_btn);
        if (backBtn != null) backBtn.setOnClickListener(v -> goBack());

        // ── Profile ──
        ImageView avatarImg = (ImageView) page.findViewById(R.id.settings_avatar);
        if (avatarImg != null) loadAvatarAsync(avatarImg);

        TextView nameTv  = (TextView) page.findViewById(R.id.settings_user_name);
        TextView emailTv = (TextView) page.findViewById(R.id.settings_user_email);
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (nameTv != null) {
            String name = (user != null && user.getDisplayName() != null
                        && !user.getDisplayName().isEmpty())
                ? user.getDisplayName() : session.getUsername();
            nameTv.setText(name);
        }
        if (emailTv != null) {
            String email = (user != null && user.getEmail() != null)
                ? user.getEmail() : session.getEmail();
            emailTv.setText(email);
        }

        // ── Rows: icons + texts from resources ──
        styleRow(page, R.id.row_security, R.drawable.ic_shield_check,
                 R.string.row_security, R.string.row_security_desc, C_GREEN);
        styleRow(page, R.id.row_devices, R.drawable.ic_device_phone,
                 R.string.row_devices, R.string.row_devices_desc, 0xFF818CF8);

        styleRow(page, R.id.row_quality, R.drawable.ic_hd,
                 R.string.row_quality, 0, C_PURPLE);
        styleRow(page, R.id.row_sub_lang, R.drawable.ic_globe,
                 R.string.row_subtitle_lang, 0, 0xFF38BDF8);
        styleRow(page, R.id.row_sub_size, R.drawable.ic_text_size,
                 R.string.row_subtitle_size, 0, 0xFF38BDF8);
        styleRow(page, R.id.row_autoplay, R.drawable.ic_speed,
                 R.string.row_autoplay_next, R.string.row_autoplay_next_desc, C_PURPLE);
        styleRow(page, R.id.row_reduce_motion, R.drawable.ic_motion,
                 R.string.row_reduce_motion, R.string.row_reduce_motion_desc, C_PURPLE);

        styleRow(page, R.id.row_cache, R.drawable.ic_database,
                 R.string.row_cache, R.string.row_cache_clear, 0xFFFB923C);
        styleRow(page, R.id.row_history, R.drawable.ic_history,
                 R.string.row_history, R.string.row_history_clear, 0xFFFB923C);

        styleRow(page, R.id.row_help, R.drawable.ic_help_circle,
                 R.string.row_help, R.string.row_help_desc, 0xFF818CF8);
        styleRow(page, R.id.row_contact, R.drawable.ic_telegram,
                 R.string.row_contact, R.string.row_contact_desc, 0xFF38BDF8);
        styleRow(page, R.id.row_about, R.drawable.ic_info_outline,
                 R.string.row_about, 0, C_PURPLE);

        // ── Row values (real, from SettingsStore) ──
        setRowValue(page, R.id.row_quality, qualityLabel(SettingsStore.getDefaultQuality(this)));
        setRowValue(page, R.id.row_sub_lang, subLangLabel(SettingsStore.getSubtitleLanguage(this)));
        setRowValue(page, R.id.row_sub_size, subSizeLabel(SettingsStore.getSubtitleSize(this)));
        setRowValue(page, R.id.row_about,   appVersion());

        bindRow(page, R.id.row_security, () -> showPage(PAGE_SECURITY, true));
        bindRow(page, R.id.row_devices,  () -> showPage(PAGE_DEVICES,  true));
        bindRow(page, R.id.row_quality,  () -> showPage(PAGE_QUALITY,  true));
        bindRow(page, R.id.row_sub_lang, () -> showPage(PAGE_SUBTITLE, true));
        bindRow(page, R.id.row_sub_size, () -> showPage(PAGE_SUBTITLE, true));
        bindRow(page, R.id.row_help,     () -> showPage(PAGE_HELP,     true));
        bindRow(page, R.id.row_contact,  this::openTelegram);
        bindRow(page, R.id.row_about,    () -> showPage(PAGE_ABOUT,    true));

        // ── Toggles (real, persisted) ──
        bindToggle(page, R.id.row_autoplay,
            SettingsStore.isAutoplayNext(this),
            on -> SettingsStore.setAutoplayNext(this, on));
        bindToggle(page, R.id.row_reduce_motion,
            SettingsStore.isReduceMotion(this),
            on -> SettingsStore.setReduceMotion(this, on));

        // ── Storage rows (real data, loaded async) ──
        bindRow(page, R.id.row_cache,   this::clearCache);
        bindRow(page, R.id.row_history, this::clearWatchHistory);
        refreshStorageValues(page);

        // ── Sign out ──
        View logoutBtn = page.findViewById(R.id.settings_logout_btn);
        if (logoutBtn != null) {
            UiMotion.pressSubtle(logoutBtn);
            logoutBtn.setOnClickListener(v -> showLogoutDialog());
        }

        // ── Version footer ──
        TextView footer = (TextView) page.findViewById(R.id.settings_version_footer);
        if (footer != null) footer.setText("Eve Cinema · v" + appVersion());

        return page;
    }

    // ── Row styling via IDs inside the included layout ────
    private void styleRow(View page, int rowId, int iconRes, int titleRes, int descRes, int tint) {
        View row = page.findViewById(rowId);
        if (row == null) return;
        ImageView icon = (ImageView) row.findViewById(R.id.row_icon);
        TextView  title = (TextView) row.findViewById(R.id.row_title);
        TextView  desc  = (TextView) row.findViewById(R.id.row_desc);
        if (icon != null) {
            icon.setImageResource(iconRes);
            icon.setColorFilter(tint);
        }
        if (title != null) title.setText(titleRes);
        if (desc != null) {
            if (descRes != 0) desc.setText(descRes);
            else desc.setVisibility(View.GONE);
        }
    }

    private void setRowValue(View page, int rowId, String value) {
        View row = page.findViewById(rowId);
        if (row == null) return;
        TextView valueTv = (TextView) row.findViewById(R.id.row_value);
        if (valueTv == null) return;
        valueTv.setText(value);
        valueTv.setVisibility(View.VISIBLE);
    }

    private void bindRow(View page, int rowId, Runnable action) {
        View row = page.findViewById(rowId);
        if (row == null) return;
        UiMotion.pressSubtle(row);
        row.setOnClickListener(v -> action.run());
    }

    // ── Toggle switch — animation via translationX (cheap) ──
    private interface ToggleListener { void onChanged(boolean on); }

    private void bindToggle(View page, int rowId, boolean initial, ToggleListener listener) {
        View row = page.findViewById(rowId);
        if (row == null) return;
        FrameLayout track = (FrameLayout) row.findViewById(R.id.switch_track);
        View knob = row.findViewById(R.id.switch_knob);
        if (track == null || knob == null) return;
        applyToggleVisual(track, knob, initial, false);
        row.setOnClickListener(v -> {
            boolean nowOn = track.getTag() instanceof Boolean && (Boolean) track.getTag();
            boolean next = !nowOn;
            applyToggleVisual(track, knob, next, true);
            listener.onChanged(next);
        });
    }

    private void applyToggleVisual(FrameLayout track, View knob, boolean on, boolean animate) {
        track.setTag(on);
        track.setBackgroundResource(on ? R.drawable.bg_switch_track_on
                                       : R.drawable.bg_switch_track_off);
        float target = on ? dpToPx(20) : 0f; // track 46dp − knob 20dp − 3dp margins ×2
        if (animate) {
            ObjectAnimator a = ObjectAnimator.ofFloat(knob, "translationX",
                knob.getTranslationX(), target);
            a.setDuration(UiMotion.MICRO);
            a.setInterpolator(UiMotion.DECEL_2);
            a.start();
        } else {
            knob.setTranslationX(target);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  STORAGE — real cache + watch history
    // ═══════════════════════════════════════════════════════
    private void refreshStorageValues(View page) {
        // Watch history count (cheap, same prefs file the player writes)
        SharedPreferences wp = getSharedPreferences(PREFS_WATCH, MODE_PRIVATE);
        int count = wp.getAll().size();
        setRowValue(page, R.id.row_history, count == 0
            ? getString(R.string.settings_history_empty)
            : getString(R.string.settings_items_count, count));

        // Cache size on a background thread (disk scan)
        View row = page.findViewById(R.id.row_cache);
        if (row == null) return;
        TextView valueTv = (TextView) row.findViewById(R.id.row_value);
        new Thread(() -> {
            long bytes = dirSize(getCacheDir()) + dirSize(getExternalCacheDir());
            String label = formatBytes(bytes);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || valueTv == null) return;
                valueTv.setText(label);
                valueTv.setVisibility(View.VISIBLE);
            });
        }).start();
    }

    private void clearCache() {
        TmdbCache.clearAll();
        Glide.get(this).clearMemory();
        new Thread(() -> {
            Glide.get(this).clearDiskCache();
            deleteRecursive(getCacheDir());
            java.io.File ext = getExternalCacheDir();
            if (ext != null) deleteRecursive(ext);
        }).start();
        toast(getString(R.string.toast_cache_cleared));
        View row = rootFrame.findViewById(R.id.row_cache);
        if (row != null) {
            TextView v = (TextView) row.findViewById(R.id.row_value);
            if (v != null) v.setText(formatBytes(0));
        }
    }

    private void clearWatchHistory() {
        getSharedPreferences(PREFS_WATCH, MODE_PRIVATE).edit().clear().apply();
        toast(getString(R.string.toast_history_cleared));
        View row = rootFrame.findViewById(R.id.row_history);
        if (row != null) {
            TextView v = (TextView) row.findViewById(R.id.row_value);
            if (v != null) v.setText(getString(R.string.settings_history_empty));
        }
    }

    private static long dirSize(java.io.File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long sum = 0;
        java.io.File[] kids = f.listFiles();
        if (kids != null) for (java.io.File k : kids) sum += dirSize(k);
        return sum;
    }

    private static void deleteRecursive(java.io.File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            java.io.File[] kids = f.listFiles();
            if (kids != null) for (java.io.File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    private static String formatBytes(long b) {
        if (b <= 0) return "0 MB";
        float mb = b / (1024f * 1024f);
        if (mb < 1) return String.format(java.util.Locale.US, "%.0f KB", b / 1024f);
        if (mb < 1024) return String.format(java.util.Locale.US, "%.1f MB", mb);
        return String.format(java.util.Locale.US, "%.2f GB", mb / 1024f);
    }

    // ═══════════════════════════════════════════════════════
    //  LABEL HELPERS
    // ═══════════════════════════════════════════════════════
    private String qualityLabel(String q) {
        if (SettingsStore.QUALITY_AUTO.equals(q)) return getString(R.string.sub_quality_auto);
        return q;
    }

    private String subLangLabel(String lang) {
        if (SettingsStore.SUB_LANG_AR.equals(lang)) return getString(R.string.sub_lang_ar);
        if (SettingsStore.SUB_LANG_EN.equals(lang)) return getString(R.string.sub_lang_en);
        return getString(R.string.sub_lang_auto);
    }

    private String subSizeLabel(int size) {
        switch (size) {
            case SettingsStore.SUB_SIZE_S: return getString(R.string.sub_size_s);
            case SettingsStore.SUB_SIZE_L: return getString(R.string.sub_size_l);
            default:                       return getString(R.string.sub_size_m);
        }
    }

    private String appVersion() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            return pi.versionName != null ? pi.versionName : "—";
        } catch (Exception e) {
            return "—";
        }
    }

    // ═══════════════════════════════════════════════════════
    //  AVATAR (preserved logic, async + initials fallback)
    // ═══════════════════════════════════════════════════════
    private void loadAvatarAsync(ImageView target) {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        String name = (user != null && user.getDisplayName() != null)
            ? user.getDisplayName() : session.getUsername();
        target.setImageBitmap(makeInitialsBitmap(name, dpToPx(58)));

        String photoUrl = null;
        if (user != null && user.getPhotoUrl() != null)
            photoUrl = user.getPhotoUrl().toString().replace("=s96-c", "=s400-c");
        if ((photoUrl == null || photoUrl.isEmpty()) && !session.getAvatarUri().isEmpty())
            photoUrl = session.getAvatarUri();
        if (photoUrl == null || photoUrl.isEmpty()) return;

        final String url = photoUrl;
        avatarThread = new Thread(() -> {
            Bitmap bmp = loadBitmapSafe(url);
            if (bmp == null || Thread.currentThread().isInterrupted()) return;
            Bitmap circular = MainActivity.makeCircular(
                Bitmap.createScaledBitmap(bmp, dpToPx(58), dpToPx(58), true));
            bmp.recycle();
            runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed()) target.setImageBitmap(circular);
            });
        });
        avatarThread.setDaemon(true);
        avatarThread.start();
    }

    private Bitmap makeInitialsBitmap(String name, int size) {
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(bmp);
        android.graphics.Paint bg = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        bg.setColor(C_PURPLE_DK);
        c.drawCircle(size / 2f, size / 2f, size / 2f, bg);
        android.graphics.Paint tp = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        tp.setColor(Color.WHITE);
        tp.setTextSize(size * 0.38f);
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        tp.setTextAlign(android.graphics.Paint.Align.CENTER);
        String init = (name != null && !name.isEmpty())
            ? String.valueOf(name.charAt(0)).toUpperCase() : "U";
        android.graphics.Rect bounds = new android.graphics.Rect();
        tp.getTextBounds(init, 0, init.length(), bounds);
        c.drawText(init, size / 2f, size / 2f + bounds.height() / 2f, tp);
        return bmp;
    }

    private Bitmap loadBitmapSafe(String url) {
        try {
            java.net.HttpURLConnection conn =
                (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(10000);
            conn.setDoInput(true);
            conn.connect();
            if (conn.getResponseCode() == 200) return BitmapFactory.decodeStream(conn.getInputStream());
            return null;
        } catch (Exception e) { return null; }
    }

    // ═══════════════════════════════════════════════════════
    //  LOGOUT DIALOG (logic preserved, glass restyle)
    // ═══════════════════════════════════════════════════════
    private void showLogoutDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dpToPx(22), dpToPx(24), dpToPx(22), dpToPx(20));
        content.setBackground(makeRoundedStroke(0xF2121224, 0x22FFFFFF, dpToPx(20), dpToPx(1)));

        TextView titleTv = makeTv(getString(R.string.dialog_signout_title), 17f, C_TEXT_PRI, Typeface.BOLD);
        titleTv.setPadding(0, 0, 0, dpToPx(8));
        content.addView(titleTv);

        TextView desc = makeTv(getString(R.string.dialog_signout_msg), 13f, C_TEXT_SEC, Typeface.NORMAL);
        desc.setLineSpacing(dpToPx(3), 1f);
        desc.setPadding(0, 0, 0, dpToPx(22));
        content.addView(desc);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        builder.setView(content);
        android.app.AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));

        TextView cancel = makeTv(getString(R.string.dialog_cancel), 13.5f, C_TEXT_SEC, Typeface.BOLD);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dpToPx(44), 1f);
        cp.setMarginEnd(dpToPx(8));
        cancel.setLayoutParams(cp);
        cancel.setGravity(Gravity.CENTER);
        cancel.setBackground(makeRoundedStroke(0x14FFFFFF, 0x22FFFFFF, dpToPx(12), dpToPx(1)));
        cancel.setOnClickListener(v -> dialog.dismiss());
        btns.addView(cancel);

        TextView confirm = makeTv(getString(R.string.settings_sign_out), 13.5f, Color.WHITE, Typeface.BOLD);
        confirm.setLayoutParams(new LinearLayout.LayoutParams(0, dpToPx(44), 1f));
        confirm.setGravity(Gravity.CENTER);
        confirm.setBackground(makeRoundedFill(0xFFDC4A4A, dpToPx(12)));
        confirm.setOnClickListener(v -> {
            dialog.dismiss();
            firebaseAuth.signOut();
            googleSignInClient.signOut();
            session.logout();
            TmdbCache.clearAll();
            Intent i = new Intent(this, LoginActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        });
        btns.addView(confirm);
        content.addView(btns);
        dialog.show();
    }

    // ═══════════════════════════════════════════════════════
    //  SUB PAGES
    // ═══════════════════════════════════════════════════════

    // ── Security ──
    private View buildSecurityPage() {
        LinearLayout root = buildSubShell(getString(R.string.sub_security_title));
        LinearLayout content = getSubContent(root);

        LinearLayout card = makePanel();
        addInfoRow(card, getString(R.string.sub_session_status),
            session.isLoggedIn() ? getString(R.string.sub_session_active)
                                 : getString(R.string.sub_session_unknown),
            session.isLoggedIn() ? C_GREEN : C_TEXT_MUT, false);
        FirebaseUser user = firebaseAuth.getCurrentUser();
        addInfoRow(card, getString(R.string.sub_signed_in_google),
            user != null ? (user.getEmail() != null ? user.getEmail() : "✓")
                         : session.getEmail(), C_TEXT_PRI, true);
        addInfoRow(card, getString(R.string.sub_device_id),
            shortId(session.getDeviceId()), C_TEXT_MUT, true);
        content.addView(card);

        TextView note = makeTv(getString(R.string.settings_google_managed), 11.5f, C_TEXT_MUT, Typeface.NORMAL);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dpToPx(24), dpToPx(14), dpToPx(24), 0);
        content.addView(note);
        return root;
    }

    // ── Devices ──
    private View buildDevicesPage() {
        LinearLayout root = buildSubShell(getString(R.string.sub_devices_title));
        LinearLayout content = getSubContent(root);

        LinearLayout card = makePanel();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dpToPx(14), dpToPx(16), dpToPx(14), dpToPx(16));

        row.addView(makeIconTile(R.drawable.ic_device_phone, C_PURPLE));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        String model = Build.MODEL != null ? Build.MODEL : getString(R.string.sub_this_device);
        info.addView(makeTv(model, 14f, C_TEXT_PRI, Typeface.BOLD));
        info.addView(makeTv("Android " + Build.VERSION.RELEASE
            + " · " + getString(R.string.sub_last_active_now), 11f, C_TEXT_MUT, Typeface.NORMAL));
        row.addView(info);

        TextView badge = makeTv(getString(R.string.sub_active_badge), 11f, C_GREEN, Typeface.BOLD);
        badge.setPadding(dpToPx(10), dpToPx(4), dpToPx(10), dpToPx(4));
        badge.setBackground(makeRoundedStroke(0x1A4ADE80, 0x4D4ADE80, dpToPx(20), dpToPx(1)));
        row.addView(badge);
        card.addView(row);
        content.addView(card);
        return root;
    }

    // ── Quality (persisted, consumed by PlayerActivity) ──
    private View buildQualityPage() {
        LinearLayout root = buildSubShell(getString(R.string.sub_quality_title));
        LinearLayout content = getSubContent(root);

        String[] values = {
            SettingsStore.QUALITY_AUTO, SettingsStore.QUALITY_1080,
            SettingsStore.QUALITY_720,  SettingsStore.QUALITY_480 };
        String[] titles = {
            getString(R.string.sub_quality_auto), "1080p HD", "720p", "480p" };
        String[] descs = {
            getString(R.string.sub_quality_auto_desc), getString(R.string.quality_1080_desc),
            getString(R.string.quality_720_desc), getString(R.string.quality_480_desc) };

        String current = SettingsStore.getDefaultQuality(this);
        LinearLayout card = makePanel();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) card.addView(buildDivider(dpToPx(54)));
            final String value = values[i];
            boolean sel = value.equals(current);
            LinearLayout row = makeSelectableRow(titles[i], descs[i], sel);
            row.setOnClickListener(v -> {
                SettingsStore.setDefaultQuality(this, value);
                toast(getString(R.string.toast_quality_set, titles[getIndex(values, value)]));
                showPage(PAGE_QUALITY, false);
            });
            card.addView(row);
        }
        content.addView(card);
        return root;
    }

    private int getIndex(String[] arr, String v) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(v)) return i;
        return 0;
    }

    // ── Subtitles (language + size, both persisted) ──
    private View buildSubtitlePage() {
        LinearLayout root = buildSubShell(getString(R.string.sub_subtitles_title));
        LinearLayout content = getSubContent(root);

        // Language group
        content.addView(makeGroupLabel(getString(R.string.sub_lang_label)));
        String[] langValues = { SettingsStore.SUB_LANG_AUTO, SettingsStore.SUB_LANG_AR, SettingsStore.SUB_LANG_EN };
        String[] langTitles = { getString(R.string.sub_lang_auto), getString(R.string.sub_lang_ar), getString(R.string.sub_lang_en) };
        String currentLang = SettingsStore.getSubtitleLanguage(this);
        LinearLayout langCard = makePanel();
        for (int i = 0; i < langValues.length; i++) {
            if (i > 0) langCard.addView(buildDivider(dpToPx(16)));
            final String value = langValues[i];
            LinearLayout row = makeSelectableRow(langTitles[i], null, value.equals(currentLang));
            row.setOnClickListener(v -> {
                SettingsStore.setSubtitleLanguage(this, value);
                showPage(PAGE_SUBTITLE, false);
            });
            langCard.addView(row);
        }
        content.addView(langCard);

        // Size group
        content.addView(makeGroupLabel(getString(R.string.sub_size_label)));
        int[] sizeValues = { SettingsStore.SUB_SIZE_S, SettingsStore.SUB_SIZE_M, SettingsStore.SUB_SIZE_L };
        String[] sizeTitles = { getString(R.string.sub_size_s), getString(R.string.sub_size_m), getString(R.string.sub_size_l) };
        int currentSize = SettingsStore.getSubtitleSize(this);
        LinearLayout sizeCard = makePanel();
        for (int i = 0; i < sizeValues.length; i++) {
            if (i > 0) sizeCard.addView(buildDivider(dpToPx(16)));
            final int value = sizeValues[i];
            LinearLayout row = makeSelectableRow(sizeTitles[i], null, value == currentSize);
            row.setOnClickListener(v -> {
                SettingsStore.setSubtitleSize(this, value);
                showPage(PAGE_SUBTITLE, false);
            });
            sizeCard.addView(row);
        }
        content.addView(sizeCard);
        return root;
    }

    // ── Help ──
    private View buildHelpPage() {
        LinearLayout root = buildSubShell(getString(R.string.sub_help_title));
        LinearLayout content = getSubContent(root);

        int[][] items = {
            { R.string.help_q1, R.string.help_q1_a },
            { R.string.help_q2, R.string.help_q2_a },
            { R.string.help_q3, R.string.help_q3_a },
            { R.string.help_q4, R.string.help_q4_a } };

        LinearLayout card = makePanel();
        for (int i = 0; i < items.length; i++) {
            if (i > 0) card.addView(buildDivider(dpToPx(54)));
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dpToPx(14), dpToPx(13), dpToPx(14), dpToPx(13));
            row.setClickable(true);
            row.setFocusable(true);
            row.setBackgroundResource(R.drawable.bg_glass_row_ripple);
            row.addView(makeIconTile(R.drawable.ic_help_circle, C_PURPLE));
            LinearLayout inf = new LinearLayout(this);
            inf.setOrientation(LinearLayout.VERTICAL);
            inf.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            inf.addView(makeTv(getString(items[i][0]), 13.5f, C_TEXT_PRI, Typeface.BOLD));
            TextView a = makeTv(getString(items[i][1]), 11.5f, C_TEXT_MUT, Typeface.NORMAL);
            a.setPadding(0, dpToPx(2), 0, 0);
            inf.addView(a);
            row.addView(inf);
            row.setOnClickListener(v -> openTelegram());
            card.addView(row);
        }
        content.addView(card);
        return root;
    }

    // ── About ──
    private View buildAboutPage() {
        LinearLayout root = buildSubShell(getString(R.string.sub_about_title));
        LinearLayout content = getSubContent(root);

        // Logo block
        LinearLayout logoSec = new LinearLayout(this);
        logoSec.setOrientation(LinearLayout.VERTICAL);
        logoSec.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams lsp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lsp.setMargins(0, dpToPx(12), 0, dpToPx(20));
        logoSec.setLayoutParams(lsp);

        FrameLayout lw = new FrameLayout(this);
        LinearLayout.LayoutParams lwp = new LinearLayout.LayoutParams(dpToPx(72), dpToPx(72));
        lwp.bottomMargin = dpToPx(14);
        lw.setLayoutParams(lwp);
        GradientDrawable lgBg = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR, new int[]{ C_PURPLE, C_PURPLE_DK });
        lgBg.setCornerRadius(dpToPx(20));
        lw.setBackground(lgBg);
        TextView lgTv = makeTv("V", 32f, Color.WHITE, Typeface.BOLD);
        lgTv.setGravity(Gravity.CENTER);
        lw.addView(lgTv, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        logoSec.addView(lw);

        TextView an = makeTv(getString(R.string.app_name), 20f, C_TEXT_PRI, Typeface.BOLD);
        an.setGravity(Gravity.CENTER);
        logoSec.addView(an);
        TextView vt = makeTv("v" + appVersion(), 12f, C_TEXT_MUT, Typeface.NORMAL);
        vt.setGravity(Gravity.CENTER);
        vt.setPadding(0, dpToPx(4), 0, 0);
        logoSec.addView(vt);
        content.addView(logoSec);

        LinearLayout infoCard = makePanel();
        infoCard.setPadding(dpToPx(16), dpToPx(6), dpToPx(16), dpToPx(6));
        addInfoRow(infoCard, getString(R.string.about_version),  appVersion(),        C_TEXT_PRI, false);
        addInfoRow(infoCard, getString(R.string.about_dev),      "Eve Studio",        C_TEXT_PRI, true);
        addInfoRow(infoCard, getString(R.string.about_platform), "Android 7.0+",      C_TEXT_PRI, true);
        addInfoRow(infoCard, getString(R.string.about_tmdb_attribution), "TMDB",      C_TEXT_MUT, true);
        content.addView(infoCard);
        return root;
    }

    // ═══════════════════════════════════════════════════════
    //  SHARED SUB-PAGE BUILDERS (same tokens as main page)
    // ═══════════════════════════════════════════════════════
    private LinearLayout buildSubShell(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.setBackgroundColor(Color.parseColor("#08080F"));

        // top bar — vector back button (no glyph characters)
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dpToPx(14), dpToPx(46), dpToPx(18), dpToPx(14));

        FrameLayout bb = new FrameLayout(this);
        LinearLayout.LayoutParams bbp = new LinearLayout.LayoutParams(dpToPx(40), dpToPx(40));
        bbp.setMarginEnd(dpToPx(12));
        bb.setLayoutParams(bbp);
        bb.setBackgroundResource(R.drawable.bg_icon_btn_glass);
        bb.setClickable(true);
        bb.setFocusable(true);
        bb.setContentDescription(getString(R.string.cd_back));
        ImageView ba = new ImageView(this);
        ba.setImageResource(R.drawable.ic_back);
        ba.setColorFilter(C_TEXT_PRI);
        FrameLayout.LayoutParams bap = new FrameLayout.LayoutParams(dpToPx(18), dpToPx(18));
        bap.gravity = Gravity.CENTER;
        bb.addView(ba, bap);
        bb.setOnClickListener(v -> goBack());
        bar.addView(bb);

        TextView ttv = makeTv(title, 20f, C_TEXT_PRI, Typeface.BOLD);
        ttv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        ttv.setMaxLines(1);
        ttv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(ttv);
        root.addView(bar);

        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        sv.setVerticalScrollBarEnabled(false);
        sv.setHorizontalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dpToPx(6), 0, dpToPx(40));
        sv.addView(content);
        root.addView(sv);
        return root;
    }

    private LinearLayout getSubContent(LinearLayout subShell) {
        ScrollView sv = (ScrollView) subShell.getChildAt(1);
        return (LinearLayout) sv.getChildAt(0);
    }

    /** لوحة زجاجية — نفس bg_glass_panel المستخدم في الصفحة الرئيسية */
    private LinearLayout makePanel() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dpToPx(16), 0, dpToPx(16), dpToPx(12));
        c.setLayoutParams(lp);
        c.setBackgroundResource(R.drawable.bg_glass_panel);
        c.setClipToOutline(true);
        c.setPadding(0, dpToPx(4), 0, dpToPx(4));
        return c;
    }

    private TextView makeGroupLabel(String text) {
        TextView t = makeTv(text, 11f, 0xFF6E6E8E, Typeface.BOLD);
        t.setLetterSpacing(0f);
        t.setPadding(dpToPx(20), dpToPx(12), dpToPx(20), dpToPx(8));
        return t;
    }

    /** صف اختيار (radio) — عنوان + وصف اختياري + علامة صح عند التحديد */
    private LinearLayout makeSelectableRow(String title, String desc, boolean selected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(14));
        row.setClickable(true);
        row.setFocusable(true);
        row.setBackgroundResource(R.drawable.bg_glass_row_ripple);

        LinearLayout inf = new LinearLayout(this);
        inf.setOrientation(LinearLayout.VERTICAL);
        inf.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        inf.addView(makeTv(title, 14f, C_TEXT_PRI,
            selected ? Typeface.BOLD : Typeface.NORMAL));
        if (desc != null) {
            TextView d = makeTv(desc, 11.5f, C_TEXT_MUT, Typeface.NORMAL);
            d.setPadding(0, dpToPx(2), 0, 0);
            inf.addView(d);
        }
        row.addView(inf);

        if (selected) {
            ImageView check = new ImageView(this);
            check.setImageResource(R.drawable.ic_check_circle);
            check.setColorFilter(C_PURPLE);
            row.addView(check, new LinearLayout.LayoutParams(dpToPx(20), dpToPx(20)));
        }
        return row;
    }

    private FrameLayout makeIconTile(int iconRes, int tint) {
        FrameLayout wrap = new FrameLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpToPx(38), dpToPx(38));
        lp.setMarginEnd(dpToPx(14));
        wrap.setLayoutParams(lp);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setColor(C_ICON_TILE);
        bg.setCornerRadius(dpToPx(12));
        bg.setStroke(dpToPx(1), 0x339B6FC4);
        wrap.setBackground(bg);
        ImageView iv = new ImageView(this);
        iv.setImageResource(iconRes);
        iv.setColorFilter(tint);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dpToPx(19), dpToPx(19));
        ip.gravity = Gravity.CENTER;
        wrap.addView(iv, ip);
        return wrap;
    }

    private View buildDivider(int startMargin) {
        View v = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1));
        lp.setMarginStart(startMargin);
        v.setLayoutParams(lp);
        v.setBackgroundColor(C_DIVIDER);
        return v;
    }

    private void addInfoRow(LinearLayout parent, String key, String val, int valColor, boolean divider) {
        if (divider) parent.addView(buildDivider(0));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dpToPx(13), 0, dpToPx(13));
        row.addView(makeTv(key, 12.5f, C_TEXT_MUT, Typeface.NORMAL));
        LinearLayout sp = new LinearLayout(this);
        sp.setLayoutParams(new LinearLayout.LayoutParams(0, 0, 1f));
        row.addView(sp);
        TextView v = makeTv(val, 12.5f, valColor, Typeface.BOLD);
        v.setMaxLines(1);
        v.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(v);
        parent.addView(row);
    }

    private String shortId(String id) {
        if (id == null || id.isEmpty()) return "—";
        return id.length() > 10 ? id.substring(0, 10) + "…" : id;
    }

    private void openTelegram() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(Config.TELEGRAM_BOT_URL)));
        } catch (Exception e) {
            toast(getString(R.string.toast_install_telegram));
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private TextView makeTv(String text, float sp, int color, int style) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTypeface(Typeface.create(Typeface.DEFAULT, style));
        return tv;
    }

    private GradientDrawable makeRoundedFill(int color, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(color);
        d.setCornerRadius(r);
        return d;
    }

    private GradientDrawable makeRoundedStroke(int fill, int stroke, int r, int sw) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(fill);
        d.setCornerRadius(r);
        d.setStroke(sw, stroke);
        return d;
    }

    // ═══════════════════════════════════════════════════════
    @Override
    protected void onResume() {
        super.onResume();
        MiuiBarFix.apply(this);
        EveFloatingButton.attach(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        EveFloatingButton.detach(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (avatarThread != null) { avatarThread.interrupt(); avatarThread = null; }
        MiuiBarFix.release(this);
    }
}
