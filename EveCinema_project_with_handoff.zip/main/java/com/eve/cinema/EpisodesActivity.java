package com.eve.cinema;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * EpisodesActivity — مصلح
 * ════════════════════════
 * ✅ الإصلاح الجوهري:
 *  - openPlayer يجيب episodeId من CinemaBoxCache
 *  - launchPlayer يمرر "episode_id" للـ PlayerActivity — وليس show_id
 *  - PlayerActivity يشغل episodeId مباشرة بدون بحث إضافي
 *
 * ✅ إصلاح AniList (مواسم الأنمي):
 *  - loadSeasonsCount يستخدم original_name (إنجليزي) بدل name (عربي)
 *  - AniListSeasonsTask يجرب اسمين ويستخدم getFullSeries (recursive)
 *  - getFullSeries في AniListClient يتتبع PREQUEL+SEQUEL بشكل كامل
 */
public class EpisodesActivity extends Activity {

    private static final String TMDB_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4M2IwMGE5M2M1YmEyMmQxNDYzNWViZmQ5YTI1M2ZjMiIsIm5iZiI6MTc1MjA1OTI4NS42MDcsInN1YiI6IjY4NmU0ZDk1NGNiMTU4ZDdiZGVkNjU2YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.b3GvmcSJXU6q_ZRGnUpqO7iFqrhaugqIovkrI8S-oYQ";
    private static final String IMG_BASE_O = "https://image.tmdb.org/t/p/original";

    // Colors
    private static final int C_VOID   = 0xFF08080F;
    private static final int C_CARD   = 0xFF1C1C2E;
    private static final int C_VIOLET = 0xFF9B6FC4;
    private static final int C_VIOLET2= 0xFF7C4FA0;
    private static final int C_LITE   = 0xFFC4A0E8;
    private static final int C_TEXT   = 0xFFFFFFFF;
    private static final int C_BORDER = 0xFF252540;

    // Pagination
    private static final int PAGE_SIZE    = 50;
    private static final int LOAD_TRIGGER = 8;

    // ViewHolder types
    private static final int VT_HEADER  = 0;
    private static final int VT_SEASONS = 1;
    private static final int VT_EPISODE = 2;
    private static final int VT_SPINNER = 3;

    // State
    private JSONObject item;
    private String     tmdbId;
    private String     mediaType;
    private int        currentSeason = 1;
    private int        totalSeasons  = 1;

    // Views
    private ImageView     heroBackdrop;
    private TextView      episodesCountBadge;
    private ProgressBar   episodesLoading;
    private RecyclerView  masterRv;
    private MasterAdapter masterAdapter;
    private SeasonAdapter seasonAdapter;

    // Resolve overlay
    private FrameLayout resolveOverlay;
    private TextView    resolveMsgTv;

    // P5: source picked on the details page (0 = default/auto); P4: chooser generation
    private int selectedSource = 0;
    private int chooserGeneration = 0;

    // Pre-built header views
    private View hdrHero;
    private View hdrSeasons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MiuiBarFix.apply(this);

        String json = getIntent().getStringExtra("item_json");
        if (json == null) { finish(); return; }
        try { item = new JSONObject(json); }
        catch (Exception e) { finish(); return; }

        tmdbId    = getIntent().getStringExtra("tmdb_id");
        mediaType = getIntent().getStringExtra("media_type");
        if (tmdbId == null) tmdbId = String.valueOf(item.optInt("id"));
        // P5: the details page's verified source choice (anime always resolves to مصدر 1).
        selectedSource = getIntent().getIntExtra("selected_source", 0);
        if ("anime".equals(mediaType))
            selectedSource = com.eve.cinema.playback.SourceChoice.SOURCE_MOVIEBOX;

        buildUI();
        loadSeasonsCount();
        startShowPrefetch();
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.enter_from_left, R.anim.exit_to_right);
    }

    // ════════════════════════════════════════════════════════════════
    // BUILD UI
    // ════════════════════════════════════════════════════════════════

    private void buildUI() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(C_VOID);

        masterRv = new RecyclerView(this);
        masterRv.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        masterRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        masterRv.setHasFixedSize(false);
        masterRv.setItemAnimator(null);
        masterRv.setPadding(0, 0, 0, dpToPx(32));
        masterRv.setClipToPadding(false);
        masterRv.setLayoutManager(new LinearLayoutManager(this));

        hdrHero    = buildHeroView();
        hdrSeasons = buildSeasonsView();

        masterAdapter = new MasterAdapter();
        masterRv.setAdapter(masterAdapter);
        root.addView(masterRv);
        root.addView(buildBackButton());

        setContentView(root);

        masterRv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) { applyParallax(rv); }
        });

        masterRv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (dy <= 0) return;
                LinearLayoutManager lm = (LinearLayoutManager) rv.getLayoutManager();
                if (lm == null) return;
                if (lm.findLastVisibleItemPosition() >= masterAdapter.getItemCount() - LOAD_TRIGGER) {
                    masterAdapter.loadNextPage();
                }
            }
        });
    }

    private View buildHeroView() {
        FrameLayout frame = new FrameLayout(this);
        frame.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, dpToPx(260)));

        heroBackdrop = new ImageView(this);
        heroBackdrop.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        heroBackdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroBackdrop.setBackgroundColor(0xFF10101E);
        frame.addView(heroBackdrop);

        View grad = new View(this);
        grad.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        grad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
            new int[]{ C_VOID, 0xEE06060F, 0x8806060F, 0x2206060F, Color.TRANSPARENT }));
        frame.addView(grad);

        LinearLayout bottomArea = new LinearLayout(this);
        FrameLayout.LayoutParams baLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        baLp.gravity = Gravity.BOTTOM;
        bottomArea.setLayoutParams(baLp);
        bottomArea.setOrientation(LinearLayout.VERTICAL);
        bottomArea.setPadding(dpToPx(20), 0, dpToPx(20), dpToPx(18));

        String title = item.optString("name", "");
        if (title.isEmpty()) title = item.optString("title", "");
        TextView titleTv = new TextView(this);
        titleTv.setText(title);
        titleTv.setTextSize(22f);
        titleTv.setTextColor(C_TEXT);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        titleTv.setMaxLines(2);
        titleTv.setShadowLayer(10, 0, 2, 0xCC000000);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.bottomMargin = dpToPx(8);
        titleTv.setLayoutParams(titleLp);
        bottomArea.addView(titleTv);

        LinearLayout badgeRow = new LinearLayout(this);
        badgeRow.setOrientation(LinearLayout.HORIZONTAL);
        badgeRow.setGravity(Gravity.CENTER_VERTICAL);

        episodesCountBadge = new TextView(this);
        episodesCountBadge.setTextSize(11f);
        episodesCountBadge.setTextColor(C_LITE);
        episodesCountBadge.setPadding(dpToPx(10), dpToPx(4), dpToPx(10), dpToPx(4));
        GradientDrawable epBadgeBg = new GradientDrawable();
        epBadgeBg.setCornerRadius(dpToPx(6));
        epBadgeBg.setColor(0x22C4A0E8);
        epBadgeBg.setStroke(dpToPx(1), 0x33C4A0E8);
        episodesCountBadge.setBackground(epBadgeBg);
        episodesCountBadge.setVisibility(View.GONE);
        badgeRow.addView(episodesCountBadge);

        episodesLoading = new ProgressBar(this);
        LinearLayout.LayoutParams spinLp = new LinearLayout.LayoutParams(dpToPx(18), dpToPx(18));
        spinLp.leftMargin = dpToPx(10);
        episodesLoading.setLayoutParams(spinLp);
        episodesLoading.setIndeterminate(true);
        episodesLoading.setVisibility(View.VISIBLE);
        badgeRow.addView(episodesLoading);

        bottomArea.addView(badgeRow);
        frame.addView(bottomArea);

        String backdrop = item.optString("backdrop_path", "");
        if (!backdrop.isEmpty()) {
            heroBackdrop.setAlpha(0f);
            heroBackdrop.setScaleX(1.08f);
            heroBackdrop.setScaleY(1.08f);
            com.bumptech.glide.Glide.with(this)
                .load(IMG_BASE_O + backdrop)
                .centerCrop()
                .transition(com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade(500))
                .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                    @Override
                    public boolean onResourceReady(android.graphics.drawable.Drawable r, Object m,
                        com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> t,
                        com.bumptech.glide.load.DataSource d, boolean f) {
                        heroBackdrop.animate().alpha(1f).scaleX(1f).scaleY(1f)
                            .setDuration(900).setInterpolator(new DecelerateInterpolator(2f)).start();
                        return false;
                    }
                    @Override
                    public boolean onLoadFailed(com.bumptech.glide.load.engine.GlideException e, Object m,
                        com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> t, boolean f) {
                        heroBackdrop.setAlpha(1f); heroBackdrop.setScaleX(1f); heroBackdrop.setScaleY(1f);
                        return false;
                    }
                })
                .into(heroBackdrop);
        }

        return frame;
    }

    private View buildSeasonsView() {
        LinearLayout col = new LinearLayout(this);
        col.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        col.setOrientation(LinearLayout.VERTICAL);

        View div = new View(this);
        div.setBackgroundColor(0x12FFFFFF);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1));
        divLp.leftMargin = dpToPx(20); divLp.rightMargin = dpToPx(20);
        div.setLayoutParams(divLp);
        col.addView(div);

        LinearLayout hdrRow = new LinearLayout(this);
        hdrRow.setOrientation(LinearLayout.HORIZONTAL);
        hdrRow.setGravity(Gravity.CENTER_VERTICAL);
        hdrRow.setPadding(dpToPx(20), dpToPx(20), dpToPx(20), dpToPx(12));
        col.addView(hdrRow);

        View accent = new View(this);
        GradientDrawable accentBg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, new int[]{ C_VIOLET, C_VIOLET2 });
        accentBg.setCornerRadius(dpToPx(2));
        accent.setBackground(accentBg);
        LinearLayout.LayoutParams acLp = new LinearLayout.LayoutParams(dpToPx(4), dpToPx(22));
        acLp.rightMargin = dpToPx(10);
        accent.setLayoutParams(acLp);
        hdrRow.addView(accent);

        TextView hdrLabel = new TextView(this);
        hdrLabel.setText("الحلقات");
        hdrLabel.setTextSize(18f);
        hdrLabel.setTextColor(C_TEXT);
        hdrLabel.setTypeface(Typeface.DEFAULT_BOLD);
        hdrRow.addView(hdrLabel);

        // ── زر عكس الترتيب ──────────────────────────────────────────
        View hdrSpacer = new View(this);
        hdrSpacer.setLayoutParams(new LinearLayout.LayoutParams(0, dpToPx(1), 1f));
        hdrRow.addView(hdrSpacer);

        FrameLayout revContainer = new FrameLayout(this);
        LinearLayout.LayoutParams revContLp = new LinearLayout.LayoutParams(dpToPx(38), dpToPx(38));
        revContLp.gravity = Gravity.CENTER_VERTICAL;
        revContLp.rightMargin = dpToPx(2);
        revContainer.setLayoutParams(revContLp);
        revContainer.setClickable(true);
        revContainer.setFocusable(true);

        GradientDrawable revBg = new GradientDrawable();
        revBg.setShape(GradientDrawable.OVAL);
        revBg.setColor(0xFF14142A);
        revBg.setStroke(dpToPx(1), 0xFF2A1A4A);
        revContainer.setBackground(revBg);

        final ImageView revIcon = new ImageView(this);
        FrameLayout.LayoutParams revIconLp = new FrameLayout.LayoutParams(dpToPx(19), dpToPx(19));
        revIconLp.gravity = Gravity.CENTER;
        revIcon.setLayoutParams(revIconLp);
        revIcon.setImageResource(R.drawable.ic_swap_vert);
        revIcon.setColorFilter(C_VIOLET);
        revContainer.addView(revIcon);

        revContainer.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(0.82f).scaleY(0.82f).setDuration(80)
                            .setInterpolator(new DecelerateInterpolator()).start(); break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(260)
                            .setInterpolator(new OvershootInterpolator(2.4f)).start(); break;
                }
                return false;
            }
        });

        revContainer.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                revIcon.animate().rotationBy(180f).setDuration(440)
                    .setInterpolator(new DecelerateInterpolator(2.5f)).start();
                masterRv.animate().alpha(0f).translationY(dpToPx(14))
                    .setDuration(160).setInterpolator(new DecelerateInterpolator())
                    .withEndAction(new Runnable() {
                        @Override public void run() {
                            masterAdapter.toggleReverse();
                            masterRv.scrollToPosition(0);
                            masterRv.animate().alpha(1f).translationY(0f)
                                .setDuration(300)
                                .setInterpolator(new DecelerateInterpolator(2.5f)).start();
                        }
                    }).start();
            }
        });

        hdrRow.addView(revContainer);

        RecyclerView seasonsRv = new RecyclerView(this);
        seasonsRv.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        seasonsRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        seasonsRv.setHasFixedSize(true);
        seasonsRv.setItemAnimator(null);
        seasonsRv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        seasonsRv.setPadding(dpToPx(16), 0, dpToPx(16), dpToPx(18));
        seasonsRv.setClipToPadding(false);
        seasonAdapter = new SeasonAdapter();
        seasonsRv.setAdapter(seasonAdapter);
        col.addView(seasonsRv);

        return col;
    }

    private View buildBackButton() {
        FrameLayout container = new FrameLayout(this);
        container.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));

        FrameLayout btn = new FrameLayout(this);
        FrameLayout.LayoutParams btnLp = new FrameLayout.LayoutParams(dpToPx(44), dpToPx(44));
        btnLp.gravity = Gravity.TOP | Gravity.START;
        btnLp.topMargin = dpToPx(14); btnLp.leftMargin = dpToPx(14);
        btn.setLayoutParams(btnLp);
        btn.setClickable(true); btn.setFocusable(true);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setShape(GradientDrawable.OVAL);
        btnBg.setColor(0xCC0D0D1A);
        btnBg.setStroke(dpToPx(1), 0x33FFFFFF);
        btn.setBackground(btnBg);

        ImageView icon = new ImageView(this);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dpToPx(20), dpToPx(20));
        iconLp.gravity = Gravity.CENTER;
        icon.setLayoutParams(iconLp);
        icon.setImageResource(R.drawable.ic_back);
        icon.setColorFilter(Color.WHITE);
        btn.addView(icon);

        btn.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80)
                            .setInterpolator(new DecelerateInterpolator()).start(); break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(220)
                            .setInterpolator(new OvershootInterpolator(2f)).start(); break;
                }
                return false;
            }
        });
        btn.setOnClickListener(v -> onBackPressed());
        container.addView(btn);
        return container;
    }

    // ════════════════════════════════════════════════════════════════
    // MASTER ADAPTER
    // ════════════════════════════════════════════════════════════════

    private class MasterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        private static final int HEADER_COUNT = 2;

        private final List<JSONObject> displayed = new ArrayList<>();
        private       List<JSONObject> all       = new ArrayList<>();
        private int     pages       = 0;
        private boolean loadingPage = false;
        private boolean showSpinner = false;

        MasterAdapter() { setHasStableIds(true); }

        // Bug 11 FIX: include season_number in the stable ID to prevent
        // collision when two episodes from different seasons share the
        // same episode_number, which caused RecyclerView glitches.
        @Override
        public long getItemId(int pos) {
            if (getItemViewType(pos) == VT_EPISODE) {
                int idx = pos - HEADER_COUNT;
                if (idx >= 0 && idx < displayed.size()) {
                    JSONObject ep = displayed.get(idx);
                    long season = ep.optInt("season_number", 1);
                    long epNum  = ep.optInt("episode_number", idx);
                    return 10000L + (season * 1000L) + epNum;
                }
            }
            return -(pos + 1L);
        }

        @Override
        public int getItemCount() {
            return HEADER_COUNT + displayed.size() + (showSpinner ? 1 : 0);
        }

        @Override
        public int getItemViewType(int pos) {
            if (pos == 0) return VT_HEADER;
            if (pos == 1) return VT_SEASONS;
            int idx = pos - HEADER_COUNT;
            if (idx < displayed.size()) return VT_EPISODE;
            if (showSpinner) return VT_SPINNER;
            return VT_EPISODE;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            switch (viewType) {
                case VT_HEADER:  return new SimpleVH(hdrHero);
                case VT_SEASONS: return new SimpleVH(hdrSeasons);
                case VT_SPINNER: return new SimpleVH(buildSpinnerView());
                case VT_EPISODE: return buildEpisodeVH();
                default:         return new SimpleVH(new View(EpisodesActivity.this));
            }
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int pos) {
            if (getItemViewType(pos) == VT_EPISODE) {
                int idx = pos - HEADER_COUNT;
                if (idx >= 0 && idx < displayed.size())
                    bindEpisode((EpisodeVH) holder, displayed.get(idx));
            }
        }

        // ── Pagination ────────────────────────────────────────────────

        void setAllEpisodes(List<JSONObject> eps) {
            int prev = displayed.size() + (showSpinner ? 1 : 0);
            all = eps;
            pages = 0;
            displayed.clear();
            loadingPage = false;
            showSpinner = false;
            if (prev > 0) notifyItemRangeRemoved(HEADER_COUNT, prev);
            loadNextPage();
        }

        void loadNextPage() {
            if (loadingPage) return;
            int start = pages * PAGE_SIZE;
            if (start >= all.size()) return;
            loadingPage = true;
            int end = Math.min(start + PAGE_SIZE, all.size());
            int insertPos = HEADER_COUNT + displayed.size();
            if (showSpinner) { showSpinner = false; notifyItemRemoved(insertPos); }
            List<JSONObject> page = new ArrayList<>(all.subList(start, end));
            displayed.addAll(page);
            pages++;
            notifyItemRangeInserted(insertPos, page.size());
            if (pages * PAGE_SIZE < all.size()) {
                showSpinner = true;
                notifyItemInserted(HEADER_COUNT + displayed.size());
            }
            loadingPage = false;
        }

        void clearEpisodes() {
            int prev = displayed.size() + (showSpinner ? 1 : 0);
            displayed.clear();
            all.clear();
            pages = 0;
            showSpinner = false;
            loadingPage = false;
            if (prev > 0) notifyItemRangeRemoved(HEADER_COUNT, prev);
        }

        // ── عكس ترتيب الحلقات ─────────────────────────────────────────
        void toggleReverse() {
            java.util.Collections.reverse(all);
            int prev = displayed.size() + (showSpinner ? 1 : 0);
            pages       = 0;
            displayed.clear();
            loadingPage = false;
            showSpinner = false;
            if (prev > 0) notifyItemRangeRemoved(HEADER_COUNT, prev);
            loadNextPage();
        }

        // Bug 7 FIX: expose total count from `all` (not just the current page)
        // so prefetchAdjacentEpisodes and openPlayer see the real episode count.
        int getTotalCount() { return all.size(); }

        // ── Episode ViewHolder ────────────────────────────────────────

        private View buildSpinnerView() {
            FrameLayout f = new FrameLayout(EpisodesActivity.this);
            f.setLayoutParams(new RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT, dpToPx(64)));
            ProgressBar pb = new ProgressBar(EpisodesActivity.this);
            pb.setIndeterminate(true);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dpToPx(24), dpToPx(24));
            lp.gravity = Gravity.CENTER;
            pb.setLayoutParams(lp);
            f.addView(pb);
            return f;
        }

        private EpisodeVH buildEpisodeVH() {
            FrameLayout wrapper = new FrameLayout(EpisodesActivity.this);
            wrapper.setLayoutParams(new RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));

            LinearLayout card = new LinearLayout(EpisodesActivity.this);
            FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dpToPx(78));
            clp.setMargins(dpToPx(16), dpToPx(5), dpToPx(16), dpToPx(5));
            card.setLayoutParams(clp);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dpToPx(18), 0, dpToPx(18), 0);
            card.setClickable(true);
            card.setFocusable(true);
            setEpBg(card, false);

            // Episode number
            TextView numTv = new TextView(EpisodesActivity.this);
            numTv.setTextSize(13f);
            numTv.setTextColor(0xFF5A5A80);
            numTv.setGravity(Gravity.CENTER);
            numTv.setTypeface(Typeface.MONOSPACE);
            numTv.setLayoutParams(new LinearLayout.LayoutParams(
                dpToPx(38), LinearLayout.LayoutParams.WRAP_CONTENT));

            // Separator
            View sep = new View(EpisodesActivity.this);
            sep.setBackgroundColor(0x18FFFFFF);
            LinearLayout.LayoutParams sepLp = new LinearLayout.LayoutParams(dpToPx(1), dpToPx(28));
            sepLp.leftMargin  = dpToPx(14);
            sepLp.rightMargin = dpToPx(18);
            sep.setLayoutParams(sepLp);

            // Title + meta column (meta: تاريخ العرض — يظهر فقط عند توفره من TMDB)
            LinearLayout textCol = new LinearLayout(EpisodesActivity.this);
            textCol.setOrientation(LinearLayout.VERTICAL);
            textCol.setGravity(Gravity.CENTER_VERTICAL);
            textCol.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView titleTv = new TextView(EpisodesActivity.this);
            titleTv.setTextSize(14.5f);
            titleTv.setTextColor(0xFFE0E0F0);
            titleTv.setTypeface(Typeface.DEFAULT_BOLD);
            titleTv.setMaxLines(1);
            titleTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            textCol.addView(titleTv);

            TextView metaTv = new TextView(EpisodesActivity.this);
            metaTv.setTextSize(10.5f);
            metaTv.setTextColor(0xFF5A5A80);
            metaTv.setMaxLines(1);
            metaTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            metaLp.topMargin = dpToPx(3);
            metaTv.setLayoutParams(metaLp);
            metaTv.setVisibility(View.GONE);
            textCol.addView(metaTv);

            card.addView(numTv);
            card.addView(sep);
            card.addView(textCol);
            wrapper.addView(card);

            return new EpisodeVH(wrapper, card, numTv, titleTv, metaTv);
        }

        private void bindEpisode(EpisodeVH h, JSONObject ep) {
            try {
                // ── حالة "سيتوفر قريباً" ─────────────────────────────────
                if (ep.optBoolean("coming_soon", false)) {
                    h.numTv.setText("✦");
                    h.numTv.setTextColor(0xFF7C4FA0);
                    h.titleTv.setText("سيتوفر هذا الأنمي قريباً");
                    h.titleTv.setTextColor(0xFF8060A8);
                    h.titleTv.setTypeface(Typeface.DEFAULT);
                    h.metaTv.setVisibility(View.GONE);

                    GradientDrawable bg = new GradientDrawable();
                    bg.setCornerRadius(dpToPx(14));
                    bg.setColor(0xFF0E0E20);
                    bg.setStroke(dpToPx(1), 0xFF2A1A40);
                    h.card.setBackground(bg);
                    h.card.setClickable(false);
                    h.card.setOnClickListener(null);
                    h.card.setOnTouchListener(null);
                    return;
                }

                // ── حلقة عادية ───────────────────────────────────────────
                int    epNum = ep.optInt("episode_number", 0);
                String name  = ep.optString("name", "");
                if (name.isEmpty()) name = "\u062d\u0644\u0642\u0629 " + epNum;

                h.numTv.setText(String.format(java.util.Locale.US, "%02d", epNum));
                h.titleTv.setText(name);

                // سطر وصفي ثانوي: تاريخ العرض (TMDB فقط — الأنمي يبقى مخفياً)
                String airDate = ep.optString("air_date", "");
                if (airDate != null && airDate.length() >= 10) {
                    h.metaTv.setText(formatAirDate(airDate));
                    h.metaTv.setVisibility(View.VISIBLE);
                } else {
                    h.metaTv.setVisibility(View.GONE);
                }

                setEpBg(h.card, false);

                final int fEp  = epNum;
                final int fSea = currentSeason;

                h.card.setOnClickListener(v -> openPlayer(fSea, fEp));
                h.card.setOnTouchListener(new View.OnTouchListener() {
                    @Override public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                setEpBg(h.card, true);
                                v.animate().scaleX(0.97f).scaleY(0.97f)
                                    .setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
                                break;
                            case MotionEvent.ACTION_UP:
                            case MotionEvent.ACTION_CANCEL:
                                setEpBg(h.card, false);
                                v.animate().scaleX(1f).scaleY(1f)
                                    .setDuration(200).setInterpolator(new OvershootInterpolator(1.6f)).start();
                                break;
                        }
                        return false;
                    }
                });
            } catch (Exception ignored) {}
        }

        private void setEpBg(View card, boolean pressed) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dpToPx(14));
            if (pressed) {
                bg.setColor(0xFF212140);
                bg.setStroke(dpToPx(1), C_VIOLET);
            } else {
                bg.setColor(C_CARD);
                bg.setStroke(dpToPx(1), C_BORDER);
            }
            card.setBackground(bg);
        }

        class SimpleVH extends RecyclerView.ViewHolder {
            SimpleVH(View v) { super(v); }
        }

        class EpisodeVH extends RecyclerView.ViewHolder {
            LinearLayout card;
            TextView numTv, titleTv, metaTv;
            EpisodeVH(View root, LinearLayout c, TextView num, TextView title, TextView meta) {
                super(root);
                card = c; numTv = num; titleTv = title; metaTv = meta;
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // SEASON ADAPTER
    // ════════════════════════════════════════════════════════════════

    private class SeasonAdapter extends RecyclerView.Adapter<SeasonAdapter.ChipVH> {
        private int count       = 0;
        private int activeIndex = 0;
        private java.util.List<AniListClient.AniSeason> aniList = new java.util.ArrayList<>();

        SeasonAdapter() { setHasStableIds(true); }

        void setCount(int c) { aniList.clear(); count = c; notifyDataSetChanged(); }
        void setAniSeasons(java.util.List<AniListClient.AniSeason> seasons) {
            aniList = seasons; count = seasons.size(); notifyDataSetChanged();
        }
        void setActive(int i) {
            int prev = activeIndex; activeIndex = i;
            if (prev >= 0 && prev < count) notifyItemChanged(prev);
            if (i >= 0 && i < count)       notifyItemChanged(i);
        }
        private String getSeasonLabel(int pos) {
            if (!aniList.isEmpty() && pos < aniList.size()) {
                AniListClient.AniSeason s = aniList.get(pos);
                if (s.year > 0) return "الجزء " + (pos+1) + " (" + s.year + ")";
                return "الجزء " + (pos + 1);
            }
            return "الموسم " + (pos + 1);
        }

        @Override public long getItemId(int pos) { return pos; }
        @Override public int  getItemCount()      { return count; }

        @Override
        public ChipVH onCreateViewHolder(ViewGroup parent, int viewType) {
            TextView chip = new TextView(EpisodesActivity.this);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.WRAP_CONTENT, RecyclerView.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dpToPx(5), 0, dpToPx(5), 0);
            chip.setLayoutParams(lp);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dpToPx(22), dpToPx(10), dpToPx(22), dpToPx(10));
            chip.setClickable(true);
            chip.setFocusable(true);
            chip.setOnTouchListener(new View.OnTouchListener() {
                @Override public boolean onTouch(View v, MotionEvent ev) {
                    switch (ev.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            v.animate().scaleX(0.92f).scaleY(0.92f)
                                .setDuration(80).setInterpolator(new DecelerateInterpolator()).start(); break;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            v.animate().scaleX(1f).scaleY(1f)
                                .setDuration(220).setInterpolator(new OvershootInterpolator(2f)).start(); break;
                    }
                    return false;
                }
            });
            return new ChipVH(chip);
        }

        @Override
        public void onBindViewHolder(ChipVH holder, int pos) {
            boolean active = (pos == activeIndex);
            holder.chip.setText(getSeasonLabel(pos));
            styleChip(holder.chip, active);
            holder.chip.setOnClickListener(v -> {
                int idx = holder.getAdapterPosition();
                if (idx < 0 || idx == activeIndex) return;
                setActive(idx);
                switchSeason(idx); // نمرر index مباشرة
            });
        }

        private void styleChip(TextView chip, boolean active) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dpToPx(24));
            if (active) {
                bg.setColors(new int[]{ 0xFFB080D8, C_VIOLET2 });
                bg.setOrientation(GradientDrawable.Orientation.TL_BR);
                chip.setTextColor(C_TEXT);
                chip.setTypeface(Typeface.DEFAULT_BOLD);
                chip.setTextSize(13.5f);
            } else {
                bg.setColor(0xFF12122A);
                bg.setStroke(dpToPx(1), 0xFF282848);
                chip.setTextColor(0xFF7070A0);
                chip.setTypeface(Typeface.DEFAULT);
                chip.setTextSize(12.5f);
            }
            chip.setBackground(bg);
        }

        class ChipVH extends RecyclerView.ViewHolder {
            TextView chip;
            ChipVH(TextView tv) { super(tv); chip = tv; }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // SEASONS + EPISODES LOADING
    // ════════════════════════════════════════════════════════════════

    // ════════════════════════════════════════════════════════════════
    // قائمة مواسم AniList (مُعبأة عند الأنمي)
    // ════════════════════════════════════════════════════════════════
    private java.util.List<AniListClient.AniSeason> aniSeasons = new java.util.ArrayList<>();

    // ── CinemaBox path (ون بيس فقط) ──────────────────────────────
    private int              cbShowId    = -1;
    private java.util.List<Integer> cbSeasonIds = new java.util.ArrayList<>();

    private void loadSeasonsCount() {
        // P7: TMDB is the season/episode metadata authority for EVERYTHING,
        // anime included. MovieBox supplies anime playback; CinemaBox is never
        // consulted for anime.
        int ts = item.optInt("number_of_seasons", 0);
        if (ts > 0) showSeasonsUI(ts);
        else        new SeasonCountTask().execute();
    }

    private void showSeasonsUI(int ts) {
        totalSeasons = ts;
        if (ts <= 0) return;
        if (seasonAdapter != null) {
            seasonAdapter.setCount(ts);
            seasonAdapter.setActive(0);
        }
        loadEpisodes(1);
    }

    // NOTE: Currently unused — CinemaBoxSeasonsTask is the active anime path.
    // Retained for potential AniList fallback use.
    private void showAniSeasons(java.util.List<AniListClient.AniSeason> seasons) {
        aniSeasons = seasons;
        totalSeasons = seasons.size();
        if (totalSeasons <= 0) {
            if (episodesLoading != null) episodesLoading.setVisibility(View.GONE);
            return;
        }
        if (seasonAdapter != null) {
            seasonAdapter.setAniSeasons(seasons);
            seasonAdapter.setActive(0);
        }
        loadAniEpisodes(0); // الموسم الأول
    }

    private void switchSeason(int seasonIndex) {
        masterAdapter.clearEpisodes();
        // P7: anime seasons/episodes come from TMDB like any other series.
        loadEpisodes(seasonIndex + 1);
    }

    private void loadEpisodes(int season) {
        currentSeason = season; // ✅ لازم يُحدَّث وإلا openPlayer يرسل موسم خاطئ
        if (episodesLoading != null) episodesLoading.setVisibility(View.VISIBLE);
        if (episodesCountBadge != null) episodesCountBadge.setVisibility(View.GONE);
        new EpisodesTask(season).execute();
    }

    // NOTE: Currently unused — CinemaBoxSeasonsTask is the active anime path.
    // Retained for potential AniList fallback use.
    private void loadAniEpisodes(int seasonIndex) {
        if (seasonIndex < 0 || seasonIndex >= aniSeasons.size()) return;
        AniListClient.AniSeason s = aniSeasons.get(seasonIndex);
        currentSeason = seasonIndex + 1;

        if (episodesLoading != null) episodesLoading.setVisibility(View.GONE);

        int epCount = s.episodes > 0 ? s.episodes : 12; // افتراضي 12 إذا غير معروف
        java.util.List<JSONObject> epList = new java.util.ArrayList<>();
        for (int i = 1; i <= epCount; i++) {
            try {
                JSONObject ep = new JSONObject();
                ep.put("episode_number", i);
                ep.put("season_number",  currentSeason);
                ep.put("name",           "الحلقة " + i);
                ep.put("air_date",       ""); // AniList لا يوفر تواريخ حلقات مجانية
                epList.add(ep);
            } catch (Exception ignored) {}
        }

        if (episodesCountBadge != null) {
            episodesCountBadge.setText(epCount + " حلقة");
            episodesCountBadge.setVisibility(View.VISIBLE);
        }

        masterAdapter.setAllEpisodes(epList);
    }

    // ════════════════════════════════════════════════════════════════
    //  Pre-fetch
    // ════════════════════════════════════════════════════════════════

    // Bug 5 FIX: fetch English title on a background thread before prefetching,
    // so the cache key always uses the English name — matching openPlayer's key.
    private void startShowPrefetch() {
        // P7: anime never touches CinemaBox — no CinemaBox prefetch either.
        if ("anime".equals(mediaType)) return;
        // P5: prefetch only the provider the user will actually play from.
        if (selectedSource == com.eve.cinema.playback.SourceChoice.SOURCE_MOVIEBOX) return;
        final String title     = item.optString("name", item.optString("title", ""));
        final String origTitle = item.optString("original_name",
                                     item.optString("original_title", null));
        final int    year      = extractYear(item.optString("first_air_date",
                                     item.optString("release_date", "")));

        new Thread(new Runnable() {
            @Override public void run() {
                String prefetchTitle = title;
                // If title is non-Latin (e.g. Arabic), fetch English name from TMDB
                if (isNonLatin(prefetchTitle)) {
                    try {
                        JSONObject en = fetchJson(
                            "https://api.themoviedb.org/3/tv/" + tmdbId + "?language=en-US");
                        String enName = en != null ? en.optString("name", "").trim() : "";
                        if (!enName.isEmpty() && !isNonLatin(enName)) {
                            prefetchTitle = enName;
                        } else if (!enName.isEmpty()) {
                            // Try stripping subtitle after ":"
                            int c = enName.indexOf(':');
                            if (c > 2) {
                                String base = enName.substring(0, c).trim();
                                if (!isNonLatin(base)) prefetchTitle = base;
                            }
                        }
                    } catch (Exception ignored) {}
                }
                CinemaBoxCache.get().prefetchEpisode(prefetchTitle, origTitle, year, 1, 1);
            }
        }).start();
    }

    private void prefetchAdjacentEpisodes(final String title, final String origTitle,
                                           final int year, final int season,
                                           final int tappedEp, final int totalEps) {
        if (tappedEp < totalEps)
            CinemaBoxCache.get().prefetchEpisode(title, origTitle, year, season, tappedEp + 1);
        if (tappedEp + 1 < totalEps)
            CinemaBoxCache.get().prefetchEpisode(title, origTitle, year, season, tappedEp + 2);
    }

    // ════════════════════════════════════════════════════════════════
    //  ✅ openPlayer — يجيب episodeId الحقيقي ثم يمرره للـ Player
    //  Bug 3 FIX: resolves next_episode_id and passes it in the Intent.
    //  Bug 4 FIX: fetches English title from TMDB when showTitle is non-Latin.
    //  Bug 7 FIX: uses getTotalCount() instead of displayed.size().
    // ════════════════════════════════════════════════════════════════

    private void openPlayer(final int season, final int episode) {
        final String initialShowTitle = item.optString("name", item.optString("title", ""));
        final String origTitle        = item.optString("original_name",
                                            item.optString("original_title", null));
        final int    showYear         = extractYear(item.optString("first_air_date",
                                            item.optString("release_date", "")));
        // Bug 7 FIX: use getTotalCount() to get the real total, not just the displayed page
        final int    totalEps         = masterAdapter != null ? masterAdapter.getTotalCount() : 999;
        final boolean anime           = "anime".equals(mediaType);

        showResolveOverlay("جارٍ التحضير...");
        // Kick off a quick prefetch with the initial (possibly non-Latin) title;
        // the corrected English prefetch happens inside the background thread below.
        // CinemaBox prefetch only when the user explicitly picked مصدر 2 —
        // an undecided probe must not warm a provider that may not be used.
        if (!anime && selectedSource == com.eve.cinema.playback.SourceChoice.SOURCE_CINEMABOX)
            prefetchAdjacentEpisodes(initialShowTitle, origTitle, showYear, season, episode, totalEps);

        new Thread(new Runnable() {
            @Override public void run() {
                // Bug 4 FIX: if showTitle is non-Latin (Arabic/Japanese),
                // fetch the English name from TMDB before searching providers.
                String showTitle = initialShowTitle;
                if (isNonLatin(showTitle)) {
                    try {
                        JSONObject en = fetchJson(
                            "https://api.themoviedb.org/3/tv/" + tmdbId + "?language=en-US");
                        String enName = en != null ? en.optString("name", "").trim() : "";
                        if (!enName.isEmpty() && !isNonLatin(enName)) {
                            showTitle = enName;
                        } else if (!enName.isEmpty()) {
                            // Second attempt: strip subtitle after ":"
                            int c = enName.indexOf(':');
                            if (c > 2) {
                                String base = enName.substring(0, c).trim();
                                if (!isNonLatin(base)) showTitle = base;
                            }
                        }
                    } catch (Exception ignored) {}
                }

                final String finalShowTitle = showTitle;
                final int gen = ++chooserGeneration;

                // P5/P7: anime is MovieBox-only; otherwise the details-page
                // choice governs. With no choice (direct entry / probe not
                // finished), recover the verified decision here.
                int source;
                if (anime) {
                    source = com.eve.cinema.playback.SourceChoice.SOURCE_MOVIEBOX;
                } else if (selectedSource != 0) {
                    source = selectedSource;
                } else {
                    com.eve.cinema.playback.SourceChoice.Decision d = probeSeriesSources(
                            finalShowTitle, origTitle, showYear);
                    if (d.noSource) {
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (isFinishing() || gen != chooserGeneration) return;
                                hideResolveOverlay();
                                showResolveError("لا يوجد مصدر موثوق لهذا العنوان",
                                        season, episode);
                            }
                        });
                        return;
                    }
                    source = d.selected;
                }

                if (source == com.eve.cinema.playback.SourceChoice.SOURCE_MOVIEBOX) {
                    // P7: anime lands here ALWAYS; CinemaBox is never consulted.
                    resolveEpisodeViaMovieBox(finalShowTitle, origTitle, showYear,
                            season, episode, gen);
                } else {
                    resolveEpisodeViaCinemaBox(finalShowTitle, origTitle, showYear,
                            season, episode, gen);
                }
            }
        }).start();
    }

    /**
     * Verified availability probe for series when the details-page decision is
     * missing (direct entry / probe not finished): MovieBox title/type/year
     * match + CinemaBox strict probe, cached by TMDB identity. Background only.
     */
    private com.eve.cinema.playback.SourceChoice.Decision probeSeriesSources(
            String title, String origTitle, int year) {
        String key = tmdbId + "|" + mediaType;
        com.eve.cinema.playback.SourceChoice.Decision cached =
                com.eve.cinema.playback.SourceDecisionCache.get(key);
        if (cached != null) return cached;
        final boolean anime = "anime".equals(mediaType);
        boolean mb = false, cb = false;
        com.eve.cinema.playback.ProbeOutcome mbOutcome =
                com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT;
        com.eve.cinema.playback.ProbeOutcome cbOutcome = null;
        try {
            com.eve.cinema.moviebox.MovieBoxBridge.SubjectProbe sp =
                    com.eve.cinema.moviebox.MovieBoxBridge.get(EpisodesActivity.this)
                            .matchSubjectOutcome(title, origTitle, year, true);
            mbOutcome = sp.outcome;
            mb = sp.outcome == com.eve.cinema.playback.ProbeOutcome.VERIFIED;
        } catch (Exception ignored) {}
        if (!anime) {
            try {
                cbOutcome = CinemaBoxBridge.probeAvailabilityOutcome(title, origTitle, year,
                        "SERIES");
                cb = cbOutcome == com.eve.cinema.playback.ProbeOutcome.VERIFIED;
            } catch (Exception e) {
                cbOutcome = com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT;
            }
        }
        boolean anyTransient = mbOutcome == com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT
                || cbOutcome == com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT;
        com.eve.cinema.playback.ProbeOutcome combined = anyTransient
                ? com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT
                : (mb || cb) ? com.eve.cinema.playback.ProbeOutcome.VERIFIED
                : com.eve.cinema.playback.ProbeOutcome.NOT_FOUND_DEFINITIVE;
        // WP2: a transient failure is never cached as a definitive negative.
        // Anime is MovieBox-only: the real flag is passed (defence in depth —
        // the caller branch already guarantees MovieBox for anime).
        com.eve.cinema.playback.SourceChoice.Decision d =
                com.eve.cinema.playback.SourceChoice.compute(mb, cb, anime);
        if (combined.isResolved())
            com.eve.cinema.playback.SourceDecisionCache.put(key, d, combined);
        com.eve.cinema.playback.ResolutionTrace.record("probe.episodes", combined.name(),
                "mb=" + mbOutcome + " cb=" + (anime ? "anime-skip" : String.valueOf(cbOutcome)));
        return d;
    }

    /** Source 1 — MovieBox (the ONLY anime path): resolve, chooser, launch. */
    private void resolveEpisodeViaMovieBox(final String showTitle, final String origTitle,
                                           final int showYear, final int season,
                                           final int episode, final int gen) {
        try {
            // TMDB↔MovieBox mapping needs TMDB's per-season episode counts.
            ensureSeasonCounts(season);
            final com.eve.cinema.moviebox.MovieBoxModels.Playback playback =
                com.eve.cinema.moviebox.MovieBoxBridge
                    .get(EpisodesActivity.this)
                    .resolveEpisode(showTitle, origTitle, showYear,
                                    season, episode, snapshotSeasonCounts());
            final com.eve.cinema.playback.ModeResolver.Availability a =
                    ModeEvidence.forMovieBox(
                            com.eve.cinema.moviebox.MovieBoxBridge.get(EpisodesActivity.this),
                            playback);
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (isFinishing() || gen != chooserGeneration) return;
                    hideResolveOverlay();
                    offerModesAndLaunch(a, mode ->
                            launchMovieBoxWithMode(playback, a, mode, showTitle,
                                    season, episode, gen));
                }
            });
        } catch (final Exception mbError) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (isFinishing() || gen != chooserGeneration) return;
                    hideResolveOverlay();
                    showResolveError(userMessage(mbError), season, episode);
                }
            });
        }
    }

    /** Source 2 — CinemaBox: the classic flow, then the pre-player chooser. */
    private void resolveEpisodeViaCinemaBox(final String finalShowTitle, final String origTitle,
                                            final int showYear, final int season,
                                            final int episode, final int gen) {
        try {
            CinemaBoxBridge.ResolveResult result =
                CinemaBoxCache.get().getEpisode(finalShowTitle, origTitle,
                                                 showYear, season, episode);

            // ✅ التحقق من صحة النتيجة
            if (result == null || result.episodeId <= 0) {
                throw new Exception("لم يُعثر على رابط بث لهذه الحلقة");
            }

            final int finalEpisodeId = result.episodeId;
            final int finalShowId    = result.showId;
            final com.eve.cinema.playback.ModeResolver.Availability a =
                    ModeEvidence.forCinemaBox(result.mediaResult);

            // Bug 3 FIX: Prefetch episode+1 early using the corrected
            // English title so the cache key will match later lookups.
            CinemaBoxCache.get().prefetchEpisode(
                finalShowTitle, origTitle, showYear, season, episode + 1);

            // Bug 3 FIX: Try to resolve next episode ID within 3 seconds.
            // Wrap getEpisode in a new Future so we can time-box the wait.
            final int[] nextIdHolder = {-1};
            ExecutorService nextExec = Executors.newSingleThreadExecutor();
            Future<CinemaBoxBridge.ResolveResult> nextFuture =
                nextExec.submit(new Callable<CinemaBoxBridge.ResolveResult>() {
                    @Override
                    public CinemaBoxBridge.ResolveResult call() throws Exception {
                        return CinemaBoxCache.get().getEpisode(
                            finalShowTitle, origTitle, showYear,
                            season, episode + 1);
                    }
                });
            try {
                CinemaBoxBridge.ResolveResult nextResult =
                    nextFuture.get(3, TimeUnit.SECONDS);
                if (nextResult != null && nextResult.episodeId > 0)
                    nextIdHolder[0] = nextResult.episodeId;
            } catch (Exception ignored) {
                nextFuture.cancel(false);
            }
            nextExec.shutdown();

            final int nextEpisodeId = nextIdHolder[0];

            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (isFinishing() || gen != chooserGeneration) return;
                    hideResolveOverlay();
                    // ✅ يمرر episode_id الحقيقي + next_episode_id إن وُجد
                    offerModesAndLaunch(a, mode ->
                            launchPlayer(finalEpisodeId, finalShowId,
                                         finalShowTitle, season, episode,
                                         nextEpisodeId, mode));
                }
            });

        } catch (final Exception e) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (isFinishing() || gen != chooserGeneration) return;
                    hideResolveOverlay();
                    showResolveError(userMessage(e), season, episode);
                }
            });
        }
    }

    private static String userMessage(Exception e) {
        if (e instanceof com.eve.cinema.moviebox.MovieBoxException)
            return ((com.eve.cinema.moviebox.MovieBoxException) e).userMessage();
        String m = e.getMessage();
        return m != null ? m : "خطأ غير معروف";
    }

    // ── P4: pre-player mode chooser (portrait, before PlayerActivity) ──

    private interface ModeLaunch {
        void launch(com.eve.cinema.playback.PlaybackMode mode);
    }

    /**
     * Shows distinct Arabic dub, in-video-subtitle, and external-subtitle choices while the
     * episodes screen is still portrait. With no Arabic mode the verified
     * English fallback (or honest original) is applied automatically — the
     * player announces it. Cancelling the sheet cancels the launch.
     */
    private void offerModesAndLaunch(com.eve.cinema.playback.ModeResolver.Availability a,
                                     ModeLaunch launch) {
        final int gen = chooserGeneration;
        final java.util.List<com.eve.cinema.playback.PlaybackMode> options =
                com.eve.cinema.playback.ModeResolver.chooserOptions(a);
        if (options.isEmpty()) {
            launch.launch(com.eve.cinema.playback.ModeResolver.automaticMode(a));
            return;
        }
        java.util.List<GlassChoiceSheet.Row> rows = new java.util.ArrayList<>();
        for (com.eve.cinema.playback.PlaybackMode m : options) {
            String label = m == com.eve.cinema.playback.PlaybackMode.ARABIC_DUB
                    ? getString(R.string.player_mode_ar_dub)
                    : m == com.eve.cinema.playback.PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE
                    ? getString(R.string.player_mode_ar_video_subtitle)
                    : getString(R.string.player_mode_ar_sub);
            String description = m == com.eve.cinema.playback.PlaybackMode.ARABIC_DUB
                    ? "يغيّر مسار الصوت إلى دبلجة عربية متحققة"
                    : m == com.eve.cinema.playback.PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE
                    ? "يشغّل إصدار فيديو مصنّفًا كمترجم؛ قد لا يمكن تغيير حجم النص المضمّن"
                    : "ملف مستقل يمكن تكبيره وتصغيره وضبط إزاحته؛ تزامنه غير مثبت تلقائيًا";
            rows.add(new GlassChoiceSheet.Row(label, description, true, false));
        }
        new GlassChoiceSheet(this, "اختر طريقة المشاهدة", rows, idx -> {
            if (isFinishing() || gen != chooserGeneration) return;
            if (idx < 0 || idx >= options.size()) return;
            launch.launch(options.get(idx));
        }).show();
    }

    /**
     * G: an Arabic dub backed by a separate dub RELEASE is resolved to that
     * release before the player opens; a manifest-verified Arabic track plays
     * the same payload with the mode applied.
     */
    private void launchMovieBoxWithMode(
            final com.eve.cinema.moviebox.MovieBoxModels.Playback base,
            final com.eve.cinema.playback.ModeResolver.Availability a,
            final com.eve.cinema.playback.PlaybackMode mode,
            final String title, final int season, final int episode, final int gen) {
        if (mode == com.eve.cinema.playback.PlaybackMode.ARABIC_DUB
                && a.arabicDubFromRelease && !a.arabicDubFromManifest) {
            final com.eve.cinema.moviebox.MovieBoxModels.DubOption dub = base.arabicDub();
            if (dub != null) {
                showResolveOverlay("جارٍ تجهيز الدبلجة...");
                new Thread(new Runnable() {
                    @Override public void run() {
                        try {
                            final com.eve.cinema.moviebox.MovieBoxModels.Playback dubbed =
                                    com.eve.cinema.moviebox.MovieBoxBridge
                                            .get(EpisodesActivity.this)
                                            .resolveDubRelease(base, dub,
                                                    com.eve.cinema.playback.LanguageMatcher.AR);
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    if (isFinishing() || gen != chooserGeneration) return;
                                    hideResolveOverlay();
                                    launchMovieBoxPlayer(dubbed, title, season, episode,
                                            com.eve.cinema.playback.PlaybackMode.ARABIC_DUB);
                                }
                            });
                        } catch (final Exception e) {
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    if (isFinishing() || gen != chooserGeneration) return;
                                    hideResolveOverlay();
                                    showResolveError("تعذّرت الدبلجة العربية — جرّب الترجمة",
                                            season, episode);
                                }
                            });
                        }
                    }
                }).start();
                return;
            }
        }
        if (mode == com.eve.cinema.playback.PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE) {
            if (base.inVideoSubtitleRelease) {
                launchMovieBoxPlayer(base, title, season, episode, mode);
                return;
            }
            final com.eve.cinema.moviebox.MovieBoxModels.DubOption release =
                    base.arabicSubtitleRelease();
            if (release == null || !a.arabicInVideoSubtitleFromRelease) {
                showResolveError("تعذّر التحقق من نسخة الترجمة داخل الفيديو — جرّب الترجمة الخارجية",
                        season, episode);
                return;
            }
            showResolveOverlay("جارٍ تجهيز نسخة الترجمة داخل الفيديو...");
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        final com.eve.cinema.moviebox.MovieBoxModels.Playback translated =
                                com.eve.cinema.moviebox.MovieBoxBridge
                                        .get(EpisodesActivity.this)
                                        .resolveArabicSubtitleRelease(base, release);
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (isFinishing() || gen != chooserGeneration) return;
                                hideResolveOverlay();
                                launchMovieBoxPlayer(translated, title, season, episode,
                                        com.eve.cinema.playback.PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE);
                            }
                        });
                    } catch (final Exception e) {
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (isFinishing() || gen != chooserGeneration) return;
                                hideResolveOverlay();
                                showResolveError("تعذّر تشغيل نسخة الترجمة داخل الفيديو — جرّب الترجمة الخارجية",
                                        season, episode);
                            }
                        });
                    }
                }
            }).start();
            return;
        }
        launchMovieBoxPlayer(base, title, season, episode, mode);
    }

    /** TMDB episode_count per season_number (filled by SeasonCountTask) for anime mapping. */
    private final java.util.Map<Integer, Integer> tmdbSeasonCounts =
            java.util.Collections.synchronizedMap(new java.util.HashMap<Integer, Integer>());

    private java.util.Map<Integer, Integer> snapshotSeasonCounts() {
        synchronized (tmdbSeasonCounts) {
            return new java.util.HashMap<Integer, Integer>(tmdbSeasonCounts);
        }
    }

    /**
     * The counts normally come from SeasonCountTask, but loadSeasonsCount() skips that
     * task when the item already carries number_of_seasons — leaving the map empty and
     * making "TMDB S2 = provider episode N" unresolvable. Fetch the missing seasons once
     * (worker thread) before resolving. A failed fetch leaves the map as it was: the
     * mapper then reports an honest ambiguity instead of guessing.
     */
    private void ensureSeasonCounts(int season) {
        boolean complete = true;
        synchronized (tmdbSeasonCounts) {
            for (int sn = 1; sn <= Math.max(season, 1); sn++) { // earlier seasons + this one (next-episode boundary)
                Integer c = tmdbSeasonCounts.get(sn);
                if (c == null || c <= 0) { complete = false; break; }
            }
        }
        if (complete || tmdbId == null || tmdbId.isEmpty() || "0".equals(tmdbId)) return;
        try {
            JSONObject d = fetchJson("https://api.themoviedb.org/3/tv/" + tmdbId + "?language=en-US");
            org.json.JSONArray ss = d != null ? d.optJSONArray("seasons") : null;
            if (ss == null) return;
            synchronized (tmdbSeasonCounts) {
                for (int i = 0; i < ss.length(); i++) {
                    JSONObject so = ss.optJSONObject(i);
                    if (so == null) continue;
                    int n = so.optInt("season_number", -1);
                    int c = so.optInt("episode_count", 0);
                    if (n >= 0 && c > 0) tmdbSeasonCounts.put(n, c);
                }
            }
        } catch (Exception ignored) {}
    }

    private void putSourceExtras(Intent intent, String searchTitle) {
        intent.putExtra("search_title", searchTitle);
        intent.putExtra("original_title", item.optString("original_name", item.optString("original_title", null)));
        intent.putExtra("year", extractYear(item.optString("first_air_date", item.optString("release_date", ""))));
        org.json.JSONObject counts = new org.json.JSONObject();
        synchronized (tmdbSeasonCounts) {
            for (java.util.Map.Entry<Integer, Integer> e : tmdbSeasonCounts.entrySet()) {
                try { counts.put(String.valueOf(e.getKey()), e.getValue()); } catch (Exception ignored) {}
            }
        }
        intent.putExtra("tmdb_season_counts", counts.toString());
    }

    /** Launches the player with a fully-resolved MovieBox playback payload. */
    private void launchMovieBoxPlayer(com.eve.cinema.moviebox.MovieBoxModels.Playback playback,
                                      String title, int season, int episode,
                                      com.eve.cinema.playback.PlaybackMode mode) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("moviebox_payload", playback.toJson().toString());
        intent.putExtra("tmdb_id",       tmdbId);
        intent.putExtra("media_type",    mediaType);
        intent.putExtra("title",         playback.title != null && !playback.title.isEmpty()
                                         ? playback.title : title);
        intent.putExtra("season",        season);
        intent.putExtra("episode",       episode);
        if (mode != null) intent.putExtra("requested_mode", mode.name());
        putSourceExtras(intent, title);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    // Bug 3 FIX: launchPlayer now accepts nextEpisodeId and puts it in the
    // Intent so PlayerActivity's onVideoEnded() and nextEpisodeCard work.
    private void launchPlayer(int episodeId, int showId,
                               String title, int season, int episode,
                               int nextEpisodeId,
                               com.eve.cinema.playback.PlaybackMode mode) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("episode_id",    episodeId);   // ✅ episode ID الحقيقي
        intent.putExtra("cinema_box_id", episodeId);   // توافق
        intent.putExtra("cb_show_id",    showId);
        intent.putExtra("tmdb_id",       tmdbId);
        intent.putExtra("media_type",    mediaType);
        intent.putExtra("title",         title);
        intent.putExtra("season",        season);
        intent.putExtra("episode",       episode);
        // Bug 3 FIX: only add next_episode_id when it was successfully resolved
        if (nextEpisodeId > 0)
            intent.putExtra("next_episode_id", nextEpisodeId);
        if (mode != null) intent.putExtra("requested_mode", mode.name());
        putSourceExtras(intent, title);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    private void showResolveOverlay(String msg) {
        if (resolveOverlay != null) {
            resolveOverlay.setVisibility(View.VISIBLE);
            if (resolveMsgTv != null) resolveMsgTv.setText(msg);
            return;
        }
        FrameLayout root = (FrameLayout) masterRv.getParent();
        resolveOverlay = new FrameLayout(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        resolveOverlay.setLayoutParams(lp);
        resolveOverlay.setBackgroundColor(0xCC08080F);
        resolveOverlay.setClickable(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams colLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        colLp.gravity = Gravity.CENTER;
        col.setLayoutParams(colLp);

        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminate(true);
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(dpToPx(40), dpToPx(40));
        pb.setLayoutParams(pbLp);
        col.addView(pb);

        resolveMsgTv = new TextView(this);
        resolveMsgTv.setText(msg);
        resolveMsgTv.setTextColor(0xFFC4A0E8);
        resolveMsgTv.setTextSize(13f);
        LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tvLp.topMargin = dpToPx(12);
        resolveMsgTv.setLayoutParams(tvLp);
        col.addView(resolveMsgTv);

        resolveOverlay.addView(col);
        if (root != null) root.addView(resolveOverlay);
    }

    private void hideResolveOverlay() {
        if (resolveOverlay != null)
            resolveOverlay.setVisibility(View.GONE);
    }

    private void showResolveError(String msg, int season, int episode) {
        if (resolveMsgTv != null) {
            resolveMsgTv.setText(msg);
            resolveMsgTv.setTextColor(0xFFFF6B6B);
        }
        if (resolveOverlay != null) resolveOverlay.setVisibility(View.VISIBLE);
        masterRv.postDelayed(new Runnable() {
            @Override public void run() { hideResolveOverlay(); }
        }, 3000);
    }

    // Bug 15 FIX: guard against non-numeric strings like "N/A" or "TBA"
    // that would cause parseInt to throw with the old implementation.
    private int extractYear(String dateStr) {
        if (dateStr == null || dateStr.length() < 4) return 0;
        String y = dateStr.substring(0, 4);
        try {
            int val = Integer.parseInt(y);
            return (val >= 1900 && val <= 2100) ? val : 0;
        } catch (Exception e) { return 0; }
    }

    /** "2024-03-12" → "12 مارس 2024" (نفس صيغة شاشة الممثل) */
    private String formatAirDate(String raw) {
        String[] parts = raw.split("-");
        if (parts.length == 3) {
            String[] months = { "يناير","فبراير","مارس","أبريل","مايو","يونيو",
                                 "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر" };
            try {
                int m = Integer.parseInt(parts[1]) - 1;
                if (m >= 0 && m < 12)
                    return Integer.parseInt(parts[2]) + " " + months[m] + " " + parts[0];
            } catch (Exception ignored) {}
        }
        return raw;
    }

    // Bug 4 + Bug 8 FIX: isNonLatin as an outer-class method with the
    // correct 0x0100 threshold (Basic Latin + Latin-1 Supplement only).
    // Using 0x0370 (old inner-class value) wrongly counted Greek as Latin.
    private boolean isNonLatin(String s) {
        if (s == null || s.isEmpty()) return false;
        int latin = 0, total = 0;
        for (char ch : s.toCharArray()) {
            if (Character.isLetter(ch)) {
                total++;
                if (ch < 0x0100) latin++; // Basic Latin + Latin-1 Supplement only
            }
        }
        return total > 0 && (double) latin / total < 0.5;
    }

    // ════════════════════════════════════════════════════════════════
    // ASYNC TASKS
    // ════════════════════════════════════════════════════════════════

    // ════════════════════════════════════════════════════════════════
    // ASYNC TASKS
    // ════════════════════════════════════════════════════════════════

    // NOTE: Currently unused — CinemaBoxSeasonsTask is the active anime path.
    // Retained for potential AniList fallback use.
    private class AniListSeasonsTask
            extends AsyncTask<Void, Void, java.util.List<AniListClient.AniSeason>> {

        private final String primaryName;   // original_name (إنجليزي/روماجي)
        private final String fallbackName;  // name (قد يكون عربياً)

        AniListSeasonsTask(String primary, String fallback) {
            this.primaryName  = primary;
            this.fallbackName = fallback;
        }

        @Override
        protected java.util.List<AniListClient.AniSeason> doInBackground(Void... p) {
            // محاولة 1: بالاسم الأصلي (original_name) — الأدق لـ AniList
            if (primaryName != null && !primaryName.isEmpty()) {
                try {
                    java.util.List<AniListClient.AniSeason> result =
                        AniListClient.getSeasonsForAnime(primaryName);
                    if (result != null && !result.isEmpty()) return result;
                } catch (Exception ignored) {}
            }
            // محاولة 2: بالاسم المحلي كاحتياطي
            if (fallbackName != null && !fallbackName.isEmpty()) {
                try {
                    java.util.List<AniListClient.AniSeason> result =
                        AniListClient.getSeasonsForAnime(fallbackName);
                    if (result != null && !result.isEmpty()) return result;
                } catch (Exception ignored) {}
            }
            return new java.util.ArrayList<>();
        }

        @Override
        protected void onPostExecute(java.util.List<AniListClient.AniSeason> seasons) {
            if (seasons != null && !seasons.isEmpty()) {
                showAniSeasons(seasons);
            } else {
                // Fallback لـ TMDB فقط إذا فشلت كل محاولات AniList
                new SeasonCountTask().execute();
            }
        }
    }

    // ── CinemaBox: مواسم ون بيس ────────────────────────────────────
    // خطوة 1: جيب showId + seasonIds دفعة واحدة من CinemaBox
    private class CinemaBoxSeasonsTask
            extends AsyncTask<Void, Void, CinemaBoxBridge.SeriesInfo> {

        @Override
        protected CinemaBoxBridge.SeriesInfo doInBackground(Void... p) {
            try {
                int year = extractYear(item.optString("first_air_date",
                            item.optString("release_date", "")));

                // ══════════════════════════════════════════════════════
                // الاستراتيجية: اسم إنجليزي واحد واضح من TMDB
                // CinemaBox يحتفظ دائماً بالأسماء الإنجليزية
                // ══════════════════════════════════════════════════════

                // الخطوة ١: جيب الاسم الإنجليزي من TMDB مباشرة
                String enTitle = null;
                try {
                    JSONObject en = fetchJson(
                        "https://api.themoviedb.org/3/tv/" + tmdbId + "?language=en-US");
                    if (en != null) {
                        enTitle = en.optString("name", "").trim();
                        if (enTitle.isEmpty()) enTitle = null;
                    }
                } catch (Exception ignored) {}

                // الخطوة ٢: ابحث بالاسم الإنجليزي فقط — نتيجة واحدة دقيقة
                if (enTitle != null && !isNonLatin(enTitle)) {
                    CinemaBoxBridge.SeriesInfo r =
                        CinemaBoxBridge.getSeriesInfo(enTitle, null, year);
                    if (r != null) return r;

                    // جرب بدون subtitle (قبل ":") كـ plan B
                    int c = enTitle.indexOf(':');
                    if (c > 2) {
                        String base = enTitle.substring(0, c).trim();
                        r = CinemaBoxBridge.getSeriesInfo(base, null, year);
                        if (r != null) return r;
                    }
                }

                // الخطوة ٣: original_name إذا كان لاتيني (مش ياباني/عربي)
                String orig = item.optString("original_name",
                              item.optString("original_title", "")).trim();
                if (!orig.isEmpty() && !isNonLatin(orig)
                        && (enTitle == null || !orig.equals(enTitle))) {
                    CinemaBoxBridge.SeriesInfo r =
                        CinemaBoxBridge.getSeriesInfo(orig, null, year);
                    if (r != null) return r;
                }

                // لم يُعثر → showComingSoon
                return null;
            } catch (Exception e) { return null; }
        }

        // Bug 8 FIX: delegate to outer-class isNonLatin() which uses the
        // correct 0x0100 threshold (was 0x0370 here, wrongly including Greek).
        private boolean isNonLatin(String s) {
            return EpisodesActivity.this.isNonLatin(s);
        }

        @Override
        protected void onPostExecute(CinemaBoxBridge.SeriesInfo info) {
            if (info == null) {
                // الأنمي غير متوفر في CinemaBox بعد → "سيتوفر قريباً"
                showComingSoon();
                return;
            }
            cbShowId    = info.showId;
            cbSeasonIds = info.seasonIds;
            showCbSeasonsUI(info.seasonCount());
        }
    }

    // خطوة 2 (عند اختيار موسم): جيب عدد حلقات الموسم من CinemaBox
    private class CbEpisodeCountTask extends AsyncTask<Void, Void, Integer> {
        private final int seasonIndex;
        CbEpisodeCountTask(int i) { seasonIndex = i; }

        @Override
        protected Integer doInBackground(Void... p) {
            try {
                return CinemaBoxBridge.getSeasonEpisodeCount(
                        cbShowId, seasonIndex, cbSeasonIds);
            } catch (Exception e) { return 0; }
        }

        @Override
        protected void onPostExecute(Integer count) {
            if (episodesLoading != null) episodesLoading.setVisibility(View.GONE);

            int epCount = (count != null && count > 0) ? count : 12;

            java.util.List<JSONObject> epList = new java.util.ArrayList<>();
            for (int i = 1; i <= epCount; i++) {
                try {
                    JSONObject ep = new JSONObject();
                    ep.put("episode_number", i);
                    ep.put("season_number",  currentSeason);
                    ep.put("name",           "الحلقة " + i);
                    ep.put("air_date",       "");
                    epList.add(ep);
                } catch (Exception ignored) {}
            }

            if (episodesCountBadge != null) {
                episodesCountBadge.setText(epCount + " حلقة");
                episodesCountBadge.setVisibility(View.VISIBLE);
            }
            masterAdapter.setAllEpisodes(epList);
        }
    }

    // عرض chips المواسم من CinemaBox (ون بيس)
    private void showCbSeasonsUI(int count) {
        totalSeasons = count;
        if (count <= 0) {
            if (episodesLoading != null) episodesLoading.setVisibility(View.GONE);
            return;
        }
        if (seasonAdapter != null) {
            seasonAdapter.setCount(count);
            seasonAdapter.setActive(0);
        }
        loadCbEpisodes(0); // ابدأ بالموسم الأول
    }

    // تحميل حلقات موسم أنمي من CinemaBox
    private void loadCbEpisodes(int seasonIndex) {
        currentSeason = seasonIndex + 1;
        if (episodesLoading != null) episodesLoading.setVisibility(View.VISIBLE);
        if (episodesCountBadge != null) episodesCountBadge.setVisibility(View.GONE);
        new CbEpisodeCountTask(seasonIndex).execute();
    }

    // ══════════════════════════════════════════════════════════════
    // الأنمي غير متوفر في CinemaBox — رسالة "سيتوفر قريباً"
    // ══════════════════════════════════════════════════════════════
    private void showComingSoon() {
        if (episodesLoading   != null) episodesLoading.setVisibility(View.GONE);
        if (episodesCountBadge != null) {
            episodesCountBadge.setText("قريباً");
            episodesCountBadge.setVisibility(View.VISIBLE);
        }
        try {
            JSONObject cs = new JSONObject();
            cs.put("coming_soon",    true);
            cs.put("episode_number", -1);
            cs.put("name",           "سيتوفر هذا الأنمي قريباً");
            java.util.List<JSONObject> list = new java.util.ArrayList<>();
            list.add(cs);
            masterAdapter.setAllEpisodes(list);
        } catch (Exception ignored) {}
    }

    // ── TMDB: عدد مواسم مسلسل عادي ──────────────────────────────
    private class SeasonCountTask extends AsyncTask<Void, Void, Integer> {
        @Override
        protected Integer doInBackground(Void... p) {
            try {
                JSONObject d = fetchJson("https://api.themoviedb.org/3/tv/" + tmdbId + "?language=en-US");
                if (d != null) {
                    org.json.JSONArray ss = d.optJSONArray("seasons");
                    if (ss != null) {
                        for (int i = 0; i < ss.length(); i++) {
                            JSONObject so = ss.optJSONObject(i);
                            if (so != null) tmdbSeasonCounts.put(so.optInt("season_number", -1),
                                                                 so.optInt("episode_count", 0));
                        }
                    }
                    return d.optInt("number_of_seasons", 1);
                }
            } catch (Exception ignored) {}
            return 1;
        }
        @Override
        protected void onPostExecute(Integer count) { showSeasonsUI(count); }
    }

    // ── TMDB: حلقات موسم مسلسل عادي ─────────────────────────────
    private class EpisodesTask extends AsyncTask<Void, Void, JSONArray> {
        private final int season;
        EpisodesTask(int s) { season = s; }

        @Override
        protected JSONArray doInBackground(Void... p) {
            try {
                JSONObject data = fetchJson("https://api.themoviedb.org/3/tv/" + tmdbId +
                    "/season/" + season + "?language=en-US");
                return data != null ? data.optJSONArray("episodes") : null;
            } catch (Exception e) { return null; }
        }

        @Override
        protected void onPostExecute(JSONArray episodes) {
            if (episodesLoading != null) episodesLoading.setVisibility(View.GONE);
            if (episodes == null) return;

            // فلتر الحلقات غير المنشورة بعد
            String today = new java.text.SimpleDateFormat("yyyy-MM-dd",
                java.util.Locale.US).format(new java.util.Date());

            java.util.List<JSONObject> epList = new java.util.ArrayList<>();
            for (int i = 0; i < episodes.length(); i++) {
                try {
                    JSONObject ep      = episodes.getJSONObject(i);
                    String     airDate = ep.optString("air_date", "");
                    if (!airDate.isEmpty() && airDate.compareTo(today) <= 0) {
                        epList.add(ep);
                    }
                } catch (Exception ignored) {}
            }

            int count = epList.size();
            if (episodesCountBadge != null) {
                episodesCountBadge.setText(count + " حلقة");
                episodesCountBadge.setVisibility(View.VISIBLE);
            }

            masterAdapter.setAllEpisodes(epList);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // VISUAL EFFECTS
    // ════════════════════════════════════════════════════════════════

    private void applyParallax(RecyclerView rv) {
        if (heroBackdrop == null) return;
        LinearLayoutManager lm = (LinearLayoutManager) rv.getLayoutManager();
        if (lm == null) return;
        View first = lm.findViewByPosition(0);
        if (first == null) return;
        heroBackdrop.setTranslationY(-first.getTop() * 0.35f);
    }

    // ════════════════════════════════════════════════════════════════
    // NETWORK + UTIL
    // ════════════════════════════════════════════════════════════════

    private JSONObject fetchJson(String urlStr) throws Exception {
        JSONObject cached = TmdbCache.getJson(urlStr);
        if (cached != null) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, 200, 0, null, cached.toString(), null, true);
            return cached;
        }
        long diagnosticStart = android.os.SystemClock.elapsedRealtime();
        int diagnosticStatus = -1;
        String diagnosticBody = null;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestProperty("Authorization", "Bearer " + TMDB_TOKEN);
        DiagnosticsRecorder.headers("TMDB", "fetch_json", "GET", urlStr, conn.getRequestProperties());
            conn.setRequestProperty("accept", "application/json");
            diagnosticStatus = conn.getResponseCode();
            if (diagnosticStatus != 200) {
                DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                        android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, null, null, false);
                return null;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            diagnosticBody = sb.toString();
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, null, false);
            JSONObject obj = new JSONObject(diagnosticBody);
            TmdbCache.putJson(urlStr, obj);
            return obj;
        } catch (Exception e) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, e, false);
            throw e;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        MiuiBarFix.apply(this);
        EveFloatingButton.attach(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        EveFloatingButton.detach(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MiuiBarFix.release(this);
    }

}
