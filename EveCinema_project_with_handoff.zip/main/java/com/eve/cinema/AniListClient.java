package com.eve.cinema;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * AniListClient — عميل AniList GraphQL لإيف سينما
 * ══════════════════════════════════════════════════
 * يُستخدم حصراً للأنمي (media_type = "anime")
 * الصفحة الرئيسية / البحث ← TMDB (بوستر + اسم)
 * صفحة التفاصيل / المواسم ← AniList (مواسم + حلقات صحيحة)
 * ══════════════════════════════════════════════════
 */
public class AniListClient {

    private static final String ENDPOINT = "https://graphql.anilist.co";
    private static final int    TIMEOUT  = 12_000;

    // ── نماذج البيانات ──────────────────────────────────────────────

    public static class AniSeason {
        public int    anilistId;
        public String title;        // romaji
        public String titleEn;      // english
        public int    episodes;
        public int    year;
        public String season;       // WINTER / SPRING / SUMMER / FALL
        public String coverImage;
        public String status;       // FINISHED / RELEASING / NOT_YET_RELEASED
        public String description;
        public double rating;       // 0–10
        public String format;       // TV / MOVIE / OVA / ONA / SPECIAL
    }

    public static class AniSearchResult {
        public int    anilistId;
        public String title;
        public String titleEn;
        public String coverImage;
        public int    episodes;
        public int    year;
        public double rating;
        public String format;
        public String status;
    }

    // ══════════════════════════════════════════════════════════════
    // البحث عن أنمي بالاسم — يُرجع قائمة نتائج
    // ══════════════════════════════════════════════════════════════
    public static List<AniSearchResult> search(String query) throws Exception {
        String gql = "query($q:String){" +
            "Page(page:1,perPage:25){" +
            "media(search:$q,type:ANIME,sort:SEARCH_MATCH){" +
            "id title{romaji english}" +
            "coverImage{large}" +
            "episodes seasonYear format status" +
            "averageScore" +
            "}}}";

        JSONObject vars = new JSONObject();
        vars.put("q", query);

        JSONObject resp = postGraphQL(gql, vars);
        List<AniSearchResult> results = new ArrayList<>();
        if (resp == null) return results;

        JSONArray arr = resp
            .optJSONObject("data")
            .optJSONObject("Page")
            .optJSONArray("media");
        if (arr == null) return results;

        for (int i = 0; i < arr.length(); i++) {
            JSONObject m = arr.optJSONObject(i);
            if (m == null) continue;
            AniSearchResult r = new AniSearchResult();
            r.anilistId  = m.optInt("id");
            JSONObject t = m.optJSONObject("title");
            r.title      = t != null ? t.optString("romaji", "") : "";
            r.titleEn    = t != null ? t.optString("english", "") : "";
            JSONObject img = m.optJSONObject("coverImage");
            r.coverImage = img != null ? img.optString("large", "") : "";
            r.episodes   = m.optInt("episodes", 0);
            r.year       = m.optInt("seasonYear", 0);
            r.rating     = m.optDouble("averageScore", 0) / 10.0;
            r.format     = m.optString("format", "TV");
            r.status     = m.optString("status", "");
            results.add(r);
        }
        return results;
    }

    // ══════════════════════════════════════════════════════════════
    // جلب كل مواسم أنمي بالاسم — الجزء الرئيسي + المتعلقات (Sequels)
    // يُرجع قائمة مرتبة بالسنة: الموسم 1 → 2 → 3 ...
    // ══════════════════════════════════════════════════════════════
    public static List<AniSeason> getSeasonsForAnime(String animeName) throws Exception {
        // خطوة 1: جيب ID الأنمي الأول بالبحث
        String gql = "query($q:String){" +
            "Media(search:$q,type:ANIME,sort:SEARCH_MATCH){" +
            "id title{romaji english}" +
            "episodes seasonYear season status format" +
            "coverImage{large}" +
            "description averageScore" +
            "relations{edges{" +
            "relationType" +
            "node{" +
            "id title{romaji english}" +
            "episodes seasonYear season status format" +
            "coverImage{large}" +
            "description averageScore" +
            "}}}}}";

        JSONObject vars = new JSONObject();
        vars.put("q", animeName);

        JSONObject resp = postGraphQL(gql, vars);
        List<AniSeason> seasons = new ArrayList<>();
        if (resp == null) return seasons;

        JSONObject data = resp.optJSONObject("data");
        if (data == null) return seasons;
        JSONObject root = data.optJSONObject("Media");
        if (root == null) return seasons;

        // أضف الجزء الرئيسي
        AniSeason main = parseSeason(root);
        if (main != null) seasons.add(main);

        // أضف المتعلقات (Sequels فقط)
        JSONObject relations = root.optJSONObject("relations");
        if (relations != null) {
            JSONArray edges = relations.optJSONArray("edges");
            if (edges != null) {
                for (int i = 0; i < edges.length(); i++) {
                    JSONObject edge = edges.optJSONObject(i);
                    if (edge == null) continue;
                    String relType = edge.optString("relationType", "");
                    // نأخذ فقط SEQUEL و SIDE_STORY و ALTERNATIVE
                    if (!"SEQUEL".equals(relType) && !"PREQUEL".equals(relType)) continue;
                    JSONObject node = edge.optJSONObject("node");
                    if (node == null) continue;
                    String fmt = node.optString("format", "TV");
                    // نتجاهل OVA و MOVIE و SPECIAL — نريد TV فقط
                    if (!"TV".equals(fmt) && !"TV_SHORT".equals(fmt) && !"ONA".equals(fmt)) continue;
                    AniSeason s = parseSeason(node);
                    if (s != null) seasons.add(s);
                }
            }
        }

        // رتّب بالسنة
        seasons.sort((a, b) -> {
            if (a.year != b.year) return Integer.compare(a.year, b.year);
            return Integer.compare(a.anilistId, b.anilistId);
        });

        // رقّم المواسم
        return seasons;
    }

    // ══════════════════════════════════════════════════════════════
    // جلب أنمي بالـ AniList ID مباشرة (أسرع)
    // ══════════════════════════════════════════════════════════════
    public static List<AniSeason> getSeasonsById(int anilistId) throws Exception {
        String gql = "query($id:Int){" +
            "Media(id:$id,type:ANIME){" +
            "id title{romaji english}" +
            "episodes seasonYear season status format" +
            "coverImage{large}" +
            "description averageScore" +
            "relations{edges{" +
            "relationType" +
            "node{" +
            "id title{romaji english}" +
            "episodes seasonYear season status format" +
            "coverImage{large}" +
            "description averageScore" +
            "}}}}}";

        JSONObject vars = new JSONObject();
        vars.put("id", anilistId);

        JSONObject resp = postGraphQL(gql, vars);
        List<AniSeason> seasons = new ArrayList<>();
        if (resp == null) return seasons;

        JSONObject root = resp
            .optJSONObject("data")
            .optJSONObject("Media");
        if (root == null) return seasons;

        AniSeason main = parseSeason(root);
        if (main != null) seasons.add(main);

        JSONObject relations = root.optJSONObject("relations");
        if (relations != null) {
            JSONArray edges = relations.optJSONArray("edges");
            if (edges != null) {
                for (int i = 0; i < edges.length(); i++) {
                    JSONObject edge = edges.optJSONObject(i);
                    if (edge == null) continue;
                    String relType = edge.optString("relationType", "");
                    if (!"SEQUEL".equals(relType) && !"PREQUEL".equals(relType)) continue;
                    JSONObject node = edge.optJSONObject("node");
                    if (node == null) continue;
                    String fmt = node.optString("format", "TV");
                    if (!"TV".equals(fmt) && !"TV_SHORT".equals(fmt) && !"ONA".equals(fmt)) continue;
                    AniSeason s = parseSeason(node);
                    if (s != null) seasons.add(s);
                }
            }
        }

        seasons.sort((a, b) -> {
            if (a.year != b.year) return Integer.compare(a.year, b.year);
            return Integer.compare(a.anilistId, b.anilistId);
        });

        return seasons;
    }

    // ══════════════════════════════════════════════════════════════
    // جلب أنمي شائع (للصفحة الرئيسية — يُستخدم مع TMDB للبوستر فقط)
    // ══════════════════════════════════════════════════════════════
    public static List<AniSearchResult> getPopular(int page) throws Exception {
        String gql = "query($p:Int){" +
            "Page(page:$p,perPage:30){" +
            "media(type:ANIME,sort:POPULARITY_DESC,format_in:[TV,TV_SHORT,ONA]){" +
            "id title{romaji english}" +
            "coverImage{large}" +
            "episodes seasonYear format status averageScore" +
            "}}}";

        JSONObject vars = new JSONObject();
        vars.put("p", page);

        return parseSearchResults(postGraphQL(gql, vars));
    }

    public static List<AniSearchResult> getTrending(int page) throws Exception {
        String gql = "query($p:Int){" +
            "Page(page:$p,perPage:30){" +
            "media(type:ANIME,sort:TRENDING_DESC,format_in:[TV,TV_SHORT,ONA]){" +
            "id title{romaji english}" +
            "coverImage{large}" +
            "episodes seasonYear format status averageScore" +
            "}}}";

        JSONObject vars = new JSONObject();
        vars.put("p", page);

        return parseSearchResults(postGraphQL(gql, vars));
    }

    public static List<AniSearchResult> getTopRated(int page) throws Exception {
        String gql = "query($p:Int){" +
            "Page(page:$p,perPage:30){" +
            "media(type:ANIME,sort:SCORE_DESC,format_in:[TV,TV_SHORT,ONA]){" +
            "id title{romaji english}" +
            "coverImage{large}" +
            "episodes seasonYear format status averageScore" +
            "}}}";

        JSONObject vars = new JSONObject();
        vars.put("p", page);

        return parseSearchResults(postGraphQL(gql, vars));
    }

    // ══════════════════════════════════════════════════════════════
    // كاش AniList (يستخدم نفس TmdbCache)
    // ══════════════════════════════════════════════════════════════
    private static final String CACHE_PREFIX = "anilist://";

    private static JSONObject getCached(String key) {
        return TmdbCache.getJson(CACHE_PREFIX + key);
    }

    private static void putCached(String key, JSONObject obj) {
        TmdbCache.putJson(CACHE_PREFIX + key, obj);
    }

    // ══════════════════════════════════════════════════════════════
    // HTTP GraphQL POST
    // ══════════════════════════════════════════════════════════════
    private static JSONObject postGraphQL(String query, JSONObject variables) throws Exception {
        // كاش مفتاحه = query + variables
        String cacheKey = query.hashCode() + ":" + variables.toString();
        JSONObject cached = getCached(cacheKey);
        if (cached != null) return cached;

        JSONObject body = new JSONObject();
        body.put("query", query);
        body.put("variables", variables);
        byte[] bodyBytes = body.toString().getBytes("UTF-8");

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(ENDPOINT).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(bodyBytes);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            if (code != 200) return null;

            BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();

            JSONObject result = new JSONObject(sb.toString());
            putCached(cacheKey, result);
            return result;

        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ══════════════════════════════════════════════════════════════
    // Parsers
    // ══════════════════════════════════════════════════════════════
    private static AniSeason parseSeason(JSONObject m) {
        if (m == null) return null;
        AniSeason s = new AniSeason();
        s.anilistId = m.optInt("id");
        JSONObject t = m.optJSONObject("title");
        s.title     = t != null ? t.optString("romaji", "") : "";
        s.titleEn   = t != null ? t.optString("english", "") : "";
        s.episodes  = m.optInt("episodes", 0);
        s.year      = m.optInt("seasonYear", 0);
        s.season    = m.optString("season", "");
        s.status    = m.optString("status", "");
        s.format    = m.optString("format", "TV");
        s.description = m.optString("description", "");
        s.rating    = m.optDouble("averageScore", 0) / 10.0;
        JSONObject img = m.optJSONObject("coverImage");
        s.coverImage = img != null ? img.optString("large", "") : "";
        return s;
    }

    private static List<AniSearchResult> parseSearchResults(JSONObject resp) {
        List<AniSearchResult> results = new ArrayList<>();
        if (resp == null) return results;
        try {
            JSONArray arr = resp
                .optJSONObject("data")
                .optJSONObject("Page")
                .optJSONArray("media");
            if (arr == null) return results;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject m = arr.optJSONObject(i);
                if (m == null) continue;
                AniSearchResult r = new AniSearchResult();
                r.anilistId  = m.optInt("id");
                JSONObject t = m.optJSONObject("title");
                r.title      = t != null ? t.optString("romaji", "") : "";
                r.titleEn    = t != null ? t.optString("english", "") : "";
                JSONObject img = m.optJSONObject("coverImage");
                r.coverImage = img != null ? img.optString("large", "") : "";
                r.episodes   = m.optInt("episodes", 0);
                r.year       = m.optInt("seasonYear", 0);
                r.rating     = m.optDouble("averageScore", 0) / 10.0;
                r.format     = m.optString("format", "TV");
                r.status     = m.optString("status", "");
                results.add(r);
            }
        } catch (Exception ignored) {}
        return results;
    }
}
