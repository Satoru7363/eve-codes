package com.eve.cinema;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Eve v6.1 — Response Parser (PATCH)
 *
 * الإضافة الجوهرية: cleanOrphanedConnectors()
 * ─────────────────────────────────────────────────────────────────────
 * حتى لو خالف النموذج التعليمات وكتب التاج بدون اسم عربي قبله،
 * هذه الدالة تُنظّف الروابط المعلّقة بعد إزالة التاجات:
 *
 * "جرّب  أو ."   →  "جرّب."          (حُذف " أو " المعلّق)
 * "أنصحك بـ ."   →  "أنصحك بشيء."    (حُذف "بـ" المعلّق)
 * "يشبه  ."      →  "."              (حُذف الفراغ الزائد)
 * " أو  ."       →  "."              (حُذف connector فارغ)
 * ─────────────────────────────────────────────────────────────────────
 */
public class EveResponseParser {

    // ── Primary patterns ─────────────────────────────────────────────
    private static final Pattern P_MOVIE = Pattern.compile(
        "\\{\\{MOVIE:([^}\\n]{1,80})\\}\\}");
    private static final Pattern P_TV    = Pattern.compile(
        "\\{\\{TV:([^}\\n]{1,80})\\}\\}");
    private static final Pattern P_ANIME = Pattern.compile(
        "\\{\\{ANIME:([^}\\n]{1,80})\\}\\}");

    // ── Fallback A — quoted title after recommendation word ──────────
    private static final Pattern P_QUOTED = Pattern.compile(
        "(?:مثل|أنصح|جرّب|شاهد|فيلم|مسلسل)"
        + "(?:\\s+(?:بـ?|في|من|عن))?"
        + "\\s*['\"\u2018\u2019\u201C\u201D]"
        + "([^'\"\u2018\u2019\u201C\u201D]{2,70})"
        + "['\"\u2018\u2019\u201C\u201D]");

    // ── Fallback B — bare media type + title ─────────────────────────
    private static final Pattern P_BARE = Pattern.compile(
        "(?:جرّب|جربي|شاهد|شاهدي|أنصح(?:ك|ي)?(?:\\s+بـ?)?)\\s+"
        + "(فيلم|مسلسل|أنمي|انمي)\\s+"
        + "([^\n.،!؟\u060C\u061B]{2,50}?)(?=\\s*[.،!؟\n\u060C\u061B]|\\s*$)",
        Pattern.MULTILINE | Pattern.UNICODE_CASE);

    private static final String[] STOP_WORDS = {
        "فيلم","مسلسل","أنمي","انمي","شيء","الفيلم","المسلسل",
        "ذلك","هذا","هذه","هو","هي","أحسن","جيد","رائع",
        "x","type","englishtitle","englishname"
    };

    // ─────────────────────────────────────────────────────────────────
    //  Data Classes
    // ─────────────────────────────────────────────────────────────────

    public static class RawMention {
        public final String title;
        public final String mediaType;
        public final float  confidence;
        public RawMention(String title, String mediaType, float confidence) {
            this.title      = title.trim();
            this.mediaType  = mediaType;
            this.confidence = confidence;
        }
    }

    public static class ParsedResponse {
        public final String          cleanText;
        public final List<RawMention> mentions;
        public final boolean          hasPrimaryExtractions;
        public ParsedResponse(String t, List<RawMention> m, boolean p) {
            cleanText = t; mentions = m; hasPrimaryExtractions = p;
        }
    }

    // ─────────────────────────────────────────────────────────────────
    //  Public API
    // ─────────────────────────────────────────────────────────────────

    public static ParsedResponse parse(String raw, boolean expectsCards, float minConf) {
        if (raw == null || raw.trim().isEmpty())
            return new ParsedResponse("", new ArrayList<>(), false);

        List<RawMention> mentions  = new ArrayList<>();
        boolean          primary   = false;

        // ── Phase 1: Primary {{TYPE:Title}} ──────────────────────────
        Matcher mM = P_MOVIE.matcher(raw);
        while (mM.find()) {
            String t = mM.group(1);
            if (isValidTitle(t)) { addIfNew(mentions, new RawMention(t, "movie", 1.0f)); primary = true; }
        }
        Matcher mT = P_TV.matcher(raw);
        while (mT.find()) {
            String t = mT.group(1);
            if (isValidTitle(t)) { addIfNew(mentions, new RawMention(t, "tv", 1.0f)); primary = true; }
        }
        Matcher mA = P_ANIME.matcher(raw);
        while (mA.find()) {
            String t = mA.group(1);
            if (isValidTitle(t)) { addIfNew(mentions, new RawMention(t, "anime", 1.0f)); primary = true; }
        }

        // ── Phase 2: Fallback (only if expecting cards and primary failed) ─
        if (!primary && expectsCards) {
            if (0.70f >= minConf) {
                Matcher mQ = P_QUOTED.matcher(raw);
                while (mQ.find()) {
                    String t = mQ.group(1);
                    if (isValidTitle(t)) addIfNew(mentions, new RawMention(t, "movie", 0.70f));
                }
            }
            if (mentions.isEmpty() && 0.50f >= minConf) {
                Matcher mB = P_BARE.matcher(raw);
                while (mB.find()) {
                    String typeAr = mB.group(1);
                    String title  = mB.group(2);
                    if (!isValidTitle(title)) continue;
                    addIfNew(mentions, new RawMention(title, resolveType(typeAr), 0.50f));
                }
            }
        }

        // ── Filter by confidence ──────────────────────────────────────
        List<RawMention> filtered = new ArrayList<>();
        for (RawMention m : mentions)
            if (m.confidence >= minConf) filtered.add(m);

        // ── Clean text ────────────────────────────────────────────────
        // Step 1: Remove all {{}} tags
        String clean = raw
            .replaceAll("\\{\\{MOVIE:[^}]*\\}\\}", "")
            .replaceAll("\\{\\{TV:[^}]*\\}\\}",    "")
            .replaceAll("\\{\\{ANIME:[^}]*\\}\\}",  "");

        // Step 2: Clean orphaned connectors left after tag removal
        clean = cleanOrphanedConnectors(clean);

        return new ParsedResponse(clean, filtered, primary);
    }

    // ─────────────────────────────────────────────────────────────────
    //  cleanOrphanedConnectors — الإصلاح الجوهري
    //
    //  يُنظّف الحالات التي يترك فيها إزالة التاج روابط عربية معلّقة:
    //
    //  "جرّب  أو ."         →  "جرّب."
    //  "أنصحك بـ ."         →  "أنصحك."
    //  "يشبه  أو  ."        →  "يشبه."
    //  "مثل  و ."           →  "مثل."
    //  "  أو   "            →  ""  (connector وحيد بدون سياق)
    // ─────────────────────────────────────────────────────────────────
    static String cleanOrphanedConnectors(String text) {
        if (text == null) return "";

        String s = text;

        // 1. أكثر من مسافة → مسافة واحدة (تنشأ بعد إزالة التاج)
        s = s.replaceAll("[ \t]{2,}", " ");

        // 2. " أو " أو " و " مباشرة قبل علامة ترقيم أو نهاية السطر
        //    "جرّب X أو ." → "جرّب X."
        s = s.replaceAll("\\s+(أو|و)\\s*([.،!؟\n]|$)", "$2");

        // 3. "بـ " وحدها قبل علامة ترقيم أو نهاية
        //    "أنصحك بـ ." → "أنصحك."
        s = s.replaceAll("\\s+بـ?\\s*([.،!؟\n]|$)", "$1");

        // 4. "بـ أو " أو "بـ و " قبل علامة ترقيم
        //    "أنصحك بـ أو ." → "أنصحك."
        s = s.replaceAll("\\s+بـ?\\s+(أو|و)\\s*([.،!؟\n]|$)", "$2");

        // 5. Connector وحيد في أول الجملة بعد إزالة التاج
        //    " أو فيلم آخر" (بداية فارغة) → احتفظ بما بعده
        s = s.replaceAll("^\\s*(أو|و)\\s+", "");

        // 6. فراغات قبل علامات الترقيم
        //    "جميل ." → "جميل."
        s = s.replaceAll("\\s+([.،!؟])", "$1");

        // 7. نقاط/فواصل متكررة " . ." → "."
        s = s.replaceAll("([.،!؟])\\s*([.،!؟])+", "$1");

        // 8. أسطر فارغة متكررة
        s = s.replaceAll("\n{3,}", "\n\n");

        // 9. مسافات نهائية/بدائية
        s = s.replaceAll("[ \t]+\n", "\n");

        return s.trim();
    }

    // ─────────────────────────────────────────────────────────────────
    //  Validation
    // ─────────────────────────────────────────────────────────────────

    static boolean isValidTitle(String raw) {
        if (raw == null) return false;
        String t = raw.trim();
        if (t.length() < 2 || t.length() > 80) return false;
        String lower = t.toLowerCase().trim();
        if (lower.contains("englishtitle") || lower.contains("englishname")
                || lower.contains("type:") || lower.contains("movie:")
                || lower.contains("tv:") || lower.contains("anime:")) return false;
        for (String stop : STOP_WORDS)
            if (lower.equals(stop)) return false;
        if (!t.matches(".*[\\p{L}].*")) return false;
        if (t.split("\\s+").length > 7) return false;
        return true;
    }

    private static String resolveType(String typeAr) {
        if (typeAr == null) return "movie";
        switch (typeAr.trim()) {
            case "مسلسل": return "tv";
            case "أنمي": case "انمي": return "anime";
            default: return "movie";
        }
    }

    private static void addIfNew(List<RawMention> list, RawMention m) {
        for (RawMention e : list)
            if (e.title.equalsIgnoreCase(m.title) && e.mediaType.equals(m.mediaType)) return;
        list.add(m);
    }
}
