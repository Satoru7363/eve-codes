package com.eve.cinema;

import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;

/** قصّ View بحواف مدوّرة عبر outline (أخف من canvas.clipPath ويدعم التسارع العتادي). */
final class RoundOutline {

    private RoundOutline() {}

    static void apply(View v, final float radiusPx) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
            }
        });
        v.setClipToOutline(true);
    }
}
