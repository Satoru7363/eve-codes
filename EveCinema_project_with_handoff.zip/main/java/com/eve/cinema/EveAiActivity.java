package com.eve.cinema;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EveAiActivity extends AppCompatActivity {

    // ── Palette ────────────────────────────────────────────────────────
    private static final int C_VOID   = 0xFF07070D;
    private static final int C_VIOLET = 0xFF9B6FC4;
    private static final int C_LITE   = 0xFFC4A0E8;

    // ── Prefs ──────────────────────────────────────────────────────────
    private static final String PREFS        = "eve_prefs";
    private static final String KEY_USER     = "user_id";
    private static final String KEY_SESS     = "session_id";
    private static final String KEY_LAST_ACT = "last_activity";
    private static final long   SESSION_TTL  = 24 * 60 * 60 * 1000L;
    private static final int    MAX_MSG_LEN  = 500;
    private static final int    MAX_UI_MSG   = 150;

    // ── State ──────────────────────────────────────────────────────────
    private String  userId;
    private String  sessionId;
    private boolean isWaitingForEve      = false;
    private boolean cinemaContentInRound = false;
    private int     msgCountSinceUpdate  = 0;

    private final List<EveMessageModel> messages = new ArrayList<>();
    private EveMessageModel typingModel = null;

    // ── View refs ──────────────────────────────────────────────────────
    private RecyclerView     recycler;
    private EveChatAdapter   adapter;
    private EditText         inputET;
    private View             sendBtn;
    private TextView         statusTV;
    private TextView         memBadge;
    private TextView         charCountTV;
    private View             scrollFab;
    private ProgressBar      loadingBar;
    private GradientDrawable inputBorder;
    private LinearLayout     chipsRow;

    // ── Concurrency ────────────────────────────────────────────────────
    private final Handler         mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService ioExecutor  = Executors.newSingleThreadExecutor();
    private ValueAnimator pulseAnimator = null;

    private boolean isAtBottom = true;
    private boolean fabVisible = false;

    // ══════════════════════════════════════════════════════════════════
    //  CHIP POOL — بدون إيموجي، كل شيء نظيف وأنيق
    // ══════════════════════════════════════════════════════════════════
    private static final String[][] CHIP_POOL = {
        { "رعب",
          "اريد فيلم رعب يخوف",
          "في مود رعب الليلة",
          "أبغى شي مرعب ما يخليني أنام",
          "اقترحي فيلم رعب حقيقي" },

        { "مزاج",
          "مللت ما أعرف شو أشوف",
          "الليلة وحيد اقترحي شي",
          "زهقت اختاري لي فيلم",
          "ما عندي مود أختار، أنتِ اختاري" },

        { "إثارة",
          "اريد فيلم إثارة وتشويق",
          "أبغى شي يخليني على حافة الكرسي",
          "فيلم تشويقي ما أتوقع نهايته",
          "اريد مسلسل إثارة ما يتوقف" },

        { "دراما",
          "اريد فيلم دراما عميق",
          "حابب شي دراما يأثر في المشاعر",
          "مسلسل دراما يستحق المتابعة",
          "اريد فيلم قصته عميقة وتأثيرها يبقى" },

        { "خيال علمي",
          "اريد فيلم خيال علمي عميق",
          "أبغى فيلم sci-fi يفكّر",
          "اقترحي خيال علمي من أفضل ما أُنتج",
          "فيلم خيال علمي نهايته تصدم" },

        { "جريمة",
          "اريد فيلم جريمة وغموض",
          "مسلسل جريمة ما أتوقع الجاني",
          "أبغى فيلم نوار جريمة ممتاز",
          "اقترحي شي في الغموض والتحقيق" },

        { "كوميدي",
          "اريد فيلم كوميدي يضحكني",
          "أبغى شي خفيف وكوميدي",
          "فيلم يرفع المزاج ويضحك",
          "اقترحي كوميدي ذكي مو سخيف" },

        { "رومانسي",
          "اريد فيلم رومانسي",
          "في مود رومانسيات الليلة",
          "أبغى مسلسل رومانسي يأثر",
          "فيلم رومانسي ما يشبه الباقي" },

        { "أنمي",
          "اريد انمي يستحق المشاهدة",
          "أبغى انمي ما شفت مثله",
          "اقترحي انمي يغير نظرتي",
          "انمي من أفضل ما أُنتج" },

        { "مسلسل",
          "اريد مسلسل أتابعه ليلة كاملة",
          "مسلسل binge-worthy ما أقدر أوقفه",
          "أبغى مسلسل يأسرني من الحلقة الأولى",
          "اقترحي مسلسل 10/10" },

        { "كوري",
          "اريد فيلم أو مسلسل كوري",
          "اقترحي درامـا كورية ممتازة",
          "أبغى شي كوري يستحق" },

        { "كلاسيك",
          "اقترحي من أفضل أفلام كل الأزمان",
          "أبغى فيلم كلاسيكي لازم أشوفه",
          "اقترحي فيلم لازم يكون في قائمة كل واحد" },

        { "قصير",
          "اريد فيلم ما يتجاوز ساعتين",
          "في مود شيء خفيف وقصير",
          "اقترحي فيلم أشوفه وأنام" },

        { "نفسي",
          "اريد فيلم نفسي عميق",
          "أبغى فيلم يخليني أفكر بعده",
          "اقترحي فيلم نفسي أو فلسفي" },

        { "حرب",
          "اريد فيلم حرب واقعي",
          "اقترحي أفضل أفلام الحرب",
          "أبغى فيلم أكشن حرب من الأفضل" },
    };

    private int[] chipOrder;

    private void initChipOrder() {
        int total = CHIP_POOL.length;
        chipOrder = new int[total];
        for (int i = 0; i < total; i++) chipOrder[i] = i;
        Random rnd = new Random(sessionId != null ? sessionId.hashCode() : System.currentTimeMillis());
        for (int i = total - 1; i > 0; i--) {
            int j = rnd.nextInt(i + 1);
            int tmp = chipOrder[i]; chipOrder[i] = chipOrder[j]; chipOrder[j] = tmp;
        }
    }

    private String pickChipMessage(int chipIdx) {
        String[] chip = CHIP_POOL[chipIdx];
        int msgCount = chip.length - 1;
        if (msgCount <= 0) return chip[0];
        int offset = (msgCountSinceUpdate + chipIdx) % msgCount;
        return chip[1 + offset];
    }

    // ══════════════════════════════════════════════════════════════════
    //  Lifecycle
    // ══════════════════════════════════════════════════════════════════

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        initIds();
        initChipOrder();
        View root = buildRoot();
        setContentView(root);
        setupInsets(root);
        setupAdapter();
        setupScrollListener();
        loadHistoryAsync();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mainHandler.removeCallbacksAndMessages(null);
        if (pulseAnimator != null) { pulseAnimator.cancel(); pulseAnimator = null; }
        ioExecutor.shutdown();
    }

    @Override
    protected void onPause() {
        super.onPause();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_SESS, sessionId)
            .putLong(KEY_LAST_ACT, System.currentTimeMillis())
            .apply();
    }

    // ══════════════════════════════════════════════════════════════════
    //  Session
    // ══════════════════════════════════════════════════════════════════

    private void initIds() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        userId = prefs.getString(KEY_USER, null);
        if (userId == null) {
            userId = "u_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
            prefs.edit().putString(KEY_USER, userId).apply();
        }
        renewSessionIfNeeded(prefs);
    }

    private void renewSessionIfNeeded(SharedPreferences prefs) {
        long    lastActivity = prefs.getLong(KEY_LAST_ACT, 0);
        boolean expired      = (System.currentTimeMillis() - lastActivity) > SESSION_TTL;
        if (expired || prefs.getString(KEY_SESS, null) == null) {
            sessionId = "s_" + System.currentTimeMillis();
            prefs.edit().putString(KEY_SESS, sessionId).apply();
        } else {
            sessionId = prefs.getString(KEY_SESS, "s_" + System.currentTimeMillis());
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  Build UI — Root
    // ══════════════════════════════════════════════════════════════════

    private View buildRoot() {
        FrameLayout root = new FrameLayout(this);

        // Subtle three-stop background gradient for depth
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{ 0xFF090912, 0xFF07070D, 0xFF080812 });
        root.setBackground(bg);

        LinearLayout mainCol = new LinearLayout(this);
        mainCol.setOrientation(LinearLayout.VERTICAL);
        mainCol.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(mainCol);

        mainCol.addView(buildHeader());
        mainCol.addView(buildRecycler(), new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        mainCol.addView(buildInputBar());

        // Loading spinner
        loadingBar = new ProgressBar(this);
        loadingBar.setIndeterminate(true);
        loadingBar.getIndeterminateDrawable()
            .setColorFilter(C_VIOLET, android.graphics.PorterDuff.Mode.SRC_IN);
        FrameLayout.LayoutParams lbLp = new FrameLayout.LayoutParams(dp(34), dp(34));
        lbLp.gravity = Gravity.CENTER;
        loadingBar.setLayoutParams(lbLp);
        loadingBar.setVisibility(View.GONE);
        root.addView(loadingBar);

        // Scroll FAB
        scrollFab = buildScrollFab();
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(dp(46), dp(46));
        fabLp.gravity      = Gravity.BOTTOM | Gravity.END;
        fabLp.bottomMargin = dp(98);
        fabLp.rightMargin  = dp(18);
        scrollFab.setLayoutParams(fabLp);
        scrollFab.setVisibility(View.GONE);
        scrollFab.setAlpha(0f);
        root.addView(scrollFab);

        return root;
    }

    // ══════════════════════════════════════════════════════════════════
    //  Scroll FAB — canvas-drawn arrow, no cheap characters
    // ══════════════════════════════════════════════════════════════════

    private View buildScrollFab() {
        FrameLayout fab = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xFF111226);
        bg.setStroke(1, 0xFF2A2A4A);
        fab.setBackground(bg);
        fab.setElevation(dp(10));
        fab.setClickable(true);
        fab.setFocusable(true);

        final float density = getResources().getDisplayMetrics().density;
        View icon = new View(this) {
            @Override
            protected void onDraw(Canvas canvas) {
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(0xFF9878C8);
                p.setStrokeWidth(density * 2f);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
                p.setStyle(Paint.Style.STROKE);
                float cx = getWidth() * 0.5f, cy = getHeight() * 0.5f;
                float arm = density * 6.5f, shaft = density * 9f;
                // Down arrow: shaft + two arms pointing down
                canvas.drawLine(cx, cy - shaft * 0.45f, cx, cy + shaft * 0.45f, p);
                canvas.drawLine(cx - arm * 0.6f, cy + shaft * 0.08f, cx, cy + shaft * 0.58f, p);
                canvas.drawLine(cx + arm * 0.6f, cy + shaft * 0.08f, cx, cy + shaft * 0.58f, p);
            }
        };
        icon.setBackgroundColor(Color.TRANSPARENT);
        icon.setLayoutParams(new FrameLayout.LayoutParams(dp(46), dp(46)));
        fab.addView(icon);
        fab.setOnClickListener(v -> scrollToBottom(true));
        return fab;
    }

    private void setupScrollListener() {
        recycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView rv, int state) {
                if (state == RecyclerView.SCROLL_STATE_DRAGGING) {
                    hideKeyboard(); inputET.clearFocus();
                }
            }
            @Override
            public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                LinearLayoutManager llm = (LinearLayoutManager) rv.getLayoutManager();
                if (llm == null) return;
                int last  = llm.findLastCompletelyVisibleItemPosition();
                int total = adapter.getItemCount() - 1;
                isAtBottom = (last >= total - 1);
                if (isAtBottom && fabVisible) {
                    fabVisible = false;
                    scrollFab.animate().alpha(0f).scaleX(0.72f).scaleY(0.72f)
                        .setDuration(220).withEndAction(() -> scrollFab.setVisibility(View.GONE)).start();
                } else if (!isAtBottom && !fabVisible && adapter.getItemCount() > 5) {
                    fabVisible = true;
                    scrollFab.setVisibility(View.VISIBLE);
                    scrollFab.animate().alpha(1f).scaleX(1f).scaleY(1f)
                        .setDuration(260).setInterpolator(new OvershootInterpolator(1.8f)).start();
                }
            }
        });
    }

    // ══════════════════════════════════════════════════════════════════
    //  Header — luxury cinema-grade redesign
    // ══════════════════════════════════════════════════════════════════

    private View buildHeader() {
        FrameLayout headerFrame = new FrameLayout(this);
        headerFrame.setBackgroundColor(0xF507070D);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.HORIZONTAL);
        inner.setGravity(Gravity.CENTER_VERTICAL);
        inner.setPadding(dp(2), dp(12), dp(16), dp(12));
        headerFrame.addView(inner, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT));

        // Back button — precision canvas chevron, no system icons
        View back = buildBackButton();
        LinearLayout.LayoutParams bkLp = new LinearLayout.LayoutParams(dp(46), dp(46));
        back.setLayoutParams(bkLp);
        back.setOnClickListener(v -> finish());
        inner.addView(back);

        // Avatar — multi-layered, organic pulse
        FrameLayout avatar = buildHeaderAvatar();
        LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        avLp.rightMargin = dp(13);
        avatar.setLayoutParams(avLp);
        inner.addView(avatar);

        // Identity column
        LinearLayout nameCol = new LinearLayout(this);
        nameCol.setOrientation(LinearLayout.VERTICAL);
        nameCol.setGravity(Gravity.CENTER_VERTICAL);
        nameCol.setLayoutParams(new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView nameTV = new TextView(this);
        nameTV.setText("إيف");
        nameTV.setTextSize(16.5f);
        nameTV.setTextColor(0xFFE8E3FF);
        nameTV.setTypeface(Typeface.DEFAULT_BOLD);
        nameTV.setLetterSpacing(0f);
        nameCol.addView(nameTV);

        statusTV = new TextView(this);
        statusTV.setText("أوراكل السينما");
        statusTV.setTextSize(10f);
        statusTV.setTextColor(0xFF353558);
        statusTV.setLetterSpacing(0f);
        nameCol.addView(statusTV);

        inner.addView(nameCol);

        // Memory badge — refined minimal pill
        memBadge = new TextView(this);
        memBadge.setTextSize(9f);
        memBadge.setTextColor(0xFF9272C8);
        memBadge.setGravity(Gravity.CENTER);
        memBadge.setPadding(dp(10), dp(4), dp(10), dp(4));
        memBadge.setLetterSpacing(0f);
        GradientDrawable mbBg = new GradientDrawable();
        mbBg.setCornerRadius(dp(20));
        mbBg.setColor(0x0CC4A0E8);
        mbBg.setStroke(1, 0x20C4A0E8);
        memBadge.setBackground(mbBg);
        memBadge.setVisibility(View.GONE);
        LinearLayout.LayoutParams mbLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mbLp.leftMargin = dp(8);
        memBadge.setLayoutParams(mbLp);
        inner.addView(memBadge);

        // Wrapper: header + hairline separator (replaces cheap shadow)
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.addView(headerFrame);

        View hairline = new View(this);
        hairline.setBackgroundColor(0xFF181830);
        wrapper.addView(hairline, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1));

        return wrapper;
    }

    // Canvas-drawn right-pointing chevron — precision, no system resources
    private View buildBackButton() {
        final float density = getResources().getDisplayMetrics().density;
        View btn = new View(this) {
            @Override
            protected void onDraw(Canvas canvas) {
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(0xFF464668);
                p.setStrokeWidth(density * 2.2f);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
                p.setStyle(Paint.Style.STROKE);
                float cx = getWidth() * 0.5f, cy = getHeight() * 0.5f;
                float s = density * 8f;
                Path path = new Path();
                // RTL back = right-pointing chevron
                path.moveTo(cx - s * 0.2f, cy - s);
                path.lineTo(cx + s * 0.5f, cy);
                path.lineTo(cx - s * 0.2f, cy + s);
                canvas.drawPath(path, p);
            }
        };
        btn.setBackgroundColor(Color.TRANSPARENT);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN)
                v.animate().alpha(0.4f).setDuration(60).start();
            else if (e.getAction() == MotionEvent.ACTION_UP
                    || e.getAction() == MotionEvent.ACTION_CANCEL)
                v.animate().alpha(1f).setDuration(220)
                    .setInterpolator(new DecelerateInterpolator(2f)).start();
            return false;
        });
        return btn;
    }

    private FrameLayout buildHeaderAvatar() {
        FrameLayout frame = new FrameLayout(this);

        // Base circle — richer gradient, cinematic depth
        View bgCircle = new View(this);
        bgCircle.setLayoutParams(new FrameLayout.LayoutParams(dp(42), dp(42)));
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColors(new int[]{ 0xFFD0A4FF, 0xFF7040B0, 0xFF371460 });
        gd.setOrientation(GradientDrawable.Orientation.TL_BR);
        bgCircle.setBackground(gd);
        frame.addView(bgCircle);

        // Subtle inner gloss highlight (top-left catch light)
        View gloss = new View(this);
        gloss.setLayoutParams(new FrameLayout.LayoutParams(dp(42), dp(42)));
        GradientDrawable glassBg = new GradientDrawable();
        glassBg.setShape(GradientDrawable.OVAL);
        glassBg.setColors(new int[]{ 0x18FFFFFF, 0x00FFFFFF });
        glassBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        gloss.setBackground(glassBg);
        frame.addView(gloss);

        // Identity letter
        TextView letter = new TextView(this);
        letter.setLayoutParams(new FrameLayout.LayoutParams(dp(42), dp(42)));
        letter.setText("E");
        letter.setTextSize(14.5f);
        letter.setTextColor(0xFFF2EEFF);
        letter.setTypeface(Typeface.DEFAULT_BOLD);
        letter.setGravity(Gravity.CENTER);
        letter.setLetterSpacing(0f);
        frame.addView(letter);

        // Static border ring (always visible, low alpha)
        View staticRing = new View(this);
        staticRing.setLayoutParams(new FrameLayout.LayoutParams(dp(42), dp(42)));
        GradientDrawable srBg = new GradientDrawable();
        srBg.setShape(GradientDrawable.OVAL);
        srBg.setColor(Color.TRANSPARENT);
        srBg.setStroke(1, 0x25C4A0E8);
        staticRing.setBackground(srBg);
        frame.addView(staticRing);

        // Animated pulse ring (sinusoidal alpha, organic breath)
        View pulseRing = new View(this);
        pulseRing.setLayoutParams(new FrameLayout.LayoutParams(dp(42), dp(42)));
        GradientDrawable prBg = new GradientDrawable();
        prBg.setShape(GradientDrawable.OVAL);
        prBg.setColor(Color.TRANSPARENT);
        prBg.setStroke(1, 0x45C4A0E8);
        pulseRing.setBackground(prBg);
        frame.addView(pulseRing);

        startPulse(pulseRing);
        return frame;
    }

    private void startPulse(View ring) {
        pulseAnimator = ValueAnimator.ofFloat(0.88f, 1.48f);
        pulseAnimator.setDuration(2800);
        pulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
        pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.setInterpolator(
            new android.view.animation.AccelerateDecelerateInterpolator());
        pulseAnimator.addUpdateListener(a -> {
            float v = (float) a.getAnimatedValue();
            ring.setScaleX(v);
            ring.setScaleY(v);
            // Sinusoidal alpha — peaks at mid-expansion, zero at both extremes
            float t = (v - 0.88f) / 0.60f;
            ring.setAlpha((float)(Math.sin(t * Math.PI) * 0.52f));
        });
        pulseAnimator.start();
    }

    private RecyclerView buildRecycler() {
        recycler = new RecyclerView(this);
        recycler.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        recycler.setBackgroundColor(Color.TRANSPARENT);
        recycler.setClipToPadding(false);
        recycler.setPadding(0, dp(6), 0, dp(12));
        recycler.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setStackFromEnd(true);
        recycler.setLayoutManager(llm);
        recycler.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator() {{
            setAddDuration(270); setRemoveDuration(160); setChangeDuration(0);
        }});
        return recycler;
    }

    private void setupAdapter() {
        adapter = new EveChatAdapter(this);
        recycler.setAdapter(adapter);
    }

    // ══════════════════════════════════════════════════════════════════
    //  Input Bar — architectural, refined
    // ══════════════════════════════════════════════════════════════════

    private View buildInputBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(0xF507070D);

        // Suggestion chips strip
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        hsv.setPadding(dp(14), dp(10), dp(14), dp(6));

        chipsRow = new LinearLayout(this);
        chipsRow.setOrientation(LinearLayout.HORIZONTAL);
        chipsRow.setGravity(Gravity.CENTER_VERTICAL);
        hsv.addView(chipsRow);
        bar.addView(hsv, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        // Character counter row
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setPadding(dp(20), dp(2), dp(20), 0);
        charCountTV = new TextView(this);
        charCountTV.setTextSize(9.5f);
        charCountTV.setTextColor(0xFF262448);
        charCountTV.setLetterSpacing(0f);
        charCountTV.setVisibility(View.GONE);
        topRow.addView(charCountTV);
        bar.addView(topRow);

        // Input row
        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(dp(14), dp(10), dp(14), dp(10));

        FrameLayout inputWrap = new FrameLayout(this);
        LinearLayout.LayoutParams iwLp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        iwLp.rightMargin = dp(10);
        inputWrap.setLayoutParams(iwLp);

        inputBorder = new GradientDrawable();
        inputBorder.setCornerRadius(dp(26));
        inputBorder.setColor(0xFF0B0B1E);
        inputBorder.setStroke(1, 0xFF1C1C36);

        inputET = new EditText(this);
        inputET.setHint("اكتب لإيف...");
        inputET.setHintTextColor(0xFF232345);
        inputET.setTextColor(0xFFCCCAEE);
        inputET.setTextSize(14f);
        inputET.setBackground(inputBorder);
        inputET.setPadding(dp(20), dp(13), dp(20), dp(13));
        inputET.setMaxLines(4);
        inputET.setFilters(new InputFilter[]{ new InputFilter.LengthFilter(MAX_MSG_LEN) });
        inputET.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEND);
        inputET.setInputType(
            android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        inputWrap.addView(inputET);

        inputET.setOnFocusChangeListener((v, f) -> animateInputBorder(f));
        inputET.setOnEditorActionListener((v, action, event) -> {
            if (action == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                handleSend(); return true;
            }
            return false;
        });
        inputET.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                if (isWaitingForEve) return;
                boolean has = s.toString().trim().length() > 0;
                sendBtn.animate()
                    .scaleX(has ? 1f : 0.80f).scaleY(has ? 1f : 0.80f)
                    .alpha(has ? 1f : 0.30f).setDuration(160).start();
                int len = s.length();
                if (len > MAX_MSG_LEN * 0.75) {
                    charCountTV.setVisibility(View.VISIBLE);
                    charCountTV.setText(len + "/" + MAX_MSG_LEN);
                    charCountTV.setTextColor(len >= MAX_MSG_LEN ? 0xFFFF5050 : 0xFF404068);
                } else {
                    charCountTV.setVisibility(View.GONE);
                }
                setChipsVisible(len == 0 && !isWaitingForEve);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        sendBtn = buildSendButton();
        inputRow.addView(inputWrap);
        inputRow.addView(sendBtn);
        sendBtn.setOnClickListener(v -> handleSend());
        bar.addView(inputRow);

        // Hairline top separator
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        View hairline = new View(this);
        hairline.setBackgroundColor(0xFF181830);
        wrapper.addView(hairline, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1));
        wrapper.addView(bar);
        return wrapper;
    }

    // ══════════════════════════════════════════════════════════════════
    //  Chips — clean Arabic labels, no emoji, premium pill style
    // ══════════════════════════════════════════════════════════════════

    private void rebuildChips() {
        if (chipsRow == null) return;
        chipsRow.removeAllViews();

        int VISIBLE = Math.min(8, chipOrder.length);
        for (int pos = 0; pos < VISIBLE; pos++) {
            final int chipIdx = chipOrder[pos];
            String label = CHIP_POOL[chipIdx][0];

            TextView tv = new TextView(this);
            tv.setText(label);
            tv.setTextSize(11.5f);
            tv.setTextColor(0xFF6E6E98);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(dp(16), dp(7), dp(16), dp(7));
            tv.setLetterSpacing(0f);
            tv.setClickable(true);
            tv.setFocusable(true);
            tv.setTag(chipIdx);

            GradientDrawable chipBg = new GradientDrawable();
            chipBg.setCornerRadius(dp(22));
            chipBg.setColor(Color.TRANSPARENT);
            chipBg.setStroke(1, 0xFF1C1C36);
            tv.setBackground(chipBg);

            tv.setOnTouchListener((v, e) -> {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(0.92f).scaleY(0.92f).alpha(0.65f).setDuration(75).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220)
                            .setInterpolator(new OvershootInterpolator(2.2f)).start();
                        break;
                }
                return false;
            });

            tv.setOnClickListener(v -> {
                if (isWaitingForEve) return;
                String msg = pickChipMessage(chipIdx);
                inputET.setText(msg);
                inputET.setSelection(msg.length());
                mainHandler.postDelayed(this::handleSend, 100);
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(8);
            tv.setLayoutParams(lp);
            chipsRow.addView(tv);
        }
    }

    private void setChipsVisible(boolean show) {
        if (chipsRow == null) return;
        View hsv = (View) chipsRow.getParent();
        if (hsv == null) return;
        if (show && hsv.getVisibility() != View.VISIBLE) {
            hsv.setAlpha(0f);
            hsv.setVisibility(View.VISIBLE);
            hsv.animate().alpha(1f).setDuration(230).start();
        } else if (!show && hsv.getVisibility() == View.VISIBLE) {
            hsv.animate().alpha(0f).setDuration(160)
                .withEndAction(() -> hsv.setVisibility(View.GONE)).start();
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  Send Button — canvas-drawn arrow, truly custom
    // ══════════════════════════════════════════════════════════════════

    private View buildSendButton() {
        FrameLayout btn = new FrameLayout(this);
        int sz = dp(46);
        btn.setLayoutParams(new LinearLayout.LayoutParams(sz, sz));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColors(new int[]{ 0xFFBB8AFF, 0xFF7242C0 });
        bg.setOrientation(GradientDrawable.Orientation.TL_BR);
        btn.setBackground(bg);
        btn.setClickable(true);
        btn.setFocusable(true);

        final float density = getResources().getDisplayMetrics().density;
        View arrowIcon = new View(this) {
            @Override
            protected void onDraw(Canvas canvas) {
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(Color.WHITE);
                p.setStrokeWidth(density * 2.2f);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
                p.setStyle(Paint.Style.STROKE);
                float cx = getWidth() * 0.5f, cy = getHeight() * 0.5f;
                float arm = density * 7f, shaft = density * 9.5f;
                // Clean upward arrow: vertical shaft + two angled arms
                canvas.drawLine(cx, cy + shaft * 0.5f, cx, cy - shaft * 0.44f, p);
                canvas.drawLine(cx - arm * 0.58f, cy - shaft * 0.06f, cx, cy - shaft * 0.58f, p);
                canvas.drawLine(cx + arm * 0.58f, cy - shaft * 0.06f, cx, cy - shaft * 0.58f, p);
            }
        };
        arrowIcon.setBackgroundColor(Color.TRANSPARENT);
        arrowIcon.setLayoutParams(new FrameLayout.LayoutParams(sz, sz));
        btn.addView(arrowIcon);
        btn.setAlpha(0.30f);
        btn.setScaleX(0.80f);
        btn.setScaleY(0.80f);
        return btn;
    }

    private void animateInputBorder(boolean focused) {
        int toColor  = focused ? C_VIOLET : 0xFF1C1C36;
        int fillColor = focused ? 0xFF101030 : 0xFF0B0B1E;
        ValueAnimator anim = ValueAnimator.ofArgb(
            focused ? 0xFF1C1C36 : C_VIOLET, toColor);
        anim.setDuration(260);
        anim.addUpdateListener(a -> {
            inputBorder.setStroke(1, (int) a.getAnimatedValue());
            inputBorder.setColor(fillColor);
        });
        anim.start();
    }

    private void setupInsets(View root) {
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            int top    = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int bottom = Math.max(
                insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom,
                insets.getInsets(WindowInsetsCompat.Type.ime()).bottom);
            v.setPadding(0, top, 0, bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    // ══════════════════════════════════════════════════════════════════
    //  History
    // ══════════════════════════════════════════════════════════════════

    private void loadHistoryAsync() {
        loadingBar.setVisibility(View.VISIBLE);
        ioExecutor.execute(() -> {
            List<EveMessageModel> saved = EveMemoryDb.get(this).getDisplayMessages(userId, MAX_UI_MSG);
            EveMemoryDb.UserDna   dna   = EveMemoryDb.get(this).getDna(userId);
            int score = dna.memoryScore();
            mainHandler.post(() -> {
                loadingBar.setVisibility(View.GONE);
                if (!saved.isEmpty()) {
                    List<EveMessageModel> display = saved.size() > MAX_UI_MSG
                        ? saved.subList(saved.size() - MAX_UI_MSG, saved.size()) : saved;
                    messages.addAll(display);
                    adapter.resetAnimationCounter();
                    adapter.submitList(new ArrayList<>(messages));
                    scrollToBottom(false);
                }
                if (score > 0) {
                    memBadge.setText("ذاكرة " + score);
                    memBadge.setVisibility(View.VISIBLE);
                }
                rebuildChips();
                setChipsVisible(true);
                restoreOrStartSession();
            });
        });
    }

    private void restoreOrStartSession() {
        EveFirebaseSync.downloadDna(userId, dna -> {
            if (dna != null) {
                ioExecutor.execute(() -> {
                    EveMemoryDb.get(EveAiActivity.this).updateDna(dna);
                    mainHandler.post(this::updateMemoryBadge);
                });
            }
        });
        if (messages.isEmpty()) mainHandler.postDelayed(this::sendWelcome, 650);
    }

    private void sendWelcome() {
        ioExecutor.execute(() -> {
            EveMemoryDb.UserDna dna = EveMemoryDb.get(this).getDna(userId);
            String welcome = dna.isEmpty()
                ? "مرحباً.\nأنا إيف — أوراكل السينما.\nأخبرني بمزاجك، وسأجد لك ما يناسب روحك."
                : "عدتَ.\nذاكرتي عنك لا تزال سليمة.\nماذا تريد أن تشاهد الليلة؟";
            mainHandler.post(() -> {
                appendEveMessage(welcome);
                ioExecutor.execute(() ->
                    EveMemoryDb.get(this).saveMessage(userId, "assistant", welcome, sessionId));
            });
        });
    }

    // ══════════════════════════════════════════════════════════════════
    //  handleSend
    // ══════════════════════════════════════════════════════════════════

    private void handleSend() {
        if (isWaitingForEve) return;
        String text = inputET.getText().toString().trim();
        if (text.isEmpty()) return;
        if (!isNetworkAvailable()) { showNetworkError(); return; }

        inputET.setText("");
        charCountTV.setVisibility(View.GONE);
        animateInputBorder(false);
        hideKeyboard();
        triggerHaptic();
        setChipsVisible(false);

        appendMessage(new EveMessageModel(EveMessageModel.TYPE_USER, text));
        final String msgText = text;
        ioExecutor.execute(() ->
            EveMemoryDb.get(this).saveMessage(userId, "user", msgText, sessionId));

        setSendEnabled(false);

        ioExecutor.execute(() -> {
            List<JSONObject>    history = EveMemoryDb.get(this).getHistory(userId, 16);
            EveMemoryDb.UserDna dna     = EveMemoryDb.get(this).getDna(userId);

            mainHandler.post(() ->
                EveGroqClient.sendMessage(
                    userId, msgText, history, dna,
                    new EveGroqClient.ChatCallback() {

                        @Override
                        public void onTyping() { showTypingIndicator(); }

                        @Override
                        public void onResponse(
                                String cleanText,
                                List<EveTmdbResolver.ResolvedMention> mentions) {

                            removeTypingIndicator();

                            List<JSONObject> cards     = new ArrayList<>();
                            List<String>     cardTypes = new ArrayList<>();

                            for (EveTmdbResolver.ResolvedMention m : mentions) {
                                if (m.tmdbData != null) {
                                    cards.add(m.tmdbData);
                                    cardTypes.add(m.source.mediaType);
                                }
                            }

                            if (!cards.isEmpty()) {
                                appendMessage(new EveMessageModel(cleanText, cards, cardTypes));
                                cinemaContentInRound = true;
                            } else if (cleanText != null && !cleanText.isEmpty()) {
                                appendEveMessage(cleanText);
                            }

                            final String           savedText  = cleanText;
                            final List<JSONObject> savedCards = new ArrayList<>(cards);
                            final List<String>     savedTypes = new ArrayList<>(cardTypes);
                            ioExecutor.execute(() -> {
                                if (!savedCards.isEmpty()) {
                                    EveMemoryDb.get(EveAiActivity.this)
                                        .saveMessageCombined(userId, savedText,
                                                             savedCards, savedTypes, sessionId);
                                    for (int i = 0; i < savedCards.size(); i++) {
                                        String title = savedCards.get(i).optString("title",
                                            savedCards.get(i).optString("name", ""));
                                        if (!title.isEmpty())
                                            EveMemoryDb.get(EveAiActivity.this)
                                                .addToWatchHistory(userId, title);
                                    }
                                } else if (savedText != null && !savedText.isEmpty()) {
                                    EveMemoryDb.get(EveAiActivity.this)
                                        .saveMessage(userId, "assistant", savedText, sessionId);
                                }
                            });

                            msgCountSinceUpdate++;
                            if (msgCountSinceUpdate >= 4) {
                                msgCountSinceUpdate = 0;
                                final boolean hasContent = cinemaContentInRound;
                                cinemaContentInRound = false;
                                ioExecutor.execute(() -> {
                                    List<JSONObject> recent =
                                        EveMemoryDb.get(EveAiActivity.this)
                                            .getHistory(userId, 20);
                                    EveGroqClient.updateDnaAsync(
                                        getApplicationContext(), userId, recent, hasContent);
                                });
                                mainHandler.postDelayed(EveAiActivity.this::updateMemoryBadge, 3500);
                            }

                            pruneMessagesIfNeeded();
                            setSendEnabled(true);
                            rebuildChips();
                        }

                        @Override
                        public void onError(String msg) {
                            removeTypingIndicator();
                            if (!isNetworkAvailable()) showNetworkError();
                            else Toast.makeText(EveAiActivity.this, msg, Toast.LENGTH_SHORT).show();
                            setSendEnabled(true);
                        }
                    })
            );
        });
    }

    // ══════════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════════

    private void pruneMessagesIfNeeded() {
        if (messages.size() > MAX_UI_MSG) {
            messages.subList(0, messages.size() - MAX_UI_MSG).clear();
            adapter.resetAnimationCounter();
            adapter.submitList(new ArrayList<>(messages));
        }
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.net.Network net = cm.getActiveNetwork();
                if (net == null) return false;
                NetworkCapabilities nc = cm.getNetworkCapabilities(net);
                return nc != null && (
                    nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
            } else {
                android.net.NetworkInfo info = cm.getActiveNetworkInfo();
                return info != null && info.isConnected();
            }
        } catch (Exception e) { return true; }
    }

    private void showNetworkError() {
        Toast.makeText(this, "لا يوجد اتصال بالإنترنت", Toast.LENGTH_SHORT).show();
        ValueAnimator err = ValueAnimator.ofArgb(0xFFFF4444, 0xFF1C1C36);
        err.setDuration(1400);
        err.addUpdateListener(a -> inputBorder.setStroke(1, (int) a.getAnimatedValue()));
        err.start();
    }

    private void triggerHaptic() {
        try {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK));
            else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(30);
        } catch (Exception ignored) {}
    }

    private void showTypingIndicator() {
        statusTV.setText("تفكر...");
        statusTV.setTextColor(0xFF484880);
        typingModel = EveMessageModel.typing();
        appendMessage(typingModel);
    }

    private void removeTypingIndicator() {
        statusTV.setText("أوراكل السينما");
        statusTV.setTextColor(0xFF353558);
        if (typingModel != null) {
            messages.remove(typingModel);
            typingModel = null;
            adapter.submitList(new ArrayList<>(messages));
        }
    }

    private void setSendEnabled(boolean enabled) {
        isWaitingForEve = !enabled;
        sendBtn.animate()
            .scaleX(enabled ? 1f : 0.82f).scaleY(enabled ? 1f : 0.82f)
            .alpha(enabled ? 1f : 0.38f).setDuration(180).start();
        sendBtn.setEnabled(enabled);
        setChipsVisible(enabled && inputET.getText().length() == 0);
    }

    private void appendEveMessage(String text) {
        appendMessage(new EveMessageModel(EveMessageModel.TYPE_EVE, text));
    }

    private void appendMessage(EveMessageModel model) {
        messages.add(model);
        adapter.submitList(new ArrayList<>(messages));
        if (isAtBottom) scrollToBottom(true);
    }

    private void scrollToBottom(boolean smooth) {
        int target = adapter.getItemCount() - 1;
        if (target < 0) return;
        if (smooth) {
            mainHandler.postDelayed(() -> {
                if (!isFinishing() && !isDestroyed())
                    recycler.smoothScrollToPosition(Math.max(0, adapter.getItemCount() - 1));
            }, 80);
        } else {
            recycler.scrollToPosition(target);
        }
    }

    private void updateMemoryBadge() {
        ioExecutor.execute(() -> {
            int score = EveMemoryDb.get(this).getDna(userId).memoryScore();
            mainHandler.post(() -> {
                if (score > 0) {
                    memBadge.setText("ذاكرة " + score);
                    if (memBadge.getVisibility() != View.VISIBLE) {
                        memBadge.setAlpha(0f);
                        memBadge.setVisibility(View.VISIBLE);
                        memBadge.animate().alpha(1f).setDuration(400).start();
                    }
                } else {
                    memBadge.setVisibility(View.GONE);
                }
            });
        });
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(inputET.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    private int dp(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
