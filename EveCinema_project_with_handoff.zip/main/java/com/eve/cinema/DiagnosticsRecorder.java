package com.eve.cinema;

import android.content.Context;
import android.os.SystemClock;
import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/** Temporary local-only diagnostic recorder. All disk I/O is serialized off the caller thread. */
public final class DiagnosticsRecorder {
    private static final String TAG = "EveDiagnostics";
    // Recording is enabled by user request; keep redaction at every disk/log boundary.
    private static final boolean RECORDING_ENABLED = true;
    private static final int MAX_PAYLOAD_BYTES = 2 * 1024 * 1024;
    private static final long MAX_TOTAL_BYTES = 100L * 1024 * 1024;
    private static final ThreadPoolExecutor WRITER = new ThreadPoolExecutor(1, 1, 0L,
            TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(512), r -> {
        Thread t = new Thread(r, "eve-diagnostic-writer"); t.setDaemon(true); return t;
    }, new ThreadPoolExecutor.AbortPolicy());
    private static final AtomicLong DROPPED = new AtomicLong();
    private static volatile File sessionDir;
    private static volatile String sessionId = "uninitialized";
    private static volatile String traceId = "";
    private static volatile String storagePath = "";
    private static volatile String storageFallbackReason = "";
    private static volatile String storageFailure = "";
    private static volatile long payloadsWritten;
    private static volatile long payloadsTruncated;
    private static volatile long eventsWritten;

    private DiagnosticsRecorder() {}

    public static boolean isRecordingEnabled() { return RECORDING_ENABLED; }

    public static synchronized void initialize(Context context) {
        if (!RECORDING_ENABLED) return;
        if (sessionDir != null) return;
        String stamp = utcStamp("yyyyMMdd_HHmmss_SSS");
        sessionId = UUID.randomUUID().toString();
        String folder = "sessions" + File.separator + stamp + "_" + sessionId;
        File preferred = new File("/storage/emulated/0/$500/EveRecords");
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30
                    && !android.os.Environment.isExternalStorageManager()) {
                throw new java.io.IOException("MANAGE_EXTERNAL_STORAGE not granted");
            }
            testStorage(preferred);
            storagePath = preferred.getAbsolutePath();
            storageFallbackReason = "";
            storageFailure = "";
            File sessions = new File(preferred, "sessions");
            if (!sessions.exists() && !sessions.mkdirs()) throw new java.io.IOException("cannot create sessions directory");
            sessionDir = new File(sessions, stamp + "_" + sessionId);
            File payloadDir = new File(sessionDir, "payloads");
            if (!payloadDir.mkdirs()) throw new java.io.IOException("cannot create session/payloads directory");
            pruneOldSessions(sessions);
            appendEvent("recorder", "session_start", "started", new JSONObject()
                    .put("storagePath", storagePath).put("storageFallbackReason", storageFallbackReason)
                    .put("secretsRedacted", false).put("payloadLimitBytes", MAX_PAYLOAD_BYTES)
                    .put("storageQuotaBytes", MAX_TOTAL_BYTES), null, null);
            writeSummary("active");
        } catch (Exception e) {
            storageFailure = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            storageFallbackReason = "No fallback used; diagnostics require the requested public directory";
            Log.e(TAG, "Recorder storage initialization failed", e);
            sessionDir = null;
        }
    }

    public static String newTrace(String operation) {
        traceId = UUID.randomUUID().toString();
        event("operation", operation, "started", new JSONObject());
        return traceId;
    }

    public static String currentTraceId() { return traceId; }

    public static JSONObject details(Object... values) {
        JSONObject result = new JSONObject();
        try { for (int i = 0; i + 1 < values.length; i += 2) result.put(String.valueOf(values[i]), values[i + 1]); }
        catch (Exception e) { Log.w(TAG, "Could not encode event details", e); }
        return result;
    }

    public static void event(String source, String operation, String status, JSONObject details) {
        if (!RECORDING_ENABLED) return;
        appendEvent(source, operation, status, details, null, null);
    }

    public static void headers(String source, String operation, String method, String url, Object headers) {
        if (!RECORDING_ENABLED) return;
        event(source, operation + "_headers", "sent", details("method", method, "url", url,
                "headers", DiagnosticRedactor.headerSummary(headers)));
    }

    /** Adds an event and saves textual request/response content under the event ID. */
    public static void network(String source, String operation, String method, String url,
                               int status, long durationMs, String requestBody,
                               String responseBody, Throwable error, boolean fromCache) {
        if (!RECORDING_ENABLED) return;
        try {
            JSONObject d = new JSONObject().put("method", method).put("url", url)
                    .put("httpStatus", status).put("durationMs", durationMs)
                    .put("cache", fromCache ? "cache" : "network")
                    .put("requestBodyPresent", requestBody != null)
                    .put("responseBodyPresent", responseBody != null);
            if (error != null) d.put("exceptionType", error.getClass().getName()).put("exception", Log.getStackTraceString(error));
            appendEvent(source, operation, error == null ? "completed" : "failed", d, requestBody, responseBody);
        } catch (Exception e) { Log.w(TAG, "Unable to enqueue network event", e); }
    }

    private static void appendEvent(String source, String operation, String status, JSONObject details,
                                    String requestBody, String responseBody) {
        if (!RECORDING_ENABLED) return;
        final String eventId = UUID.randomUUID().toString();
        final String safeOperation = DiagnosticRedactor.redactText(operation);
        final long elapsed = SystemClock.elapsedRealtime();
        final String now = utcStamp("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        final JSONObject data = details == null ? new JSONObject() : details;
        final String safeRequestBody = requestBody == null ? null : DiagnosticRedactor.redactText(requestBody);
        final String safeResponseBody = responseBody == null ? null : DiagnosticRedactor.redactText(responseBody);
        try {
            data.put("timestampUtc", now).put("elapsedRealtimeMs", elapsed)
                    .put("sessionId", sessionId).put("traceId", traceId)
                    .put("eventId", eventId).put("eventType", "diagnostic")
                    .put("source", DiagnosticRedactor.redactText(source))
                    .put("operation", DiagnosticRedactor.redactText(operation))
                    .put("status", DiagnosticRedactor.redactText(status))
                    .put("secretsRedacted", true);
        } catch (Exception ignored) { }
        try {
            WRITER.execute(() -> {
                if (sessionDir == null) { DROPPED.incrementAndGet(); Log.w(TAG, "event dropped; recorder unavailable: " + safeOperation); return; }
                try {
                    File sessions = sessionDir.getParentFile();
                    pruneOldSessions(sessions);
                    long expected = data.toString().length() * 2L
                            + (safeRequestBody == null ? 0 : Math.min(safeRequestBody.getBytes(StandardCharsets.UTF_8).length, MAX_PAYLOAD_BYTES))
                            + (safeResponseBody == null ? 0 : Math.min(safeResponseBody.getBytes(StandardCharsets.UTF_8).length, MAX_PAYLOAD_BYTES));
                    if (sizeOf(sessions) + expected > MAX_TOTAL_BYTES) {
                        DROPPED.incrementAndGet();
                        Log.e(TAG, "diagnostic storage quota reached; event dropped: " + safeOperation);
                        writeSummary("quota_reached");
                        return;
                    }
                    JSONObject refs = new JSONObject();
                    if (safeRequestBody != null) refs.put("request", writePayload(eventId + "_request.txt", safeRequestBody));
                    if (safeResponseBody != null) refs.put("response", writePayload(eventId + "_response.txt", safeResponseBody));
                    data.put("payloadReferences", refs);
                    if (DROPPED.get() > 0) data.put("droppedEventsBeforeThis", DROPPED.get());
                    File log = new File(sessionDir, "events.jsonl");
                    try (FileOutputStream out = new FileOutputStream(log, true)) {
                        String safeEvent = DiagnosticRedactor.redactText(data.toString());
                        out.write((safeEvent + "\n").getBytes(StandardCharsets.UTF_8));
                        out.flush();
                    }
                    eventsWritten++;
                    if (eventsWritten % 10 == 0) writeSummary("active");
                } catch (Exception e) {
                    storageFailure = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
                    Log.e(TAG, "Diagnostic event write failed", e);
                }
            });
        } catch (RuntimeException e) {
            DROPPED.incrementAndGet();
            Log.e(TAG, "Diagnostic queue full; event dropped: " + safeOperation, e);
        }
    }

    private static void testStorage(File dir) throws Exception {
        if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("directory creation denied/failed: " + dir);
        File test = new File(dir, ".eve_write_test_" + UUID.randomUUID());
        try {
            try (FileOutputStream out = new FileOutputStream(test)) { out.write(0x45); out.flush(); out.getFD().sync(); }
            try (java.io.FileInputStream in = new java.io.FileInputStream(test)) {
                if (in.read() != 0x45 || in.read() != -1) throw new java.io.IOException("read-back validation failed");
            }
        } finally { if (test.exists() && !test.delete()) Log.w(TAG, "could not remove storage probe " + test); }
    }

    public static void flushForCrash() {
        if (!RECORDING_ENABLED) return;
        final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
        try {
            WRITER.execute(() -> { writeSummary("crash"); latch.countDown(); });
            latch.await(750, TimeUnit.MILLISECONDS);
        } catch (Exception e) { Log.e(TAG, "could not flush diagnostic log before crash handling", e); }
    }

    private static JSONObject writePayload(String name, String text) throws Exception {
        byte[] bytes = DiagnosticRedactor.redactText(text).getBytes(StandardCharsets.UTF_8);
        int captured = Math.min(bytes.length, MAX_PAYLOAD_BYTES);
        byte[] saved = new byte[captured]; System.arraycopy(bytes, 0, saved, 0, captured);
        File dir = new File(sessionDir, "payloads");
        File target = new File(dir, name);
        try (FileOutputStream out = new FileOutputStream(target)) { out.write(saved); out.flush(); }
        boolean truncated = captured < bytes.length;
        if (truncated) payloadsTruncated++;
        payloadsWritten++;
        return new JSONObject().put("path", "payloads/" + name).put("state", truncated ? "truncated" : "complete")
                .put("originalByteLength", bytes.length).put("capturedByteLength", captured)
                .put("truncationReason", truncated ? "per-payload limit 2 MiB" : JSONObject.NULL)
                .put("sha256", sha256(bytes));
    }

    private static String sha256(byte[] bytes) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
            StringBuilder b = new StringBuilder(); for (byte x : digest) b.append(String.format(Locale.US, "%02x", x & 255));
            return b.toString();
        } catch (Exception ignored) { return "unavailable"; }
    }

    private static void writeSummary(String state) {
        if (sessionDir == null) return;
        try {
            JSONObject j = new JSONObject().put("sessionId", sessionId).put("state", state)
                    .put("storagePath", DiagnosticRedactor.redactText(storagePath))
                    .put("sessionPath", DiagnosticRedactor.redactText(sessionDir.getAbsolutePath()))
                    .put("storageFallbackReason", DiagnosticRedactor.redactText(storageFallbackReason))
                    .put("storageFailure", DiagnosticRedactor.redactText(storageFailure))
                    .put("secretsRedacted", true).put("eventsWritten", eventsWritten)
                    .put("droppedEvents", DROPPED.get()).put("payloadsWritten", payloadsWritten)
                    .put("payloadsTruncated", payloadsTruncated).put("payloadLimitBytes", MAX_PAYLOAD_BYTES)
                    .put("quotaBytes", MAX_TOTAL_BYTES).put("updatedUtc", utcStamp("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
            try (FileOutputStream out = new FileOutputStream(new File(sessionDir, "session_summary.json"))) {
                out.write(j.toString(2).getBytes(StandardCharsets.UTF_8)); out.flush();
            }
        } catch (Exception e) { storageFailure = "summary write failed: " + e; Log.e(TAG, "Summary write failed", e); }
    }

    private static void pruneOldSessions(File sessions) {
        File[] dirs = sessions.listFiles(File::isDirectory);
        if (dirs == null) return;
        long total = 0; for (File f : dirs) total += sizeOf(f);
        java.util.Arrays.sort(dirs, (a,b) -> Long.compare(a.lastModified(), b.lastModified()));
        for (File f : dirs) {
            if (total <= MAX_TOTAL_BYTES) break;
            if (f.equals(sessionDir) || !new File(f, "session_summary.json").isFile()) continue;
            long size = sizeOf(f); if (deleteTree(f)) total -= size;
        }
    }
    private static long sizeOf(File f) { if (f.isFile()) return f.length(); File[] c=f.listFiles(); long n=0; if(c!=null) for(File x:c)n+=sizeOf(x); return n; }
    private static boolean deleteTree(File f) { File[] c=f.listFiles(); if(c!=null) for(File x:c) if(!deleteTree(x)) return false; return !f.exists() || f.delete(); }
    private static String utcStamp(String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
        format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return format.format(new Date());
    }

    public static void finish(String reason) {
        if (!RECORDING_ENABLED) return;
        event("recorder", "session_end", "finished", details("reason", reason));
        try { WRITER.execute(() -> writeSummary("finished")); } catch (RuntimeException ignored) { }
    }
}
