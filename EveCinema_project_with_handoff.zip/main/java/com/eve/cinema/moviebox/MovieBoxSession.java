/*
 * Derived from MovieBox-Tui (Rust) — upstream dual-licensed MIT / Apache-2.0.
 * Upstream copyright retained. See NOTICE at the project root for the full
 * license texts and attribution scope.
 */
package com.eve.cinema.moviebox;

/*
 * Ported from MovieBox-Tui (src/providers/moviebox/session.rs).
 * MovieBox-Tui is dual-licensed MIT / Apache-2.0; see NOTICE.
 */

import org.json.JSONObject;

/**
 * Visitor session for the MovieBox API. Immutable value object; expiry is
 * derived from the JWT payload when possible, otherwise a 7-day rolling
 * window from creation (matches session.rs is_valid()).
 */
public final class MovieBoxSession {

    /** Sessions older than this are treated as expired when no JWT exp exists. */
    private static final long FALLBACK_TTL_SECS = 7L * 24 * 3600;
    /** Refresh this many seconds before actual expiry. */
    private static final long EXPIRY_SKEW_SECS = 60;

    public final String token;
    public final String userId;      // may be null
    public final Long expiresAtSecs; // may be null
    public final long createdAtSecs;

    public MovieBoxSession(String token, String userId, Long expiresAtSecs, long createdAtSecs) {
        this.token = token;
        this.userId = userId;
        this.expiresAtSecs = expiresAtSecs;
        this.createdAtSecs = createdAtSecs;
    }

    public static MovieBoxSession fromTokenAndPayload(String token, String explicitUid) {
        String[] claims = parseJwtClaims(token);
        String uid = explicitUid != null ? explicitUid : claims[0];
        Long exp = claims[1] != null ? Long.valueOf(claims[1]) : null;
        return new MovieBoxSession(token, uid, exp, nowSecs());
    }

    public boolean isValid() {
        return isValid(nowSecs());
    }

    boolean isValid(long nowSecs) {
        if (token == null || token.trim().isEmpty()) return false;
        if (expiresAtSecs != null) {
            return nowSecs + EXPIRY_SKEW_SECS < expiresAtSecs;
        }
        return nowSecs < createdAtSecs + FALLBACK_TTL_SECS;
    }

    private static long nowSecs() {
        return System.currentTimeMillis() / 1000L;
    }

    /**
     * Extracts (uid, exp) from a JWT without verifying the signature.
     * Returns a String[2] {uid, exp} where either element may be null.
     * Tolerates URL-safe and standard Base64, padded or not (session.rs).
     */
    public static String[] parseJwtClaims(String token) {
        String[] out = new String[]{null, null};
        if (token == null) return out;
        String[] parts = token.split("\\.", -1);
        if (parts.length < 2) return out;

        byte[] decoded = MovieBoxBase64.decode(parts[1]);
        if (decoded == null) return out;

        try {
            JSONObject val = new JSONObject(new String(decoded, java.nio.charset.StandardCharsets.UTF_8));
            out[0] = optStringOrNumber(val, "userId");
            if (out[0] == null) out[0] = optStringOrNumber(val, "uid");
            if (out[0] == null) out[0] = optStringOrNumber(val, "sub");

            Object exp = val.opt("exp");
            if (exp instanceof Number) {
                out[1] = Long.toString(((Number) exp).longValue());
            } else if (exp instanceof String) {
                try {
                    out[1] = Long.toString(Long.parseLong((String) exp));
                } catch (NumberFormatException ignored) {}
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static String optStringOrNumber(JSONObject obj, String key) {
        Object v = obj.opt(key);
        if (v instanceof String && !((String) v).isEmpty()) return (String) v;
        if (v instanceof Number) return String.valueOf(v);
        return null;
    }

    // ── Persistence (SharedPreferences on Android) ───────────

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("token", token);
            if (userId != null) o.put("userId", userId);
            if (expiresAtSecs != null) o.put("expiresAt", expiresAtSecs.longValue());
            o.put("createdAt", createdAtSecs);
        } catch (Exception ignored) {}
        return o;
    }

    public static MovieBoxSession fromJson(JSONObject o) {
        if (o == null) return null;
        try {
            String token = o.optString("token", "");
            if (token.isEmpty()) return null;
            String uid = o.has("userId") ? o.optString("userId", null) : null;
            Long exp = o.has("expiresAt") ? o.optLong("expiresAt") : null;
            long created = o.optLong("createdAt", nowSecs());
            return new MovieBoxSession(token, uid, exp, created);
        } catch (Exception e) {
            return null;
        }
    }
}
