/*
 * Derived from MovieBox-Tui (Rust) — upstream dual-licensed MIT / Apache-2.0.
 * Upstream copyright retained. See NOTICE at the project root for the full
 * license texts and attribution scope.
 */
package com.eve.cinema.moviebox;

/*
 * Ported from MovieBox-Tui (src/providers/moviebox/title.rs).
 * MovieBox-Tui is dual-licensed MIT / Apache-2.0; see NOTICE.
 */

import java.util.Locale;

/**
 * Cleans noisy MovieBox titles (leading [tags], trailing "- Hindi Dub",
 * " S01", "_1080P", "(Director's Cut)" etc.) and maps language names to
 * ISO codes for subtitle matching.
 */
public final class MovieBoxTitleCleaner {

    private MovieBoxTitleCleaner() {}

    private static final String[] DUB_TAGS = {
        "hindi", "tamil", "telugu", "kannada", "malayalam", "bengali", "marathi",
        "punjabi", "gujarati", "urdu", "english", "spanish", "french", "german",
        "italian", "japanese", "korean", "chinese", "russian", "portuguese",
        "turkish", "arabic", "dub", "audio", "multi", "season"
    };

    public static String cleanMovieboxTitle(String rawTitle) {
        if (rawTitle == null) return "";
        String title = rawTitle.trim();
        if (title.isEmpty()) return "";

        // Strip leading [TAG] blocks.
        while (title.startsWith("[")) {
            int close = title.indexOf(']');
            if (close < 0) break;
            String remainder = title.substring(close + 1).trim();
            if (remainder.isEmpty()) break;
            title = remainder;
        }

        // Cut a trailing [..] block.
        int bracket = title.indexOf('[');
        if (bracket > 0) title = title.substring(0, bracket).trim();

        // Cut "(...)" unless it is a 4-digit year.
        int paren = title.indexOf('(');
        if (paren > 0) {
            String inside = title.substring(paren + 1);
            int closeIdx = inside.indexOf(')');
            String content = (closeIdx >= 0 ? inside.substring(0, closeIdx) : inside).trim();
            boolean isYear = content.length() == 4 && allDigits(content)
                    && inRange(content, 1900, 2099);
            if (!isYear) title = title.substring(0, paren).trim();
        }

        // Cut " - <language/tag>" suffixes.
        int dash = lastIndexOf(title, " - ");
        if (dash >= 0) {
            String suffix = title.substring(dash + 3);
            String lower = suffix.toLowerCase(Locale.US);
            boolean isTag = false;
            for (String tag : DUB_TAGS) {
                if (lower.contains(tag)) { isTag = true; break; }
            }
            if (!isTag && suffix.length() > 1
                    && (suffix.charAt(0) == 's' || suffix.charAt(0) == 'S')
                    && allDigitsOrDash(suffix.substring(1))) {
                isTag = true;
            }
            if (isTag) title = title.substring(0, dash).trim();
        }

        // Cut " S01" / " S01-S02" style suffixes.
        int sIdx = lastIndexOf(title, " S");
        if (sIdx >= 0) {
            String suffix = title.substring(sIdx + 2);
            boolean isSeason = !suffix.isEmpty() && allDigitsDashOrS(suffix)
                    && Character.isDigit(suffix.charAt(0));
            if (isSeason) title = title.substring(0, sIdx).trim();
        }

        // Cut " season N" (case-insensitive).
        int seasonIdx = lastIndexOfIgnoreCase(title, " season ");
        if (seasonIdx >= 0) title = title.substring(0, seasonIdx).trim();

        // Cut a trailing resolution token after '_', ' ', '.', or '-'.
        for (char sep : new char[]{'_', ' ', '.', '-'}) {
            int pos = title.lastIndexOf(sep);
            if (pos >= 0) {
                String suffix = title.substring(pos + 1);
                if (isResolutionToken(suffix)) {
                    title = title.substring(0, pos).trim();
                }
            }
        }

        String cleaned = trimEndChars(title, new char[]{'-', ':', '_', '.', ' '}).trim();
        return cleaned.isEmpty() ? rawTitle.trim() : cleaned;
    }

    private static boolean allDigits(String s) {
        if (s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) if (!Character.isDigit(s.charAt(i))) return false;
        return true;
    }

    private static boolean allDigitsOrDash(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!Character.isDigit(c) && c != '-') return false;
        }
        return true;
    }

    private static boolean allDigitsDashOrS(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!Character.isDigit(c) && c != '-' && c != 'S') return false;
        }
        return true;
    }

    private static boolean inRange(String digits, int min, int max) {
        try {
            int v = Integer.parseInt(digits);
            return v >= min && v <= max;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isResolutionToken(String suffix) {
        if (suffix.length() < 2) return false;
        char last = suffix.charAt(suffix.length() - 1);
        if (last != 'p' && last != 'P') return false;
        String digits = suffix.substring(0, suffix.length() - 1);
        return allDigits(digits) && inRange(digits, 144, 8640);
    }

    private static int lastIndexOf(String s, String sub) {
        return s.lastIndexOf(sub);
    }

    private static int lastIndexOfIgnoreCase(String haystack, String needle) {
        return haystack.toLowerCase(Locale.US).lastIndexOf(needle.toLowerCase(Locale.US));
    }

    private static String trimEndChars(String s, char[] chars) {
        int end = s.length();
        outer:
        while (end > 0) {
            char c = s.charAt(end - 1);
            for (char t : chars) {
                if (c == t) { end--; continue outer; }
            }
            break;
        }
        return s.substring(0, end);
    }

    /** Maps a language name/code to a 2-letter ISO code; null when unknown. */
    public static String languageToCode(String name) {
        if (name == null) return null;
        String lower = name.trim().toLowerCase(Locale.US);
        switch (lower) {
            case "english": case "en": case "eng": return "en";
            case "spanish": case "es": case "spa": case "español": case "castellano": return "es";
            case "hindi": case "hi": case "hin": return "hi";
            case "french": case "fr": case "fre": case "fra": case "français": return "fr";
            case "german": case "de": case "ger": case "deu": case "deutsch": return "de";
            case "italian": case "it": case "ita": case "italiano": return "it";
            case "japanese": case "ja": case "jpn": return "ja";
            case "korean": case "ko": case "kor": return "ko";
            case "chinese": case "zh": case "zho": case "chi": case "mandarin": case "cantonese": return "zh";
            case "portuguese": case "pt": case "por": case "português": return "pt";
            case "russian": case "ru": case "rus": return "ru";
            case "arabic": case "ar": case "ara": return "ar";
            case "turkish": case "tr": case "tur": case "türkçe": return "tr";
            case "bengali": case "bn": case "ben": return "bn";
            case "tamil": case "ta": case "tam": return "ta";
            case "telugu": case "te": case "tel": return "te";
            case "malayalam": case "ml": case "mal": return "ml";
            case "kannada": case "kn": case "kan": return "kn";
            case "marathi": case "mr": case "mar": return "mr";
            case "punjabi": case "pa": case "pan": return "pa";
            case "gujarati": case "gu": case "guj": return "gu";
            case "urdu": case "ur": case "urd": return "ur";
            case "indonesian": case "id": case "ind": case "bahasa": return "id";
            case "thai": case "th": case "tha": return "th";
            case "vietnamese": case "vi": case "vie": return "vi";
            case "dutch": case "nl": case "dut": case "nld": case "nederlands": return "nl";
            case "polish": case "pl": case "pol": case "polski": return "pl";
            case "swedish": case "sv": case "swe": case "svenska": return "sv";
            case "danish": case "da": case "dan": case "dansk": return "da";
            case "norwegian": case "no": case "nor": case "norsk": return "no";
            case "finnish": case "fi": case "fin": case "suomi": return "fi";
            case "greek": case "el": case "ell": case "gre": return "el";
            case "hebrew": case "he": case "heb": return "he";
            case "czech": case "cs": case "cze": case "ces": return "cs";
            case "hungarian": case "hu": case "hun": case "magyar": return "hu";
            case "romanian": case "ro": case "rum": case "ron": case "română": return "ro";
            case "ukrainian": case "uk": case "ukr": return "uk";
            case "persian": case "fa": case "fas": case "per": case "فارسی": return "fa";
            case "tagalog": case "tl": case "fil": case "filipino": return "tl";
            case "malay": case "ms": case "msa": case "may": case "melayu": return "ms";
            default: return null;
        }
    }
}
