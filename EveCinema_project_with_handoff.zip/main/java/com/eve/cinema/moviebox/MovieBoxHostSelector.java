package com.eve.cinema.moviebox;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public final class MovieBoxHostSelector {

    public static final List<String> ALLOWED_BASES = Collections.unmodifiableList(Arrays.asList(
            "https://api6.aoneroom.com",
            "https://api5.aoneroom.com",
            "https://api4.aoneroom.com",
            "https://api4sg.aoneroom.com",
            "https://api3.aoneroom.com",
            "https://api6sg.aoneroom.com",
            "https://api.inmoviebox.com"));

    public static final long STATS_TTL_MS = 6L * 60L * 60L * 1000L;
    private static final long PERSIST_INTERVAL_MS = 15_000L;
    private static final long TIMEOUT_SAMPLE_MS = 12_000L;
    private static final double LATENCY_ALPHA = 0.3;
    private static final double SUCCESS_ALPHA = 0.2;

    public interface Clock {
        long nowMs();
    }

    public interface MetricsStore {
        String load();
        void save(String json);
    }

    public enum FailureKind {
        DNS,
        CONNECT,
        TIMEOUT,
        SERVER_5XX,
        RATE_LIMITED,
        BAD_RESPONSE
    }

    private static final Clock SYSTEM_CLOCK = new Clock() {
        @Override public long nowMs() {
            return System.currentTimeMillis();
        }
    };

    private final Clock clock;
    private final MetricsStore store;
    private final Random random;
    private final Map<String, Map<String, HostStats>> statsByNetwork =
            new LinkedHashMap<>();

    private String networkKey = "unknown";
    private long fallbackCount;
    private String lastSuccessHost;
    private long lastSuccessTimeMs;
    private long lastPersistMs;
    private boolean hasPersisted;

    public MovieBoxHostSelector() {
        this(null, null, null);
    }

    public MovieBoxHostSelector(Clock clock, MetricsStore store, Random random) {
        this.clock = clock == null ? SYSTEM_CLOCK : clock;
        this.store = store;
        this.random = random == null ? new Random() : random;
        load();
    }

    public static boolean isAllowed(String base) {
        return base != null && base.startsWith("https://") && ALLOWED_BASES.contains(base);
    }

    public synchronized List<String> candidates(boolean allowExploration) {
        dropExpired();
        long now = clock.nowMs();
        final Map<String, HostStats> networkStats = statsFor(networkKey, false);
        List<String> healthy = new ArrayList<>();
        List<String> cooling = new ArrayList<>();
        for (String base : ALLOWED_BASES) {
            HostStats stats = networkStats == null ? null : networkStats.get(base);
            if (stats == null || stats.cooldownUntilMs <= now) healthy.add(base);
            else cooling.add(base);
        }
        Collections.sort(healthy, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                return Double.compare(score(a, networkStats), score(b, networkStats));
            }
        });
        Collections.sort(cooling, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                HostStats sa = networkStats.get(a);
                HostStats sb = networkStats.get(b);
                int cooldownOrder = Long.compare(sa.cooldownUntilMs, sb.cooldownUntilMs);
                return cooldownOrder != 0 ? cooldownOrder
                        : Integer.compare(ALLOWED_BASES.indexOf(a), ALLOWED_BASES.indexOf(b));
            }
        });
        List<String> result = new ArrayList<>(healthy.size() + cooling.size());
        result.addAll(healthy);
        result.addAll(cooling);

        if (allowExploration && healthy.size() > 1 && random.nextDouble() < 0.1) {
            String oldest = null;
            long oldestAt = Long.MAX_VALUE;
            for (String base : healthy) {
                HostStats stats = networkStats == null ? null : networkStats.get(base);
                long updated = stats == null ? Long.MIN_VALUE : stats.lastUpdatedMs;
                if (oldest == null || updated < oldestAt) {
                    oldest = base;
                    oldestAt = updated;
                }
            }
            if (oldest != null && !oldest.equals(result.get(0))
                    && successEstimate(oldest, networkStats) >= 0.5) {
                result.remove(oldest);
                result.add(0, oldest);
            }
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void recordSuccess(String base, long latencyMs) {
        requireAllowed(base);
        long now = clock.nowMs();
        HostStats stats = getStats(networkKey, base, now);
        double measuredLatency = Math.max(0, latencyMs);
        stats.latencyEwmaMs = stats.samples == 0 ? measuredLatency
                : ewma(stats.latencyEwmaMs, measuredLatency, LATENCY_ALPHA);
        stats.successEwma = stats.samples == 0 ? 1.0
                : ewma(stats.successEwma, 1.0, SUCCESS_ALPHA);
        stats.samples++;
        stats.consecutiveFailures = 0;
        stats.cooldownUntilMs = 0;
        stats.lastFailureKind = null;
        stats.lastUpdatedMs = now;
        stats.lastSuccessMs = now;
        lastSuccessHost = base;
        lastSuccessTimeMs = now;
        persistIfDue();
    }

    public synchronized void recordFailure(String base, FailureKind kind, long retryAfterMs) {
        requireAllowed(base);
        if (kind == null) throw new IllegalArgumentException("kind");
        long now = clock.nowMs();
        HostStats stats = getStats(networkKey, base, now);
        stats.successEwma = stats.samples == 0 ? 0.0
                : ewma(stats.successEwma, 0.0, SUCCESS_ALPHA);
        if (kind == FailureKind.TIMEOUT) {
            stats.latencyEwmaMs = stats.samples == 0 ? TIMEOUT_SAMPLE_MS
                    : ewma(stats.latencyEwmaMs, TIMEOUT_SAMPLE_MS, LATENCY_ALPHA);
        }
        stats.samples++;
        stats.consecutiveFailures++;
        stats.lastFailureKind = kind;
        stats.lastUpdatedMs = now;
        if (kind == FailureKind.DNS) {
            stats.cooldownUntilMs = now + 10L * 60L * 1000L;
        } else if (kind == FailureKind.RATE_LIMITED) {
            long requested = retryAfterMs <= 0 ? 5_000L : retryAfterMs;
            stats.cooldownUntilMs = now + Math.max(2_000L, Math.min(requested, 60_000L));
        } else if (stats.consecutiveFailures >= 2) {
            long cooldown = 30_000L;
            for (int i = 2; i < stats.consecutiveFailures && cooldown < 600_000L; i++) {
                cooldown = Math.min(cooldown * 2L, 600_000L);
            }
            stats.cooldownUntilMs = now + cooldown;
        }
        persistIfDue();
    }

    public synchronized void onNetworkChanged(String networkKey) {
        String nextKey = normalizeNetworkKey(networkKey);
        boolean changedNetwork = !this.networkKey.equals(nextKey);
        this.networkKey = nextKey;
        if (!changedNetwork) return;
        Map<String, HostStats> networkStats = statsFor(nextKey, false);
        boolean changed = false;
        if (networkStats != null) {
            for (HostStats stats : networkStats.values()) {
                if (stats.lastFailureKind == FailureKind.DNS
                        || stats.lastFailureKind == FailureKind.CONNECT
                        || stats.lastFailureKind == FailureKind.TIMEOUT) {
                    if (stats.cooldownUntilMs != 0) {
                        stats.cooldownUntilMs = 0;
                        changed = true;
                    }
                }
            }
        }
        if (changed) persistIfDue();
    }

    public synchronized void recordFallback() {
        fallbackCount++;
    }

    public synchronized Diagnostics snapshot() {
        List<String> ordered = candidates(false);
        List<HostDiagnostics> hosts = new ArrayList<>(ALLOWED_BASES.size());
        long now = clock.nowMs();
        Map<String, HostStats> networkStats = statsFor(networkKey, false);
        for (String base : ALLOWED_BASES) {
            HostStats stats = networkStats == null ? null : networkStats.get(base);
            if (stats == null) {
                hosts.add(new HostDiagnostics(base, 0, 90, 0, 0, -1));
            } else {
                long latency = stats.samples == 0 ? 0
                        : Math.round(stats.latencyEwmaMs / 10.0) * 10L;
                int successPct = stats.samples == 0 ? 90
                        : (int) Math.round(stats.successEwma * 100.0);
                long cooldown = Math.max(0L, stats.cooldownUntilMs - now);
                long successAge = stats.lastSuccessMs == 0 ? -1
                        : Math.max(0L, now - stats.lastSuccessMs);
                hosts.add(new HostDiagnostics(base, latency, successPct, stats.samples,
                        cooldown, successAge));
            }
        }
        return new Diagnostics(networkKey, ordered.isEmpty() ? null : ordered.get(0),
                fallbackCount, lastSuccessHost, hosts);
    }

    public synchronized void flush() {
        if (store != null) {
            store.save(serialize());
            lastPersistMs = clock.nowMs();
            hasPersisted = true;
        }
    }

    private void load() {
        if (store == null) return;
        try {
            String json = store.load();
            if (json == null || json.trim().isEmpty()) return;
            JSONObject root = new JSONObject(json);
            if (root.optInt("v", -1) != 1) return;
            JSONArray entries = root.optJSONArray("entries");
            if (entries == null) return;
            for (int i = 0; i < entries.length(); i++) {
                JSONObject entry = entries.optJSONObject(i);
                if (entry == null) continue;
                String base = entry.optString("b", "");
                if (!isAllowed(base)) continue;
                String key = normalizeNetworkKey(entry.optString("k", "unknown"));
                HostStats stats = new HostStats();
                stats.latencyEwmaMs = Math.max(0, entry.optDouble("l", 0));
                stats.successEwma = clamp(entry.optDouble("s", 0.9), 0.0, 1.0);
                stats.samples = Math.max(0, entry.optInt("n", 0));
                stats.consecutiveFailures = Math.max(0, entry.optInt("c", 0));
                stats.cooldownUntilMs = Math.max(0, entry.optLong("cu", 0));
                String failureKind = entry.optString("fk", "");
                try {
                    stats.lastFailureKind = FailureKind.valueOf(failureKind);
                } catch (IllegalArgumentException ignored) {}
                stats.lastUpdatedMs = Math.max(0, entry.optLong("u", 0));
                stats.lastSuccessMs = Math.max(0, entry.optLong("su", 0));
                if (stats.lastSuccessMs > 0 && (lastSuccessHost == null
                        || stats.lastSuccessMs > lastSuccessTimeMs)) {
                    lastSuccessHost = base;
                    lastSuccessTimeMs = stats.lastSuccessMs;
                }
                statsByNetwork.computeIfAbsent(key, unused -> new LinkedHashMap<String, HostStats>())
                        .put(base, stats);
            }
        } catch (Exception ignored) {}
    }

    private void dropExpired() {
        long now = clock.nowMs();
        boolean removed = false;
        for (Map<String, HostStats> networkStats : statsByNetwork.values()) {
            List<String> expired = new ArrayList<>();
            for (Map.Entry<String, HostStats> entry : networkStats.entrySet()) {
                HostStats stats = entry.getValue();
                if (stats.samples > 0 && now - stats.lastUpdatedMs > STATS_TTL_MS) {
                    expired.add(entry.getKey());
                }
            }
            for (String base : expired) {
                networkStats.remove(base);
                removed = true;
            }
        }
        if (removed) persistIfDue();
    }

    private double score(String base, Map<String, HostStats> networkStats) {
        HostStats stats = networkStats == null ? null : networkStats.get(base);
        double latency = stats == null || stats.samples == 0
                ? 1_500.0 + 25.0 * ALLOWED_BASES.indexOf(base) : stats.latencyEwmaMs;
        double success = stats == null || stats.samples == 0 ? 0.9 : stats.successEwma;
        return latency + (1.0 - success) * 4_000.0;
    }

    private double successEstimate(String base, Map<String, HostStats> networkStats) {
        HostStats stats = networkStats == null ? null : networkStats.get(base);
        return stats == null || stats.samples == 0 ? 0.9 : stats.successEwma;
    }

    private HostStats getStats(String key, String base, long now) {
        Map<String, HostStats> networkStats = statsFor(key, true);
        HostStats stats = networkStats.get(base);
        if (stats == null) {
            stats = new HostStats();
            stats.lastUpdatedMs = now;
            networkStats.put(base, stats);
        }
        return stats;
    }

    private Map<String, HostStats> statsFor(String key, boolean create) {
        Map<String, HostStats> stats = statsByNetwork.get(key);
        if (stats == null && create) {
            stats = new LinkedHashMap<>();
            statsByNetwork.put(key, stats);
        }
        return stats;
    }

    private void persistIfDue() {
        if (store == null) return;
        long now = clock.nowMs();
        if (!hasPersisted || now - lastPersistMs >= PERSIST_INTERVAL_MS) {
            store.save(serialize());
            lastPersistMs = now;
            hasPersisted = true;
        }
    }

    private String serialize() {
        JSONObject root = new JSONObject();
        JSONArray entries = new JSONArray();
        try {
            root.put("v", 1);
            for (Map.Entry<String, Map<String, HostStats>> network : statsByNetwork.entrySet()) {
                for (Map.Entry<String, HostStats> host : network.getValue().entrySet()) {
                    HostStats stats = host.getValue();
                    JSONObject entry = new JSONObject();
                    entry.put("k", network.getKey());
                    entry.put("b", host.getKey());
                    entry.put("l", stats.latencyEwmaMs);
                    entry.put("s", stats.successEwma);
                    entry.put("n", stats.samples);
                    entry.put("c", stats.consecutiveFailures);
                    entry.put("cu", stats.cooldownUntilMs);
                    if (stats.lastFailureKind != null)
                        entry.put("fk", stats.lastFailureKind.name());
                    entry.put("u", stats.lastUpdatedMs);
                    entry.put("su", stats.lastSuccessMs);
                    entries.put(entry);
                }
            }
            root.put("entries", entries);
        } catch (Exception ignored) {}
        return root.toString();
    }

    private static double ewma(double previous, double sample, double alpha) {
        return previous * (1.0 - alpha) + sample * alpha;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(value, max));
    }

    private static String normalizeNetworkKey(String key) {
        if ("wifi".equals(key) || "cellular".equals(key) || "ethernet".equals(key)
                || "vpn".equals(key)) return key;
        return "unknown";
    }

    private static void requireAllowed(String base) {
        if (!isAllowed(base)) throw new IllegalArgumentException("Unapproved MovieBox API base");
    }

    public static final class Diagnostics {
        public final String networkKey;
        public final String preferredBase;
        public final long fallbackCount;
        public final String lastSuccessHost;
        public final List<HostDiagnostics> hosts;

        private Diagnostics(String networkKey, String preferredBase, long fallbackCount,
                            String lastSuccessHost, List<HostDiagnostics> hosts) {
            this.networkKey = networkKey;
            this.preferredBase = preferredBase;
            this.fallbackCount = fallbackCount;
            this.lastSuccessHost = lastSuccessHost;
            this.hosts = Collections.unmodifiableList(new ArrayList<>(hosts));
        }

        @Override public String toString() {
            StringBuilder out = new StringBuilder(256);
            out.append("MovieBoxHosts{network=").append(networkKey)
                    .append(", preferred=").append(preferredBase)
                    .append(", fallbacks=").append(fallbackCount)
                    .append(", lastSuccess=").append(lastSuccessHost)
                    .append(", hosts=[");
            for (int i = 0; i < hosts.size(); i++) {
                if (i > 0) out.append(';');
                HostDiagnostics host = hosts.get(i);
                out.append(host.base).append(':').append(host.latencyMs).append("ms/")
                        .append(host.successPct).append("%/n").append(host.samples)
                        .append("/cooldown=").append(host.cooldownRemainingMs)
                        .append("/successAge=").append(host.lastSuccessAgeMs);
            }
            return out.append("]}").toString();
        }
    }

    public static final class HostDiagnostics {
        public final String base;
        public final long latencyMs;
        public final int successPct;
        public final int samples;
        public final long cooldownRemainingMs;
        public final long lastSuccessAgeMs;

        private HostDiagnostics(String base, long latencyMs, int successPct, int samples,
                                long cooldownRemainingMs, long lastSuccessAgeMs) {
            this.base = base;
            this.latencyMs = latencyMs;
            this.successPct = successPct;
            this.samples = samples;
            this.cooldownRemainingMs = cooldownRemainingMs;
            this.lastSuccessAgeMs = lastSuccessAgeMs;
        }
    }

    private static final class HostStats {
        double latencyEwmaMs;
        double successEwma = 0.9;
        int samples;
        int consecutiveFailures;
        long cooldownUntilMs;
        FailureKind lastFailureKind;
        long lastUpdatedMs;
        long lastSuccessMs;
    }
}
