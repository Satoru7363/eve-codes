package com.eve.cinema.moviebox;

import java.io.IOException;

public final class TransportException extends IOException {

    private static final long serialVersionUID = 1L;

    public enum Phase {
        BEFORE_SEND,
        AFTER_SEND
    }

    public final Phase phase;
    public final MovieBoxHostSelector.FailureKind kind;

    public TransportException(String message, Phase phase,
                              MovieBoxHostSelector.FailureKind kind, Throwable cause) {
        super(message, cause);
        this.phase = phase;
        this.kind = kind;
    }

    public TransportException(String message, Phase phase,
                              MovieBoxHostSelector.FailureKind kind) {
        this(message, phase, kind, null);
    }
}
