package com.eve.cinema.moviebox;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.eve.cinema.moviebox.MovieBoxModels.SeasonInfo;

/**
 * Explicit TMDB → MovieBox season/episode mapping. TMDB and MovieBox frequently
 * disagree for anime (single long MovieBox season with absolute numbering,
 * split cours, specials). The mapper never guesses: when the evidence is
 * ambiguous it returns null and the caller fails safely.
 */
public final class MovieBoxEpisodeMapper {

    private MovieBoxEpisodeMapper() {}

    public enum Confidence { EXACT, ABSOLUTE, SPLIT_COUR, VERIFIED_BY_STREAM }

    public static final class MappingException extends Exception {
        public enum Reason {
            NO_SEASON_EVIDENCE,
            EPISODE_NOT_LISTED,
            AMBIGUOUS,
            INCOMPLETE_EPISODE_LIST,
            SPECIALS_UNMAPPED,
            INVALID_INPUT
        }

        public final Reason reason;

        MappingException(Reason reason, String message) {
            super(message);
            this.reason = reason;
        }
    }

    public static final class Mapping {
        public final int season;
        public final int episode;
        public final Confidence confidence;
        public final String evidence;
        Mapping(int season, int episode, Confidence c, String evidence) {
            this.season = season; this.episode = episode; this.confidence = c; this.evidence = evidence;
        }
    }

    /**
     * @param tmdbSeasonCounts TMDB episode_count per season_number (may be null/empty);
     *                         required for absolute and split-cour mappings.
     */
    public static Mapping map(int tmdbSeason, int tmdbEpisode, List<SeasonInfo> mbSeasons,
                              Map<Integer, Integer> tmdbSeasonCounts) throws MappingException {
        if (tmdbEpisode <= 0 || tmdbSeason < 0)
            throw failure(MappingException.Reason.INVALID_INPUT, "Invalid TMDB season/episode");
        if (mbSeasons == null || mbSeasons.isEmpty())
            throw failure(MappingException.Reason.NO_SEASON_EVIDENCE,
                    "MovieBox season-info unavailable");

        SeasonInfo same = find(mbSeasons, tmdbSeason);
        // "MovieBox S2 == TMDB S2" is only trusted when no EARLIER MovieBox season
        // swallowed episodes that TMDB files under later seasons (e.g. MovieBox S1
        // lists 47 episodes while TMDB S1 has 24): then MovieBox's numbering is
        // shifted and a same-numbered entry is a coincidence, not evidence.
        boolean aligned = precedingSeasonsAligned(tmdbSeason, mbSeasons, tmdbSeasonCounts);
        if (aligned && same != null && !same.episodes.isEmpty()
                && same.episodes.contains(tmdbEpisode)) {
            return new Mapping(tmdbSeason, tmdbEpisode, Confidence.EXACT,
                    "MovieBox S" + tmdbSeason + " lists E" + tmdbEpisode);
        }
        if (tmdbSeason == 0)
            throw failure(MappingException.Reason.SPECIALS_UNMAPPED,
                    "TMDB specials are not listed by MovieBox");

        int absolute = absoluteEpisode(tmdbSeason, tmdbEpisode, tmdbSeasonCounts);
        if (absolute <= 0) {
            if (same != null && same.episodes.isEmpty())
                throw failure(MappingException.Reason.NO_SEASON_EVIDENCE,
                        "MovieBox season has no episode list");
            throw failure(MappingException.Reason.AMBIGUOUS,
                    "TMDB season counts are insufficient for absolute numbering");
        }

        List<SeasonInfo> regular = new ArrayList<>();
        for (SeasonInfo s : mbSeasons) if (s.seasonNumber > 0) regular.add(s);
        Collections.sort(regular, (a, b) -> Integer.compare(a.seasonNumber, b.seasonNumber));

        if (regular.size() == 1 && tmdbSeason > 1) {
            SeasonInfo only = regular.get(0);
            if (!isComplete(only))
                throw failure(MappingException.Reason.INCOMPLETE_EPISODE_LIST,
                        "MovieBox episode list is incomplete");
            if (only.episodes.contains(absolute)) {
                return new Mapping(only.seasonNumber, absolute, Confidence.ABSOLUTE,
                        "TMDB S" + tmdbSeason + "E" + tmdbEpisode + " = absolute E" + absolute
                        + " in single MovieBox season " + only.seasonNumber);
            }
            throw failure(MappingException.Reason.EPISODE_NOT_LISTED,
                    "MovieBox does not list absolute episode " + absolute);
        }

        int before = 0;
        for (SeasonInfo s : regular) {
            if (!isComplete(s))
                throw failure(MappingException.Reason.INCOMPLETE_EPISODE_LIST,
                        "MovieBox S" + s.seasonNumber + " episode list is incomplete");
            int count = Collections.max(s.episodes);
            if (absolute <= before + count) {
                int ep = absolute - before;
                if (!s.episodes.contains(ep))
                    throw failure(MappingException.Reason.EPISODE_NOT_LISTED,
                            "MovieBox does not list the mapped episode");
                if (aligned && s.seasonNumber == tmdbSeason && ep == tmdbEpisode)
                    throw failure(MappingException.Reason.EPISODE_NOT_LISTED,
                            "MovieBox numbering does not establish a split-cour mapping");
                return new Mapping(s.seasonNumber, ep, Confidence.SPLIT_COUR,
                        "absolute E" + absolute + " falls in MovieBox S" + s.seasonNumber + "E" + ep);
            }
            before += count;
        }
        throw failure(MappingException.Reason.EPISODE_NOT_LISTED,
                "MovieBox does not list the mapped episode");
    }

    /**
     * False when an earlier MovieBox season is LARGER than the TMDB season of the same
     * number — proof that MovieBox merged later TMDB seasons into it. Unknown counts or a
     * missing earlier MovieBox season cannot disprove alignment, so they keep the
     * explicit listing (no behaviour change without evidence).
     */
    static boolean precedingSeasonsAligned(int tmdbSeason, List<SeasonInfo> mbSeasons,
                                           Map<Integer, Integer> tmdbSeasonCounts) {
        if (tmdbSeason <= 1 || tmdbSeasonCounts == null || tmdbSeasonCounts.isEmpty()) return true;
        for (int s = 1; s < tmdbSeason; s++) {
            Integer tmdbCount = tmdbSeasonCounts.get(s);
            SeasonInfo mb = find(mbSeasons, s);
            if (tmdbCount == null || tmdbCount <= 0 || mb == null || mb.episodes.isEmpty()) continue;
            if (Collections.max(mb.episodes) > tmdbCount) return false;
        }
        return true;
    }

    /** True only for a unique contiguous list of episode numbers from 1 to max. */
    public static boolean isComplete(SeasonInfo season) {
        if (season == null || season.episodes == null || season.episodes.isEmpty()) return false;
        int max = 0;
        java.util.HashSet<Integer> seen = new java.util.HashSet<>();
        for (Integer episode : season.episodes) {
            if (episode == null || episode <= 0 || !seen.add(episode)) return false;
            max = Math.max(max, episode);
        }
        return seen.size() == max;
    }

    /** Sum of TMDB episodes of seasons 1..season-1 plus episode; -1 if unknown. */
    public static int absoluteEpisode(int season, int episode, Map<Integer, Integer> counts) {
        if (season <= 1) return season == 1 ? episode : -1;
        if (counts == null) return -1;
        int total = 0;
        for (int s = 1; s < season; s++) {
            Integer c = counts.get(s);
            if (c == null || c <= 0) return -1;
            total += c;
        }
        return total + episode;
    }

    private static SeasonInfo find(List<SeasonInfo> seasons, int number) {
        for (SeasonInfo s : seasons) if (s.seasonNumber == number) return s;
        return null;
    }

    private static MappingException failure(MappingException.Reason reason, String message) {
        return new MappingException(reason, message);
    }
}
