package com.eve.cinema.moviebox;

/**
 * Small self-contained Base64 codec (standard alphabet).
 *
 * Written specifically so the MovieBox core stays testable on a plain JVM:
 * android.util.Base64 is unavailable in local unit tests and java.util.Base64
 * requires API 26+, while Eve's minSdk is lower.
 */
final class MovieBoxBase64 {

    private static final char[] ALPHABET =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();

    private MovieBoxBase64() {}

    /** Standard Base64 encoding with '=' padding. */
    static String encode(byte[] data) {
        StringBuilder out = new StringBuilder((data.length + 2) / 3 * 4);
        for (int i = 0; i < data.length; i += 3) {
            int b0 = data[i] & 0xFF;
            int b1 = (i + 1 < data.length) ? data[i + 1] & 0xFF : -1;
            int b2 = (i + 2 < data.length) ? data[i + 2] & 0xFF : -1;

            out.append(ALPHABET[b0 >>> 2]);
            out.append(ALPHABET[((b0 & 0x03) << 4) | (b1 < 0 ? 0 : (b1 >>> 4))]);
            out.append(b1 < 0 ? '=' : ALPHABET[((b1 & 0x0F) << 2) | (b2 < 0 ? 0 : (b2 >>> 6))]);
            out.append(b2 < 0 ? '=' : ALPHABET[b2 & 0x3F]);
        }
        return out.toString();
    }

    /**
     * Decodes standard or URL-safe Base64, with or without padding.
     * Returns null on malformed input (mirrors the Rust `.ok()` semantics).
     */
    static byte[] decode(String s) {
        if (s == null) return null;
        // Normalize URL-safe variants to the standard alphabet, then re-pad.
        StringBuilder norm = new StringBuilder(s.length() + 4);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '-') norm.append('+');
            else if (c == '_') norm.append('/');
            else norm.append(c);
        }
        int pad = (4 - norm.length() % 4) % 4;
        for (int i = 0; i < pad; i++) norm.append('=');

        int[] table = new int[128];
        java.util.Arrays.fill(table, -1);
        for (int i = 0; i < ALPHABET.length; i++) table[ALPHABET[i]] = i;

        String t = norm.toString();
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(t.length() * 3 / 4);
        int acc = 0;
        int bits = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c == '=') break;
            if (c >= 128 || table[c] < 0) return null; // invalid character
            acc = (acc << 6) | table[c];
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                out.write((acc >>> bits) & 0xFF);
            }
        }
        return out.toByteArray();
    }
}
