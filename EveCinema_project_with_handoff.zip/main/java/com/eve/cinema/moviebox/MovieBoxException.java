package com.eve.cinema.moviebox;

/**
 * Error categories for the MovieBox provider. Arabic user-facing messages match
 * the tone of the existing CinemaBox error strings in Eve.
 */
public class MovieBoxException extends Exception {

    public enum Kind {
        TITLE_NOT_FOUND,
        EPISODE_UNAVAILABLE,
        EPISODE_MAPPING_UNVERIFIED,
        NETWORK,
        API_STATUS,
        REGION_UNAVAILABLE,
        SESSION,
        NO_SOURCE,
        INVALID_SOURCE,
        PARSE
    }

    public final Kind kind;
    public final int httpStatus;
    public final boolean hasCarrierCode;

    public MovieBoxException(Kind kind, String message) {
        this(kind, message, 0, null, false);
    }

    public MovieBoxException(Kind kind, String message, int httpStatus) {
        this(kind, message, httpStatus, null, false);
    }

    public MovieBoxException(Kind kind, String message, Throwable cause) {
        this(kind, message, 0, cause, false);
    }

    public MovieBoxException(Kind kind, String message, boolean hasCarrierCode) {
        this(kind, message, 0, null, hasCarrierCode);
    }

    public MovieBoxException(Kind kind, String message, int httpStatus, Throwable cause) {
        this(kind, message, httpStatus, cause, false);
    }

    private MovieBoxException(Kind kind, String message, int httpStatus, Throwable cause,
                              boolean hasCarrierCode) {
        super(message, cause);
        this.kind = kind;
        this.httpStatus = httpStatus;
        this.hasCarrierCode = hasCarrierCode;
    }

    /** Concise Arabic message suitable for Eve's resolve-error overlay. */
    public String userMessage() {
        switch (kind) {
            case TITLE_NOT_FOUND:    return "لم يُعثر على العنوان في MovieBox";
            case EPISODE_UNAVAILABLE:return "الموسم/الحلقة غير متاحة في MovieBox";
            case EPISODE_MAPPING_UNVERIFIED:
                return "تعذر التحقق من رقم الحلقة في MovieBox؛ جرّب المصدر 2";
            case NETWORK:            return "تعذّر الوصول إلى خوادم MovieBox — تحقق من الشبكة";
            case REGION_UNAVAILABLE:
                return hasCarrierCode ? "MovieBox غير متاح في منطقتك حالياً"
                        : "تعذر تحديد منطقة الجهاز لخدمة MovieBox؛ استخدم المصدر 2";
            case SESSION:            return "فشل إنشاء جلسة MovieBox";
            case NO_SOURCE:          return "لا توجد روابط بث متاحة من MovieBox";
            case INVALID_SOURCE:     return "روابط MovieBox غير صالحة للتشغيل";
            case PARSE:              return "استجابة MovieBox غير مفهومة";
            case API_STATUS:
            default:                 return "خطأ من MovieBox" + (httpStatus > 0 ? " (" + httpStatus + ")" : "");
        }
    }
}
