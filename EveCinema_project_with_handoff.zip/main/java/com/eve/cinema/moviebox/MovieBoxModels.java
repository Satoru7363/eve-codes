/*
 * Derived from MovieBox-Tui (Rust) — upstream dual-licensed MIT / Apache-2.0.
 * Upstream copyright retained. See NOTICE at the project root for the full
 * license texts and attribution scope.
 */
package com.eve.cinema.moviebox;

/*
 * Data models for the MovieBox provider. Adapted from MovieBox-Tui
 * (src/providers/models.rs and src/providers/moviebox/adapt.rs) — MIT/Apache-2.0,
 * see NOTICE. Only the fields Eve actually consumes are kept.
 */

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class MovieBoxModels {

    private MovieBoxModels() {}

    /** One MovieBox search subject. */
    public static final class SubjectItem {
        public String subjectId;
        public String title;
        public boolean isSeries;   // subjectType == 2
        public String year;        // 4-digit or ""
        public String posterUrl;   // may be null
        public int seasonCount;    // 0 when unknown
    }

    /** One season of a series subject. */
    public static final class SeasonInfo {
        public int seasonNumber;
        public List<Integer> episodes = new ArrayList<>(); // episode numbers (1-based)
    }

    /**
     * One playable stream from play-info/v2. A single DASH stream legitimately
     * covers all of {@link #resolutions}; for plain MP4 entries only the top
     * declared resolution is advertised (no fabricated quality URLs).
     */
    public static final class StreamSource {
        public String streamId;          // may be null; used as resourceId for captions
        public String url;               // playable URL (manifest or file), never a notice URL
        public String codec;             // may be null
        public String format;            // e.g. "MP4"
        public long sizeBytes;           // 0 when unknown
        /** Provider-reported runtime in seconds; 0 when not supplied. */
        public long durationSeconds;
        public List<Integer> resolutions = new ArrayList<>(); // sorted desc
        public final Map<String, String> headers = new LinkedHashMap<>(); // playback headers
        public int season;               // 0 for movies
        public int episode;              // 0 for movies
        /** Audio language of this release when documented (e.g. "ar" for a dub subject); null = original/unknown. */
        public String audioLanguage;
        /** MovieBox subject that produced this stream (differs from Playback.subjectId for dub releases). */
        public String releaseSubjectId;
        /** True only when the API item explicitly documents the requested season and episode. */
        public boolean numberingFromResponse;
        /** Captions fetched for this exact resource id (get-ext-captions). */
        public List<SubtitleOption> subtitles = new ArrayList<>();
        /** True when captions have been requested for this resource, including an empty result. */
        public boolean captionsResolved;

        public boolean isDash() {
            String u = url == null ? "" : url.split("\\?")[0];
            return u.endsWith(".mpd") || u.contains("/dash/");
        }

        public boolean isHls() {
            return url != null && url.split("\\?")[0].endsWith(".m3u8");
        }

        /** Adaptive manifests expose their real renditions through Media3 tracks. */
        public boolean isAdaptive() { return isDash() || isHls(); }

        /** Highest declared resolution, or 0 when the API did not declare one. */
        public int topResolution() {
            return resolutions.isEmpty() ? 0 : resolutions.get(0);
        }

        public boolean hasKnownResolution() { return topResolution() > 0; }

        public String qualityLabel() {
            return hasKnownResolution() ? topResolution() + "p" : "جودة غير معروفة";
        }
    }

    /** One external subtitle. */
    public static final class SubtitleOption {
        public String name;
        public String url;
        /** Normalised language ("ar", "en", ...) or null when unknown. */
        public String languageCode;
        public String resourceId;
        public String subjectId;
        public int season;
        public int episode;
        /** Resource row title/episode/runtime/playability were matched to the selected video. */
        public boolean resourceIdentityVerified;
        /** Headers required to download this subtitle (provider-specific). */
        public final Map<String, String> headers = new LinkedHashMap<>();

        /** Best language evidence: code first, then display name. */
        public String languageEvidence() {
            return languageCode != null && !languageCode.isEmpty() ? languageCode : name;
        }
    }

    /** A MovieBox alternative release from the mixed subject.dubs list (audio or video-sub). */
    public static final class DubOption {
        public String subjectId;
        public String language;
        public String label;
        /** Provider {@code lanCode} exactly as returned; null when absent. */
        public String lanCode;
        /** Provider {@code type} exactly as returned (number rendered as text). */
        public String rawType;

        /** Hint-level classification from provider type, lanCode and labels. */
        public MovieBoxReleaseClassifier.Result classification() {
            return MovieBoxReleaseClassifier.classifyProviderRelease(
                    lanCode, rawType, language, label);
        }
    }

    /**
     * Fully resolved playback for one movie/episode — this is the single
     * contract handed from the resolver layer to PlayerActivity as JSON.
     */
    public static final class Playback {
        /** Active release subject: the MovieBox subject whose streams play now.
         *  For a dub release this is the DUB subject id, not the base work id. */
        public String subjectId;
        /** Original/canonical work subject id. Null or equal to subjectId when
         *  the active release IS the canonical work. Never overwritten when a
         *  dub release is activated. */
        public String canonicalSubjectId;
        public String title;
        public boolean isSeries;
        /** True only after an explicitly subtitle-labelled MovieBox video release is resolved. */
        public boolean inVideoSubtitleRelease;
        /** Whether subject.dubs metadata was fetched successfully; empty may be a valid result. */
        public boolean dubsResolved;
        public int season;   // 0 for movies
        public int episode;  // 0 for movies
        public List<StreamSource> streams = new ArrayList<>();
        public List<SubtitleOption> subtitles = new ArrayList<>();
        public List<DubOption> dubs = new ArrayList<>();
        /** Requested TMDB numbering (season/episode above are MovieBox numbering). */
        public int tmdbSeason;
        public int tmdbEpisode;
        public Map<Integer, Integer> tmdbSeasonCounts = new LinkedHashMap<>();
        public String mappingConfidence;
        public String mappingEvidence;
        /** Audio language of the whole playback when it is a documented dub release. */
        public String audioLanguage;
        /** Non-null when one or more get-ext-captions calls failed (diagnostics). */
        public String captionsError;
        /** How this RELEASE was chosen (label, season claim, subtitle verification). */
        public String releaseEvidence;

        /** Canonical work identity: the base subject even while a dub release plays. */
        public String canonicalSubjectId() {
            return canonicalSubjectId != null && !canonicalSubjectId.isEmpty()
                    ? canonicalSubjectId : subjectId;
        }

        /** Active release identity: the subject whose streams are playing now. */
        public String activeSubjectId() {
            return subjectId;
        }

        /** True when {@code id} is the canonical work, the active release, or a
         *  documented sibling/dub release of this work (subject.dubs). */
        public boolean isKnownSibling(String id) {
            if (id == null || id.isEmpty()) return false;
            if (id.equals(subjectId) || id.equals(canonicalSubjectId())) return true;
            for (DubOption d : dubs) {
                if (d != null && id.equals(d.subjectId)) return true;
            }
            return false;
        }

        /** Explicitly documented sibling: the canonical work id (when set) or a subject.dubs entry. */
        public boolean isDocumentedSibling(String id) {
            if (id == null || id.isEmpty()) return false;
            if (canonicalSubjectId != null && !canonicalSubjectId.isEmpty()
                    && id.equals(canonicalSubjectId)) return true;
            for (DubOption d : dubs) {
                if (d != null && id.equals(d.subjectId)) return true;
            }
            return false;
        }

        /** Captions resolved for this exact stream only. */
        public List<SubtitleOption> subtitlesFor(StreamSource s) {
            return s != null && s.subtitles != null ? s.subtitles
                    : java.util.Collections.<SubtitleOption>emptyList();
        }

        /**
         * A caption must belong to the active release subject. A documented sibling
         * with the same title/runtime can still be a different cut or audio mix, so
         * it is never used as a substitute. Within the active subject, exact IDs are
         * direct association; alternate rows require verified metadata. Neither path
         * proves cue synchronization; the player keeps external timing unverified.
         */
        public static boolean belongsTo(SubtitleOption o, StreamSource s, Playback p) {
            if (o == null || s == null || p == null) return false;
            String expectedSubject = s.releaseSubjectId != null
                    ? s.releaseSubjectId : p.subjectId;
            boolean sameEpisode = o.season == s.season && o.episode == s.episode;
            return MovieBoxCaptionResourcePolicy.belongsTo(expectedSubject, p.subjectId,
                    s.streamId, o.subjectId, o.resourceId, sameEpisode,
                    p.isDocumentedSibling(o.subjectId), o.resourceIdentityVerified);
        }

        /**
         * True when at least one selectable caption was fetched for THIS release's
         * own subject and belongs to the stream it is attached to. Captions borrowed
         * from a sibling release do not count — they prove nothing about this release.
         */
        public boolean hasOwnSelectableSubtitles() {
            for (StreamSource s : streams) {
                if (s == null || s.subtitles == null) continue;
                String own = s.releaseSubjectId != null ? s.releaseSubjectId : subjectId;
                for (SubtitleOption o : s.subtitles) {
                    if (o != null && o.url != null && !o.url.isEmpty()
                            && own != null && own.equals(o.subjectId)
                            && belongsTo(o, s, this)) return true;
                }
            }
            return false;
        }

        /**
         * A documented release that the metadata labels as an Arabic DUB. Only an explicit
         * dub marker qualifies: an Arabic-subtitle release, a bare "Arabic" label, or
         * conflicting metadata (see {@link MovieBoxReleaseClassifier}) is never returned.
         * This is a hint — the audio is verified separately (manifest / verifyDubRelease).
         */
        public DubOption arabicDub() {
            for (DubOption d : dubs) {
                if (d == null || d.subjectId == null || d.subjectId.isEmpty()) continue;
                if (subjectId != null && subjectId.equals(d.subjectId)) continue;
                if (d.classification().kind == MovieBoxReleaseClassifier.Kind.ARABIC_DUB) return d;
            }
            return null;
        }

        /** A distinct playable video-release candidate; not a get-ext-captions file. */
        public DubOption arabicSubtitleRelease() {
            for (DubOption d : dubs) {
                if (d == null || d.subjectId == null || d.subjectId.isEmpty()) continue;
                if (subjectId != null && subjectId.equals(d.subjectId)) continue;
                if (d.classification().kind == MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE)
                    return d;
            }
            return null;
        }

        public JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("subjectId", subjectId);
                if (canonicalSubjectId != null && !canonicalSubjectId.isEmpty()
                        && !canonicalSubjectId.equals(subjectId))
                    o.put("canonicalSubjectId", canonicalSubjectId);
                o.put("title", title);
                o.put("isSeries", isSeries);
                o.put("inVideoSubtitleRelease", inVideoSubtitleRelease);
                o.put("dubsResolved", dubsResolved);
                o.put("season", season);
                o.put("episode", episode);
                JSONArray ss = new JSONArray();
                for (StreamSource s : streams) {
                    JSONObject so = new JSONObject();
                    so.put("url", s.url);
                    if (s.streamId != null) so.put("streamId", s.streamId);
                    if (s.codec != null) so.put("codec", s.codec);
                    so.put("format", s.format == null ? "MP4" : s.format);
                    so.put("size", s.sizeBytes);
                    so.put("durationSeconds", s.durationSeconds);
                    so.put("season", s.season);
                    so.put("episode", s.episode);
                    so.put("numberingFromResponse", s.numberingFromResponse);
                    so.put("captionsResolved", s.captionsResolved);
                    JSONArray res = new JSONArray();
                    for (Integer r : s.resolutions) res.put(r.intValue());
                    so.put("resolutions", res);
                    JSONObject h = new JSONObject();
                    for (Map.Entry<String, String> e : s.headers.entrySet())
                        h.put(e.getKey(), e.getValue());
                    so.put("headers", h);
                    if (s.audioLanguage != null) so.put("audioLanguage", s.audioLanguage);
                    if (s.releaseSubjectId != null) so.put("releaseSubjectId", s.releaseSubjectId);
                    so.put("subtitles", subsToJson(s.subtitles));
                    ss.put(so);
                }
                o.put("streams", ss);
                JSONArray dj = new JSONArray();
                for (DubOption d : dubs) {
                    JSONObject dobj = new JSONObject();
                    dobj.put("subjectId", d.subjectId);
                    dobj.put("language", d.language);
                    dobj.put("label", d.label);
                    if (d.lanCode != null) dobj.put("lanCode", d.lanCode);
                    if (d.rawType != null) dobj.put("rawType", d.rawType);
                    dj.put(dobj);
                }
                o.put("dubs", dj);
                o.put("tmdbSeason", tmdbSeason);
                o.put("tmdbEpisode", tmdbEpisode);
                JSONObject counts = new JSONObject();
                for (Map.Entry<Integer, Integer> e : tmdbSeasonCounts.entrySet())
                    counts.put(String.valueOf(e.getKey()), e.getValue());
                o.put("tmdbSeasonCounts", counts);
                if (mappingConfidence != null) o.put("mappingConfidence", mappingConfidence);
                if (mappingEvidence != null) o.put("mappingEvidence", mappingEvidence);
                if (audioLanguage != null) o.put("audioLanguage", audioLanguage);
                if (captionsError != null) o.put("captionsError", captionsError);
                if (releaseEvidence != null) o.put("releaseEvidence", releaseEvidence);
            } catch (Exception ignored) {}
            return o;
        }

        private static JSONArray subsToJson(List<SubtitleOption> list) throws org.json.JSONException {
            JSONArray subs = new JSONArray();
            if (list == null) return subs;
            for (SubtitleOption sub : list) {
                JSONObject so = new JSONObject();
                so.put("name", sub.name);
                so.put("url", sub.url);
                if (sub.languageCode != null) so.put("lang", sub.languageCode);
                if (sub.resourceId != null) so.put("resourceId", sub.resourceId);
                if (sub.subjectId != null) so.put("subjectId", sub.subjectId);
                so.put("season", sub.season);
                so.put("episode", sub.episode);
                so.put("resourceIdentityVerified", sub.resourceIdentityVerified);
                JSONObject h = new JSONObject();
                for (Map.Entry<String, String> e : sub.headers.entrySet())
                    h.put(e.getKey(), e.getValue());
                so.put("headers", h);
                subs.put(so);
            }
            return subs;
        }

        private static List<SubtitleOption> subsFromJson(JSONArray subs) {
            List<SubtitleOption> out = new ArrayList<>();
            if (subs == null) return out;
            for (int i = 0; i < subs.length(); i++) {
                JSONObject so = subs.optJSONObject(i);
                if (so == null) continue;
                SubtitleOption sub = new SubtitleOption();
                sub.name = so.optString("name", "");
                sub.url = so.optString("url", "");
                sub.languageCode = so.has("lang") ? so.optString("lang") : null;
                sub.resourceId = so.has("resourceId") ? so.optString("resourceId") : null;
                sub.subjectId = so.has("subjectId") ? so.optString("subjectId") : null;
                sub.season = so.optInt("season", 0);
                sub.episode = so.optInt("episode", 0);
                sub.resourceIdentityVerified = so.optBoolean("resourceIdentityVerified", false);
                JSONObject h = so.optJSONObject("headers");
                if (h != null) {
                    for (java.util.Iterator<String> it = h.keys(); it.hasNext();) {
                        String k = it.next();
                        sub.headers.put(k, h.optString(k, ""));
                    }
                }
                if (!sub.url.isEmpty()) out.add(sub);
            }
            return out;
        }

        public static Playback fromJson(JSONObject o) {
            if (o == null) return null;
            try {
                Playback p = new Playback();
                p.subjectId = o.optString("subjectId", "");
                p.canonicalSubjectId = o.has("canonicalSubjectId")
                        ? o.optString("canonicalSubjectId") : null;
                p.title = o.optString("title", "");
                p.isSeries = o.optBoolean("isSeries", false);
                p.inVideoSubtitleRelease = o.optBoolean("inVideoSubtitleRelease", false);
                p.dubsResolved = o.optBoolean("dubsResolved", false);
                p.season = o.optInt("season", 0);
                p.episode = o.optInt("episode", 0);
                JSONArray ss = o.optJSONArray("streams");
                if (ss != null) {
                    for (int i = 0; i < ss.length(); i++) {
                        JSONObject so = ss.optJSONObject(i);
                        if (so == null) continue;
                        StreamSource s = new StreamSource();
                        s.url = so.optString("url", "");
                        if (s.url.isEmpty()) continue;
                        s.streamId = so.has("streamId") ? so.optString("streamId") : null;
                        s.codec = so.has("codec") ? so.optString("codec") : null;
                        s.format = so.optString("format", "MP4");
                        s.sizeBytes = so.optLong("size", 0);
                        s.durationSeconds = so.optLong("durationSeconds", 0);
                        s.season = so.optInt("season", 0);
                        s.episode = so.optInt("episode", 0);
                        s.numberingFromResponse = so.optBoolean("numberingFromResponse", false);
                        s.captionsResolved = so.optBoolean("captionsResolved", false);
                        JSONArray res = so.optJSONArray("resolutions");
                        if (res != null) {
                            for (int j = 0; j < res.length(); j++)
                                s.resolutions.add(res.optInt(j));
                        }
                        JSONObject h = so.optJSONObject("headers");
                        if (h != null) {
                            for (java.util.Iterator<String> it = h.keys(); it.hasNext();) {
                                String k = it.next();
                                s.headers.put(k, h.optString(k, ""));
                            }
                        }
                        s.audioLanguage = so.has("audioLanguage") ? so.optString("audioLanguage") : null;
                        s.releaseSubjectId = so.has("releaseSubjectId") ? so.optString("releaseSubjectId") : null;
                        s.subtitles = subsFromJson(so.optJSONArray("subtitles"));
                        p.streams.add(s);
                    }
                }
                p.subtitles = subsFromJson(o.optJSONArray("subtitles"));
                JSONArray dj = o.optJSONArray("dubs");
                if (dj != null) {
                    for (int i = 0; i < dj.length(); i++) {
                        JSONObject d = dj.optJSONObject(i);
                        if (d == null) continue;
                        DubOption dub = new DubOption();
                        dub.subjectId = d.optString("subjectId", "");
                        dub.language = d.optString("language", "");
                        dub.label = d.optString("label", "");
                        dub.lanCode = d.has("lanCode") ? d.optString("lanCode") : null;
                        dub.rawType = d.has("rawType") ? d.optString("rawType") : null;
                        p.dubs.add(dub);
                    }
                }
                p.tmdbSeason = o.optInt("tmdbSeason", p.season);
                p.tmdbEpisode = o.optInt("tmdbEpisode", p.episode);
                JSONObject counts = o.optJSONObject("tmdbSeasonCounts");
                if (counts != null) {
                    for (java.util.Iterator<String> it = counts.keys(); it.hasNext();) {
                        String key = it.next();
                        try { p.tmdbSeasonCounts.put(Integer.parseInt(key), counts.optInt(key)); }
                        catch (NumberFormatException ignored) {}
                    }
                }
                p.mappingConfidence = o.has("mappingConfidence") ? o.optString("mappingConfidence") : null;
                p.mappingEvidence = o.has("mappingEvidence") ? o.optString("mappingEvidence") : null;
                p.audioLanguage = o.has("audioLanguage") ? o.optString("audioLanguage") : null;
                p.captionsError = o.has("captionsError") ? o.optString("captionsError") : null;
                p.releaseEvidence = o.has("releaseEvidence") ? o.optString("releaseEvidence") : null;
                return p;
            } catch (Exception e) {
                return null;
            }
        }
    }
}
