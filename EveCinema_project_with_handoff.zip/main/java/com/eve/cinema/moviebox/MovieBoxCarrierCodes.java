package com.eve.cinema.moviebox;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public final class MovieBoxCarrierCodes {

    private static final Map<String, String> CODES;

    static {
        Map<String, String> codes = new LinkedHashMap<>();
        codes.put("IQ", "41820");
        codes.put("AE", "42402");
        codes.put("SA", "42001");
        codes.put("EG", "60202");
        codes.put("IN", "40401");
        codes.put("ID", "51010");
        codes.put("JO", "41601");
        codes.put("KW", "41902");
        codes.put("QA", "42701");
        codes.put("BH", "42601");
        codes.put("OM", "42202");
        codes.put("LB", "41501");
        codes.put("SY", "41701");
        codes.put("YE", "42101");
        codes.put("PS", "42505");
        codes.put("LY", "60600");
        codes.put("TN", "60502");
        codes.put("DZ", "60301");
        codes.put("MA", "60400");
        codes.put("SD", "63401");
        codes.put("TR", "28601");
        codes.put("PK", "41001");
        codes.put("IR", "43211");
        codes.put("MY", "50212");
        codes.put("PH", "51502");
        codes.put("NG", "62130");
        codes.put("KE", "63902");
        codes.put("DE", "26201");
        codes.put("FR", "20801");
        codes.put("BD", "47001");
        codes.put("TH", "52001");
        codes.put("VN", "45201");
        codes.put("BR", "72405");
        CODES = Collections.unmodifiableMap(codes);
    }

    private MovieBoxCarrierCodes() {}

    public static String forCountry(String countryIso) {
        if (countryIso == null) return "";
        String code = CODES.get(countryIso.toUpperCase(Locale.US));
        return code == null ? "" : code;
    }

    public static String countryForTimezone(String tzId) {
        if (tzId == null) return "";
        switch (tzId) {
            case "Asia/Baghdad": return "IQ";
            case "Asia/Dubai": return "AE";
            case "Asia/Riyadh": return "SA";
            case "Africa/Cairo": return "EG";
            case "Asia/Kolkata":
            case "Asia/Calcutta": return "IN";
            case "Asia/Jakarta":
            case "Asia/Makassar":
            case "Asia/Jayapura":
            case "Asia/Pontianak": return "ID";
            case "Asia/Amman": return "JO";
            case "Asia/Kuwait": return "KW";
            case "Asia/Qatar": return "QA";
            case "Asia/Bahrain": return "BH";
            case "Asia/Muscat": return "OM";
            case "Asia/Beirut": return "LB";
            case "Asia/Damascus": return "SY";
            case "Asia/Aden": return "YE";
            case "Asia/Gaza":
            case "Asia/Hebron": return "PS";
            case "Africa/Tripoli": return "LY";
            case "Africa/Tunis": return "TN";
            case "Africa/Algiers": return "DZ";
            case "Africa/Casablanca":
            case "Africa/El_Aaiun": return "MA";
            case "Africa/Khartoum": return "SD";
            case "Europe/Istanbul":
            case "Asia/Istanbul": return "TR";
            case "Asia/Karachi": return "PK";
            case "Asia/Tehran": return "IR";
            case "Asia/Kuala_Lumpur":
            case "Asia/Kuching": return "MY";
            case "Asia/Manila": return "PH";
            case "Africa/Lagos": return "NG";
            case "Africa/Nairobi": return "KE";
            case "Europe/Berlin": return "DE";
            case "Europe/Paris": return "FR";
            case "Asia/Dhaka": return "BD";
            case "Asia/Bangkok": return "TH";
            case "Asia/Ho_Chi_Minh":
            case "Asia/Saigon": return "VN";
            case "America/Sao_Paulo": return "BR";
            default: return "";
        }
    }
}
