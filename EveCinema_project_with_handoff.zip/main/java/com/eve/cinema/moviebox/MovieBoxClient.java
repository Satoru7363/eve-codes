/*
 * Derived from MovieBox-Tui (Rust) — upstream dual-licensed MIT / Apache-2.0.
 * Upstream copyright retained. See NOTICE at the project root for the full
 * license texts and attribution scope.
 */
package com.eve.cinema.moviebox;

/*
 * Ported from MovieBox-Tui (src/providers/moviebox/client.rs and the endpoint
 * methods in src/providers/moviebox/mod.rs). MovieBox-Tui is dual-licensed
 * MIT / Apache-2.0; see NOTICE.
 *
 * reqwest is replaced by HttpURLConnection because that is the networking
 * stack the Eve app already uses (no OkHttp dependency exists in the project).
 */

import org.json.JSONObject;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeoutException;

/**
 * MovieBox API client: visitor session lifecycle, host pool rotation with
 * retry, and signed GET/POST requests. All methods are blocking — call them
 * off the Android main thread (Eve resolves on background threads already).
 */
public final class MovieBoxClient {

    private static final int CONNECT_TIMEOUT_MS = 3_000;
    private static final int READ_TIMEOUT_MS    = 12_000;
    private static final int MAX_ATTEMPTS = 4;
    private static final long REQUEST_DEADLINE_MS = 25_000L;
    private static final long LOGIN_FAILURE_THROTTLE_MS = 3_000L;

    private static final String LOGIN_PATH = "/wefeed-mobile-bff/user-api/visitor-login";

    public interface FallbackListener {
        void onFallback(String base, String diagnostics);
    }

    /** Persistence hook wired up by MovieBoxBridge on Android. */
    public interface SessionStore {
        MovieBoxSession load();
        void save(MovieBoxSession session);
        void clear();
    }

    private volatile MovieBoxSession session;
    private final Object sessionLock = new Object();

    private final MovieBoxIdentity identity;
    private final MovieBoxHostSelector selector;
    private final Transport transport;
    private final Random random = new Random();
    private volatile SessionStore sessionStore;
    private volatile FallbackListener fallbackListener;
    private long lastLoginFailureAtMs = Long.MIN_VALUE;
    private MovieBoxException lastLoginFailure;

    public MovieBoxClient() {
        this(emptyIdentity(), new MovieBoxHostSelector(), new HttpUrlTransport());
    }

    public MovieBoxClient(MovieBoxIdentity identity, MovieBoxHostSelector selector,
                          Transport transport) {
        this.identity = identity == null ? emptyIdentity() : identity;
        this.selector = selector == null ? new MovieBoxHostSelector() : selector;
        this.transport = transport == null ? new HttpUrlTransport() : transport;
    }

    private static MovieBoxIdentity emptyIdentity() {
        return MovieBoxIdentity.build("", "", "", "", "", "", "", "", "", "");
    }

    public void setSessionStore(SessionStore store) {
        this.sessionStore = store;
    }

    public void setFallbackListener(FallbackListener listener) {
        this.fallbackListener = listener;
    }

    public String userAgent() {
        return identity.userAgent;
    }

    // ── Session lifecycle (client.rs ensure_session) ─────────

    public String ensureSession() throws MovieBoxException {
        return ensureSession(System.nanoTime() + REQUEST_DEADLINE_MS * 1_000_000L);
    }

    private String ensureSession(long deadlineNanos) throws MovieBoxException {
        MovieBoxSession current = session;
        if (current != null && current.isValid()) return current.token;

        SessionStore store = sessionStore;
        if (store != null) {
            try {
                MovieBoxSession persisted = store.load();
                if (persisted != null && persisted.isValid()) {
                    session = persisted;
                    return persisted.token;
                }
            } catch (Exception ignored) {}
        }

        synchronized (sessionLock) {
            current = session;
            if (current != null && current.isValid()) return current.token;

            long now = System.currentTimeMillis();
            if (lastLoginFailure != null && now >= lastLoginFailureAtMs
                    && now - lastLoginFailureAtMs < LOGIN_FAILURE_THROTTLE_MS) {
                throw lastLoginFailure;
            }
            try {
                MovieBoxSession fresh = fetchFreshSession(deadlineNanos);
                session = fresh;
                lastLoginFailure = null;
                lastLoginFailureAtMs = Long.MIN_VALUE;
                if (store != null) {
                    try { store.save(fresh); } catch (Exception ignored) {}
                }
                return fresh.token;
            } catch (MovieBoxException e) {
                lastLoginFailure = e;
                lastLoginFailureAtMs = System.currentTimeMillis();
                throw e;
            }
        }
    }

    private MovieBoxSession fetchFreshSession(long deadlineNanos) throws MovieBoxException {
        JSONObject val = request("POST", LOGIN_PATH, "{}", false, false, deadlineNanos);
        String token = val.optString("token", "").trim();
        if (token.isEmpty())
            throw new MovieBoxException(MovieBoxException.Kind.SESSION, "Missing token");
        String uid = optStringOrNumber(val, "uid");
        if (uid == null) uid = optStringOrNumber(val, "userId");
        return MovieBoxSession.fromTokenAndPayload(token, uid);
    }

    private static String optStringOrNumber(JSONObject obj, String key) {
        Object v = obj.opt(key);
        if (v instanceof String && !((String) v).isEmpty()) return (String) v;
        if (v instanceof Number) return String.valueOf(v);
        return null;
    }

    public void invalidateSession() {
        synchronized (sessionLock) {
            session = null;
            clearStoredSession();
        }
    }

    private void invalidateSession(String rejectedToken) {
        synchronized (sessionLock) {
            MovieBoxSession current = session;
            if (current != null && rejectedToken.equals(current.token)) {
                session = null;
                clearStoredSession();
            }
        }
    }

    private void clearStoredSession() {
        SessionStore store = sessionStore;
        if (store != null) {
            try { store.clear(); } catch (Exception ignored) {}
        }
    }

    /** client.rs absorb_x_user — the server can rotate the token via header. */
    private void absorbXUser(Transport.Response response) {
        try {
            String xUser = response.header("x-user");
            if (xUser == null || xUser.isEmpty()) return;
            JSONObject json = new JSONObject(xUser);
            String token = json.optString("token", "");
            if (token.isEmpty()) return;
            String uid = optStringOrNumber(json, "uid");
            if (uid == null) uid = optStringOrNumber(json, "userId");
            MovieBoxSession rotated = MovieBoxSession.fromTokenAndPayload(token, uid);
            session = rotated;
            SessionStore store = sessionStore;
            if (store != null) {
                try { store.save(rotated); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    // ── HTTP core ────────────────────────────────────────────

    private JSONObject get(String pathAndQuery) throws MovieBoxException {
        return request("GET", pathAndQuery, null, true, true);
    }

    private JSONObject post(String pathAndQuery, String body) throws MovieBoxException {
        return request("POST", pathAndQuery, body, true, true);
    }

    private JSONObject request(String method, String pathAndQuery, String body,
                               boolean idempotent, boolean authed) throws MovieBoxException {
        return request(method, pathAndQuery, body, idempotent, authed,
                System.nanoTime() + REQUEST_DEADLINE_MS * 1_000_000L);
    }

    private JSONObject request(String method, String pathAndQuery, String body,
                               boolean idempotent, boolean authed, long deadlineNanos)
            throws MovieBoxException {
        if (!authed) {
            return requestHosts(method, pathAndQuery, body, idempotent, false, null,
                    deadlineNanos);
        }
        String token = ensureSession(deadlineNanos);
        try {
            return requestHosts(method, pathAndQuery, body, idempotent, true, token,
                    deadlineNanos);
        } catch (MovieBoxException e) {
            boolean tokenProblem = e.kind == MovieBoxException.Kind.API_STATUS
                    && (e.httpStatus == 401 || e.httpStatus == 403);
            if (!tokenProblem) throw e;
            invalidateSession(token);
            String freshToken = ensureSession(deadlineNanos);
            return requestHosts(method, pathAndQuery, body, idempotent, true, freshToken,
                    deadlineNanos);
        }
    }

    private JSONObject requestHosts(String method, String pathAndQuery, String body,
                                    boolean idempotent, boolean authed, String authToken,
                                    long deadlineNanos)
            throws MovieBoxException {
        List<String> candidates = selector.candidates(idempotent);
        int attempts = Math.min(MAX_ATTEMPTS, candidates.size());
        int lastStatus = 0;
        Throwable lastError = null;

        for (int i = 0; i < attempts; i++) {
            if (Thread.currentThread().isInterrupted()) {
                throw new MovieBoxException(MovieBoxException.Kind.NETWORK, "Interrupted");
            }
            if (i > 0) {
                long remainingMs = (deadlineNanos - System.nanoTime()) / 1_000_000L;
                if (remainingMs <= 0) break;
                long backoffMs = 100L + random.nextInt(201);
                try { Thread.sleep(Math.min(backoffMs, remainingMs)); }
                catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new MovieBoxException(MovieBoxException.Kind.NETWORK, "Interrupted", ie);
                }
                if (Thread.currentThread().isInterrupted()) {
                    throw new MovieBoxException(MovieBoxException.Kind.NETWORK, "Interrupted");
                }
            }
            if (System.nanoTime() >= deadlineNanos) break;
            String base = candidates.get(i);
            if (!MovieBoxHostSelector.isAllowed(base)) {
                throw new IllegalArgumentException("Unapproved MovieBox API base");
            }
            if (i > 0) {
                selector.recordFallback();
                FallbackListener listener = fallbackListener;
                if (listener != null) {
                    try {
                        listener.onFallback(base, selector.snapshot().toString());
                    } catch (RuntimeException ignored) {}
                }
            }
            String url = base + pathAndQuery;
            Map<String, String> headers = MovieBoxSigner.buildSignedHeaders(
                    method, url, body, authed ? authToken : null,
                    identity.userAgent, identity.clientInfo);
            long remainingMs = (deadlineNanos - System.nanoTime()) / 1_000_000L;
            if (remainingMs <= 0) break;
            int connectTimeoutMs = (int) Math.min(CONNECT_TIMEOUT_MS, remainingMs);
            int readTimeoutMs = (int) Math.min(READ_TIMEOUT_MS,
                    Math.max(1L, remainingMs - connectTimeoutMs));
            long startedNanos = System.nanoTime();
            try {
                Transport.Response response = transport.execute(method, url, headers, body,
                        connectTimeoutMs, readTimeoutMs);
                long completedNanos = System.nanoTime();
                long latencyMs = Math.max(0L, (completedNanos - startedNanos) / 1_000_000L);
                absorbXUser(response);
                int status = response.status;
                lastStatus = status;
                if (completedNanos >= deadlineNanos) {
                    selector.recordFailure(base, MovieBoxHostSelector.FailureKind.TIMEOUT, 0);
                    lastError = new TimeoutException("MovieBox request deadline exceeded");
                    continue;
                }

                if (status >= 200 && status < 300) {
                    JSONObject parsed;
                    try {
                        parsed = new JSONObject(response.body);
                    } catch (Exception parseError) {
                        selector.recordFailure(base,
                                MovieBoxHostSelector.FailureKind.BAD_RESPONSE, 0);
                        lastError = parseError;
                        if (idempotent) continue;
                        throw new MovieBoxException(MovieBoxException.Kind.PARSE,
                                "Invalid MovieBox response", parseError);
                    }
                    if (isRegionResponse(parsed)) throw regionUnavailable();
                    selector.recordSuccess(base, latencyMs);
                    return unwrapData(parsed);
                }

                if (status == 403 && isRegionResponse(response.body)) {
                    throw regionUnavailable();
                }
                if (status == 429) {
                    selector.recordFailure(base, MovieBoxHostSelector.FailureKind.RATE_LIMITED,
                            retryAfterMs(response));
                    if (idempotent) continue;
                    throw apiStatus(status, response.body);
                }
                if (isRetryableServerError(status)) {
                    selector.recordFailure(base, MovieBoxHostSelector.FailureKind.SERVER_5XX, 0);
                    if (idempotent) continue;
                    throw apiStatus(status, response.body);
                }
                throw apiStatus(status, response.body);
            } catch (MovieBoxException e) {
                throw e;
            } catch (TransportException e) {
                selector.recordFailure(base, e.kind, 0);
                lastError = e;
                if (idempotent || e.phase == TransportException.Phase.BEFORE_SEND) {
                    continue;
                }
                throw new MovieBoxException(MovieBoxException.Kind.NETWORK,
                        "MovieBox request failed after sending", e);
            }
        }

        throw new MovieBoxException(MovieBoxException.Kind.NETWORK,
                "All hosts unavailable", lastStatus, lastError);
    }

    private static JSONObject unwrapData(JSONObject body) throws MovieBoxException {
        if (!body.has("data")) return body;
        Object data = body.opt("data");
        if (data instanceof JSONObject) return (JSONObject) data;
        JSONObject wrapped = new JSONObject();
        try {
            wrapped.put("data", data);
        } catch (Exception e) {
            throw new MovieBoxException(MovieBoxException.Kind.PARSE,
                    "Invalid MovieBox data", e);
        }
        return wrapped;
    }

    private MovieBoxException regionUnavailable() {
        return new MovieBoxException(MovieBoxException.Kind.REGION_UNAVAILABLE,
                "Service not available in current region", identity.hasCarrierCode);
    }

    private static boolean isRegionResponse(JSONObject response) {
        try {
            return response.optInt("code") == 403
                    && response.optString("message", "")
                    .contains("Service not available in current region");
        } catch (Exception ignored) {}
        return false;
    }

    private static boolean isRegionResponse(String body) {
        try {
            return isRegionResponse(new JSONObject(body));
        } catch (Exception ignored) {
            return false;
        }
    }

    private static boolean isRetryableServerError(int status) {
        return status == 500 || status == 502 || status == 503 || status == 504;
    }

    private static MovieBoxException apiStatus(int status, String body) {
        return new MovieBoxException(MovieBoxException.Kind.API_STATUS,
                apiStatusMessage(status, body), status);
    }

    private static String apiStatusMessage(int status, String body) {
        String prefix = "HTTP " + status;
        if (body == null || body.isEmpty()) return prefix;
        try {
            Object value = new JSONObject(body).opt("message");
            if (!(value instanceof String)) return prefix;
            String message = (String) value;
            if (message.isEmpty()) return prefix;
            return prefix + ": " + message.substring(0, Math.min(200, message.length()));
        } catch (Exception ignored) {
            return prefix;
        }
    }

    private static long retryAfterMs(Transport.Response response) {
        String value = response.header("Retry-After");
        if (value == null) return 0;
        try {
            long seconds = Long.parseLong(value.trim());
            if (seconds <= 0) return 0;
            return seconds > 60 ? 60_000L : seconds * 1_000L;
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    // ── Public API endpoints (mod.rs) ────────────────────────

    /** POST /wefeed-mobile-bff/subject-api/search/v2 */
    public JSONObject search(String query, int page) throws MovieBoxException {
        // serde_json's default map orders keys; replicate for a stable,
        // byte-exact signed body.
        String body = "{\"keyword\":" + JSONObject.quote(query)
                + ",\"page\":" + page + ",\"perPage\":15,\"subjectType\":0}";
        return post("/wefeed-mobile-bff/subject-api/search/v2", body);
    }

    /**
     * GET /wefeed-mobile-bff/subject-api/get?subjectId=...
     * For series (subjectType==2) also merges season-info into "seasons".
     */
    public JSONObject getDetails(String subjectId) throws MovieBoxException {
        JSONObject details = get("/wefeed-mobile-bff/subject-api/get?subjectId=" + subjectId);

        JSONObject subject = MovieBoxParser.detailsSubject(details);
        if (MovieBoxParser.detailsIsSeries(subject)) {
            try {
                JSONObject seasonInfo =
                        get("/wefeed-mobile-bff/subject-api/season-info?subjectId=" + subjectId);
                // Merge where the parser actually looks: on the subject object
                // (the Rust code inserts at the data level, which its own
                // adapter never reads — that path is a no-op there).
                subject.put("seasons", seasonInfo);
            } catch (Exception ignored) {}
        }
        return details;
    }

    /** GET /wefeed-mobile-bff/subject-api/play-info/v2 */
    public JSONObject getPlayInfo(String subjectId, int season, int episode)
            throws MovieBoxException {
        String path = (season == 0 && episode == 0)
                ? "/wefeed-mobile-bff/subject-api/play-info/v2?subjectId=" + subjectId
                : "/wefeed-mobile-bff/subject-api/play-info/v2?subjectId=" + subjectId
                        + "&se=" + season + "&ep=" + episode;
        return get(path);
    }

    /** GET /wefeed-mobile-bff/subject-api/resource (one page). */
    public JSONObject getResources(String subjectId, int season, int episode, int page,
                                   Integer resolution, int perPage) throws MovieBoxException {
        StringBuilder sb = new StringBuilder("/wefeed-mobile-bff/subject-api/resource?subjectId=")
                .append(subjectId);
        if (!(season == 0 && episode == 0)) {
            sb.append("&se=").append(season).append("&ep=").append(episode);
        }
        sb.append("&page=").append(page).append("&perPage=").append(perPage);
        if (resolution != null && resolution > 0) sb.append("&resolution=").append(resolution);
        return get(sb.toString());
    }

    /** GET /wefeed-mobile-bff/subject-api/get-ext-captions */
    public JSONObject getExtCaptions(String subjectId, String resourceId)
            throws MovieBoxException {
        return get("/wefeed-mobile-bff/subject-api/get-ext-captions?subjectId=" + subjectId
                + "&resourceId=" + resourceId);
    }
}
