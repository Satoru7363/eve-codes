package com.eve.cinema.moviebox;

/** Pure page-order policy for MovieBox episode resource lookup. */
public final class MovieBoxSubtitleResourcePlanner {
    private MovieBoxSubtitleResourcePlanner() {}

    /**
     * MovieBox has returned both global episode paging and season/episode-filtered
     * paging in observed integrations. Probe the expected global page first, then
     * page 1 as a safe fallback; the caller follows each response's has-more chain.
     */
    public static int[] pageOrder(int episode) {
        int primary = episode > 0 ? (episode - 1) / 20 + 1 : 1;
        return primary == 1 ? new int[]{1} : new int[]{primary, 1};
    }
}
