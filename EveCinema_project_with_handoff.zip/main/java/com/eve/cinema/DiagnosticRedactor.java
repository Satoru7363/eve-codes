package com.eve.cinema;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Redaction helpers shared by the local diagnostic recorder and its Logcat trace sink. */
public final class DiagnosticRedactor {
    private static final String MASK = "[REDACTED]";
    private static final Pattern QUERY_PARAMETER = Pattern.compile("(?i)([?&;])([^=?&;\\s\\\"'<>#]+)=([^&;\\s\\\"'<>#]*)");
    private static final Pattern COOKIE_HEADER = Pattern.compile("(?im)(^|[\\r\\n])([ \\t]*(?:cookie|set-cookie)[ \\t]*:[ \\t]*)([^\\r\\n]+)");
    private static final Pattern COOKIE_MAP = Pattern.compile("(?i)(\\b(?:cookie|set-cookie)\\b\\s*=\\s*)([^,}\\]]+)");
    private static final Pattern KEY_VALUE = Pattern.compile(
            "(?i)([\\\"']?)([A-Za-z0-9_.%/-]+)([\\\"']?\\s*[:=]\\s*)(\\\"(?:\\\\\\.|[^\\\"\\\\])*\\\"|'(?:\\\\.|[^'\\\\])*'|(?:Bearer|Basic)\\s+[^\\s,;&}\\]]+|[^\\s,;&}\\]]+)");
    private static final Pattern INLINE_AUTH_HEADER = Pattern.compile(
            "(?i)(\\b(?:proxy[-_]?authorization|authorization)\\s*[:=]\\s*)(?:(?:Bearer|Basic)\\s+)?[A-Za-z0-9._~+/=-]+");
    private static final Pattern INLINE_COOKIE_HEADER = Pattern.compile(
            "(?i)(\\b(?:cookie|set-cookie)\\s*[:=]\\s*)(?:\\\"(?:\\\\\\.|[^\\\"\\\\])*\\\"|'(?:\\\\.|[^'\\\\])*'|[^\\r\\n\\\"'}\\]]+)");
    private static final Pattern XML_SECRET = Pattern.compile("(?is)(<\\s*([A-Za-z0-9_.:-]+)[^>]*>)(.*?)(</\\s*\\2\\s*>)");
    private static final Pattern AUTH_SCHEME = Pattern.compile("(?i)\\b(?:Bearer|Basic)\\s+[A-Za-z0-9._~+/=-]+");
    private static final Pattern JWT = Pattern.compile("\\beyJ[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{5,}\\b");

    private DiagnosticRedactor() {}

    /** Redacts sensitive key/value material while retaining ordinary diagnostic text. */
    public static String redactText(String input) {
        if (input == null || input.isEmpty()) return input;
        String value = input;
        value = redactQueryParameters(value);
        value = redactCookieHeaderLines(value);
        value = replaceSensitivePairs(COOKIE_MAP, value, true);
        value = replaceSensitivePairs(KEY_VALUE, value, false);
        value = INLINE_AUTH_HEADER.matcher(value).replaceAll("$1" + MASK);
        value = INLINE_COOKIE_HEADER.matcher(value).replaceAll("$1" + MASK);
        value = redactXmlElements(value);
        value = AUTH_SCHEME.matcher(value).replaceAll(MASK);
        value = JWT.matcher(value).replaceAll(MASK);
        return value;
    }

    private static String redactCookieHeaderLines(String input) {
        Matcher m = COOKIE_HEADER.matcher(input);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            m.appendReplacement(out, Matcher.quoteReplacement(m.group(1) + m.group(2) + MASK));
        }
        m.appendTail(out);
        return out.toString();
    }

    /** Summarize header names only; never stringify or persist header values. */
    public static String headerSummary(Object headers) {
        if (!(headers instanceof Map)) return "header values omitted; unstructured header container";
        List<String> names = new ArrayList<>();
        for (Object key : ((Map<?, ?>) headers).keySet()) {
            if (key != null) names.add(redactText(String.valueOf(key)));
        }
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        return "header values omitted; names=" + names;
    }

    private static String redactQueryParameters(String input) {
        Matcher m = QUERY_PARAMETER.matcher(input);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            String key = decodeKey(m.group(2));
            String replacement = m.group(1) + m.group(2) + "="
                    + (isSensitiveKey(key) ? MASK : m.group(3));
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        return out.toString();
    }

    private static String replaceSensitivePairs(Pattern pattern, String input, boolean wholeValue) {
        Matcher m = pattern.matcher(input);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            String key;
            String prefix;
            String oldValue;
            if (wholeValue) {
                // Cookie values may contain multiple semicolon-separated name/value pairs.
                prefix = m.group(1);
                key = prefix;
                oldValue = m.group(2);
            } else {
                prefix = m.group(1) + m.group(2) + m.group(3);
                key = m.group(2);
                oldValue = m.group(4);
            }
            boolean jsonValue = !wholeValue && "\"".equals(m.group(1))
                    && m.group(3).trim().startsWith("\":");
            String replacement = isSensitiveKey(key)
                    ? prefix + maskedLike(oldValue, jsonValue) : m.group();
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        return out.toString();
    }

    private static String redactXmlElements(String input) {
        Matcher m = XML_SECRET.matcher(input);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            String replacement = isSensitiveKey(m.group(2))
                    ? m.group(1) + MASK + m.group(4)
                    : m.group(1) + redactXmlElements(m.group(3)) + m.group(4);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        return out.toString();
    }

    private static String maskedLike(String oldValue, boolean jsonValue) {
        if (oldValue == null || oldValue.isEmpty()) return MASK;
        if (oldValue.charAt(0) == '"') return "\"" + MASK + "\"";
        if (oldValue.charAt(0) == '\'') return "'" + MASK + "'";
        // A redacted scalar in a JSON property must remain a JSON value. Quote the
        // marker for numbers/booleans/null instead of emitting bare [REDACTED].
        if (jsonValue) return "\"" + MASK + "\"";
        return MASK;
    }

    private static boolean isSensitiveKey(String key) {
        if (key == null) return false;
        String normalized = key.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        // Recorder metadata; this boolean reports whether the line was sanitized.
        if (normalized.equals("secretsredacted")) return false;
        return normalized.equals("key") || normalized.equals("auth") || normalized.equals("sig")
                || normalized.contains("authorization") || normalized.contains("cookie")
                || normalized.contains("token") || normalized.contains("apikey")
                || normalized.contains("secret") || normalized.contains("signature")
                || normalized.contains("password") || normalized.contains("passwd")
                || normalized.contains("credential") || normalized.contains("accesskey")
                || normalized.contains("privatekey") || normalized.contains("awsaccesskeyid")
                || normalized.contains("googleaccessid") || normalized.contains("keypairid")
                || normalized.equals("sessionid");
    }

    private static String decodeKey(String key) {
        try { return URLDecoder.decode(key.replace("+", "%2B"), StandardCharsets.UTF_8.name()); }
        catch (Exception ignored) { return key; }
    }
}
