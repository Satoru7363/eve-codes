package com.eve.cinema;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * FirebaseLicenseClient
 * ─────────────────────────────────────────────────────────────────────────────
 * عميل Firebase Realtime Database REST API للقراءة والكتابة المحدودة.
 *
 * العمليات المسموحة من التطبيق (بحسب قواعد الأمان):
 *   READ   — قراءة بيانات كود محدد (يجب معرفة الكود للوصول)
 *   WRITE  — ربط الجهاز (deviceId) فقط عند أول تفعيل
 *   WRITE  — تحديث lastLogin في كل دخول
 *
 * جميع العمليات تعمل في Thread خلفي — لا تُستدعى من Main Thread.
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class FirebaseLicenseClient {

    // ── النتائج ───────────────────────────────────────────────────────────────

    public enum Status {
        VALID,           // الكود صالح ونشط، مرتبط بهذا الجهاز (أو سيُربط الآن)
        UNBOUND,         // الكود صالح لكن لم يُربط بجهاز بعد (أول تفعيل)
        BOUND_OTHER,     // الكود مرتبط بجهاز آخر
        INACTIVE,        // الكود موجود لكن معطّل (active=false)
        BANNED,          // الجهاز أو الكود محظور
        NOT_FOUND,       // الكود غير موجود في Firebase
        NETWORK_ERROR,   // فشل الاتصال بالشبكة
        EXPIRED          // الكود منتهي الصلاحية
    }

    public static class Result {
        public final Status  status;
        public final long    telegramId;
        public final String  username;

        public Result(Status status, long telegramId, String username) {
            this.status     = status;
            this.telegramId = telegramId;
            this.username   = username;
        }

        public static Result of(Status s) { return new Result(s, 0, ""); }
    }

    // ── القراءة من Firebase ───────────────────────────────────────────────────

    /**
     * يجلب بيانات كود محدد من Firebase ويتحقق منه.
     * يعمل في Thread خلفي.
     *
     * @param code     كود التفعيل المُدخَل من المستخدم
     * @param deviceId معرّف الجهاز (SHA-256 hash)
     * @return Result بالحالة والبيانات
     */
    public static Result fetchAndVerify(String code, String deviceId) {
        try {
            String urlStr = Config.FIREBASE_LICENSE_URL + code.toUpperCase().trim() + ".json";
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setRequestProperty("Cache-Control", "no-cache");

            int httpCode = conn.getResponseCode();

            if (httpCode == 404) {
                return Result.of(Status.NOT_FOUND);
            }
            if (httpCode != 200) {
                return Result.of(Status.NETWORK_ERROR);
            }

            BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();

            String body = sb.toString().trim();

            // Firebase يُعيد "null" إذا لم يوجد المسار
            if (body.equals("null") || body.isEmpty()) {
                return Result.of(Status.NOT_FOUND);
            }

            return parseAndVerify(new JSONObject(body), code, deviceId);

        } catch (Exception e) {
            return Result.of(Status.NETWORK_ERROR);
        }
    }

    /**
     * يحلّل بيانات JSON من Firebase ويتحقق من الحالة.
     */
    private static Result parseAndVerify(JSONObject data, String code, String deviceId) {
        try {
            boolean isActive = data.optBoolean("active", true);
            boolean isBanned = data.optBoolean("banned", false);
            String  bound    = data.optString("deviceId", "");
            long    tid      = data.optLong("telegramId", 0);
            String  uname    = data.optString("username", "");
            long    expires  = data.optLong("expiresAt", 0);

            // فحص الحظر
            if (isBanned) return Result.of(Status.BANNED);

            // فحص التفعيل
            if (!isActive) return Result.of(Status.INACTIVE);

            // فحص انتهاء الصلاحية (0 = لا نهاية)
            if (expires > 0 && System.currentTimeMillis() / 1000 > expires) {
                return Result.of(Status.EXPIRED);
            }

            // فحص ربط الجهاز
            if (bound == null || bound.isEmpty()) {
                return new Result(Status.UNBOUND, tid, uname);
            } else if (bound.equalsIgnoreCase(deviceId)) {
                return new Result(Status.VALID, tid, uname);
            } else {
                return Result.of(Status.BOUND_OTHER);
            }

        } catch (Exception e) {
            return Result.of(Status.NETWORK_ERROR);
        }
    }

    // ── ربط الجهاز (أول تفعيل) ───────────────────────────────────────────────

    /**
     * يربط الجهاز بالكود عبر Firebase REST PATCH.
     * يعمل فقط إذا كان deviceId فارغاً في قاعدة البيانات (قواعد الأمان تمنع الكتابة مجدداً).
     * يعمل في Thread خلفي.
     *
     * @return true إذا نجح الربط أو كان مرتبطاً مسبقاً
     */
    public static boolean bindDevice(String code, String deviceId) {
        try {
            String urlStr = Config.FIREBASE_LICENSE_URL + code.toUpperCase().trim() + ".json";
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PATCH");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setDoOutput(true);

            // نرسل فقط deviceId و lastLogin
            JSONObject patch = new JSONObject();
            patch.put("deviceId",  deviceId);
            patch.put("lastLogin", System.currentTimeMillis() / 1000);

            byte[] body = patch.toString().getBytes(StandardCharsets.UTF_8);
            OutputStream os = conn.getOutputStream();
            os.write(body);
            os.close();

            int httpCode = conn.getResponseCode();
            return httpCode >= 200 && httpCode < 300;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * يُحدّث lastLogin فقط (لا يُغيّر deviceId).
     * يُستدعى في كل دخول ناجح.
     * يعمل في Thread خلفي.
     */
    public static void updateLastLogin(String code) {
        try {
            String urlStr = Config.FIREBASE_LICENSE_URL + code.toUpperCase().trim() + ".json";
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PATCH");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.setDoOutput(true);

            JSONObject patch = new JSONObject();
            patch.put("lastLogin", System.currentTimeMillis() / 1000);

            byte[] body = patch.toString().getBytes(StandardCharsets.UTF_8);
            OutputStream os = conn.getOutputStream();
            os.write(body);
            os.close();

            conn.getResponseCode(); // ensure request is sent

        } catch (Exception ignored) {
            // عدم تحديث lastLogin لا يُوقف التطبيق
        }
    }
}
