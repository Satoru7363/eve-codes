package com.eve.cinema;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * EveMessageModel — نموذج بيانات موحّد للمحادثة
 *
 * الإصلاحات:
 * ─────────────────────────────────────────────────────────────────────
 * 1. AtomicLong لـ sIdCounter → thread-safe بالكامل
 * 2. areContentsTheSame أكثر دقة لـ TYPE_EVE_COMBINED
 * 3. حقول protected بدلاً من public raw
 */
public class EveMessageModel {

    public static final int TYPE_USER         = 0;
    public static final int TYPE_EVE          = 1;
    public static final int TYPE_CARD         = 2;
    public static final int TYPE_TYPING       = 3;
    public static final int TYPE_EVE_COMBINED = 4;

    // ── Thread-safe ID ────────────────────────────────────────────────
    private static final AtomicLong sIdCounter = new AtomicLong(System.currentTimeMillis());

    // ── الحقول ───────────────────────────────────────────────────────
    public final long         stableId;
    public final int          type;
    public final String       content;
    public       JSONObject   cardData;
    public       String       mediaType;
    public final long         timestamp;

    public List<JSONObject> cards      = new ArrayList<>();
    public List<String>     cardTypes  = new ArrayList<>();

    // ── Constructors ─────────────────────────────────────────────────

    public EveMessageModel(int type, String content) {
        this.stableId  = sIdCounter.getAndIncrement();
        this.type      = type;
        this.content   = (content != null) ? content : "";
        this.cardData  = null;
        this.mediaType = null;
        this.timestamp = System.currentTimeMillis();
    }

    public EveMessageModel(JSONObject cardData, String mediaType) {
        this.stableId  = sIdCounter.getAndIncrement();
        this.type      = TYPE_CARD;
        this.content   = "";
        this.cardData  = cardData;
        this.mediaType = (mediaType != null) ? mediaType : "movie";
        this.timestamp = System.currentTimeMillis();
    }

    public EveMessageModel(String text, List<JSONObject> cards, List<String> cardTypes) {
        this.stableId  = sIdCounter.getAndIncrement();
        this.type      = TYPE_EVE_COMBINED;
        this.content   = (text != null) ? text : "";
        this.cardData  = null;
        this.mediaType = null;
        this.cards     = (cards != null)     ? cards     : new ArrayList<>();
        this.cardTypes = (cardTypes != null) ? cardTypes : new ArrayList<>();
        this.timestamp = System.currentTimeMillis();
    }

    public static EveMessageModel typing() {
        return new EveMessageModel(TYPE_TYPING, "");
    }

    // ── DiffUtil ─────────────────────────────────────────────────────
    public static class DiffCallback
            extends androidx.recyclerview.widget.DiffUtil.ItemCallback<EveMessageModel> {

        @Override
        public boolean areItemsTheSame(EveMessageModel a, EveMessageModel b) {
            return a.stableId == b.stableId;
        }

        @Override
        public boolean areContentsTheSame(EveMessageModel a, EveMessageModel b) {
            if (a.type != b.type) return false;
            if (a.type == TYPE_TYPING) return true;
            if (!a.content.equals(b.content)) return false;

            if (a.type == TYPE_CARD) {
                String ja = (a.cardData != null) ? a.cardData.toString() : "";
                String jb = (b.cardData != null) ? b.cardData.toString() : "";
                return ja.equals(jb);
            }

            // FIX: مقارنة محتوى البطاقات الفعلي وليس العدد فقط
            if (a.type == TYPE_EVE_COMBINED) {
                if (a.cards.size() != b.cards.size()) return false;
                for (int i = 0; i < a.cards.size(); i++) {
                    String ja = (a.cards.get(i) != null) ? a.cards.get(i).toString() : "";
                    String jb = (b.cards.get(i) != null) ? b.cards.get(i).toString() : "";
                    if (!ja.equals(jb)) return false;
                }
                return true;
            }
            return true;
        }
    }
}
