package com.eve.cinema;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small source switch sheet with fixed user-facing order independent of enum values. */
public final class SourceSwitchSheet extends Dialog {
    public static final int MOVIEBOX = 2, CINEMABOX = 1;
    public interface Listener { void onSourceChosen(int source); }
    private final int current; private final boolean movieBoxAvailable, cinemaBoxAvailable;
    private final String movieBoxReason, cinemaBoxReason; private final Listener listener;
    public SourceSwitchSheet(Context context, int current, boolean movieBoxAvailable, String movieBoxReason,
                             boolean cinemaBoxAvailable, String cinemaBoxReason, Listener listener) {
        super(context, R.style.QualitySheetTheme); this.current = current; this.movieBoxAvailable = movieBoxAvailable;
        this.movieBoxReason = movieBoxReason; this.cinemaBoxAvailable = cinemaBoxAvailable; this.cinemaBoxReason = cinemaBoxReason; this.listener = listener;
    }
    @Override protected void onCreate(android.os.Bundle state) {
        super.onCreate(state); requestWindowFeature(Window.FEATURE_NO_TITLE); float d = getContext().getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(getContext()); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(px(d,22),px(d,20),px(d,22),px(d,20));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xF21B1925); bg.setCornerRadius(px(d,24)); bg.setStroke(px(d,1),0x557D63A6); root.setBackground(bg);
        TextView title = text("تغيير مصدر المشاهدة",18,0xFFFFFFFF,true); title.setGravity(Gravity.CENTER); root.addView(title,lp(-1,-2,0,0,0,px(d,15)));
        root.addView(row("مصدر 1 — MovieBox", movieBoxAvailable, movieBoxReason, current == MOVIEBOX, MOVIEBOX, d));
        root.addView(row("مصدر 2 — CinemaBox", cinemaBoxAvailable, cinemaBoxReason, current == CINEMABOX, CINEMABOX, d));
        TextView cancel = text("إغلاق",14,0xFFB9B3C6,false); cancel.setGravity(Gravity.CENTER); cancel.setPadding(0,px(d,12),0,0); cancel.setOnClickListener(v -> dismiss()); root.addView(cancel);
        setContentView(root); Window w=getWindow(); if(w!=null){w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);w.setGravity(Gravity.BOTTOM);w.setBackgroundDrawableResource(android.R.color.transparent);}
    }
    private View row(String label, boolean available, String reason, boolean selected, int source, float d) {
        LinearLayout row=new LinearLayout(getContext()); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(px(d,15),px(d,14),px(d,15),px(d,14));
        GradientDrawable bg=new GradientDrawable(); bg.setColor(selected?0xFF30283E:(available?0xFF262131:0xFF201E27)); bg.setCornerRadius(px(d,15)); bg.setStroke(px(d,1),selected?0xFF9B6FC4:(available?0x887B61A7:0x443F3B46)); row.setBackground(bg);
        LinearLayout.LayoutParams p=lp(-1,-2,0,0,0,px(d,9)); row.setLayoutParams(p);
        row.addView(text(label,16,available?0xFFFFFFFF:0xFF77727E,true)); String detail=selected?"المصدر الحالي":(available?"متاح للتبديل":(reason==null||reason.isEmpty()?"غير متاح للحلقة الحالية":reason));
        TextView sub=text(detail,12,available?0xFFC9BED9:0xFF7B7681,false); LinearLayout.LayoutParams sp=lp(-1,-2,0,px(d,4),0,0); row.addView(sub,sp);
        row.setEnabled(available && !selected); row.setClickable(available && !selected); row.setFocusable(true); row.setContentDescription(label+". "+detail);
        if(available&&!selected) row.setOnClickListener(v->{dismiss();if(listener!=null)listener.onSourceChosen(source);}); return row;
    }
    private TextView text(String s,int z,int c,boolean b){TextView v=new TextView(getContext());v.setText(s);v.setTextSize(z);v.setTextColor(c);if(b)v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return v;}
    private static LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,b);return p;}
    private static int px(float d,int v){return(int)(d*v+.5f);}
}
