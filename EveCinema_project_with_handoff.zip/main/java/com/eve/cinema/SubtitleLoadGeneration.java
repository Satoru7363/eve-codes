package com.eve.cinema;

import java.util.concurrent.atomic.AtomicLong;

/** Monotonic request-generation token; late results are accepted only for the latest ticket. */
final class SubtitleLoadGeneration {
    private final AtomicLong value = new AtomicLong();
    long next() { return value.incrementAndGet(); }
    void invalidate() { value.incrementAndGet(); }
    boolean isCurrent(long ticket) { return value.get() == ticket; }
}
