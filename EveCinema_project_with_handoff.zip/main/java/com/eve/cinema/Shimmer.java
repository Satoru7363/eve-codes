package com.eve.cinema;

import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import java.util.ArrayList;

/**
 * Shimmer — animator واحد مشترك لكل عناصر الـ skeleton.
 * ────────────────────────────────────────────────────────────────
 * بدل ValueAnimator لكل بطاقة (ينتهي بعشرات الـ callbacks في كل frame)،
 * animator واحد يكتب alpha لقائمة الـ views الحيّة. الـ view يُزال تلقائيًا
 * عند فصله من النافذة، ويتوقف الـ animator ذاتيًا لما تفرغ القائمة.
 */
final class Shimmer {

    private static final ArrayList<View> TARGETS = new ArrayList<>();
    private static ValueAnimator sAnim;
    private static float sValue = 0.65f;

    private static final View.OnAttachStateChangeListener AUTO_DETACH =
        new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) { }
            @Override public void onViewDetachedFromWindow(View v) { detach(v); }
        };

    private Shimmer() {}

    static void attach(View v) {
        if (v == null) return;
        if (!TARGETS.contains(v)) {
            TARGETS.add(v);
            v.addOnAttachStateChangeListener(AUTO_DETACH);
        }
        v.setAlpha(sValue);
        ensureRunning();
    }

    /** يربط كل View وسمه (tag) "shimmer" داخل شجرة الـ skeleton. */
    static void attachTagged(View root) {
        if (root == null) return;
        if ("shimmer".equals(root.getTag())) attach(root);
        if (root instanceof android.view.ViewGroup) {
            final android.view.ViewGroup g = (android.view.ViewGroup) root;
            for (int i = 0; i < g.getChildCount(); i++) attachTagged(g.getChildAt(i));
        }
    }

    static void detachTagged(View root) {
        if (root == null) return;
        if ("shimmer".equals(root.getTag())) detach(root);
        if (root instanceof android.view.ViewGroup) {
            final android.view.ViewGroup g = (android.view.ViewGroup) root;
            for (int i = 0; i < g.getChildCount(); i++) detachTagged(g.getChildAt(i));
        }
    }

    static void detach(View v) {
        if (v == null) return;
        TARGETS.remove(v);
        v.removeOnAttachStateChangeListener(AUTO_DETACH);
    }

    static void pause()  { if (sAnim != null && sAnim.isRunning()) sAnim.pause(); }
    static void resume() { if (sAnim != null && sAnim.isPaused())  sAnim.resume(); else if (!TARGETS.isEmpty()) ensureRunning(); }

    static void stopAll() {
        if (sAnim != null) { sAnim.cancel(); sAnim = null; }
        TARGETS.clear();
    }

    private static void ensureRunning() {
        if (sAnim != null) return;
        final ValueAnimator a = ValueAnimator.ofFloat(0.42f, 1f);
        a.setDuration(1100);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.setInterpolator(new AccelerateDecelerateInterpolator());
        a.addUpdateListener(anim -> {
            sValue = (float) anim.getAnimatedValue();
            final int n = TARGETS.size();
            if (n == 0) {                       // لا أحد يستمع → أوقف نفسك
                anim.cancel();
                if (sAnim == anim) sAnim = null;
                return;
            }
            for (int i = n - 1; i >= 0; i--) TARGETS.get(i).setAlpha(sValue);
        });
        sAnim = a;
        a.start();
    }
}
