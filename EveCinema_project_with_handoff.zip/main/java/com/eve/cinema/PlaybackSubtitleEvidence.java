package com.eve.cinema;

import com.eve.cinema.playback.SubtitleParser;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Keeps validated Arabic and English caption evidence isolated across preflight probes. */
final class PlaybackSubtitleEvidence<T> {
    private T arabicTrack, englishTrack;
    private List<SubtitleParser.Cue> arabicCues = Collections.emptyList();
    private List<SubtitleParser.Cue> englishCues = Collections.emptyList();

    void setArabic(T track, List<SubtitleParser.Cue> cues) {
        arabicTrack = track; arabicCues = copy(cues);
    }
    void setEnglish(T track, List<SubtitleParser.Cue> cues) {
        englishTrack = track; englishCues = copy(cues);
    }
    T trackForMode(int mode, boolean englishAudio) {
        if (mode == PlaybackModePolicy.ARABIC_SUBTITLES) return arabicCues.isEmpty() ? null : arabicTrack;
        if (mode == PlaybackModePolicy.ENGLISH_SUBTITLE_FALLBACK)
            return englishCues.isEmpty() ? null : englishTrack;
        if (mode == PlaybackModePolicy.ENGLISH_FALLBACK && !englishAudio)
            return englishCues.isEmpty() ? null : englishTrack;
        return null;
    }
    List<SubtitleParser.Cue> cuesForMode(int mode, boolean englishAudio) {
        if (mode == PlaybackModePolicy.ARABIC_SUBTITLES) return arabicCues;
        if (mode == PlaybackModePolicy.ENGLISH_SUBTITLE_FALLBACK) return englishCues;
        if (mode == PlaybackModePolicy.ENGLISH_FALLBACK && !englishAudio) return englishCues;
        return Collections.emptyList();
    }
    private static List<SubtitleParser.Cue> copy(List<SubtitleParser.Cue> cues) {
        return cues == null || cues.isEmpty() ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(cues));
    }
}
