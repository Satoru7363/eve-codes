package com.eve.cinema;

import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;

/**
 * UiMotion — shared motion tokens for Eve Cinema.
 * ────────────────────────────────────────────────────────────────
 * Single source of truth for the interpolators/durations used across
 * screens (MainActivity, hero carousel, and — as the redesign pass
 * continues — DetailActivity, EveChatAdapter, etc.) so every screen
 * shares the exact same "feel" instead of each file re-tuning its
 * own slightly-different copy of the same curve.
 *
 * Timings follow a 150–300ms window for taps/micro-interactions,
 * with longer bands reserved for cinematic entrances (hero reveals,
 * backdrop crossfades).
 *
 * NOTE: this does not change any already-correct, context-specific
 * effect (e.g. CinematicScrollView-hosted cards intentionally use
 * alpha-only feedback to avoid fighting the scroll view's own scale
 * animation). It only centralizes the values so future call sites
 * don't drift from them by accident.
 */
public final class UiMotion {

    private UiMotion() {}

    // ── Interpolators — reuse these instances everywhere ────────────
    public static final DecelerateInterpolator DECEL_2  = new DecelerateInterpolator(2.0f);
    public static final DecelerateInterpolator DECEL_15 = new DecelerateInterpolator(1.5f);
    public static final DecelerateInterpolator DECEL_25 = new DecelerateInterpolator(2.5f);
    public static final AccelerateInterpolator ACCEL_2  = new AccelerateInterpolator(2.0f);
    public static final AccelerateDecelerateInterpolator ACCEL_DECEL = new AccelerateDecelerateInterpolator();
    public static final OvershootInterpolator OVERSHOOT_14 = new OvershootInterpolator(1.4f);
    public static final OvershootInterpolator OVERSHOOT_18 = new OvershootInterpolator(1.8f);
    public static final OvershootInterpolator OVERSHOOT_28 = new OvershootInterpolator(2.8f);

    /** منحنى "emphasized decelerate" — انزلاق سريع في البداية وهبوط ناعم (انتقالات الـ Hero). */
    public static final PathInterpolator EMPHASIZED = new PathInterpolator(0.2f, 0f, 0f, 1f);

    // ── Duration tiers (ms) ───────────────────────────────────────────
    public static final long MICRO     = 150;  // press feedback
    public static final long SHORT     = 220;  // small fades / overlays
    public static final long MEDIUM    = 320;  // row / card entrances
    public static final long LONG      = 500;  // section reveals
    public static final long CINEMATIC = 700;  // hero / backdrop entrances

    /**
     * Standard "premium" button press — scale + alpha with a soft
     * overshoot on release. Use for standalone buttons NOT hosted
     * inside a scroll container that already owns scale.
     */
    public static void pressEffect(View view) {
        view.setOnTouchListener((v, event) -> {
            if (!v.isEnabled() || !v.isClickable()) return false;
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().cancel();
                    v.animate().scaleX(0.93f).scaleY(0.93f).alpha(0.70f)
                        .setDuration(60).setInterpolator(ACCEL_2).start();
                    break;
                case MotionEvent.ACTION_UP:
                    v.animate().cancel();
                    v.animate().scaleX(1.03f).scaleY(1.03f).alpha(1f)
                        .setDuration(80).setInterpolator(DECEL_15)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                            .setDuration(160).setInterpolator(OVERSHOOT_14).start())
                        .start();
                    break;
                case MotionEvent.ACTION_CANCEL:
                    v.animate().cancel();
                    v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(140).setInterpolator(OVERSHOOT_14).start();
                    break;
            }
            return false;
        });
    }

    /**
     * ضغط هادئ: تصغير بسيط + خفوت خفيف، رجوع بدون overshoot.
     * يُستخدم للأزرار والبطاقات والأزرار النصية بدل pressEffect (0.93 + 1.03) الأقوى.
     */
    public static void pressSubtle(View view) {
        view.setOnTouchListener((v, event) -> {
            if (!v.isEnabled() || !v.isClickable()) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().cancel();
                    v.animate().scaleX(0.96f).scaleY(0.96f).alpha(0.82f)
                        .setDuration(90).setInterpolator(DECEL_15).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().cancel();
                    v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(180).setInterpolator(DECEL_2).start();
                    break;
            }
            return false;
        });
    }
}
