package com.eve.cinema;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Small HTTP boundary for subtitle fetches; isolated to make transport behavior fixture-testable. */
final class SubtitleHttpClient {
    interface Cancellation { boolean isCancelled(); }
    interface ConnectionListener {
        void onOpened(HttpURLConnection connection);
        void onClosed(HttpURLConnection connection);
    }
    private SubtitleHttpClient() {}

    static String fetch(String urlStr, Map<String, String> headers,
                        Cancellation cancellation, ConnectionListener listener) throws Exception {
        if (cancellation != null && cancellation.isCancelled()) throw new java.io.IOException("cancelled");
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        if (listener != null) listener.onOpened(conn);
        try {
            if (cancellation != null && cancellation.isCancelled()) throw new java.io.IOException("cancelled");
            conn.setConnectTimeout(12_000); conn.setReadTimeout(15_000); conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("Accept-Encoding", "gzip");
            if (headers != null) for (Map.Entry<String, String> h : headers.entrySet()) {
                if (h.getKey() != null && h.getValue() != null) conn.setRequestProperty(h.getKey(), h.getValue());
            }
            int status = conn.getResponseCode();
            if (status < 200 || status >= 300) throw new java.io.IOException("HTTP " + status);
            String encoding = conn.getHeaderField("Content-Encoding");
            InputStream raw = conn.getInputStream();
            InputStream in = "gzip".equalsIgnoreCase(encoding) ? new GZIPInputStream(raw) : raw;
            try (InputStream body = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int n;
                while ((n = body.read(buf)) != -1) {
                    if (cancellation != null && cancellation.isCancelled()) throw new java.io.IOException("cancelled");
                    out.write(buf, 0, n);
                    if (out.size() > 8 * 1024 * 1024) throw new java.io.IOException("حجم ملف الترجمة أكبر من الحد المسموح");
                }
                if (out.size() == 0) throw new java.io.IOException("استجابة فارغة");
                return new String(out.toByteArray(), StandardCharsets.UTF_8).replace("\uFEFF", "");
            }
        } finally {
            conn.disconnect();
            if (listener != null) listener.onClosed(conn);
        }
    }
}
