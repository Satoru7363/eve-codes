package com.eve.cinema;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.WeakHashMap;

/**
 * EveFloatingButton — زر عائم ذكي قابل للسحب
 *
 * الإصلاحات الجوهرية:
 *
 *  [1] حفظ الموضع:  يحفظ X/Y كنسبة من حجم الشاشة في SharedPreferences
 *                    → يُستعاد بدقة في كل فتح حتى مع تغيير الشاشة
 *
 *  [2] لا تعارض مع زر القائمة:
 *                    الموضع الافتراضي = اليمين بارتفاع 62% — بعيد عن
 *                    منطقة القائمة السفلية وأي FAB آخر
 *
 *  [3] Gravity.TOP|START: LayoutParams لا يتعارض مع setX/setY
 *                    الكود القديم كان يستخدم BOTTOM|END والتعارض يُربك الموضع
 *
 *  [4] تحديد مناطق آمنة: snapToEdge يمنع الزر من الاختباء خلف شريط
 *                    الحالة أو شريط التنقل
 *
 *  [5] تصميم فاخر: أيقونة E مرسومة بـ Canvas — لا TextView، لا resources جاهزة
 */
public class EveFloatingButton {

    // ── Palette — consistent with Eve cinema theme ─────────────────────
    private static final int C_VIOLET  = 0xFF9B6FC4;
    private static final int C_VIOLET2 = 0xFF7C4FA0;

    // ── Position persistence keys ──────────────────────────────────────
    private static final String PREFS_FAB   = "eve_fab_pos";
    private static final String KEY_X_RATIO = "xr";   // X / parentWidth
    private static final String KEY_Y_RATIO = "yr";   // Y / parentHeight

    // ── Safe zones (dp) — منع الاختباء خلف الأشرطة ────────────────────
    private static final int SAFE_TOP    = 80;   // below status bar
    private static final int SAFE_BOTTOM = 110;  // above nav bar + FAB zone

    // ── Activity registry ──────────────────────────────────────────────
    private static final WeakHashMap<Activity, EveFloatingButton> sActive =
        new WeakHashMap<>();

    // ══════════════════════════════════════════════════════════════════
    //  Static API
    // ══════════════════════════════════════════════════════════════════

    public static void attach(Activity activity) {
        if (activity == null || sActive.containsKey(activity)) return;
        ViewGroup root = activity.findViewById(android.R.id.content);
        if (root == null) return;
        sActive.put(activity, new EveFloatingButton(activity, root));
    }

    public static void detach(Activity activity) {
        if (activity == null) return;
        EveFloatingButton btn = sActive.remove(activity);
        if (btn != null) btn.remove();
    }

    // ══════════════════════════════════════════════════════════════════
    //  Fields
    // ══════════════════════════════════════════════════════════════════

    private final Context     context;
    private final FrameLayout container;
    private final View        btnView;     // الدائرة القابلة للضغط
    private final TextView    badgeTV;
    private       ValueAnimator pulseAnim;

    // Drag state
    private float   dX, dY;
    private float   downRawX, downRawY;
    private boolean wasDragged;

    // ══════════════════════════════════════════════════════════════════
    //  Constructor
    // ══════════════════════════════════════════════════════════════════

    public EveFloatingButton(Context context, ViewGroup rootView) {
        this.context = context;

        final int SIZE = dp(54);   // قطر الزر
        final int PAD  = dp(10);   // هامش للـ ring (تجاوز حدود الـ container)
        final int WRAP = SIZE + PAD * 2; // حجم الـ container الكلي

        // ── Container ─────────────────────────────────────────────────
        // Gravity.TOP|START: setX/setY يعملان بلا تعارض مع layout gravity
        container = new FrameLayout(context);
        container.setClipChildren(false);   // ring يتجاوز الحدود بلا قص
        container.setClipToPadding(false);
        FrameLayout.LayoutParams cLp = new FrameLayout.LayoutParams(WRAP, WRAP);
        cLp.gravity = Gravity.TOP | Gravity.START;
        container.setLayoutParams(cLp);
        // مخفي مبدئياً — entrance animation ستُظهره بعد تحديد الموضع
        container.setAlpha(0f);
        container.setScaleX(0f);
        container.setScaleY(0f);

        // ── Glow ring ──────────────────────────────────────────────────
        View ring = new View(context);
        FrameLayout.LayoutParams rLp = new FrameLayout.LayoutParams(WRAP, WRAP);
        rLp.gravity = Gravity.CENTER;
        ring.setLayoutParams(rLp);
        GradientDrawable ringBg = new GradientDrawable();
        ringBg.setShape(GradientDrawable.OVAL);
        ringBg.setColor(Color.TRANSPARENT);
        ringBg.setStroke(1, 0x40C4A0E8);
        ring.setBackground(ringBg);
        ring.setAlpha(0f);
        container.addView(ring);

        // ── Main button circle ─────────────────────────────────────────
        FrameLayout btn = new FrameLayout(context);
        FrameLayout.LayoutParams bLp = new FrameLayout.LayoutParams(SIZE, SIZE);
        bLp.gravity = Gravity.CENTER;
        btn.setLayoutParams(bLp);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setShape(GradientDrawable.OVAL);
        btnBg.setColors(new int[]{ 0xFFCCA8FF, 0xFF7040B8, 0xFF3C1668 });
        btnBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        btn.setBackground(btnBg);
        btn.setElevation(dp(10));
        btn.setClickable(true);
        btn.setFocusable(true);

        // ── Inner gloss highlight — TL catch-light (تطابق مع avatar) ──
        View gloss = new View(context);
        GradientDrawable glassBg = new GradientDrawable();
        glassBg.setShape(GradientDrawable.OVAL);
        glassBg.setColors(new int[]{ 0x15FFFFFF, 0x00FFFFFF });
        glassBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        gloss.setBackground(glassBg);
        btn.addView(gloss, new FrameLayout.LayoutParams(SIZE, SIZE));

        // ── Icon: حرف E مرسوم بـ Canvas ───────────────────────────────
        // دقة كاملة — لا TextView، لا rendering artifacts، لا resources جاهزة
        final float density = context.getResources().getDisplayMetrics().density;
        View iconView = new View(context) {
            @Override
            protected void onDraw(Canvas canvas) {
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(0xFFF0EEFF);
                p.setStrokeWidth(density * 2.1f);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
                p.setStyle(Paint.Style.STROKE);

                float cx  = getWidth()  * 0.5f;
                float cy  = getHeight() * 0.5f;
                float h   = density * 9.5f;   // نصف ارتفاع الـ E
                float wid = density * 7.5f;   // عرض الأشرطة الأفقية
                float mw  = density * 5.2f;   // الشريط الأوسط (أقصر للتمييز)
                float lx  = cx - wid * 0.45f; // x الشريط العمودي الأيسر

                // الشريط العمودي الأيسر
                canvas.drawLine(lx, cy - h, lx, cy + h, p);
                // الشريط العلوي
                canvas.drawLine(lx, cy - h, lx + wid, cy - h, p);
                // الشريط الأوسط (أقصر — يُعطي طابعاً معمارياً)
                canvas.drawLine(lx, cy, lx + mw, cy, p);
                // الشريط السفلي
                canvas.drawLine(lx, cy + h, lx + wid, cy + h, p);
            }
        };
        iconView.setBackgroundColor(Color.TRANSPARENT);
        iconView.setLayoutParams(new FrameLayout.LayoutParams(SIZE, SIZE));
        btn.addView(iconView);

        container.addView(btn);
        btnView = btn;

        // ── Badge ──────────────────────────────────────────────────────
        badgeTV = new TextView(context);
        int BSZ = dp(18);
        FrameLayout.LayoutParams bdLp = new FrameLayout.LayoutParams(BSZ, BSZ);
        bdLp.gravity     = Gravity.TOP | Gravity.END;
        bdLp.topMargin   = dp(3);
        bdLp.rightMargin = dp(3);
        badgeTV.setLayoutParams(bdLp);
        badgeTV.setTextSize(7.5f);
        badgeTV.setTextColor(Color.WHITE);
        badgeTV.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        badgeTV.setGravity(Gravity.CENTER);
        GradientDrawable bdBg = new GradientDrawable();
        bdBg.setShape(GradientDrawable.OVAL);
        bdBg.setColor(0xFFE53935);
        badgeTV.setBackground(bdBg);
        badgeTV.setVisibility(View.GONE);
        container.addView(badgeTV);

        rootView.addView(container);

        // ── تحديد الموضع بعد انتهاء الـ layout (لمعرفة أبعاد الشاشة الحقيقية) ──
        container.post(this::restoreOrDefaultPosition);

        setupTouch();
        startPulse(ring);
        playEntrance();
    }

    // ══════════════════════════════════════════════════════════════════
    //  Position — حفظ واستعادة
    // ══════════════════════════════════════════════════════════════════

    /**
     * يستعيد الموضع المحفوظ كنسبة من الشاشة.
     * إذا لا يوجد موضع محفوظ → الموضع الافتراضي: يمين + 62% من الأعلى
     * (بعيد عن منطقة الـ FAB السفلية وأزرار القائمة)
     */
    private void restoreOrDefaultPosition() {
        View parent = (View) container.getParent();
        if (parent == null) return;

        int pw = parent.getWidth();
        int ph = parent.getHeight();
        if (pw == 0 || ph == 0) {
            // الشاشة لم تُقاس بعد — أعد المحاولة في الـ frame التالي
            container.post(this::restoreOrDefaultPosition);
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences(PREFS_FAB, Context.MODE_PRIVATE);
        float xr = prefs.getFloat(KEY_X_RATIO, -1f);
        float yr = prefs.getFloat(KEY_Y_RATIO, -1f);

        float targetX, targetY;

        if (xr >= 0f && yr >= 0f) {
            // استعادة من prefs مع ضمان البقاء في المناطق الآمنة
            targetX = xr * pw;
            targetY = yr * ph;
        } else {
            // الموضع الافتراضي: حافة اليمين، 62% من الأعلى
            // هذا يتجنب: شريط التنقل، منطقة القائمة السفلية، وأي FAB آخر
            targetX = pw - container.getWidth() - dp(18);
            targetY = ph * 0.62f;
        }

        // فرض الحدود الآمنة دائماً
        targetX = clampX(targetX, pw);
        targetY = clampY(targetY, ph);

        container.setX(targetX);
        container.setY(targetY);
    }

    /** يحفظ الموضع الحالي كنسبة من أبعاد الشاشة — يُستدعى بعد كل snap */
    private void savePosition() {
        View parent = (View) container.getParent();
        if (parent == null || parent.getWidth() == 0) return;

        float xr = container.getX() / parent.getWidth();
        float yr = container.getY() / parent.getHeight();

        context.getSharedPreferences(PREFS_FAB, Context.MODE_PRIVATE)
            .edit()
            .putFloat(KEY_X_RATIO, xr)
            .putFloat(KEY_Y_RATIO, yr)
            .apply();
    }

    // ══════════════════════════════════════════════════════════════════
    //  Touch — drag على btnView → container يتحرك
    // ══════════════════════════════════════════════════════════════════

    private void setupTouch() {
        btnView.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {

                case MotionEvent.ACTION_DOWN:
                    dX         = container.getX() - e.getRawX();
                    dY         = container.getY() - e.getRawY();
                    downRawX   = e.getRawX();
                    downRawY   = e.getRawY();
                    wasDragged = false;
                    btnView.animate()
                        .scaleX(0.87f).scaleY(0.87f)
                        .setDuration(80)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float movedDist = (float) Math.hypot(
                        e.getRawX() - downRawX,
                        e.getRawY() - downRawY);
                    if (!wasDragged && movedDist > dp(6)) {
                        wasDragged = true;
                    }
                    if (wasDragged) {
                        container.setX(e.getRawX() + dX);
                        container.setY(e.getRawY() + dY);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    btnView.animate()
                        .scaleX(1f).scaleY(1f)
                        .setDuration(280)
                        .setInterpolator(new OvershootInterpolator(2.4f))
                        .start();
                    if (wasDragged) {
                        snapToEdge();
                    } else {
                        // Tap → فتح EveAiActivity
                        Intent intent = new Intent(context, EveAiActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);
                    }
                    return true;
            }
            return false;
        });
    }

    // ══════════════════════════════════════════════════════════════════
    //  Snap to edge — يلتصق بأقرب حافة + يحفظ الموضع
    // ══════════════════════════════════════════════════════════════════

    private void snapToEdge() {
        View parent = (View) container.getParent();
        if (parent == null) return;

        int pw = parent.getWidth();
        int ph = parent.getHeight();

        // التصاق بأقرب حافة أفقية
        float cx      = container.getX() + container.getWidth() * 0.5f;
        float targetX = (cx < pw * 0.5f)
            ? dp(16)
            : pw - container.getWidth() - dp(16);

        // تقييد Y ضمن المنطقة الآمنة
        float targetY = clampY(container.getY(), ph);

        container.animate()
            .x(targetX).y(targetY)
            .setDuration(440)
            .setInterpolator(new OvershootInterpolator(1.5f))
            .withEndAction(this::savePosition)   // ← حفظ بعد كل snap
            .start();
    }

    // ══════════════════════════════════════════════════════════════════
    //  Helpers — حدود آمنة
    // ══════════════════════════════════════════════════════════════════

    private float clampX(float x, int parentW) {
        return Math.max(dp(8), Math.min(x, parentW - container.getWidth() - dp(8)));
    }

    private float clampY(float y, int parentH) {
        float minY = dp(SAFE_TOP);
        float maxY = parentH - container.getHeight() - dp(SAFE_BOTTOM);
        return Math.max(minY, Math.min(y, Math.max(minY, maxY)));
    }

    // ══════════════════════════════════════════════════════════════════
    //  Badge
    // ══════════════════════════════════════════════════════════════════

    public void showBadge(int count) {
        if (count <= 0) {
            badgeTV.setVisibility(View.GONE);
            return;
        }
        badgeTV.setText(count > 9 ? "9+" : String.valueOf(count));
        if (badgeTV.getVisibility() != View.VISIBLE) {
            badgeTV.setScaleX(0f);
            badgeTV.setScaleY(0f);
            badgeTV.setVisibility(View.VISIBLE);
            badgeTV.animate()
                .scaleX(1f).scaleY(1f)
                .setDuration(230)
                .setInterpolator(new OvershootInterpolator(3.2f))
                .start();
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  Remove
    // ══════════════════════════════════════════════════════════════════

    public void remove() {
        if (pulseAnim != null) { pulseAnim.cancel(); pulseAnim = null; }
        ViewGroup parent = (ViewGroup) container.getParent();
        if (parent != null) {
            container.animate()
                .alpha(0f).scaleX(0.32f).scaleY(0.32f)
                .setDuration(200)
                .setInterpolator(new DecelerateInterpolator(2f))
                .withEndAction(() -> parent.removeView(container))
                .start();
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  Pulse — sinusoidal alpha (عضوي، يتنفس)
    // ══════════════════════════════════════════════════════════════════

    private void startPulse(View ring) {
        pulseAnim = ValueAnimator.ofFloat(0.88f, 1.52f);
        pulseAnim.setDuration(2800);
        pulseAnim.setRepeatMode(ValueAnimator.REVERSE);
        pulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnim.setInterpolator(
            new android.view.animation.AccelerateDecelerateInterpolator());
        pulseAnim.addUpdateListener(a -> {
            float v = (float) a.getAnimatedValue();
            ring.setScaleX(v);
            ring.setScaleY(v);
            float t = (v - 0.88f) / 0.64f;   // normalized 0..1
            ring.setAlpha((float)(Math.sin(t * Math.PI) * 0.50f));
        });
        pulseAnim.start();
    }

    // ══════════════════════════════════════════════════════════════════
    //  Entrance animation
    // ══════════════════════════════════════════════════════════════════

    private void playEntrance() {
        // الموضع يُحدد في post() قبل بدء الـ 260ms delay
        container.postDelayed(() ->
            container.animate()
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(440)
                .setInterpolator(new OvershootInterpolator(2.2f))
                .start(),
            260);
    }

    // ══════════════════════════════════════════════════════════════════
    //  Utils
    // ══════════════════════════════════════════════════════════════════

    private int dp(int v) {
        return (int) (v * context.getResources().getDisplayMetrics().density);
    }
}
