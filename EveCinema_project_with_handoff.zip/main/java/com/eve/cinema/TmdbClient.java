package com.eve.cinema;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * TmdbClient — عميل TMDB لإيف سينما
 * ══════════════════════════════════════════════════════════
 *  يُستخدم من DetailActivity / EpisodesActivity / MainActivity
 *  لا يعتمد على WebView — HTTP مباشر
 * ══════════════════════════════════════════════════════════
 */
public class TmdbClient {

    private static final int TIMEOUT = 10_000;

    // ══════════════════════════════════════════════════════════
    //  نماذج البيانات
    // ══════════════════════════════════════════════════════════

    public static class MovieInfo {
        public String  id;
        public String  title;
        public String  overview;
        public String  posterPath;     // مسار فقط — أضف Config.TMDB_IMAGE_BASE + size
        public String  backdropPath;
        public String  releaseDate;
        public double  rating;
        public int     ratingCount;
        public int     runtime;        // بالدقائق
        public String  genres;         // مفصولة بـ "،"
        public String  tagline;
        public String  status;
        public String  originalLanguage;
        public List<CastMember> cast;
        public List<Video>      videos;
    }

    public static class TvInfo {
        public String  id;
        public String  name;
        public String  overview;
        public String  posterPath;
        public String  backdropPath;
        public String  firstAirDate;
        public double  rating;
        public int     ratingCount;
        public int     numberOfSeasons;
        public int     numberOfEpisodes;
        public String  genres;
        public String  status;
        public String  originalLanguage;
        public List<CastMember> cast;
        public List<Video>      videos;
        public List<Season>     seasons;
    }

    public static class Season {
        public int    seasonNumber;
        public int    episodeCount;
        public String name;
        public String airDate;
        public String posterPath;
    }

    public static class Episode {
        public int    episodeNumber;
        public int    seasonNumber;
        public String name;
        public String overview;
        public String airDate;
        public double rating;
        public String stillPath;
        public int    runtime;
    }

    public static class CastMember {
        public String name;
        public String character;
        public String profilePath;
    }

    public static class Video {
        public String name;
        public String key;   // YouTube key
        public String type;  // "Trailer" / "Teaser" / ...
        public String site;  // "YouTube"
    }

    public static class SearchResult {
        public String  id;
        public String  title;
        public String  mediaType;   // "movie" / "tv"
        public String  posterPath;
        public String  releaseDate;
        public double  rating;
    }

    // ══════════════════════════════════════════════════════════
    //  الدوال العامة
    // ══════════════════════════════════════════════════════════

    /** تفاصيل فيلم */
    public static MovieInfo getMovieDetails(String tmdbId) throws Exception {
        String url = String.format(Config.TMDB_MOVIE_DETAILS, tmdbId);
        JSONObject json = fetchJson(url);
        return parseMovieInfo(json);
    }

    /** تفاصيل مسلسل */
    public static TvInfo getTvDetails(String tmdbId) throws Exception {
        String url = String.format(Config.TMDB_TV_DETAILS, tmdbId);
        JSONObject json = fetchJson(url);
        return parseTvInfo(json);
    }

    /** حلقات موسم معين */
    public static List<Episode> getSeasonEpisodes(String tmdbId, int season) throws Exception {
        String url = String.format(Config.TMDB_SEASON, tmdbId, season);
        JSONObject json = fetchJson(url);
        List<Episode> episodes = new ArrayList<>();
        JSONArray arr = json.optJSONArray("episodes");
        if (arr == null) return episodes;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject ep = arr.getJSONObject(i);
            Episode e = new Episode();
            e.episodeNumber = ep.optInt("episode_number");
            e.seasonNumber  = ep.optInt("season_number");
            e.name          = ep.optString("name", "");
            e.overview      = ep.optString("overview", "");
            e.airDate       = ep.optString("air_date", "");
            e.rating        = ep.optDouble("vote_average", 0);
            e.stillPath     = ep.optString("still_path", "");
            e.runtime       = ep.optInt("runtime", 0);
            episodes.add(e);
        }
        return episodes;
    }

    /** بحث متعدد (أفلام + مسلسلات) */
    public static List<SearchResult> search(String query) throws Exception {
        String encoded = java.net.URLEncoder.encode(query, "UTF-8");
        String url = String.format(Config.TMDB_SEARCH_MULTI, encoded);
        JSONObject json = fetchJson(url);
        List<SearchResult> results = new ArrayList<>();
        JSONArray arr = json.optJSONArray("results");
        if (arr == null) return results;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject item = arr.getJSONObject(i);
            String type = item.optString("media_type", "");
            if (!"movie".equals(type) && !"tv".equals(type)) continue;
            SearchResult r = new SearchResult();
            r.id          = String.valueOf(item.optInt("id"));
            r.mediaType   = type;
            r.title       = "movie".equals(type)
                            ? item.optString("title", item.optString("original_title", ""))
                            : item.optString("name",  item.optString("original_name", ""));
            r.posterPath  = item.optString("poster_path", "");
            r.releaseDate = "movie".equals(type)
                            ? item.optString("release_date", "")
                            : item.optString("first_air_date", "");
            r.rating      = item.optDouble("vote_average", 0);
            results.add(r);
        }
        return results;
    }

    /** الرائج — type: "movie" أو "tv" أو "all" */
    public static List<SearchResult> getTrending(String type) throws Exception {
        String url = String.format(Config.TMDB_TRENDING, type);
        return parseResultsList(fetchJson(url));
    }

    /** الأكثر شعبية */
    public static List<SearchResult> getPopular(String type) throws Exception {
        String url = String.format(Config.TMDB_POPULAR, type);
        return parseResultsList(fetchJson(url));
    }

    /** الأعلى تقييماً */
    public static List<SearchResult> getTopRated(String type) throws Exception {
        String url = String.format(Config.TMDB_TOP_RATED, type);
        return parseResultsList(fetchJson(url));
    }

    // ══════════════════════════════════════════════════════════
    //  Helpers لبناء روابط الصور
    // ══════════════════════════════════════════════════════════

    public static String buildPosterUrl(String path) {
        if (path == null || path.isEmpty()) return "";
        return Config.TMDB_IMAGE_BASE + Config.TMDB_POSTER_SIZE + path;
    }

    public static String buildBackdropUrl(String path) {
        if (path == null || path.isEmpty()) return "";
        return Config.TMDB_IMAGE_BASE + Config.TMDB_BACKDROP_SIZE + path;
    }

    public static String buildStillUrl(String path) {
        if (path == null || path.isEmpty()) return "";
        return Config.TMDB_IMAGE_BASE + "w300" + path;
    }

    // ══════════════════════════════════════════════════════════
    //  Parser الداخلية
    // ══════════════════════════════════════════════════════════

    private static MovieInfo parseMovieInfo(JSONObject json) {
        MovieInfo m = new MovieInfo();
        m.id               = String.valueOf(json.optInt("id"));
        m.title            = json.optString("title", json.optString("original_title", ""));
        m.overview         = json.optString("overview", "");
        m.posterPath       = json.optString("poster_path", "");
        m.backdropPath     = json.optString("backdrop_path", "");
        m.releaseDate      = json.optString("release_date", "");
        m.rating           = json.optDouble("vote_average", 0);
        m.ratingCount      = json.optInt("vote_count", 0);
        m.runtime          = json.optInt("runtime", 0);
        m.tagline          = json.optString("tagline", "");
        m.status           = json.optString("status", "");
        m.originalLanguage = json.optString("original_language", "");
        m.genres           = parseGenres(json.optJSONArray("genres"));
        m.cast             = parseCast(json.optJSONObject("credits"));
        m.videos           = parseVideos(json.optJSONObject("videos"));
        return m;
    }

    private static TvInfo parseTvInfo(JSONObject json) {
        TvInfo t = new TvInfo();
        t.id               = String.valueOf(json.optInt("id"));
        t.name             = json.optString("name", json.optString("original_name", ""));
        t.overview         = json.optString("overview", "");
        t.posterPath       = json.optString("poster_path", "");
        t.backdropPath     = json.optString("backdrop_path", "");
        t.firstAirDate     = json.optString("first_air_date", "");
        t.rating           = json.optDouble("vote_average", 0);
        t.ratingCount      = json.optInt("vote_count", 0);
        t.numberOfSeasons  = json.optInt("number_of_seasons", 1);
        t.numberOfEpisodes = json.optInt("number_of_episodes", 0);
        t.status           = json.optString("status", "");
        t.originalLanguage = json.optString("original_language", "");
        t.genres           = parseGenres(json.optJSONArray("genres"));
        t.cast             = parseCast(json.optJSONObject("credits"));
        t.videos           = parseVideos(json.optJSONObject("videos"));
        t.seasons          = parseSeasons(json.optJSONArray("seasons"));
        return t;
    }

    private static String parseGenres(JSONArray arr) {
        if (arr == null || arr.length() == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length(); i++) {
            if (i > 0) sb.append("، ");
            sb.append(arr.optJSONObject(i).optString("name", ""));
        }
        return sb.toString();
    }

    private static List<CastMember> parseCast(JSONObject credits) {
        List<CastMember> list = new ArrayList<>();
        if (credits == null) return list;
        JSONArray arr = credits.optJSONArray("cast");
        if (arr == null) return list;
        int limit = Math.min(arr.length(), 15);
        for (int i = 0; i < limit; i++) {
            JSONObject item = arr.optJSONObject(i);
            if (item == null) continue;
            CastMember c = new CastMember();
            c.name        = item.optString("name", "");
            c.character   = item.optString("character", "");
            c.profilePath = item.optString("profile_path", "");
            list.add(c);
        }
        return list;
    }

    private static List<Video> parseVideos(JSONObject videosObj) {
        List<Video> list = new ArrayList<>();
        if (videosObj == null) return list;
        JSONArray arr = videosObj.optJSONArray("results");
        if (arr == null) return list;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject item = arr.optJSONObject(i);
            if (item == null) continue;
            Video v = new Video();
            v.name = item.optString("name", "");
            v.key  = item.optString("key", "");
            v.type = item.optString("type", "");
            v.site = item.optString("site", "");
            list.add(v);
        }
        return list;
    }

    private static List<Season> parseSeasons(JSONArray arr) {
        List<Season> list = new ArrayList<>();
        if (arr == null) return list;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject item = arr.optJSONObject(i);
            if (item == null) continue;
            int num = item.optInt("season_number", 0);
            if (num == 0) continue; // تخطّ "Specials"
            Season s = new Season();
            s.seasonNumber = num;
            s.episodeCount = item.optInt("episode_count", 0);
            s.name         = item.optString("name", "الموسم " + num);
            s.airDate      = item.optString("air_date", "");
            s.posterPath   = item.optString("poster_path", "");
            list.add(s);
        }
        return list;
    }

    private static List<SearchResult> parseResultsList(JSONObject json) {
        List<SearchResult> list = new ArrayList<>();
        JSONArray arr = json.optJSONArray("results");
        if (arr == null) return list;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject item = arr.optJSONObject(i);
            if (item == null) continue;
            SearchResult r = new SearchResult();
            r.id         = String.valueOf(item.optInt("id"));
            r.title      = item.optString("title",
                           item.optString("name",
                           item.optString("original_title",
                           item.optString("original_name", ""))));
            r.posterPath  = item.optString("poster_path", "");
            r.releaseDate = item.optString("release_date",
                           item.optString("first_air_date", ""));
            r.rating      = item.optDouble("vote_average", 0);
            // TMDB يُرجع media_type في trending وإلا نستنتجه
            String type = item.optString("media_type", "");
            if (type.isEmpty()) {
                type = item.has("title") ? "movie" : "tv";
            }
            r.mediaType = type;
            list.add(r);
        }
        return list;
    }

    // ══════════════════════════════════════════════════════════
    //  HTTP Client
    // ══════════════════════════════════════════════════════════

    private static JSONObject fetchJson(String urlStr) throws Exception {
        HttpURLConnection conn = null;
        long diagnosticStart = android.os.SystemClock.elapsedRealtime();
        int diagnosticStatus = -1;
        String diagnosticBody = null;
        try {
            conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Authorization", Config.TMDB_BEARER_TOKEN);
            DiagnosticsRecorder.headers("TMDB", "fetch_json", "GET", urlStr, conn.getRequestProperties());
            conn.setRequestProperty("User-Agent", Config.USER_AGENT);

            int code = conn.getResponseCode();
            diagnosticStatus = code;
            if (code == 401) throw new Exception("TMDB: مفتاح API غير صالح");
            if (code == 404) throw new Exception("TMDB: المحتوى غير موجود");
            if (code >= 400) throw new Exception("TMDB: خطأ " + code);

            BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            diagnosticBody = sb.toString();
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, null, false);
            return new JSONObject(diagnosticBody);
        } catch (Exception e) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, e, false);
            throw e;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
