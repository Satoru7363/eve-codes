package com.eve.cinema;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;

/**
 * RegisterActivity — شاشة إكمال التسجيل وربط الجهاز
 * ─────────────────────────────────────────────────────────────────────────────
 * تُفتح من LoginActivity عندما يكون الكود صالحاً لكن لم يُربط بجهاز بعد.
 *
 * التدفق:
 *   1. المستخدم يدخل الكود + الاسم
 *   2. نتحقق من الكود في Firebase (يجب أن يكون active وغير مربوط)
 *   3. نرسل PATCH لربط deviceId عبر Firebase REST API
 *   4. نحفظ الجلسة ونفتح MainActivity
 *
 * قواعد الأمان:
 *   • Firebase تسمح بكتابة deviceId فقط إذا كانت قيمته فارغة (أول مرة)
 *   • بعد الربط، لا يمكن تغيير deviceId من التطبيق
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class RegisterActivity extends Activity {

    private static final int PICK_IMAGE = 100;

    private UserSession session;
    private String customAvatarUri = null;

    private EditText    codeInput, nameInput;
    private TextView    errorView, registerBtn;
    private ProgressBar progress;
    private ImageView   avatarPreview;
    private LinearLayout avatarPlaceholder;
    private FrameLayout  avatarUploadArea, avatarRemove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MiuiBarFix.apply(this);
        setContentView(R.layout.activity_register);

        session = new UserSession(this);

        codeInput         = (EditText)      findViewById(R.id.register_code_input);
        nameInput         = (EditText)      findViewById(R.id.register_name_input);
        errorView         = (TextView)      findViewById(R.id.register_error);
        progress          = (ProgressBar)   findViewById(R.id.register_progress);
        registerBtn       = (TextView)      findViewById(R.id.register_btn);
        avatarPreview     = (ImageView)     findViewById(R.id.avatar_preview);
        avatarPlaceholder = (LinearLayout)  findViewById(R.id.avatar_placeholder);
        avatarUploadArea  = (FrameLayout)   findViewById(R.id.avatar_upload_area);
        avatarRemove      = (FrameLayout)   findViewById(R.id.avatar_remove);

        // كود مسبق من LoginActivity
        String preCode = getIntent().getStringExtra("pre_code");
        if (preCode != null && !preCode.isEmpty()) {
            codeInput.setText(preCode);
        }

        // زر رجوع
        FrameLayout backBtn = (FrameLayout) findViewById(R.id.register_back);
        if (backBtn != null) backBtn.setOnClickListener(v -> finish());

        // منطقة رفع الصورة
        if (avatarUploadArea != null) {
            avatarUploadArea.setOnClickListener(v -> pickImageFromGallery());
        }
        if (avatarRemove != null) {
            avatarRemove.setOnClickListener(v -> clearAvatar());
        }

        // زر الحصول على كود
        LinearLayout getBotBtn = (LinearLayout) findViewById(R.id.register_get_code_btn);
        if (getBotBtn != null) {
            getBotBtn.setOnClickListener(v -> openTelegramBot());
        }

        registerBtn.setOnClickListener(v -> attemptRegister());

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(400);
        fadeIn.setFillAfter(true);
        findViewById(android.R.id.content).startAnimation(fadeIn);
    }

    // ════════════════════════════════════════════════════════════════════
    // رفع الصورة
    // ════════════════════════════════════════════════════════════════════

    private void pickImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE);
    }

    private void clearAvatar() {
        customAvatarUri = null;
        if (avatarPreview   != null) { avatarPreview.setVisibility(View.GONE); avatarPreview.setImageBitmap(null); }
        if (avatarPlaceholder != null) avatarPlaceholder.setVisibility(View.VISIBLE);
        if (avatarRemove    != null) avatarRemove.setVisibility(View.GONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    try {
                        getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {}

                    InputStream is  = getContentResolver().openInputStream(uri);
                    Bitmap bmp      = BitmapFactory.decodeStream(is);
                    if (bmp != null) {
                        customAvatarUri = uri.toString();
                        Bitmap circular = MainActivity.makeCircular(
                            Bitmap.createScaledBitmap(bmp, 192, 192, true));

                        if (avatarPreview != null) {
                            avatarPreview.setImageBitmap(circular);
                            avatarPreview.setVisibility(View.VISIBLE);
                            avatarPreview.animate().scaleX(0.8f).scaleY(0.8f).setDuration(0).start();
                            avatarPreview.animate().scaleX(1f).scaleY(1f).setDuration(250).start();
                        }
                        if (avatarPlaceholder != null) avatarPlaceholder.setVisibility(View.GONE);
                        if (avatarRemove      != null) avatarRemove.setVisibility(View.VISIBLE);
                    }
                } catch (Exception e) {
                    Toast.makeText(this, getString(R.string.err_avatar_load), Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // منطق التسجيل وربط الجهاز عبر Firebase
    // ════════════════════════════════════════════════════════════════════

    private void attemptRegister() {
        final String code     = codeInput.getText().toString().trim().toUpperCase();
        final String name     = nameInput.getText().toString().trim();
        final String deviceId = session.getDeviceId();

        if (code.isEmpty())    { showError(getString(R.string.err_enter_code)); return; }
        if (name.isEmpty())    { showError(getString(R.string.err_enter_name)); return; }
        if (name.length() < 2) { showError(getString(R.string.err_name_short)); return; }

        errorView.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        registerBtn.setAlpha(0.6f);
        registerBtn.setClickable(false);

        final String finalAvatarUri = customAvatarUri != null ? customAvatarUri : "";

        new Thread(() -> {
            // ① تحقق من الكود في Firebase
            FirebaseLicenseClient.Result result =
                FirebaseLicenseClient.fetchAndVerify(code, deviceId);

            if (result.status == FirebaseLicenseClient.Status.NETWORK_ERROR) {
                showErrorOnUi(getString(R.string.err_network_retry));
                return;
            }
            if (result.status == FirebaseLicenseClient.Status.NOT_FOUND) {
                showErrorOnUi(getString(R.string.err_code_invalid));
                return;
            }
            if (result.status == FirebaseLicenseClient.Status.INACTIVE) {
                showErrorOnUi(getString(R.string.err_code_revoked));
                return;
            }
            if (result.status == FirebaseLicenseClient.Status.BANNED) {
                showErrorOnUi(getString(R.string.err_device_banned));
                return;
            }
            if (result.status == FirebaseLicenseClient.Status.EXPIRED) {
                showErrorOnUi(getString(R.string.err_code_expired));
                return;
            }
            if (result.status == FirebaseLicenseClient.Status.BOUND_OTHER) {
                showErrorOnUi(getString(R.string.err_code_other_device));
                return;
            }

            // ② إذا كان VALID (مرتبط بهذا الجهاز) أو UNBOUND → تابع
            if (result.status == FirebaseLicenseClient.Status.UNBOUND) {
                // ③ اربط الجهاز عبر Firebase REST PATCH
                boolean bound = FirebaseLicenseClient.bindDevice(code, deviceId);
                if (!bound) {
                    showErrorOnUi(getString(R.string.err_device_link));
                    return;
                }
            }

            // ④ حفظ الجلسة والملف الشخصي
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                registerBtn.setAlpha(1f);
                registerBtn.setClickable(true);

                session.loginWithCode(code);
                if (result.telegramId != 0) session.saveTelegramId(result.telegramId);
                session.saveProfile(name, 0, finalAvatarUri.isEmpty() ? null : finalAvatarUri);

                startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            });

        }).start();
    }

    // ════════════════════════════════════════════════════════════════════
    // UI helpers
    // ════════════════════════════════════════════════════════════════════

    private void openTelegramBot() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=amhnak_bot")));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Config.TELEGRAM_BOT_URL)));
        }
    }

    private void showErrorOnUi(final String msg) {
        runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
            registerBtn.setAlpha(1f);
            registerBtn.setClickable(true);
            showError(msg);
        });
    }

    private void showError(String msg) {
        errorView.setText(msg);
        errorView.setVisibility(View.VISIBLE);
        AlphaAnimation a = new AlphaAnimation(0f, 1f);
        a.setDuration(250);
        errorView.startAnimation(a);
    }

    /** يُستدعى من MainActivity لعمل أفاتار افتراضي */
    public static Bitmap makeAvatarBitmap(int idx, int size) {
        int[] colors = { 0xFF3B4B8C, 0xFF8B3B6B, 0xFF3B6B4B,
                         0xFF6B3B8B, 0xFF8B6B3B, 0xFF3B8B8B, 0xFF6B3B3B };
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(bmp);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        int safeIdx = ((idx % colors.length) + colors.length) % colors.length;
        p.setColor(colors[safeIdx]);
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, p);
        p.setColor(0xCCFFFFFF);
        p.setTextSize(size * 0.42f);
        p.setTextAlign(android.graphics.Paint.Align.CENTER);
        p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        String[] initials = {"A","B","C","D","E","F","G"};
        canvas.drawText(initials[safeIdx], size / 2f, size / 2f + size * 0.15f, p);
        return bmp;
    }

    @Override
    protected void onResume() {
        super.onResume();
        MiuiBarFix.apply(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MiuiBarFix.release(this);
    }
}
