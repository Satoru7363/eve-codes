package com.eve.cinema;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * ══════════════════════════════════════════════════════════
 *  AdBlocker.java — محرك "الإبادة الجراحية" للإعلانات
 *  ✅ إصلاح: حماية ملفات الترجمة (VTT/SRT) من الحجب
 * ══════════════════════════════════════════════════════════
 */
public class AdBlocker {

    // ══════════════════════════════════════════════════════
    // امتدادات الترجمة — لا تُحجب أبداً
    // ══════════════════════════════════════════════════════
    private static final Set<String> SUBTITLE_EXTENSIONS = new HashSet<>(Arrays.asList(
        ".vtt", ".srt", ".ass", ".ssa", ".sub", ".sbv"
    ));

    // مسارات الترجمة الشائعة — لا تُحجب أبداً
    private static final Set<String> SUBTITLE_PATH_KEYWORDS = new HashSet<>(Arrays.asList(
        "/subtitle", "/subtitles", "/sub/", "/subs/",
        "/caption", "/captions", "/cc/",
        "/track/",   // ← هذا كان السبب الرئيسي!
        "/tracks/",
        "/vtt/", "/srt/",
        "subtitle=", "subtitles=", "caption="
    ));

    // نطاقات الترجمة المعروفة — لا تُحجب أبداً
    private static final Set<String> SUBTITLE_DOMAINS = new HashSet<>(Arrays.asList(
        "sub.vidsrc", "subs.vidsrc", "cc.vidsrc",
        "subtitles.vidsrc", "caption.vidsrc",
        "opensubtitles", "subscene", "subdl.com",
        "jimaku.cc", "timedtext", "googlevideo.com"
    ));

    // ══════════════════════════════════════════════════════
    // Blacklist الكلمات المحظورة في الـ URL
    // ══════════════════════════════════════════════════════
    private static final Set<String> URL_BLACKLIST_KEYWORDS = new HashSet<>(Arrays.asList(
        // شبكات إعلانية
        "doubleclick", "googlesyndication", "googletagmanager", "googletagservices",
        "google-analytics", "ga.js", "pagead", "adservice",
        "adsystem", "adnxs", "adsafeprotected", "advertising",
        "amazon-adsystem", "criteo", "outbrain", "taboola", "zergnet",
        "revcontent", "mgid", "propellerads", "popcash", "popads",
        "adcash", "hilltopads", "trafficjunky", "juicyads",
        "exoclick", "trafficstars", "ero-advertising",

        // تتبع وتحليل — ⚠️ تمت إزالة "tracker" و"tracking" لأنها تتشابه مع "track" للترجمة
        // ⚠️ تمت إزالة "analytics" لأن بعض CDN تستخدمها في مسارات شرعية
        "pixel", "beacon", "telemetry",
        "hotjar", "mixpanel",
        "segment.io", "amplitude", "newrelic", "datadog",
        "sentry.io", "logrocket", "fullstory",

        // نوافذ منبثقة
        // ⚠️ تمت إزالة "redirect" لأن vidsrc يستخدمها في روابط البث
        "popup", "popunder", "clickunder",
        "click.php", "go.php", "out.php", "link.php",

        // شبكات CDN إعلانية
        "moatads", "adsrvr", "rubiconproject", "openx",
        "pubmatic", "appnexus", "smartadserver", "bidswitch",
        "lijit", "undertone", "33across", "sharethrough",

        // اختصار روابط إعلانية
        "adf.ly", "linkvertise", "shrinkme", "shorte.st",
        "adfoc.us", "ouo.io"
    ));

    // كلمات في مسار الـ URL (path) تدل على إعلانات
    private static final Set<String> URL_PATH_BLACKLIST = new HashSet<>(Arrays.asList(
        "/ads/", "/ad/", "/adv/", "/advertisement/",
        "/banner/", "/banners/", "/pop/", "/pops/",
        // ⚠️ تمت إزالة "/click/" و"/track/" لأن بعض مشغّلات الترجمة تستخدمها
        "/spy/", "/ping/"
    ));

    // ══════════════════════════════════════════════════════
    // Domain Whitelist — هذه النطاقات مسموح بها دائماً
    // ══════════════════════════════════════════════════════
    private static final Set<String> DOMAIN_WHITELIST = new HashSet<>(Arrays.asList(
        // ─── مصدر البث الوحيد: vidrock.net ───────────────────
        "vidrock.net", "www.vidrock.net",

        // CDN شرعي للمشغلين
        "jwplayer.com", "cdn.jwplayer.com", "content.jwplatform.com",
        "cdnjs.cloudflare.com",
        "videojs.com", "cdn.videojs.com",

        // مصادر شرعية لـ HLS / DASH
        "jsdelivr.net",

        // TMDB للبوسترات
        "image.tmdb.org", "themoviedb.org", "api.themoviedb.org",

        // Google Fonts
        "fonts.googleapis.com", "fonts.gstatic.com",

        // السيرفر المحلي
        extractHost(Config.PUBLIC_HOST)
    ));

    private static String extractHost(String url) {
        try {
            return url.replaceAll("https?://", "").split(":")[0].split("/")[0];
        } catch (Exception e) {
            return url;
        }
    }

    // نمط Regex للكشف عن إعلانات — ⚠️ تمت إزالة "track" لحماية الترجمة
    private static final Pattern AD_PATTERN = Pattern.compile(
        ".*(ad[s]?[._/-]|[._/-]ad[s]?|popup|popunder|banner[s]?|" +
        "click[bait]?|sponsor|promo|affiliate|" +
        "advert[ise]?|impression|conversion).*",
        Pattern.CASE_INSENSITIVE
    );

    /**
     * ✅ أولاً: هل هذا الـ URL خاص بالترجمة؟ → لا تحجبه أبداً
     */
    private static boolean isSubtitleUrl(String lowerUrl) {
        // فحص الامتداد
        for (String ext : SUBTITLE_EXTENSIONS) {
            if (lowerUrl.endsWith(ext) || lowerUrl.contains(ext + "?")) return true;
        }
        // فحص المسار
        for (String path : SUBTITLE_PATH_KEYWORDS) {
            if (lowerUrl.contains(path)) return true;
        }
        // فحص النطاق
        for (String domain : SUBTITLE_DOMAINS) {
            if (lowerUrl.contains(domain)) return true;
        }
        return false;
    }

    /**
     * الطبقة الأولى: هل يجب حظر هذا الـ URL؟
     * @param url الرابط المطلوب
     * @return true = احجب، false = اسمح
     */
    public static boolean shouldBlock(String url) {
        if (url == null || url.isEmpty()) return false;

        String lowerUrl = url.toLowerCase();

        // ✅ الحماية الأولى: لا تحجب ملفات الترجمة أبداً
        if (isSubtitleUrl(lowerUrl)) return false;

        // 1. فحص blacklist الكلمات
        for (String keyword : URL_BLACKLIST_KEYWORDS) {
            if (lowerUrl.contains(keyword)) return true;
        }

        // 2. فحص مسار الـ URL
        for (String path : URL_PATH_BLACKLIST) {
            if (lowerUrl.contains(path)) return true;
        }

        // 3. نمط regex
        if (AD_PATTERN.matcher(lowerUrl).matches()) return true;

        // 4. حجب WebSocket المشبوهة
        if (lowerUrl.startsWith("ws://") || lowerUrl.startsWith("wss://")) {
            String wsHost = lowerUrl.replaceAll("wss?://", "").split("/")[0].split(":")[0];
            return !wsHost.equals(extractHost(Config.PUBLIC_HOST));
        }

        return false;
    }

    // ══════════════════════════════════════════════════════
    // الطبقة الثانية: JavaScript Injection
    // ══════════════════════════════════════════════════════
    public static String getInjectedJS() {
        return
        "(function() {" +

        // ── إلغاء النوافذ المنبثقة ──
        "  var _noop = function() { return null; };" +
        "  window.open = _noop;" +
        "  window.alert = _noop;" +
        "  window.confirm = function() { return true; };" +
        "  window.prompt = function() { return ''; };" +
        "  window.showModalDialog = _noop;" +

        // ── منع إعادة التوجيه ──
        "  try {" +
        "    Object.defineProperty(window, 'location', {" +
        "      get: function() { return window.location; }," +
        "      set: function(v) {" +
        "        if (typeof v === 'string' && v.indexOf('eve-cinema') === -1) {" +
        "          console.log('[AdKiller] Blocked redirect to:', v);" +
        "          return;" +
        "        }" +
        "        window.location.href = v;" +
        "      }" +
        "    });" +
        "  } catch(e) {}" +

        // ── تعطيل document.write ──
        "  document.write = function() {};" +
        "  document.writeln = function() {};" +

        // ── منع النقرات على روابط إعلانية ──
        "  document.addEventListener('click', function(e) {" +
        "    if (e.target && e.target.tagName === 'A') {" +
        "      var href = e.target.href || '';" +
        "      var adKeywords = ['ads', 'pop', 'adf.ly'];" +
        "      for (var i = 0; i < adKeywords.length; i++) {" +
        "        if (href.toLowerCase().indexOf(adKeywords[i]) !== -1) {" +
        "          e.preventDefault();" +
        "          e.stopPropagation();" +
        "          return false;" +
        "        }" +
        "      }" +
        "    }" +
        "  }, true);" +

        // ── قائمة iframes المسموح بها ——————————————————————
        // ✅ تمت إضافة مسارات الترجمة للقائمة البيضاء
        "  var ALLOWED_IFRAME_HOSTS = [" +
        "    'vidrock.net', 'www.vidrock.net'," +
        "    'jwplayer', 'videojs', 'content.jwplatform'," +
        "    'subtitle', 'subtitles', 'caption', 'track'" +
        "  ];" +

        // ── MutationObserver للإعلانات ──
        "  var adSelectors = [" +
        "    '[id*=\"banner\"]', '[class*=\"banner\"]'," +
        "    '[id*=\"popup\"]', '[class*=\"popup\"]'," +
        "    '[id*=\"overlay\"]:not(.player-overlay)'," +
        "    'iframe[src*=\"doubleclick\"]'," +
        "    'iframe[src*=\"googlesynd\"]', 'ins.adsbygoogle'," +
        "    'script[src*=\"googletag\"]'," +
        "    '[data-adunit]'" +
        "  ];" +

        "  function killAds() {" +
        "    adSelectors.forEach(function(sel) {" +
        "      try {" +
        "        document.querySelectorAll(sel).forEach(function(el) {" +
        "          var rect = el.getBoundingClientRect();" +
        "          var zIndex = parseInt(window.getComputedStyle(el).zIndex) || 0;" +
        "          if (zIndex > 100 || " +
        "              rect.width > window.innerWidth * 0.8 ||" +
        "              el.tagName === 'INS') {" +
        "            el.remove();" +
        "          }" +
        "        });" +
        "      } catch(e) {}" +
        "    });" +

        // ✅ iframes — يحجب فقط المشبوهة، ويستثني الترجمة
        "    document.querySelectorAll('iframe').forEach(function(fr) {" +
        "      var src = (fr.src || '').toLowerCase();" +
        "      if (src === '' || src === 'about:blank') return;" +
        "      var isAllowed = ALLOWED_IFRAME_HOSTS.some(function(a) {" +
        "        return src.indexOf(a) !== -1;" +
        "      });" +
        "      if (!isAllowed) {" +
        "        var zIndex = parseInt(window.getComputedStyle(fr).zIndex) || 0;" +
        "        var rect = fr.getBoundingClientRect();" +
        "        // احجب فقط iframes بـ z-index مرتفع أو حجم كبير (تنبيهات/إعلانات)" +
        "        if (zIndex > 50 || rect.width > window.innerWidth * 0.9) {" +
        "          fr.remove();" +
        "        }" +
        "      }" +
        "    });" +
        "  }" +

        "  killAds();" +
        "  setInterval(killAds, 800);" +

        "  var observer = new MutationObserver(function(mutations) {" +
        "    mutations.forEach(function(m) {" +
        "      m.addedNodes.forEach(function(node) {" +
        "        if (node.nodeType === 1) killAds();" +
        "      });" +
        "    });" +
        "  });" +
        "  observer.observe(document.body || document.documentElement, {" +
        "    childList: true, subtree: true" +
        "  });" +

        // ── Click-Jack Absorber ──
        "  var clickCount = 0;" +
        "  var maxAbsorb = 3;" +
        "  var absorber = document.createElement('div');" +
        "  absorber.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;" +
        "    z-index:99999;background:transparent;pointer-events:all;';" +
        "  absorber.addEventListener('click', function(e) {" +
        "    e.preventDefault(); e.stopPropagation();" +
        "    clickCount++;" +
        "    if (clickCount >= maxAbsorb) {" +
        "      absorber.style.pointerEvents = 'none';" +
        "      absorber.remove();" +
        "    }" +
        "  });" +
        "  if (document.body) document.body.appendChild(absorber);" +

        "  console.log('[إيف Ad-Killer] ✅ تم تفعيل الحماية مع دعم الترجمة');" +
        "})();";
    }

    // ══════════════════════════════════════════════════════
    // الطبقة الثالثة: CSS Injection
    // ══════════════════════════════════════════════════════
    public static String getInjectedCSS() {
        return
        // إخفاء العناصر الإعلانية — ✅ لا تشمل عناصر الترجمة
        "[id*='banner']:not(video):not(track)," +
        "[class*='banner']:not(video)," +
        "[id*='popup']," +
        "[class*='popup']," +
        "[id*='overlay']:not(.player-overlay)," +
        "ins.adsbygoogle," +
        ".adsbygoogle," +
        "#google_ads_iframe," +
        "[id^='google_ads']," +
        "[id*='dfp-ad']," +
        ".ad-container," +
        ".advertisement," +
        ".sponsored," +
        "body > div[style*='z-index: 99'][style*='position: fixed'][style*='top: 0']," +
        "body > div[style*='z-index:99'][style*='position:fixed'][style*='top:0']" +
        "{ display: none !important; visibility: hidden !important;" +
        "  opacity: 0 !important; pointer-events: none !important;" +
        "  max-height: 0 !important; overflow: hidden !important; }";
    }
}
