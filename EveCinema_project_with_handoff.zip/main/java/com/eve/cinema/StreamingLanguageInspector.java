package com.eve.cinema;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;

import javax.xml.parsers.DocumentBuilderFactory;

/** Reads only explicit audio-language declarations from HLS/DASH manifests. */
public final class StreamingLanguageInspector {
    private static final int MAX_BYTES = 2 * 1024 * 1024;
    private StreamingLanguageInspector() {}

    public static Set<String> inspect(String url, Map<String, String> headers) throws Exception {
        if (url == null || url.trim().isEmpty()) return Collections.emptySet();
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        try {
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(12000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("Accept-Encoding", "gzip");
            connection.setRequestProperty("Accept", "application/dash+xml, application/vnd.apple.mpegurl, */*");
            if (headers != null) for (Map.Entry<String, String> h : headers.entrySet()) {
                if (h.getKey() != null && h.getValue() != null) connection.setRequestProperty(h.getKey(), h.getValue());
            }
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new java.io.IOException("Manifest HTTP " + status);
            InputStream raw = connection.getInputStream();
            InputStream in = "gzip".equalsIgnoreCase(connection.getHeaderField("Content-Encoding"))
                    ? new GZIPInputStream(raw) : raw;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int read;
            while ((read = in.read(buffer)) >= 0) {
                out.write(buffer, 0, read);
                if (out.size() > MAX_BYTES) throw new java.io.IOException("Manifest exceeds inspection limit");
            }
            in.close();
            return parseLanguages(new String(out.toByteArray(), StandardCharsets.UTF_8));
        } finally { connection.disconnect(); }
    }

    /** Pure parser entry point, also used by local fixture tests. */
    public static Set<String> parseLanguages(String raw) throws Exception {
        if (raw == null) return Collections.emptySet();
        String text = raw.replace("\uFEFF", "").trim();
        Set<String> languages = new HashSet<>();
        if (text.startsWith("#EXTM3U")) {
            for (String line : text.split("\\r?\\n")) {
                String upper = line.toUpperCase(Locale.ROOT);
                if (!upper.startsWith("#EXT-X-MEDIA:") || !upper.contains("TYPE=AUDIO")) continue;
                String lang = attribute(line, "LANGUAGE");
                if (lang != null && !lang.trim().isEmpty()) languages.add(lang.trim());
            }
            return languages;
        }
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        try { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) {}
        try { factory.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) {}
        try { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) {}
        factory.setXIncludeAware(false);
        factory.setExpandEntityReferences(false);
        Document document = factory.newDocumentBuilder().parse(
                new org.xml.sax.InputSource(new java.io.StringReader(text)));
        NodeList sets = document.getElementsByTagNameNS("*", "AdaptationSet");
        if (sets.getLength() == 0) sets = document.getElementsByTagName("AdaptationSet");
        for (int i = 0; i < sets.getLength(); i++) {
            Node node = sets.item(i);
            if (!(node instanceof Element)) continue;
            Element adaptation = (Element) node;
            String contentType = attr(adaptation, "contentType");
            String mimeType = attr(adaptation, "mimeType");
            boolean audio = "audio".equalsIgnoreCase(contentType) || mimeType.toLowerCase(Locale.ROOT).startsWith("audio/");
            if (!audio) {
                NodeList reps = adaptation.getElementsByTagNameNS("*", "Representation");
                if (reps.getLength() == 0) reps = adaptation.getElementsByTagName("Representation");
                for (int r = 0; r < reps.getLength(); r++) {
                    Node rep = reps.item(r);
                    if (rep instanceof Element && attr((Element) rep, "mimeType").toLowerCase(Locale.ROOT).startsWith("audio/")) { audio = true; break; }
                }
            }
            if (!audio) continue;
            String language = attr(adaptation, "lang");
            if (!language.isEmpty()) languages.add(language);
        }
        return languages;
    }

    private static String attr(Element element, String name) {
        if (element.hasAttribute(name)) return element.getAttribute(name).trim();
        String value = element.getAttributeNS("http://www.w3.org/XML/1998/namespace", name);
        return value == null ? "" : value.trim();
    }
    private static String attribute(String line, String key) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:^|[,;])\\s*" + key + "\\s*=\\s*\"([^\"]*)\"", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(line);
        if (m.find()) return m.group(1);
        m = java.util.regex.Pattern.compile("(?:^|[,;])\\s*" + key + "\\s*=\\s*([^,;]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(line);
        return m.find() ? m.group(1).trim() : null;
    }
}
