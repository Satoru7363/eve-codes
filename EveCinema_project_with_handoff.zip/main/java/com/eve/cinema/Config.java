package com.eve.cinema;

/**
 * ══════════════════════════════════════════════════════════
 *  Config.java — الإعدادات المركزية لإيف سينما
 *  نظام البث: CinemaBox (cinema.albox.co)
 *  معلومات الأفلام: TMDB
 * ══════════════════════════════════════════════════════════
 */
public class Config {

    // ══════════════════════════════════════════════════════════
    //  CinemaBox — مصدر البث الأساسي
    //  بيانات الدخول لحساب CinemaBox الخاص بك
    //  (اشتراك مدفوع مطلوب)
    // ══════════════════════════════════════════════════════════
    public static final String CINEMABOX_EMAIL    = "bkrmshtaq79@gmail.com";    // ← غيّر هذا
    public static final String CINEMABOX_PASSWORD = "07744080333@@";     // ← غيّر هذا

    // ══════════════════════════════════════════════════════════
    //  TMDB — معلومات الأفلام والمسلسلات
    //  احصل على مفتاحك من: https://www.themoviedb.org/settings/api
    // ══════════════════════════════════════════════════════════
    public static final String TMDB_BEARER_TOKEN =
        "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4M2IwMGE5M2M1YmEyMmQxNDYzNWViZmQ5YTI1M2ZjMiIsIm5iZiI6MTc1MjA1OTI4NS42MDcsInN1YiI6IjY4NmU0ZDk1NGNiMTU4ZDdiZGVkNjU2YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.b3GvmcSJXU6q_ZRGnUpqO7iFqrhaugqIovkrI8S-oYQ";                             // ← Bearer token
    public static final String TMDB_API_KEY      = "83b00a93c5ba22d14635ebfd9a253fc2"; // ← أو API key
    public static final String TMDB_BASE_URL     = "https://api.themoviedb.org/3/";
    public static final String TMDB_IMAGE_BASE   = "https://image.tmdb.org/t/p/";
    public static final String TMDB_POSTER_SIZE  = "w500";
    public static final String TMDB_BACKDROP_SIZE= "w1280";
    public static final String TMDB_LANGUAGE     = "ar-SA";             // عربي أولاً

    // نقاط TMDB الرئيسية
    public static final String TMDB_MOVIE_DETAILS = TMDB_BASE_URL + "movie/%s?language=" + TMDB_LANGUAGE + "&append_to_response=credits,videos,similar";
    public static final String TMDB_TV_DETAILS    = TMDB_BASE_URL + "tv/%s?language=" + TMDB_LANGUAGE + "&append_to_response=credits,videos,similar";
    public static final String TMDB_SEASON        = TMDB_BASE_URL + "tv/%s/season/%d?language=" + TMDB_LANGUAGE;
    public static final String TMDB_SEARCH_MULTI  = TMDB_BASE_URL + "search/multi?query=%s&language=" + TMDB_LANGUAGE + "&page=1";
    public static final String TMDB_TRENDING      = TMDB_BASE_URL + "trending/%s/week?language=" + TMDB_LANGUAGE;
    public static final String TMDB_POPULAR       = TMDB_BASE_URL + "%s/popular?language=" + TMDB_LANGUAGE + "&page=1";
    public static final String TMDB_TOP_RATED     = TMDB_BASE_URL + "%s/top_rated?language=" + TMDB_LANGUAGE + "&page=1";

    // ══════════════════════════════════════════════════════════
    //  Firebase Realtime Database — نظام التراخيص
    // ══════════════════════════════════════════════════════════
    public static final String FIREBASE_DB_URL      = "https://eve-cinema-4c6f9-default-rtdb.europe-west1.firebasedatabase.app";
    public static final String FIREBASE_LICENSE_URL = FIREBASE_DB_URL + "/licenses/";

    // ══════════════════════════════════════════════════════════
    //  الباقي من الإعدادات العامة
    // ══════════════════════════════════════════════════════════
    public static final String TELEGRAM_BOT_URL  = "https://t.me/amhnak_bot";
    public static final boolean REQUIRE_TOKEN     = false;

    // ══════════════════════════════════════════════════════════
    //  User-Agent (للاتصال بـ TMDB و CinemaBox)
    // ══════════════════════════════════════════════════════════
    public static final String USER_AGENT =
        "Mozilla/5.0 (Linux; Android 12; Redmi Note 8 Pro) " +
        "AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/120.0.0.0 Mobile Safari/537.36";

    // ══════════════════════════════════════════════════════════
    //  ملاحظة: تمت إزالة جميع روابط vidrock.net
    //  البث الآن حصراً من CinemaBoxExtractor
    // ══════════════════════════════════════════════════════════

    // ══════════════════════════════════════════════════════════
    //  متغيرات متوافقة مع الكود القديم (لا تحذفها)
    // ══════════════════════════════════════════════════════════

    // PUBLIC_HOST — يُستخدم في AdBlocker لتبييض نطاق السيرفر
    // اتركه فارغاً إذا لم يعد لديك Cloudflare server
    public static final String PUBLIC_HOST = "";

    // API_VERIFY — كان يُستخدم في TokenManager للتحقق من الرمز
    // الآن غير مستخدم لكن نحتفظ به لتجنب أخطاء التصريح
    public static final String API_VERIFY  = "";
    public static final String API_WATCH   = "";
    public static final String API_PARTY   = "";

    // OpenSubtitles — اترك فارغاً لتعطيل الترجمة الخارجية
    // أو ضع مفتاحك من https://www.opensubtitles.com/en/consumers
    public static final String OPENSUBTITLES_API_KEY = "";

    // WebView user-agent (محتفَظ به للتوافق مع AdBlocker)
    public static final String USER_AGENT_OVERRIDE =
        "Mozilla/5.0 (Linux; Android 12; Redmi Note 8 Pro) " +
        "AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/120.0.0.0 Mobile Safari/537.36";
    public static final int    WEBVIEW_TIMEOUT = 30_000;

    private Config() {}
}
