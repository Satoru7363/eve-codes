package com.eve.cinema;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Generic glass / purple bottom sheet (same visual language as
 * {@link QualityBottomSheet}) used for the viewing-mode chooser, the source
 * switch and the real-rendition quality menu.
 */
public class GlassChoiceSheet extends Dialog {

    public interface OnChoice { void onChoice(int index); }

    public static final class Row {
        final String label;
        final String detail;
        final boolean enabled;
        final boolean current;
        public Row(String label, String detail, boolean enabled, boolean current) {
            this.label = label; this.detail = detail; this.enabled = enabled; this.current = current;
        }
    }

    private final String title;
    private final List<Row> rows;
    private final OnChoice callback;

    public GlassChoiceSheet(Context ctx, String title, List<Row> rows, OnChoice callback) {
        super(ctx, R.style.QualitySheetTheme);
        this.title = title;
        this.rows = rows != null ? rows : new ArrayList<Row>();
        this.callback = callback;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(buildLayout());
        Window w = getWindow();
        if (w != null) {
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setWindowAnimations(R.style.QualitySheetAnim);
        }
    }

    private View buildLayout() {
        Context ctx = getContext();
        float d = ctx.getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(ctx.getDrawable(R.drawable.bg_quality_sheet));
        root.setPadding((int) (24 * d), (int) (20 * d), (int) (24 * d), (int) (20 * d));

        View handle = new View(ctx);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams((int) (40 * d), (int) (4 * d));
        hlp.gravity = Gravity.CENTER_HORIZONTAL;
        hlp.bottomMargin = (int) (20 * d);
        handle.setLayoutParams(hlp);
        handle.setBackground(ctx.getDrawable(R.drawable.bg_handle));
        root.addView(handle);

        TextView t = new TextView(ctx);
        t.setText(title);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.bottomMargin = (int) (16 * d);
        t.setLayoutParams(tlp);
        root.addView(t);

        for (int i = 0; i < rows.size(); i++) root.addView(buildRow(ctx, rows.get(i), i, d));
        return root;
    }

    private View buildRow(Context ctx, Row r, final int index, float d) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding((int) (14 * d), (int) (14 * d), (int) (14 * d), (int) (14 * d));
        row.setBackground(ctx.getDrawable(r.current ? R.drawable.bg_quality_row_active : R.drawable.bg_quality_row));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = (int) (8 * d);
        row.setLayoutParams(lp);
        row.setAlpha(r.enabled ? 1f : 0.42f);

        TextView label = new TextView(ctx);
        label.setText(r.current ? r.label + "  ✓" : r.label);
        label.setTextColor(r.current ? 0xFF9B6FC4 : 0xFFFFFFFF);
        label.setTextSize(15f);
        row.addView(label);

        if (r.detail != null && !r.detail.isEmpty()) {
            TextView detail = new TextView(ctx);
            detail.setText(r.detail);
            detail.setTextColor(0xFF9A9A9A);
            detail.setTextSize(12f);
            row.addView(detail);
        }

        if (r.enabled) {
            row.setClickable(true);
            row.setFocusable(true);
            row.setOnClickListener(v -> {
                dismiss();
                if (callback != null) callback.onChoice(index);
            });
        }
        return row;
    }
}
