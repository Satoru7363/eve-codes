package com.eve.cinema.playback;

/**
 * Classified result of a provider availability probe (WP2).
 *
 * The details/episodes source probe must never turn a transient failure into
 * "the title does not exist": only a search that actually completed may yield
 * a definitive answer, and only that answer may be cached.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public enum ProbeOutcome {
    /** The provider search completed and a candidate passed every identity gate. */
    VERIFIED,
    /** The provider search completed and no candidate exists/passed — a real negative. */
    NOT_FOUND_DEFINITIVE,
    /** Candidates existed but were rejected by identity gates (type/year/title). */
    REJECTED_BY_IDENTITY,
    /** Timeout, HTTP error, login failure or parse error — says nothing about existence. */
    UNRESOLVED_TRANSIENT;

    /** True for outcomes that may be shown/cached as a definitive negative. */
    public boolean isDefinitiveNegative() {
        return this == NOT_FOUND_DEFINITIVE || this == REJECTED_BY_IDENTITY;
    }

    /** True when the probe actually answered the availability question. */
    public boolean isResolved() {
        return this != UNRESOLVED_TRANSIENT;
    }
}
