package com.eve.cinema.playback;

/**
 * Shared identity gates for provider candidates (MovieBox and CinemaBox).
 *
 * A provider candidate is only accepted when it can be the SAME work as the
 * TMDB identity being resolved:
 *  - media type must match on EVERY search/fallback path (a movie request can
 *    never use a series candidate and vice versa);
 *  - when both years are known and contradict each other (different
 *    installment / remake), the candidate is rejected outright — a title match
 *    can never override a contradictory year.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public final class MediaIdentity {

    /** Years closer than this are treated as release-date noise, not remakes. */
    public static final int MAX_YEAR_DIFF = 1;
    /** Beyond this the works are considered different installments/remakes. */
    public static final int HARD_YEAR_DIFF = 3;

    private MediaIdentity() {}

    /** Normalised provider type: "movie" or "series"; null when unknown. */
    public static String normalizeType(String raw) {
        if (raw == null) return null;
        String t = raw.trim().toLowerCase(java.util.Locale.US);
        switch (t) {
            case "movie": case "movies": case "film": case "1": return "movie";
            case "series": case "tv": case "show": case "anime": case "2": return "series";
            default: return t.isEmpty() ? null : t;
        }
    }

    /**
     * Type gate: unknown candidate type is allowed (score decides), a known
     * contradictory type is rejected. {@code wantType} accepts
     * "movie"/"series"/"tv"/"anime" ("anime" is a series on both providers).
     */
    public static boolean typeMatches(String wantType, String candidateType) {
        String want = normalizeType(wantType);
        String cand = normalizeType(candidateType);
        if (want == null || cand == null) return true;
        return want.equals(cand);
    }

    /**
     * Year gate. When either year is unknown the candidate survives (identity
     * must then be proven by strong title/metadata evidence). When both are
     * known:
     *  - |diff| <= 1  → compatible (release-date variance);
     *  - |diff| 2..3  → suspicious (heavy score penalty, not fatal);
     *  - |diff| > 3   → hard reject: different installment/remake.
     */
    public static boolean yearsCompatible(int wantYear, int candidateYear) {
        if (wantYear <= 0 || candidateYear <= 0) return true;
        return Math.abs(wantYear - candidateYear) <= HARD_YEAR_DIFF;
    }

    /** Strict rejection used before scoring: different installment/remake. */
    public static boolean yearHardRejects(int wantYear, int candidateYear) {
        return !yearsCompatible(wantYear, candidateYear);
    }

    /** Suspicious-but-not-fatal zone, for score penalties. */
    public static boolean yearSuspicious(int wantYear, int candidateYear) {
        if (wantYear <= 0 || candidateYear <= 0) return false;
        int diff = Math.abs(wantYear - candidateYear);
        return diff > MAX_YEAR_DIFF && diff <= HARD_YEAR_DIFF;
    }

    /** Why a provider candidate was rejected by an identity gate. */
    public enum RejectReason {
        NONE,
        TYPE_MISMATCH,
        /** Both years known and contradictory for this gate. */
        YEAR_MISMATCH,
        /** The candidate's year is missing/unverified where the gate requires one. */
        YEAR_UNVERIFIED,
        /** A missing/±1 year was only allowed with exact title equality, and the title is not exact. */
        TITLE_NOT_EXACT
    }

    /**
     * Strict CinemaBox MOVIE year gate (F5): when the TMDB year is known the
     * candidate year must be EXACTLY equal — no ±1, no unknown-year survival.
     * An unknown TMDB year cannot gate anything, so the candidate survives and
     * the title/type evidence decides.
     */
    public static boolean cinemaBoxMovieYearOk(int wantYear, int candidateYear) {
        if (wantYear <= 0) return true;
        return candidateYear == wantYear;
    }

    /**
     * CinemaBox SERIES year gate: both years known → reject when they differ by
     * more than 1; a ±1 difference is accepted only with exact normalized-title
     * equality (a franchise neighbour one year apart with a merely similar title
     * is a different show). A missing candidate year does not reject on its own
     * (that would regress discovery) but then requires exact title equality too.
     */
    public static boolean cinemaBoxSeriesYearOk(int wantYear, int candidateYear,
                                                boolean exactTitleMatch) {
        if (wantYear <= 0) return true;
        if (candidateYear <= 0) return exactTitleMatch;
        int diff = Math.abs(wantYear - candidateYear);
        if (diff > MAX_YEAR_DIFF) return false;
        return diff == 0 || exactTitleMatch;
    }

    /**
     * The CinemaBox identity verdict for one candidate, for tracing: which gate
     * (if any) rejected it. {@code type} is the requested provider type
     * ("MOVIE"/"SERIES"); {@code exactTitleMatch} is exact normalized equality
     * against the reference title.
     */
    public static RejectReason cinemaBoxRejection(String type, int wantYear, int candidateYear,
                                                  boolean exactTitleMatch) {
        boolean movie = type != null && "movie".equals(normalizeType(type));
        if (movie) {
            if (wantYear <= 0) return RejectReason.NONE;
            if (candidateYear <= 0) return RejectReason.YEAR_UNVERIFIED;
            return candidateYear == wantYear ? RejectReason.NONE : RejectReason.YEAR_MISMATCH;
        }
        if (wantYear <= 0) return RejectReason.NONE;
        if (candidateYear <= 0)
            return exactTitleMatch ? RejectReason.NONE : RejectReason.YEAR_UNVERIFIED;
        int diff = Math.abs(wantYear - candidateYear);
        if (diff > MAX_YEAR_DIFF) return RejectReason.YEAR_MISMATCH;
        if (diff == 1 && !exactTitleMatch) return RejectReason.TITLE_NOT_EXACT;
        return RejectReason.NONE;
    }
}
