package com.eve.cinema.playback;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Tiny bounded trace of resolution decisions (WP2): which stage ran, the
 * outcome class, why a candidate was rejected, and which availability level
 * was proven. Built for the owner's device runs — the activities install a
 * Logcat sink with tag {@link #TAG} ("EveTrace") and the last entries can be
 * dumped from the debug screen.
 *
 * Privacy: query strings, tokens, cookies and headers are never recorded;
 * free-form details are stripped of URLs/query strings and long identifiers
 * are truncated before they reach the buffer.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public final class ResolutionTrace {

    /** Logcat tag the Android sink must use. */
    public static final String TAG = "EveTrace";
    private static final int MAX_ENTRIES = 200;
    private static final int MAX_DETAIL = 160;

    /** Receives one already-sanitised line (e.g. android.util.Log.d(TAG, line)). */
    public interface Sink {
        void log(String tag, String line);
    }

    private static final class Entry {
        final long at;
        final String line;
        Entry(long at, String line) { this.at = at; this.line = line; }
    }

    private static final List<Entry> BUFFER = new ArrayList<>(MAX_ENTRIES);
    private static volatile Sink sink;

    private ResolutionTrace() {}

    /** Installs (or clears, with null) the external sink. Callers: activities. */
    public static void setSink(Sink s) {
        sink = s;
    }

    /**
     * Records one resolution event. {@code stage} is a short stable identifier
     * ("mb.search", "cb.identity", "probe.details", "captions"); {@code detail}
     * is sanitised before storing — pass no secrets and no full URLs.
     */
    public static void record(String stage, String outcome, String detail) {
        StringBuilder sb = new StringBuilder(64);
        sb.append(stage == null ? "-" : stage)
          .append('|').append(outcome == null ? "-" : outcome);
        String clean = sanitize(detail);
        if (!clean.isEmpty()) sb.append('|').append(clean);
        String line = sb.toString();
        synchronized (BUFFER) {
            if (BUFFER.size() >= MAX_ENTRIES) BUFFER.remove(0);
            BUFFER.add(new Entry(System.currentTimeMillis(), line));
        }
        Sink s = sink;
        if (s != null) {
            try { s.log(TAG, line); } catch (RuntimeException ignored) {}
        }
    }

    /** Oldest-first copy of the buffered lines (bounded by {@link #MAX_ENTRIES}). */
    public static List<String> snapshot() {
        synchronized (BUFFER) {
            List<String> out = new ArrayList<>(BUFFER.size());
            for (Entry e : BUFFER) out.add(e.line);
            return out;
        }
    }

    /** Test hook. */
    public static void clear() {
        synchronized (BUFFER) { BUFFER.clear(); }
    }

    /**
     * Strips anything that could carry a query string, token, cookie or header
     * value and truncates long runs of identifier characters. Keeps short
     * structural facts (ids, scores, reasons, season/episode numbers).
     */
    static String sanitize(String detail) {
        if (detail == null) return "";
        String s = detail.trim();
        if (s.isEmpty()) return "";
        // Cut URLs outright: a signed URL can carry tokens in its query.
        if (s.contains("://")) {
            int idx = s.indexOf("://");
            int start = idx;
            while (start > 0 && s.charAt(start - 1) != ' ' && s.charAt(start - 1) != '(') start--;
            int end = s.indexOf(' ', idx);
            if (end < 0) end = s.length();
            s = s.substring(0, start) + "[url]" + (end < s.length() ? s.substring(end) : "");
        }
        // Drop anything after a bare '?' — query strings carry signatures.
        int q = s.indexOf('?');
        if (q >= 0) s = s.substring(0, q) + "[query]";
        // Redact common secret carriers.
        s = redactKey(s, "token");
        s = redactKey(s, "cookie");
        s = redactKey(s, "authorization");
        s = redactKey(s, "header");
        s = redactKey(s, "password");
        // Truncate very long identifier runs (session/subject ids beyond 12 chars).
        StringBuilder out = new StringBuilder(s.length());
        int run = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean idChar = Character.isLetterOrDigit(c);
            if (idChar) {
                run++;
                if (run <= 12) out.append(c);
                else if (run == 13) out.append('…');
            } else {
                run = 0;
                out.append(c);
            }
        }
        String r = out.toString().trim();
        return r.length() > MAX_DETAIL ? r.substring(0, MAX_DETAIL - 1) + "…" : r;
    }

    private static String redactKey(String s, String key) {
        String lower = s.toLowerCase(Locale.US);
        String needle = key + "=";
        int idx = lower.indexOf(needle);
        if (idx < 0) {
            needle = key + ": ";
            idx = lower.indexOf(needle);
            if (idx < 0) {
                needle = key + ":";
                idx = lower.indexOf(needle);
            }
        }
        if (idx < 0) return s;
        int valStart = idx + needle.length();
        int valEnd = s.indexOf(' ', valStart);
        if (valEnd < 0) valEnd = s.length();
        return s.substring(0, valStart) + "[redacted]"
                + (valEnd < s.length() ? s.substring(valEnd) : "");
    }
}
