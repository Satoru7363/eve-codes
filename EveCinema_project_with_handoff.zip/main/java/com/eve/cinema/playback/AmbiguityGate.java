package com.eve.cinema.playback;

/**
 * Top-2 ambiguity gate for provider candidate scoring (P6 / franchise safety).
 *
 * A search for "Resident Evil (2002)" must never silently pick "Resident Evil:
 * Welcome to Raccoon City (2021)" — nor the reverse — when both candidates
 * clear the minimum score with no decisive margin and their years prove they
 * are different installments. In that case the honest answer is "not found",
 * never a guess.
 *
 * Conservative by design:
 *  - the runner-up must itself clear {@code minScore} (a weak runner-up is no
 *    ambiguity);
 *  - a decisive score margin (>= {@link #MARGIN}) settles the choice;
 *  - an unknown candidate year cannot prove a different installment, so it
 *    never triggers rejection.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public final class AmbiguityGate {

    /** Score margin below which two conflicting-year candidates tie. */
    public static final int MARGIN = 6;

    private AmbiguityGate() {}

    /**
     * @param bestScore   score of the best candidate
     * @param bestYear    release year of the best candidate (0 = unknown)
     * @param secondScore score of the runner-up (below minScore = no runner-up)
     * @param secondYear  release year of the runner-up (0 = unknown)
     * @param minScore    the minimum acceptance score of the calling round
     * @return true when the result is ambiguous and must be rejected
     */
    public static boolean isAmbiguous(int bestScore, int bestYear,
                                      int secondScore, int secondYear,
                                      int minScore) {
        if (secondScore < minScore) return false;
        if (bestScore - secondScore >= MARGIN) return false;
        if (bestYear <= 0 || secondYear <= 0) return false;
        return bestYear != secondYear;
    }
}
