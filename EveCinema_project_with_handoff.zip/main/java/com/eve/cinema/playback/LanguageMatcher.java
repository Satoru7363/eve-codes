package com.eve.cinema.playback;

import java.util.Locale;

/**
 * Normalises subtitle / audio language labels coming from providers and Media3
 * Formats. Arabic is matched by ISO codes (ar, ara, arb, ar-XX) and by names
 * ("Arabic", "العربية", "عربي"). Never matches Hindi, Armenian, etc.
 */
public final class LanguageMatcher {

    public static final String AR = "ar";
    public static final String EN = "en";

    private LanguageMatcher() {}

    public static boolean isArabic(String raw) {
        return AR.equals(normalize(raw));
    }

    public static boolean isEnglish(String raw) {
        return EN.equals(normalize(raw));
    }

    /** Returns "ar", "en", another lower-case primary code, or null when unknown. */
    public static String normalize(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty()) return null;
        String lower = s.toLowerCase(Locale.ROOT);

        if (lower.contains("عرب") || lower.contains("arabic")) return AR;
        if (lower.contains("إنجليز") || lower.contains("انجليز") || lower.contains("english"))
            return EN;

        String code = lower.replace('_', '-');
        int dash = code.indexOf('-');
        String primary = dash > 0 ? code.substring(0, dash) : code;
        switch (primary) {
            case "ar": case "ara": case "arb": return AR;
            case "en": case "eng": return EN;
            case "und": case "unknown": case "": return null;
            default:
                return primary.matches("[a-z]{2,3}") ? primary : null;
        }
    }
}
