package com.eve.cinema.playback;

/**
 * Single source of truth for when the custom «الحلقة التالية» button may be
 * on screen. Pure Java so the rule is unit-tested without a player.
 *
 * The button is visible only when ALL of the following hold:
 *  - a valid next episode exists;
 *  - the player controls are currently visible;
 *  - the duration is known and valid (unknown / zero / negative → hidden;
 *    Media3 reports an unknown duration as C.TIME_UNSET, a large negative);
 *  - the duration is longer than the window, so the window can never cover
 *    the start of an episode just because playback began;
 *  - at most {@link #WINDOW_MS} remain: {@code duration - position}.
 *
 * It is re-evaluated from the real player state (no timer of its own), so a
 * backward seek hides it immediately and bringing the controls back inside
 * the window shows it again.
 */
public final class NextEpisodeWindow {

    /** The button appears when this much (or less) of the episode remains. */
    public static final long WINDOW_MS = 60_000L;

    private NextEpisodeWindow() {}

    public static boolean shouldShow(boolean validNextEpisode, boolean controlsVisible,
                                     long durationMs, long positionMs) {
        if (!validNextEpisode || !controlsVisible) return false;
        if (durationMs <= WINDOW_MS) return false; // unknown/zero/invalid, or too short to have a "start" outside the window
        if (positionMs < 0) return false;
        return remainingMs(durationMs, positionMs) <= WINDOW_MS;
    }

    /** {@code duration - position}, never negative. */
    public static long remainingMs(long durationMs, long positionMs) {
        return Math.max(0L, durationMs - positionMs);
    }
}
