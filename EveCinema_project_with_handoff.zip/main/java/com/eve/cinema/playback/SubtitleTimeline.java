package com.eve.cinema.playback;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Immutable timeline index for parsed subtitle cues. At a given instant the
 * latest-starting active cue wins; cue intervals are [startMs, endMs).
 * Prefix maximum end times let the lookup find long overlapping cues without
 * relying on an arbitrary small backward scan window.
 */
public final class SubtitleTimeline {
    private final List<SubtitleParser.Cue> cues;
    private final long[] prefixMaxEndMs;

    public SubtitleTimeline(List<SubtitleParser.Cue> input) {
        List<SubtitleParser.Cue> copy = new ArrayList<>();
        if (input != null) {
            for (SubtitleParser.Cue cue : input) {
                if (cue != null && cue.startMs >= 0 && cue.endMs > cue.startMs
                        && cue.text != null && !cue.text.isEmpty()) copy.add(cue);
            }
        }
        // Stable ordering preserves source order for cues sharing a start time.
        Collections.sort(copy, (a, b) -> Long.compare(a.startMs, b.startMs));
        cues = Collections.unmodifiableList(copy);
        prefixMaxEndMs = new long[cues.size()];
        long maxEnd = Long.MIN_VALUE;
        for (int i = 0; i < cues.size(); i++) {
            maxEnd = Math.max(maxEnd, cues.get(i).endMs);
            prefixMaxEndMs[i] = maxEnd;
        }
    }

    public int size() { return cues.size(); }

    /** Returns the winning cue index or -1 when no cue is active. */
    public int indexAt(long positionMs) {
        if (positionMs < 0 || cues.isEmpty()) return -1;
        int low = 0;
        int high = cues.size();
        while (low < high) {
            int mid = (low + high) >>> 1;
            if (cues.get(mid).startMs <= positionMs) low = mid + 1;
            else high = mid;
        }
        for (int i = low - 1; i >= 0; i--) {
            // No interval at or before i can still be active; older cues may be skipped.
            if (prefixMaxEndMs[i] <= positionMs) break;
            SubtitleParser.Cue cue = cues.get(i);
            if (cue.startMs <= positionMs && positionMs < cue.endMs) return i;
        }
        return -1;
    }

    public SubtitleParser.Cue cueAt(long positionMs) {
        int index = indexAt(positionMs);
        return index < 0 ? null : cues.get(index);
    }
}
