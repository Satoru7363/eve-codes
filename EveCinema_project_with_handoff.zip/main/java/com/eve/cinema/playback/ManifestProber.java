package com.eve.cinema.playback;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Fetches an adaptive manifest (DASH MPD / HLS master) with the stream's own
 * provider headers and extracts the audio languages it declares. Used ONLY by
 * the portrait pre-player chooser as a lightweight, cancellable preflight —
 * playback itself is still done by Media3, which re-reads the manifest.
 *
 * Safety rules:
 *  - the response body is capped ({@link #MAX_MANIFEST_BYTES}) — a manifest is
 *    kilobytes, a media segment is not; oversize bodies are abandoned;
 *  - only http(s) URLs are fetched; signed query strings are sent as-is and
 *    never logged here;
 *  - any failure returns an empty list: the chooser simply offers fewer modes,
 *    it never invents an audio language.
 *
 * Pure Java (HttpURLConnection is JDK) — unit-tested with a local HTTP server.
 */
public final class ManifestProber {

    public static final int MAX_MANIFEST_BYTES = 512 * 1024;
    public static final int CONNECT_TIMEOUT_MS = 8000;
    public static final int READ_TIMEOUT_MS    = 8000;

    private ManifestProber() {}

    /**
     * Downloads the manifest at {@code url} (only when the URL shape says it
     * is an adaptive manifest) and returns its declared audio languages.
     * Never throws; empty list on any error or non-manifest URL.
     */
    public static List<String> fetchAudioLanguages(String url, Map<String, String> headers) {
        List<String> out = new ArrayList<>();
        if (url == null || url.isEmpty()) return out;
        String clean = url.split("\\?")[0].toLowerCase(java.util.Locale.US);
        boolean dash = clean.endsWith(".mpd") || clean.contains("/dash/");
        boolean hls  = clean.endsWith(".m3u8");
        if (!dash && !hls) return out;
        if (!url.startsWith("https://") && !url.startsWith("http://")) return out;

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setInstanceFollowRedirects(true);
            if (headers != null) {
                for (Map.Entry<String, String> h : headers.entrySet()) {
                    if (h.getKey() == null || h.getValue() == null) continue;
                    conn.setRequestProperty(h.getKey(), h.getValue());
                }
            }
            int code = conn.getResponseCode();
            if (code / 100 != 2) return out;
            String body = readCapped(conn.getInputStream(), MAX_MANIFEST_BYTES);
            if (body == null) return out;
            return dash ? ManifestAudioParser.parseDashAudioLanguages(body)
                        : ManifestAudioParser.parseHlsAudioLanguages(body);
        } catch (Exception e) {
            return out;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** Reads at most {@code max} bytes; null when the body exceeds the cap. */
    private static String readCapped(InputStream in, int max) throws Exception {
        if (in == null) return null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int total = 0;
        int n;
        try {
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > max) return null;
                bos.write(buf, 0, n);
            }
        } finally {
            try { in.close(); } catch (Exception ignored) {}
        }
        return new String(bos.toByteArray(), "UTF-8");
    }
}
