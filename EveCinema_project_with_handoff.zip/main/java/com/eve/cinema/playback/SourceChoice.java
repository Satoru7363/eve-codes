package com.eve.cinema.playback;

/**
 * The details-page source selector model. Pure Java — unit-tested on the JVM.
 *
 * Stable source ids (never reorder, never reuse):
 *   1 = MovieBox   (user label: «مصدر 1»)
 *   2 = CinemaBox  (user label: «مصدر 2»)
 *
 * User-facing labels are ONLY the generic Arabic labels; provider names are
 * never exposed in the UI. Anime policy lives here too: anime is MovieBox-only,
 * so a CinemaBox probe result is ignored for anime regardless of availability.
 */
public final class SourceChoice {

    public static final int SOURCE_MOVIEBOX  = 1;
    public static final int SOURCE_CINEMABOX = 2;

    /** Canonical user-facing labels — exactly «مصدر 1» / «مصدر 2». */
    public static final String LABEL_1 = "مصدر 1";
    public static final String LABEL_2 = "مصدر 2";

    private SourceChoice() {}

    /** Label for a source id; empty string for an unknown id. */
    public static String label(int sourceId) {
        if (sourceId == SOURCE_MOVIEBOX)  return LABEL_1;
        if (sourceId == SOURCE_CINEMABOX) return LABEL_2;
        return "";
    }

    public static boolean isValid(int sourceId) {
        return sourceId == SOURCE_MOVIEBOX || sourceId == SOURCE_CINEMABOX;
    }

    /**
     * The availability decision for the details page.
     * {@link #choices} holds the exposed source ids in display order (1 then 2);
     * {@link #selected} is the default selection (first exposed choice);
     * {@link #showDropdown} is true only when the user has a real choice;
     * {@link #noSource} is true when neither provider verified the content.
     */
    public static final class Decision {
        public final int[] choices;
        public final int selected;
        public final boolean showDropdown;
        public final boolean noSource;

        Decision(int[] choices, int selected, boolean showDropdown, boolean noSource) {
            this.choices = choices;
            this.selected = selected;
            this.showDropdown = showDropdown;
            this.noSource = noSource;
        }

        public boolean exposes(int sourceId) {
            for (int c : choices) if (c == sourceId) return true;
            return false;
        }
    }

    /**
     * Computes what the details page shows.
     *
     * @param movieboxAvailable  verified MovieBox title/type/year match
     * @param cinemaBoxAvailable verified CinemaBox title/type/year match
     * @param isAnime            anime policy: MovieBox-only, CinemaBox ignored
     */
    public static Decision compute(boolean movieboxAvailable,
                                   boolean cinemaBoxAvailable,
                                   boolean isAnime) {
        boolean mb = movieboxAvailable;
        boolean cb = cinemaBoxAvailable && !isAnime;

        if (mb && cb)
            return new Decision(new int[]{SOURCE_MOVIEBOX, SOURCE_CINEMABOX},
                    SOURCE_MOVIEBOX, true, false);
        if (mb)
            return new Decision(new int[]{SOURCE_MOVIEBOX},
                    SOURCE_MOVIEBOX, false, false);
        if (cb)
            return new Decision(new int[]{SOURCE_CINEMABOX},
                    SOURCE_CINEMABOX, false, false);
        return new Decision(new int[0], 0, false, true);
    }

    /**
     * Sanitises a stored/restored selection against the current decision:
     * keeps the user's pick when it is still exposed, otherwise falls back to
     * the decision's default (0 when there is no source at all).
     */
    public static int coerceSelection(Decision d, int wanted) {
        if (d == null) return 0;
        if (isValid(wanted) && d.exposes(wanted)) return wanted;
        return d.selected;
    }
}
