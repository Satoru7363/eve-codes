package com.eve.cinema.playback;

/** Distinct Arabic playback paths plus the automatic English fallback. */
public enum PlaybackMode {
    /** Downloaded/attached external caption; independently sized and timed. */
    ARABIC_SUBTITLE,
    /** A provider-labelled video release carrying Arabic text in the picture. */
    ARABIC_IN_VIDEO_SUBTITLE,
    ARABIC_DUB,
    /** Never offered in the chooser; applied automatically when Arabic is absent. */
    ENGLISH_FALLBACK,
    /** Nothing Arabic or English verified — original playback, subtitles off. */
    ORIGINAL;

    public static PlaybackMode fromName(String name) {
        if (name == null) return null;
        try { return valueOf(name); } catch (IllegalArgumentException e) { return null; }
    }
}
