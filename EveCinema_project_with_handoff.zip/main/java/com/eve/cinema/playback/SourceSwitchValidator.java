package com.eve.cinema.playback;

public final class SourceSwitchValidator {

    public enum Result { OK, NO_STREAMS, WRONG_EPISODE }

    private SourceSwitchValidator() {}

    public static Result validate(boolean series, int wantS, int wantE,
                                  Integer gotS, Integer gotE, boolean hasStreams) {
        if (!hasStreams) return Result.NO_STREAMS;
        if (!series || (gotS == null && gotE == null)) return Result.OK;
        if ((gotS != null && gotS != wantS) || (gotE != null && gotE != wantE))
            return Result.WRONG_EPISODE;
        return Result.OK;
    }
}
