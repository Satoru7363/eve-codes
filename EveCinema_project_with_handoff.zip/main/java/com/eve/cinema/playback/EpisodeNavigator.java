package com.eve.cinema.playback;

import java.util.Map;
import java.util.TreeMap;

public final class EpisodeNavigator {

    public enum Provider { MOVIEBOX, CINEMABOX }

    private EpisodeNavigator() {}

    public static int[] next(int season, int episode, Map<Integer, Integer> tmdbCounts) {
        if (season <= 0 || episode <= 0 || tmdbCounts == null) return null;
        Integer currentCount = tmdbCounts.get(season);
        if (currentCount == null || currentCount <= 0) return null;
        if (episode < currentCount) return new int[] {season, episode + 1};
        for (Map.Entry<Integer, Integer> entry : new TreeMap<>(tmdbCounts).entrySet()) {
            Integer nextSeason = entry.getKey();
            Integer count = entry.getValue();
            if (nextSeason > season && count != null && count > 0)
                return new int[] {nextSeason, 1};
        }
        return null;
    }
}
