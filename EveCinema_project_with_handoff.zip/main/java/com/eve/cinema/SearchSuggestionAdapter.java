package com.eve.cinema;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * SearchSuggestionAdapter
 * ─────────────────────────────────────────────────────────────────
 * Multi-view-type RecyclerView adapter for the live search screen.
 *
 * View types:
 *   TYPE_HEADER      — Section label ("Recent Searches", "Trending")
 *   TYPE_RECENT      — Recent search chip (text + delete)
 *   TYPE_SUGGESTION  — Live suggestion row (poster + meta) — LIST style
 *   TYPE_SKELETON    — Loading placeholder (grid, span=1)
 *   TYPE_EMPTY       — Empty/no-results state
 *   TYPE_GRID_POSTER — Full grid card matching main screen (span=1, 3-col grid)
 *
 * Performance rules:
 *   • DiffUtil for all updates — NO notifyDataSetChanged
 *   • setHasStableIds(true)
 *   • Glide with diskCache — no transforms during scroll
 *   • ViewHolder caches all views — zero findViewById in bind
 *   • Shared skeleton pulse from SearchActivity overlay
 * ─────────────────────────────────────────────────────────────────
 */
public class SearchSuggestionAdapter
        extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    // ── View types ──────────────────────────────────────────────────
    public static final int TYPE_HEADER      = 0;
    public static final int TYPE_RECENT      = 1;
    public static final int TYPE_SUGGESTION  = 2;  // list-style (kept for compatibility)
    public static final int TYPE_SKELETON    = 3;
    public static final int TYPE_EMPTY       = 4;
    public static final int TYPE_GRID_POSTER = 5;  // 3-column grid card (main screen style)

    // ── Image base URLs ─────────────────────────────────────────────
    private static final String IMG_BASE_W185 = "https://image.tmdb.org/t/p/w185";
    private static final String IMG_BASE_W342 = "https://image.tmdb.org/t/p/w342";

    // ── Glide options — shared, allocated once ──────────────────────
    private static final RequestOptions GLIDE_OPTS_LIST = new RequestOptions()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .centerCrop()
            .placeholder(R.drawable.bg_skeleton)
            .error(R.drawable.bg_skeleton);

    private static final RequestOptions GLIDE_OPTS_GRID = new RequestOptions()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .centerCrop();

    private static final DecelerateInterpolator DECEL = new DecelerateInterpolator(2f);

    // ── Shared skeleton pulse value (set by SearchActivity) ─────────
    private float skeletonAlpha = 0.08f;

    // ── Item model ──────────────────────────────────────────────────
    public static class SearchItem {
        public final int    type;
        public final String headerTitle;
        public final String recentQuery;
        public final int    tmdbId;
        public final String title;
        public final String posterPath;
        public final String mediaType;
        public final String year;
        public final double rating;
        public final long   stableId;
        /** Full raw JSON from TMDB search result — passed directly to DetailActivity */
        public final String rawJson;

        public static SearchItem header(String title) {
            return new SearchItem(TYPE_HEADER, title, null, -1, null, null, null, null, 0, title.hashCode(), null);
        }
        public static SearchItem recent(String query) {
            return new SearchItem(TYPE_RECENT, null, query, -1, null, null, null, null, 0, ("r:" + query).hashCode(), null);
        }
        public static SearchItem suggestion(int tmdbId, String title, String poster,
                                             String mediaType, String year) {
            return new SearchItem(TYPE_SUGGESTION, null, null, tmdbId, title, poster, mediaType, year, 0,
                    ("s:" + mediaType + tmdbId).hashCode(), null);
        }
        /** Grid poster — matches main screen card style, rawJson = full TMDB result */
        public static SearchItem gridPoster(int tmdbId, String title, String poster,
                                             String mediaType, String year, double rating, String rawJson) {
            return new SearchItem(TYPE_GRID_POSTER, null, null, tmdbId, title, poster, mediaType, year, rating,
                    ("g:" + mediaType + tmdbId).hashCode(), rawJson);
        }
        public static SearchItem skeleton(int index) {
            return new SearchItem(TYPE_SKELETON, null, null, -1, null, null, null, null, 0, ("sk:" + index).hashCode(), null);
        }
        public static SearchItem empty() {
            return new SearchItem(TYPE_EMPTY, null, null, -1, null, null, null, null, 0, Long.MIN_VALUE, null);
        }

        private SearchItem(int type, String headerTitle, String recentQuery,
                           int tmdbId, String title, String posterPath,
                           String mediaType, String year, double rating, long stableId, String rawJson) {
            this.type        = type;
            this.headerTitle = headerTitle;
            this.recentQuery = recentQuery;
            this.tmdbId      = tmdbId;
            this.title       = title;
            this.posterPath  = posterPath;
            this.mediaType   = mediaType;
            this.year        = year;
            this.rating      = rating;
            this.stableId    = stableId;
            this.rawJson     = rawJson;
        }

        boolean sameContent(SearchItem o) {
            if (o == null || type != o.type) return false;
            switch (type) {
                case TYPE_HEADER:      return Objects.equals(headerTitle, o.headerTitle);
                case TYPE_RECENT:      return Objects.equals(recentQuery, o.recentQuery);
                case TYPE_SUGGESTION:
                case TYPE_GRID_POSTER: return tmdbId == o.tmdbId
                        && Objects.equals(mediaType, o.mediaType);
                case TYPE_SKELETON:    return stableId == o.stableId;
                case TYPE_EMPTY:       return true;
                default:               return false;
            }
        }
    }

    // ── Callbacks ───────────────────────────────────────────────────
    public interface OnSuggestionClickListener {
        void onSuggestionClick(SearchItem item);
    }
    public interface OnRecentClickListener {
        void onRecentClick(String query);
        void onRecentDelete(String query);
    }

    // ── State ───────────────────────────────────────────────────────
    private List<SearchItem>          items    = new ArrayList<>();
    private final Context             context;
    private OnSuggestionClickListener suggestionListener;
    private OnRecentClickListener     recentListener;

    public SearchSuggestionAdapter(Context context) {
        this.context = context;
        setHasStableIds(true);
    }

    public void setSuggestionClickListener(OnSuggestionClickListener l) { suggestionListener = l; }
    public void setRecentClickListener(OnRecentClickListener l)          { recentListener    = l; }
    public void setSkeletonAlpha(float alpha)                            { skeletonAlpha     = alpha; }

    // ── DiffUtil update — NEVER notifyDataSetChanged ────────────────
    public void setItems(final List<SearchItem> newItems) {
        final List<SearchItem> oldItems = items;
        DiffUtil.DiffResult diff = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override public int getOldListSize() { return oldItems.size(); }
            @Override public int getNewListSize() { return newItems.size(); }
            @Override public boolean areItemsTheSame(int op, int np) {
                return oldItems.get(op).stableId == newItems.get(np).stableId;
            }
            @Override public boolean areContentsTheSame(int op, int np) {
                return oldItems.get(op).sameContent(newItems.get(np));
            }
        });
        items = newItems;
        diff.dispatchUpdatesTo(this);
    }

    @Override public long getItemId(int position)  { return items.get(position).stableId; }
    @Override public int  getItemCount()           { return items.size(); }
    @Override public int  getItemViewType(int pos) { return items.get(pos).type; }

    // ── ViewHolder creation ─────────────────────────────────────────
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater li = LayoutInflater.from(context);
        switch (viewType) {
            case TYPE_HEADER:
                return new HeaderVH(li.inflate(R.layout.item_search_header, parent, false));
            case TYPE_RECENT:
                return new RecentVH(li.inflate(R.layout.item_search_recent, parent, false));
            case TYPE_SUGGESTION:
                return new SuggestionVH(li.inflate(R.layout.item_suggestion, parent, false));
            case TYPE_SKELETON:
                return new SkeletonVH(li.inflate(R.layout.item_skeleton, parent, false));
            case TYPE_EMPTY:
                return new EmptyVH(li.inflate(R.layout.item_search_empty, parent, false));
            case TYPE_GRID_POSTER:
                return new GridPosterVH(li.inflate(R.layout.item_search_grid_poster, parent, false));
            default:
                throw new IllegalStateException("Unknown viewType: " + viewType);
        }
    }

    // ── Binding ─────────────────────────────────────────────────────
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        SearchItem item = items.get(position);
        switch (item.type) {
            case TYPE_HEADER:
                ((HeaderVH) holder).bind(item);
                break;
            case TYPE_RECENT:
                ((RecentVH) holder).bind(item);
                break;
            case TYPE_SUGGESTION:
                ((SuggestionVH) holder).bind(item);
                break;
            case TYPE_GRID_POSTER:
                ((GridPosterVH) holder).bind(item);
                break;
            case TYPE_SKELETON:
                ((SkeletonVH) holder).bind(skeletonAlpha);
                break;
            case TYPE_EMPTY:
                break;
        }
    }

    @Override
    public void onViewRecycled(@NonNull RecyclerView.ViewHolder holder) {
        if (holder instanceof SuggestionVH) {
            Glide.with(context).clear(((SuggestionVH) holder).poster);
        } else if (holder instanceof GridPosterVH) {
            GridPosterVH vh = (GridPosterVH) holder;
            Glide.with(context).clear(vh.posterImg);
            // Remove shimmer listener to prevent leak
            if (vh.shimmerListener != null && SearchActivity.sShimmerAnimator != null) {
                SearchActivity.sShimmerAnimator.removeUpdateListener(vh.shimmerListener);
                vh.shimmerListener = null;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // ViewHolders
    // ══════════════════════════════════════════════════════════════

    // — Header ——————————————————————————————————————————————————
    static class HeaderVH extends RecyclerView.ViewHolder {
        final TextView label;
        HeaderVH(View v) { super(v); label = v.findViewById(R.id.header_label); }
        void bind(SearchItem item) { label.setText(item.headerTitle); }
    }

    // — Recent ——————————————————————————————————————————————————
    class RecentVH extends RecyclerView.ViewHolder {
        final TextView queryText;
        final View     deleteBtn;
        RecentVH(View v) {
            super(v);
            queryText = v.findViewById(R.id.recent_query);
            deleteBtn = v.findViewById(R.id.recent_delete);
        }
        void bind(SearchItem item) {
            queryText.setText(item.recentQuery);
            itemView.setOnClickListener(v -> {
                if (recentListener != null) recentListener.onRecentClick(item.recentQuery);
            });
            deleteBtn.setOnClickListener(v -> {
                if (recentListener != null) recentListener.onRecentDelete(item.recentQuery);
            });
        }
    }

    // — Suggestion (list style) ——————————————————————————————————
    class SuggestionVH extends RecyclerView.ViewHolder {
        final ImageView poster;
        final ImageView placeholder;
        final TextView  title;
        final TextView  type;
        final TextView  year;
        SuggestionVH(View v) {
            super(v);
            poster      = v.findViewById(R.id.suggestion_poster);
            placeholder = v.findViewById(R.id.suggestion_poster_placeholder);
            title       = v.findViewById(R.id.suggestion_title);
            type        = v.findViewById(R.id.suggestion_type);
            year        = v.findViewById(R.id.suggestion_year);
        }
        void bind(SearchItem item) {
            title.setText(item.title);
            type.setText("movie".equals(item.mediaType) ? "Movie" :
                         "tv".equals(item.mediaType)    ? "Series" :
                         item.mediaType != null          ? item.mediaType : "");
            year.setText(item.year != null ? item.year : "");
            if (item.posterPath != null && !item.posterPath.isEmpty()) {
                placeholder.setVisibility(View.GONE);
                Glide.with(context).load(IMG_BASE_W185 + item.posterPath)
                        .apply(GLIDE_OPTS_LIST).into(poster);
            } else {
                Glide.with(context).clear(poster);
                poster.setImageDrawable(null);
                placeholder.setVisibility(View.VISIBLE);
            }
            itemView.setOnClickListener(v -> {
                if (suggestionListener != null) suggestionListener.onSuggestionClick(item);
            });
        }
    }

    // — Grid Poster (main screen style, 3-col grid) ─────────────
    class GridPosterVH extends RecyclerView.ViewHolder {
        final ImageView posterImg;
        final View      skeleton;
        final View      pressOverlay;
        final TextView  ratingBadge;
        final TextView  titleText;
        ValueAnimator.AnimatorUpdateListener shimmerListener;

        GridPosterVH(View v) {
            super(v);
            posterImg    = v.findViewById(R.id.grid_poster_img);
            skeleton     = v.findViewById(R.id.grid_poster_skeleton);
            pressOverlay = v.findViewById(R.id.grid_poster_press_overlay);
            ratingBadge  = v.findViewById(R.id.grid_poster_rating);
            titleText    = v.findViewById(R.id.grid_poster_title);

            // clipToOutline must be set programmatically — XML attr unreliable on many devices
            // The background drawable (bg_card_poster) has 14dp corners which define the outline
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                posterImg.setClipToOutline(true);
                skeleton.setClipToOutline(true);
                pressOverlay.setClipToOutline(true);
            }
        }

        void bind(SearchItem item) {
            titleText.setText(item.title != null ? item.title : "");

            // Rating badge
            if (item.rating > 0) {
                ratingBadge.setVisibility(View.VISIBLE);
                ratingBadge.setText("\u2605 " + String.format(java.util.Locale.US, "%.1f", item.rating));
                ratingBadge.setAlpha(0f); // fades in after image loads
                GradientDrawable rbBg = new GradientDrawable();
                rbBg.setColor(item.rating >= 7.5 ? 0xCC9B6FC4 : 0xBB252540);
                rbBg.setCornerRadius(dpToPx(6));
                ratingBadge.setBackground(rbBg);
            } else {
                ratingBadge.setVisibility(View.GONE);
            }

            // Skeleton shimmer — attach to shared animator
            skeleton.setAlpha(0.08f);
            if (shimmerListener != null && SearchActivity.sShimmerAnimator != null) {
                SearchActivity.sShimmerAnimator.removeUpdateListener(shimmerListener);
            }
            shimmerListener = anim -> skeleton.setAlpha((float) anim.getAnimatedValue());
            if (SearchActivity.sShimmerAnimator != null) {
                SearchActivity.sShimmerAnimator.addUpdateListener(shimmerListener);
            }

            // Load poster
            if (item.posterPath != null && !item.posterPath.isEmpty()) {
                final ValueAnimator.AnimatorUpdateListener capturedListener = shimmerListener;
                Glide.with(context)
                        .load(IMG_BASE_W342 + item.posterPath)
                        .apply(GLIDE_OPTS_GRID)
                        .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                            @Override
                            public boolean onResourceReady(android.graphics.drawable.Drawable r, Object m,
                                    com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> t,
                                    com.bumptech.glide.load.DataSource d, boolean f) {
                                if (SearchActivity.sShimmerAnimator != null)
                                    SearchActivity.sShimmerAnimator.removeUpdateListener(capturedListener);
                                skeleton.animate().alpha(0f).setDuration(180).start();
                                if (ratingBadge.getVisibility() == View.VISIBLE)
                                    ratingBadge.animate().alpha(1f).setDuration(180).setStartDelay(30).start();
                                return false;
                            }
                            @Override
                            public boolean onLoadFailed(com.bumptech.glide.load.engine.GlideException e, Object m,
                                    com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> t, boolean f) {
                                if (SearchActivity.sShimmerAnimator != null)
                                    SearchActivity.sShimmerAnimator.removeUpdateListener(capturedListener);
                                skeleton.setAlpha(0.08f);
                                return false;
                            }
                        })
                        .into(posterImg);
            } else {
                if (SearchActivity.sShimmerAnimator != null)
                    SearchActivity.sShimmerAnimator.removeUpdateListener(shimmerListener);
                skeleton.setAlpha(0f);
            }

            // Press effect — glass overlay on touch
            itemView.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        pressOverlay.animate().alpha(1f).setDuration(80)
                                .setInterpolator(DECEL).start();
                        itemView.animate().scaleX(0.96f).scaleY(0.96f)
                                .setDuration(100).setInterpolator(DECEL).start();
                        break;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        pressOverlay.animate().alpha(0f).setDuration(200)
                                .setInterpolator(DECEL).start();
                        itemView.animate().scaleX(1f).scaleY(1f)
                                .setDuration(200).setInterpolator(DECEL).start();
                        break;
                }
                return false; // allow click to propagate
            });

            itemView.setOnClickListener(v -> {
                if (suggestionListener != null) suggestionListener.onSuggestionClick(item);
            });
        }

        private int dpToPx(int dp) {
            return (int)(dp * context.getResources().getDisplayMetrics().density);
        }
    }

    // — Skeleton ————————————————————————————————————————————————
    static class SkeletonVH extends RecyclerView.ViewHolder {
        SkeletonVH(View v) { super(v); }
        void bind(float alpha) { itemView.setAlpha(alpha); }
    }

    // — Empty ———————————————————————————————————————————————————
    static class EmptyVH extends RecyclerView.ViewHolder {
        EmptyVH(View v) { super(v); }
    }
}
